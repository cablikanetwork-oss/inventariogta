import re
import time
from typing import Dict, Tuple
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import timedelta
from app.core.database import get_db
from app.core.security import verify_pin, hash_pin, create_access_token
from app.core.config import settings
from app.models.user import User
from app.schemas.user import LoginRequest, RecoverPinRequest, TokenResponse, UserResponse

router = APIRouter()

# Control en memoria contra intentos de fuerza bruta: username -> (intentos_fallidos, bloqueado_hasta_timestamp)
_failed_attempts: Dict[str, Tuple[int, float]] = {}
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 60

# Cédula del Gerente de Tecnología y Llaves Maestras de Emergencia por defecto
MANAGER_ID_CARD_CLEAN = "14287629"
MASTER_RECOVERY_KEYS = {"TUANDAMIO", "TUANDAMIO2026", "GERENCIA14287629"}


def _normalize_id_card(raw: str) -> str:
    return re.sub(r"[^0-9]", "", (raw or ""))


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest, db: AsyncSession = Depends(get_db)):
    uname = request.username.lower().strip()
    now = time.time()

    # Verificar si la cuenta está temporalmente bloqueada por intentos fallidos
    if uname in _failed_attempts:
        fails, locked_until = _failed_attempts[uname]
        if locked_until > now:
            remaining = int(round(locked_until - now))
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Teclado bloqueado por seguridad tras {MAX_FAILED_ATTEMPTS} intentos fallidos. Espera {remaining} segundos o usa '¿Olvidaste tu PIN?'."
            )
        elif locked_until > 0 and now >= locked_until:
            _failed_attempts.pop(uname, None)

    result = await db.execute(
        select(User).where(User.username == uname, User.is_active == True)
    )
    user = result.scalar_one_or_none()

    if not user or not verify_pin(request.pin, user.pin_hash):
        fails, _ = _failed_attempts.get(uname, (0, 0.0))
        new_fails = fails + 1
        if new_fails >= MAX_FAILED_ATTEMPTS:
            _failed_attempts[uname] = (new_fails, now + LOCKOUT_SECONDS)
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Demasiados intentos fallidos ({MAX_FAILED_ATTEMPTS}). El acceso para @{uname} se ha bloqueado por {LOCKOUT_SECONDS} segundos."
            )
        else:
            _failed_attempts[uname] = (new_fails, 0.0)
            remaining_tries = MAX_FAILED_ATTEMPTS - new_fails
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Usuario o PIN incorrecto ({remaining_tries} {'intento restante' if remaining_tries == 1 else 'intentos restantes'})"
            )

    # Login exitoso: limpiar contador de fallos
    _failed_attempts.pop(uname, None)

    access_token = create_access_token(
        data={"sub": str(user.id), "role": user.role.value},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )

    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(user)
    )


@router.post("/recover-pin", response_model=TokenResponse)
async def recover_pin(request: RecoverPinRequest, db: AsyncSession = Depends(get_db)):
    """Permite restablecer el PIN validando Cédula del Titular (o Gerente TI) + Llave de Seguridad."""
    uname = request.username.lower().strip()
    result = await db.execute(
        select(User).where(User.username == uname, User.is_active == True)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No se encontró un usuario activo con ese identificador"
        )

    input_ci_clean = _normalize_id_card(request.id_card)
    user_ci_clean = _normalize_id_card(user.id_card or "")

    # 1. Validar Cédula de Identidad (la del propio usuario si la tiene registrada, o la del Gerente de TI)
    ci_valid = False
    if user_ci_clean and input_ci_clean == user_ci_clean:
        ci_valid = True
    elif input_ci_clean == MANAGER_ID_CARD_CLEAN:
        ci_valid = True

    if not ci_valid or not input_ci_clean:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="La Cédula de Identidad ingresada no coincide con el titular ni con la Gerencia de Tecnología"
        )

    # 2. Validar Llave de Recuperación (personal del usuario o Llave Maestra corporativa)
    input_key_clean = request.recovery_key.strip().upper()
    key_valid = False
    if user.recovery_key_hash and verify_pin(input_key_clean, user.recovery_key_hash):
        key_valid = True
    elif input_key_clean in MASTER_RECOVERY_KEYS:
        key_valid = True

    if not key_valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Llave de Seguridad / Recuperación inválida"
        )

    # 3. Actualizar el PIN y desbloquear cuenta
    user.pin_hash = hash_pin(request.new_pin)
    if not user.id_card and input_ci_clean:
        user.id_card = request.id_card.strip()

    await db.commit()
    await db.refresh(user)

    _failed_attempts.pop(uname, None)

    access_token = create_access_token(
        data={"sub": str(user.id), "role": user.role.value},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )

    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(user)
    )


