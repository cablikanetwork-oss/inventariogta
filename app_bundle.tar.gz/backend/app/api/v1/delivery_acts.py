import os
import re
import json
import base64
import hashlib
from typing import List, Optional
from uuid import UUID
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc, or_
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.api.deps import get_current_user, require_admin
from app.models.user import User
from app.models.company import CompanyConfig
from app.models.delivery_act import DeliveryAct, DeliveryActItem, DEFAULT_TERMS_CLAUSE
from app.models.equipment import Equipment, EquipmentStatus
from app.models.movement import Movement, MovementType
from app.schemas.delivery_act import DeliveryActCreate, DeliveryActUpdate, DeliveryActResponse

UPLOAD_DIR = "/app/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


class Base64UploadRequest(BaseModel):
    data_url: str
    filename: Optional[str] = None


router = APIRouter()


@router.get("/", response_model=List[DeliveryActResponse])
async def list_delivery_acts(
    search: Optional[str] = Query(None, description="Buscar por número de acta, nombre o cédula"),
    act_type: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = (
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .order_by(desc(DeliveryAct.created_at))
    )

    if act_type:
        query = query.where(DeliveryAct.act_type == act_type)

    if search:
        search_filter = f"%{search}%"
        query = query.where(
            or_(
                DeliveryAct.act_number.ilike(search_filter),
                DeliveryAct.recipient_name.ilike(search_filter),
                DeliveryAct.recipient_id_card.ilike(search_filter),
                DeliveryAct.delivered_by_name.ilike(search_filter),
            )
        )

    result = await db.execute(query)
    return result.scalars().all()


@router.get("/employees/solvency")
async def get_employees_solvency(
    search: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Calcula el estado de solvencia tecnológica (Paz y Salvo de TI para RRHH) por trabajador."""
    acts_res = await db.execute(
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .order_by(desc(DeliveryAct.created_at))
    )
    all_acts = acts_res.scalars().all()

    eq_res = await db.execute(
        select(Equipment).where(Equipment.is_active == True)
    )
    all_eq = eq_res.scalars().all()
    eq_by_id = {eq.id: eq for eq in all_eq}
    eq_by_serial = {eq.serial_number.upper(): eq for eq in all_eq}

    employees_map = {}

    for act in all_acts:
        ci_clean = re.sub(r"[^0-9A-Za-z]", "", (act.recipient_id_card or "")).upper()
        emp_key = ci_clean or act.recipient_name.strip().upper()

        if emp_key not in employees_map:
            employees_map[emp_key] = {
                "recipient_name": act.recipient_name,
                "recipient_id_card": act.recipient_id_card,
                "recipient_position": act.recipient_position,
                "recipient_department": act.recipient_department,
                "active_equipment_map": {},
                "returned_equipment_list": [],
                "acts": [],
            }

        emp = employees_map[emp_key]
        # Mantener cargo/departamento más reciente si estaban vacíos
        if not emp["recipient_position"] and act.recipient_position:
            emp["recipient_position"] = act.recipient_position
        if not emp["recipient_department"] and act.recipient_department:
            emp["recipient_department"] = act.recipient_department

        emp["acts"].append({
            "id": str(act.id),
            "act_number": act.act_number,
            "act_type": act.act_type,
            "created_at": act.created_at.isoformat() if act.created_at else None,
            "scanned_document_url": act.scanned_document_url,
            "items_count": len(act.items),
        })

        for item in act.items:
            live_eq = (
                eq_by_id.get(item.equipment_id)
                if item.equipment_id
                else eq_by_serial.get((item.serial_number or "").upper())
            )
            serial_key = (item.serial_number or str(item.id)).upper()

            # Verificar si el equipo sigue actualmente asignado a este trabajador
            is_currently_held = False
            if live_eq:
                if (
                    live_eq.status == EquipmentStatus.assigned
                    and live_eq.assigned_to
                    and live_eq.assigned_to.strip().lower() == act.recipient_name.strip().lower()
                ):
                    is_currently_held = True

            eq_summary = {
                "equipment_id": str(live_eq.id) if live_eq else (str(item.equipment_id) if item.equipment_id else None),
                "equipment_name": item.equipment_name,
                "brand": item.brand,
                "model": item.model,
                "serial_number": item.serial_number,
                "specs": item.specs,
                "act_number": act.act_number,
                "act_date": act.created_at.isoformat() if act.created_at else None,
            }

            if is_currently_held:
                if serial_key not in emp["active_equipment_map"]:
                    emp["active_equipment_map"][serial_key] = eq_summary
            else:
                if act.act_type == "return" or not is_currently_held:
                    emp["returned_equipment_list"].append(eq_summary)

    results = []
    for emp in employees_map.values():
        if search:
            q = search.strip().lower()
            if (
                q not in (emp["recipient_name"] or "").lower()
                and q not in (emp["recipient_id_card"] or "").lower()
                and q not in (emp["recipient_position"] or "").lower()
            ):
                continue

        active_list = list(emp["active_equipment_map"].values())
        returned_list = emp["returned_equipment_list"]
        results.append({
            "recipient_name": emp["recipient_name"],
            "recipient_id_card": emp["recipient_id_card"],
            "recipient_position": emp["recipient_position"],
            "recipient_department": emp["recipient_department"],
            "active_equipment": active_list,
            "active_count": len(active_list),
            "returned_equipment": returned_list[:15],
            "returned_count": len(returned_list),
            "acts": emp["acts"],
            "is_solvent": len(active_list) == 0,
        })

    return results


@router.get("/public-verify/{identifier}")
async def public_verify_act_or_solvency(
    identifier: str,
    db: AsyncSession = Depends(get_db),
):
    """
    Endpoint público (sin login requerido) para que Personal de Seguridad (Garita),
    RRHH o Auditoría verifiquen la autenticidad de un Acta de Entrega, Acta de Devolución
    o Certificado de Solvencia escaneando el código QR impreso en la hoja.
    """
    cleaned = identifier.strip()

    cfg_res = await db.execute(select(CompanyConfig).limit(1))
    company_cfg = cfg_res.scalar_one_or_none()
    company_payload = {
        "name": company_cfg.name if (company_cfg and company_cfg.name) else "GRUPO TUANDAMIO",
        "logo_url": company_cfg.logo_url if company_cfg else None,
        "primary_color": company_cfg.primary_color if company_cfg else "#2563EB",
    }

    # Caso 1: Certificado de Solvencia por Cédula (SOLV-<cedula>)
    if cleaned.upper().startswith("SOLV-"):
        target_ci = cleaned[5:].strip()
        target_ci_clean = re.sub(r"[^0-9A-Za-z]", "", target_ci).upper()

        acts_res = await db.execute(
            select(DeliveryAct)
            .options(selectinload(DeliveryAct.items))
            .order_by(desc(DeliveryAct.created_at))
        )
        all_acts = acts_res.scalars().all()

        matching_acts = [
            a for a in all_acts
            if re.sub(r"[^0-9A-Za-z]", "", (a.recipient_id_card or "")).upper() == target_ci_clean
            or (a.recipient_id_card or "").strip().lower() == target_ci.lower()
        ]

        if not matching_acts:
            raise HTTPException(
                status_code=404,
                detail=f"No existe ningún registro de solvencia o actas para el documento '{target_ci}'"
            )

        eq_res = await db.execute(select(Equipment).where(Equipment.is_active == True))
        all_eq = eq_res.scalars().all()
        eq_by_id = {eq.id: eq for eq in all_eq}
        eq_by_serial = {eq.serial_number.upper(): eq for eq in all_eq}

        latest_act = matching_acts[0]
        active_items = {}
        returned_items = []

        for act in matching_acts:
            for item in act.items:
                live_eq = (
                    eq_by_id.get(item.equipment_id)
                    if item.equipment_id
                    else eq_by_serial.get((item.serial_number or "").upper())
                )
                s_key = (item.serial_number or str(item.id)).upper()
                is_held = bool(
                    live_eq
                    and live_eq.status == EquipmentStatus.assigned
                    and live_eq.assigned_to
                    and live_eq.assigned_to.strip().lower() == act.recipient_name.strip().lower()
                )
                item_dict = {
                    "equipment_id": str(live_eq.id) if live_eq else (str(item.equipment_id) if item.equipment_id else None),
                    "equipment_name": item.equipment_name,
                    "brand": item.brand,
                    "model": item.model,
                    "serial_number": item.serial_number,
                    "specs": item.specs,
                    "act_number": act.act_number,
                    "live_status": live_eq.status.value if live_eq else "available",
                    "currently_assigned_to_recipient": is_held,
                }
                if is_held:
                    if s_key not in active_items:
                        active_items[s_key] = item_dict
                else:
                    returned_items.append(item_dict)

        is_solvent = len(active_items) == 0
        verif_hash = hashlib.sha256(
            f"SOLV:{latest_act.recipient_id_card}:{len(matching_acts)}".encode()
        ).hexdigest()[:16].upper()

        return {
            "document_kind": "solvency_certificate",
            "is_authentic": True,
            "verification_hash": verif_hash,
            "verified_at": datetime.now(timezone.utc).isoformat(),
            "validity_status": "VALID_RETURN_SOLVENCY" if is_solvent else "ACTIVE_CUSTODY_PENDING",
            "security_verdict": (
                "SOLVENCIA TECNOLÓGICA AUTÉNTICA — PAZ Y SALVO VERIFICADO (0 EQUIPOS PENDIENTES)"
                if is_solvent
                else f"ATENCIÓN: EL TRABAJADOR AÚN POSEE {len(active_items)} EQUIPO(S) BAJO CUSTODIA ACTIVA"
            ),
            "allow_exit": False,
            "act": {
                "id": str(latest_act.id),
                "act_number": f"SOLV-{latest_act.recipient_id_card}",
                "act_type": "solvency",
                "city": latest_act.city or "Caracas",
                "recipient_name": latest_act.recipient_name,
                "recipient_id_card": latest_act.recipient_id_card,
                "recipient_position": latest_act.recipient_position,
                "recipient_department": latest_act.recipient_department,
                "recipient_signature": latest_act.recipient_signature,
                "delivered_by_name": latest_act.delivered_by_name or "Raimundo Gil",
                "delivered_by_position": latest_act.delivered_by_position or "Gerente de Tecnología",
                "delivered_by_id_card": latest_act.delivered_by_id_card or "14.287.629",
                "accessories": latest_act.accessories,
                "scanned_document_url": latest_act.scanned_document_url,
                "scanned_at": latest_act.scanned_at.isoformat() if latest_act.scanned_at else None,
                "evidence_photos_list": latest_act.evidence_photos_list,
                "created_at": latest_act.created_at.isoformat() if latest_act.created_at else None,
                "items": list(active_items.values()) + returned_items[:10],
            },
            "company": company_payload,
        }

    # Caso 2: Acta de Asignación o Acta de Devolución (por UUID o act_number ACT-2026-XXXX)
    parsed_uuid = None
    try:
        parsed_uuid = UUID(cleaned)
    except Exception:
        parsed_uuid = None

    conds = [DeliveryAct.act_number.ilike(cleaned)]
    if parsed_uuid:
        conds.append(DeliveryAct.id == parsed_uuid)

    res = await db.execute(
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .where(or_(*conds))
    )
    act = res.scalar_one_or_none()

    if not act:
        raise HTTPException(
            status_code=404,
            detail=f"ALERTA DE SEGURIDAD: No existe ningún acta oficial registrada con el código '{cleaned}'. Verifique posible documento no autorizado."
        )

    # Verificar estado actual en vivo de cada equipo incluido en el acta
    items_verified = []
    any_still_assigned_to_recipient = False

    for item in act.items:
        live_eq = None
        if item.equipment_id:
            eq_r = await db.execute(select(Equipment).where(Equipment.id == item.equipment_id))
            live_eq = eq_r.scalar_one_or_none()
        if not live_eq and item.serial_number:
            eq_r = await db.execute(
                select(Equipment).where(Equipment.serial_number.ilike(item.serial_number))
            )
            live_eq = eq_r.scalar_one_or_none()

        currently_held = False
        live_status_str = "unknown"
        live_assigned_to = None

        if live_eq:
            live_status_str = live_eq.status.value if hasattr(live_eq.status, "value") else str(live_eq.status)
            live_assigned_to = live_eq.assigned_to
            if (
                live_eq.status == EquipmentStatus.assigned
                and live_eq.assigned_to
                and live_eq.assigned_to.strip().lower() == act.recipient_name.strip().lower()
            ):
                currently_held = True
                any_still_assigned_to_recipient = True

        items_verified.append({
            "id": str(item.id),
            "equipment_id": str(live_eq.id) if live_eq else (str(item.equipment_id) if item.equipment_id else None),
            "equipment_name": item.equipment_name,
            "equipment_type": item.equipment_type,
            "brand": item.brand,
            "model": item.model,
            "serial_number": item.serial_number,
            "specs": item.specs,
            "live_status": live_status_str,
            "live_assigned_to": live_assigned_to,
            "currently_assigned_to_recipient": currently_held,
        })

    verif_hash = hashlib.sha256(
        f"{act.id}:{act.act_number}:{act.recipient_id_card}:{act.created_at}".encode()
    ).hexdigest()[:16].upper()

    if act.act_type == "return":
        validity_status = "VALID_RETURN_SOLVENCY"
        security_verdict = (
            "ACTA DE DEVOLUCIÓN / SOLVENCIA TI AUTÉNTICA — EL EQUIPO FUE REINTEGRADO CONFORME A TI"
        )
        allow_exit = False
    else:
        if any_still_assigned_to_recipient:
            validity_status = "VALID_ACTIVE_ASSIGNMENT"
            security_verdict = (
                "ACTA DE ASIGNACIÓN AUTÉNTICA Y VIGENTE — EL TRABAJADOR ESTÁ AUTORIZADO A PORTAR EL EQUIPO"
            )
            allow_exit = True
        else:
            validity_status = "EXPIRED_OR_RETURNED_ASSIGNMENT"
            security_verdict = (
                "ALERTA DE SEGURIDAD: ACTA HISTÓRICA VENCIDA — EL EQUIPO YA FUE DEVUELTO O REASIGNADO A OTRO CUSTODIO"
            )
            allow_exit = False

    return {
        "document_kind": "delivery_act",
        "is_authentic": True,
        "verification_hash": verif_hash,
        "verified_at": datetime.now(timezone.utc).isoformat(),
        "validity_status": validity_status,
        "security_verdict": security_verdict,
        "allow_exit": allow_exit,
        "act": {
            "id": str(act.id),
            "act_number": act.act_number,
            "act_type": act.act_type,
            "city": act.city,
            "recipient_name": act.recipient_name,
            "recipient_id_card": act.recipient_id_card,
            "recipient_position": act.recipient_position,
            "recipient_department": act.recipient_department,
            "recipient_signature": act.recipient_signature,
            "delivered_by_name": act.delivered_by_name or "Raimundo Gil",
            "delivered_by_position": act.delivered_by_position or "Gerente de Tecnología",
            "delivered_by_id_card": act.delivered_by_id_card or "14.287.629",
            "accessories": act.accessories,
            "scanned_document_url": act.scanned_document_url,
            "scanned_at": act.scanned_at.isoformat() if act.scanned_at else None,
            "evidence_photos_list": act.evidence_photos_list,
            "created_at": act.created_at.isoformat() if act.created_at else None,
            "items": items_verified,
        },
        "company": company_payload,
    }


@router.get("/{act_id}", response_model=DeliveryActResponse)
async def get_delivery_act(
    act_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = (
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .where(DeliveryAct.id == act_id)
    )
    result = await db.execute(query)
    act = result.scalar_one_or_none()
    if not act:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Acta de entrega no encontrada"
        )
    return act


@router.post("/", response_model=DeliveryActResponse, status_code=status.HTTP_201_CREATED)
async def create_delivery_act(
    act_in: DeliveryActCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # 1. Generar número correlativo anual (ej: ACT-2026-0001)
    current_year = datetime.now(timezone.utc).year
    prefix = f"ACT-{current_year}-"

    count_query = select(func.count(DeliveryAct.id)).where(DeliveryAct.act_number.like(f"{prefix}%"))
    count_res = await db.execute(count_query)
    total_year_acts = count_res.scalar() or 0
    next_number = total_year_acts + 1
    act_number = f"{prefix}{next_number:04d}"

    # 2. Datos del entregador persistentes (Raimundo Gil, Gerente de Tecnología, C.I. 14.287.629)
    delivered_name = act_in.delivered_by_name or "Raimundo Gil"
    delivered_pos = act_in.delivered_by_position or "Gerente de Tecnología"
    delivered_ci = act_in.delivered_by_id_card or "14.287.629"

    evidence_json = json.dumps(act_in.evidence_photos) if act_in.evidence_photos else None

    # 3. Crear el acta principal
    new_act = DeliveryAct(
        act_number=act_number,
        act_type=act_in.act_type or "assignment",
        city=act_in.city or "Caracas",
        recipient_name=act_in.recipient_name,
        recipient_id_card=act_in.recipient_id_card,
        recipient_position=act_in.recipient_position,
        recipient_department=act_in.recipient_department,
        recipient_signature=act_in.recipient_signature,
        delivered_by_user_id=current_user.id,
        delivered_by_name=delivered_name,
        delivered_by_position=delivered_pos,
        delivered_by_id_card=delivered_ci,
        terms_clause=act_in.terms_clause or DEFAULT_TERMS_CLAUSE,
        notes=act_in.notes,
        accessories=act_in.accessories,
        evidence_photos=evidence_json,
    )
    db.add(new_act)
    await db.flush()

    # 4. Agregar items y actualizar estatus según si es Asignación o Devolución
    is_return = (act_in.act_type or "assignment") == "return"

    for item_in in act_in.items:
        act_item = DeliveryActItem(
            act_id=new_act.id,
            equipment_id=item_in.equipment_id,
            equipment_name=item_in.equipment_name,
            equipment_type=item_in.equipment_type or "Equipo Tecnológico",
            brand=item_in.brand,
            model=item_in.model,
            serial_number=item_in.serial_number,
            specs=item_in.specs,
        )
        db.add(act_item)

        if act_in.auto_assign_equipment and item_in.equipment_id:
            eq_query = select(Equipment).where(Equipment.id == item_in.equipment_id)
            eq_res = await db.execute(eq_query)
            equipment = eq_res.scalar_one_or_none()
            if equipment:
                if is_return:
                    equipment.status = EquipmentStatus.available
                    equipment.assigned_to = None
                    movement = Movement(
                        type=MovementType.return_item,
                        equipment_id=equipment.id,
                        from_warehouse_id=equipment.current_warehouse_id,
                        to_warehouse_id=equipment.current_warehouse_id,
                        assigned_to=None,
                        notes=f"Devolución de equipo según Acta N° {act_number} ({act_in.recipient_name})",
                        performed_by=current_user.id
                    )
                else:
                    equipment.status = EquipmentStatus.assigned
                    equipment.assigned_to = act_in.recipient_name
                    movement = Movement(
                        type=MovementType.exit,
                        equipment_id=equipment.id,
                        from_warehouse_id=equipment.current_warehouse_id,
                        assigned_to=act_in.recipient_name,
                        notes=f"Generación de Acta de Asignación N° {act_number}",
                        performed_by=current_user.id
                    )
                db.add(movement)

    await db.commit()
    await db.refresh(new_act)

    full_act_query = (
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .where(DeliveryAct.id == new_act.id)
    )
    res = await db.execute(full_act_query)
    return res.scalar_one()


@router.put("/{act_id}", response_model=DeliveryActResponse)
async def update_delivery_act(
    act_id: UUID,
    act_in: DeliveryActUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Edita un acta existente (datos del trabajador, tipo de acta, equipos, especificaciones o accesorios)
    y sincroniza automáticamente la custodia en el inventario de equipos."""
    query = (
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .where(DeliveryAct.id == act_id)
    )
    res = await db.execute(query)
    act = res.scalar_one_or_none()
    if not act:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Acta de entrega no encontrada",
        )

    old_recipient_name = act.recipient_name
    old_act_type = act.act_type
    old_eq_ids = {item.equipment_id for item in act.items if item.equipment_id}

    # Actualizar campos principales del acta
    if act_in.act_type is not None:
        act.act_type = act_in.act_type
    if act_in.city is not None:
        act.city = act_in.city
    if act_in.recipient_name is not None:
        act.recipient_name = act_in.recipient_name.strip()
    if act_in.recipient_id_card is not None:
        act.recipient_id_card = act_in.recipient_id_card.strip()
    if act_in.recipient_position is not None:
        act.recipient_position = act_in.recipient_position.strip() or None
    if act_in.recipient_department is not None:
        act.recipient_department = act_in.recipient_department.strip() or None
    if act_in.recipient_signature is not None:
        act.recipient_signature = act_in.recipient_signature or None
    if act_in.delivered_by_name is not None:
        act.delivered_by_name = act_in.delivered_by_name.strip() or "Raimundo Gil"
    if act_in.delivered_by_position is not None:
        act.delivered_by_position = act_in.delivered_by_position.strip() or "Gerente de Tecnología"
    if act_in.delivered_by_id_card is not None:
        act.delivered_by_id_card = act_in.delivered_by_id_card.strip() or "14.287.629"
    if act_in.terms_clause is not None:
        act.terms_clause = act_in.terms_clause or DEFAULT_TERMS_CLAUSE
    if act_in.notes is not None:
        act.notes = act_in.notes.strip() or None
    if act_in.accessories is not None:
        act.accessories = act_in.accessories.strip() or None

    is_return = (act.act_type or "assignment") == "return"

    if act_in.items is not None:
        new_eq_ids = {item.equipment_id for item in act_in.items if item.equipment_id}
        removed_eq_ids = old_eq_ids - new_eq_ids

        # 1. Si se quitaron equipos de un acta de asignación, liberarlos en el inventario
        if act_in.auto_assign_equipment and old_act_type == "assignment":
            for rem_id in removed_eq_ids:
                eq_r = await db.execute(select(Equipment).where(Equipment.id == rem_id))
                rem_eq = eq_r.scalar_one_or_none()
                if rem_eq and rem_eq.status == EquipmentStatus.assigned:
                    if not rem_eq.assigned_to or rem_eq.assigned_to.strip().lower() == (old_recipient_name or "").strip().lower():
                        rem_eq.status = EquipmentStatus.available
                        rem_eq.assigned_to = None
                        db.add(
                            Movement(
                                type=MovementType.return_item,
                                equipment_id=rem_eq.id,
                                from_warehouse_id=rem_eq.current_warehouse_id,
                                to_warehouse_id=rem_eq.current_warehouse_id,
                                assigned_to=None,
                                notes=f"Equipo retirado al editar Acta N° {act.act_number}",
                                performed_by=current_user.id,
                            )
                        )

        # 2. Reemplazar los renglones de equipos del acta
        act.items.clear()
        await db.flush()

        for item_in in act_in.items:
            act_item = DeliveryActItem(
                act_id=act.id,
                equipment_id=item_in.equipment_id,
                equipment_name=item_in.equipment_name,
                equipment_type=item_in.equipment_type or "Equipo Tecnológico",
                brand=item_in.brand,
                model=item_in.model,
                serial_number=item_in.serial_number,
                specs=item_in.specs,
            )
            act.items.append(act_item)
            db.add(act_item)

            if act_in.auto_assign_equipment and item_in.equipment_id:
                eq_r = await db.execute(select(Equipment).where(Equipment.id == item_in.equipment_id))
                equipment = eq_r.scalar_one_or_none()
                if equipment:
                    if is_return:
                        equipment.status = EquipmentStatus.available
                        equipment.assigned_to = None
                    else:
                        equipment.status = EquipmentStatus.assigned
                        equipment.assigned_to = act.recipient_name
    else:
        # Si no se envió lista nueva de items pero cambió el nombre del receptor o el tipo de acta, sincronizar equipos actuales
        if act_in.auto_assign_equipment:
            for item in act.items:
                if item.equipment_id:
                    eq_r = await db.execute(select(Equipment).where(Equipment.id == item.equipment_id))
                    equipment = eq_r.scalar_one_or_none()
                    if equipment:
                        if is_return:
                            equipment.status = EquipmentStatus.available
                            equipment.assigned_to = None
                        else:
                            if (
                                equipment.status == EquipmentStatus.assigned
                                and equipment.assigned_to
                                and equipment.assigned_to.strip().lower() == (old_recipient_name or "").strip().lower()
                            ) or equipment.status == EquipmentStatus.available:
                                equipment.status = EquipmentStatus.assigned
                                equipment.assigned_to = act.recipient_name

    act.updated_at = datetime.now(timezone.utc)
    await db.commit()

    db.expire_all()

    full_act_query = (
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .where(DeliveryAct.id == act.id)
    )
    res = await db.execute(full_act_query)
    return res.scalar_one()


@router.post("/{act_id}/upload-scan", response_model=DeliveryActResponse)
async def upload_scanned_act_file(
    act_id: UUID,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Sube el PDF o imagen escaneada de la hoja física firmada por el trabajador y el Gerente."""
    query = select(DeliveryAct).options(selectinload(DeliveryAct.items)).where(DeliveryAct.id == act_id)
    res = await db.execute(query)
    act = res.scalar_one_or_none()
    if not act:
        raise HTTPException(status_code=404, detail="Acta no encontrada")

    ext = os.path.splitext(file.filename or "scan.jpg")[1].lower()
    if ext not in {".pdf", ".png", ".jpg", ".jpeg", ".webp"}:
        ext = ".jpg"

    ts = int(datetime.now(timezone.utc).timestamp())
    safe_filename = f"act_scan_{act.act_number}_{ts}{ext}"
    file_path = os.path.join(UPLOAD_DIR, safe_filename)

    content = await file.read()
    with open(file_path, "wb") as f:
        f.write(content)

    act.scanned_document_url = f"/uploads/{safe_filename}"
    act.scanned_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(act)
    return act


@router.post("/{act_id}/upload-scan-base64", response_model=DeliveryActResponse)
async def upload_scanned_act_base64(
    act_id: UUID,
    payload: Base64UploadRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Guarda una captura digitalizada desde el Modo Escáner de Documento de la cámara móvil."""
    query = select(DeliveryAct).options(selectinload(DeliveryAct.items)).where(DeliveryAct.id == act_id)
    res = await db.execute(query)
    act = res.scalar_one_or_none()
    if not act:
        raise HTTPException(status_code=404, detail="Acta no encontrada")

    raw_data = payload.data_url
    ext = ".jpg"
    if "," in raw_data:
        header, b64_part = raw_data.split(",", 1)
        if "pdf" in header:
            ext = ".pdf"
        elif "png" in header:
            ext = ".png"
    else:
        b64_part = raw_data

    binary = base64.b64decode(b64_part)
    ts = int(datetime.now(timezone.utc).timestamp())
    safe_filename = f"act_scan_{act.act_number}_{ts}{ext}"
    file_path = os.path.join(UPLOAD_DIR, safe_filename)

    with open(file_path, "wb") as f:
        f.write(binary)

    act.scanned_document_url = f"/uploads/{safe_filename}"
    act.scanned_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(act)
    return act


@router.post("/{act_id}/upload-evidence", response_model=DeliveryActResponse)
async def upload_act_evidence_photo(
    act_id: UUID,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Adjunta una foto de evidencia del estado físico del equipo al momento de la entrega o devolución."""
    query = select(DeliveryAct).options(selectinload(DeliveryAct.items)).where(DeliveryAct.id == act_id)
    res = await db.execute(query)
    act = res.scalar_one_or_none()
    if not act:
        raise HTTPException(status_code=404, detail="Acta no encontrada")

    ext = os.path.splitext(file.filename or "evidencia.jpg")[1].lower()
    if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
        ext = ".jpg"

    ts = int(datetime.now(timezone.utc).timestamp() * 1000)
    safe_filename = f"act_evid_{act.act_number}_{ts}{ext}"
    file_path = os.path.join(UPLOAD_DIR, safe_filename)

    content = await file.read()
    with open(file_path, "wb") as f:
        f.write(content)

    current_list = act.evidence_photos_list
    current_list.append(f"/uploads/{safe_filename}")
    act.evidence_photos = json.dumps(current_list)

    await db.commit()
    await db.refresh(act)
    return act


@router.delete("/{act_id}/evidence/{photo_idx}", response_model=DeliveryActResponse)
async def remove_act_evidence_photo(
    act_id: UUID,
    photo_idx: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = select(DeliveryAct).options(selectinload(DeliveryAct.items)).where(DeliveryAct.id == act_id)
    res = await db.execute(query)
    act = res.scalar_one_or_none()
    if not act:
        raise HTTPException(status_code=404, detail="Acta no encontrada")

    current_list = act.evidence_photos_list
    if 0 <= photo_idx < len(current_list):
        current_list.pop(photo_idx)
        act.evidence_photos = json.dumps(current_list)
        await db.commit()
        await db.refresh(act)
    return act


@router.delete("/{act_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_delivery_act(
    act_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = (
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .where(DeliveryAct.id == act_id)
    )
    res = await db.execute(query)
    act = res.scalar_one_or_none()
    if not act:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Acta de entrega no encontrada"
        )

    for item in act.items:
        if item.equipment_id:
            eq_query = select(Equipment).where(Equipment.id == item.equipment_id)
            eq_res = await db.execute(eq_query)
            equipment = eq_res.scalar_one_or_none()
            if equipment:
                equipment.status = EquipmentStatus.available
                equipment.assigned_to = None

                movement = Movement(
                    type=MovementType.return_item,
                    equipment_id=equipment.id,
                    from_warehouse_id=equipment.current_warehouse_id,
                    to_warehouse_id=equipment.current_warehouse_id,
                    assigned_to=None,
                    notes=f"Reversión automática por anulación/eliminación del Acta N° {act.act_number}",
                    performed_by=current_user.id,
                )
                db.add(movement)

    await db.delete(act)
    await db.commit()
    return None
