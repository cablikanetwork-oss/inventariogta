import os
import uuid
import shutil
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.config import settings
from app.api.deps import require_admin
from app.models.company import CompanyConfig
from app.models.user import User
from app.schemas.company import CompanyConfigResponse, CompanyConfigUpdate

router = APIRouter()

ALLOWED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".svg"}
ALLOWED_CONTENT_TYPES = {
    "image/png",
    "image/jpeg",
    "image/jpg",
    "image/webp",
    "image/svg+xml",
}

async def get_or_create_config(db: AsyncSession) -> CompanyConfig:
    result = await db.execute(select(CompanyConfig).limit(1))
    config = result.scalar_one_or_none()
    if not config:
        config = CompanyConfig(
            name="InventoryOS Tech",
            primary_color="#2563EB",
            secondary_color="#1E40AF",
            accent_color="#F59E0B"
        )
        db.add(config)
        await db.commit()
        await db.refresh(config)
    return config

def remove_previous_upload(logo_url: str | None) -> None:
    """Elimina el archivo anterior de uploads si era un archivo local subido."""
    if not logo_url or not logo_url.startswith("/uploads/"):
        return
    filename = logo_url.replace("/uploads/", "").strip()
    if not filename:
        return
    old_path = Path(settings.UPLOAD_DIR) / filename
    try:
        if old_path.is_file():
            old_path.unlink()
    except Exception:
        pass

@router.get("/config", response_model=CompanyConfigResponse)
async def get_company_config(db: AsyncSession = Depends(get_db)):
    """Endpoint público: devuelve la configuración de marca blanca antes del login."""
    return await get_or_create_config(db)

@router.put("/config", response_model=CompanyConfigResponse)
async def update_company_config(
    update: CompanyConfigUpdate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    config = await get_or_create_config(db)
    update_data = update.model_dump(exclude_unset=True)
    
    # Si cambiaron el logo por URL externa o nulo, limpiar el archivo anterior si era local
    if "logo_url" in update_data and update_data["logo_url"] != config.logo_url:
        remove_previous_upload(config.logo_url)

    for field, value in update_data.items():
        setattr(config, field, value)

    await db.commit()
    await db.refresh(config)
    return config

@router.post("/config/logo", response_model=CompanyConfigResponse)
async def upload_company_logo(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    """
    Sube un archivo de imagen (PNG, JPG, SVG, WEBP) para el logotipo de la empresa.
    Se almacena de forma persistente en el volumen de uploads y se asocia en la base de datos.
    """
    if not file.filename:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Archivo inválido")

    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Formato no permitido. Utiliza archivos: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}"
        )

    # Validar content type si viene presente
    if file.content_type and file.content_type.lower() not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El archivo proporcionado no es una imagen válida"
        )

    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

    config = await get_or_create_config(db)

    # Limpiar logo anterior si era local
    remove_previous_upload(config.logo_url)

    # Generar nombre único con UUID para evitar colisiones y problemas de cache
    unique_filename = f"logo_{uuid.uuid4().hex[:10]}{ext}"
    destination_path = Path(settings.UPLOAD_DIR) / unique_filename

    try:
        # Guardar en chunks para controlar tamaño de archivo
        file_size = 0
        with open(destination_path, "wb") as buffer:
            while chunk := await file.read(1024 * 64):
                file_size += len(chunk)
                if file_size > settings.MAX_UPLOAD_SIZE:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"La imagen supera el límite permitido de {settings.MAX_UPLOAD_SIZE // (1024 * 1024)}MB"
                    )
                buffer.write(chunk)
    except HTTPException:
        if destination_path.exists():
            destination_path.unlink()
        raise
    except Exception as e:
        if destination_path.exists():
            destination_path.unlink()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error al guardar la imagen: {str(e)}")

    # Guardar ruta relativa accesible por Nginx y FastAPI StaticFiles
    config.logo_url = f"/uploads/{unique_filename}"
    await db.commit()
    await db.refresh(config)

    return config

@router.delete("/config/logo", response_model=CompanyConfigResponse)
async def delete_company_logo(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    """Elimina el logotipo personalizado de la empresa y vuelve al isotipo predeterminado."""
    config = await get_or_create_config(db)
    remove_previous_upload(config.logo_url)
    config.logo_url = None
    await db.commit()
    await db.refresh(config)
    return config
