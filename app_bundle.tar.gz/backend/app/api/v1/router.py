from fastapi import APIRouter
from app.api.v1 import auth, company, users, warehouses, equipment, movements, delivery_acts, reports, audit, assistant, backup

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Autenticación"])
api_router.include_router(company.router, prefix="/company", tags=["Configuración Empresa"])
api_router.include_router(users.router, prefix="/users", tags=["Usuarios"])
api_router.include_router(warehouses.router, prefix="/warehouses", tags=["Almacenes"])
api_router.include_router(equipment.router, prefix="/equipment", tags=["Equipos / Inventario"])
api_router.include_router(movements.router, prefix="/movements", tags=["Movimientos"])
api_router.include_router(delivery_acts.router, prefix="/delivery-acts", tags=["Actas de Entrega"])
api_router.include_router(reports.router, prefix="/reports", tags=["Reportes"])
api_router.include_router(audit.router, prefix="/audit", tags=["Auditoría de Inventario"])
api_router.include_router(assistant.router, prefix="/assistant", tags=["Copiloto IA de Inventario"])
api_router.include_router(backup.router, prefix="/backup", tags=["Respaldo Cloud Google Drive y Sheets"])
