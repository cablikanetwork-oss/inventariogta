import uuid
from datetime import date, datetime, timezone
from typing import List, Optional
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.equipment import Equipment, EquipmentStatus, EquipmentCategory
from app.models.warehouse import Warehouse
from app.models.movement import Movement
from app.models.delivery_act import DeliveryAct, DeliveryActItem
from app.schemas.equipment import EquipmentResponse
from app.schemas.movement import MovementResponse

router = APIRouter()

@router.get("/equipment/{equipment_id}/lifecycle")
async def get_equipment_lifecycle(
    equipment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Retorna la hoja de vida completa del equipo: trazabilidad, movimientos y actas."""
    eq_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(Equipment.id == equipment_id)
    )
    equipment = eq_res.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")

    # Movimientos ordenados cronológicamente
    mov_res = await db.execute(
        select(Movement)
        .options(
            selectinload(Movement.from_warehouse),
            selectinload(Movement.to_warehouse),
            selectinload(Movement.performed_by_user)
        )
        .where(Movement.equipment_id == equipment_id)
        .order_by(Movement.created_at.asc())
    )
    movements = mov_res.scalars().all()

    # Actas de entrega relacionadas
    act_items_res = await db.execute(
        select(DeliveryActItem)
        .options(selectinload(DeliveryActItem.delivery_act))
        .where(DeliveryActItem.equipment_id == equipment_id)
    )
    act_items = act_items_res.scalars().all()
    acts_data = []
    for item in act_items:
        if item.delivery_act:
            acts_data.append({
                "act_id": item.delivery_act.id,
                "act_number": item.delivery_act.act_number,
                "receiver_name": item.delivery_act.receiver_name,
                "receiver_department": item.delivery_act.receiver_department,
                "delivery_date": item.delivery_act.delivery_date,
                "status": item.delivery_act.status,
            })

    # Antigüedad en días
    now = datetime.now(timezone.utc)
    base_date = equipment.purchase_date if equipment.purchase_date else equipment.created_at.date()
    age_days = (now.date() - base_date).days if base_date else 0

    return {
        "equipment": EquipmentResponse.model_validate(equipment),
        "age_days": max(0, age_days),
        "movements_count": len(movements),
        "movements": [MovementResponse.model_validate(m) for m in movements],
        "delivery_acts": acts_data
    }

@router.get("/obsolescence")
async def get_obsolescence_report(
    threshold_years: int = Query(3, ge=1, le=20),
    warehouse_id: Optional[uuid.UUID] = Query(None),
    category: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Reporte de antigüedad, depreciación y obsolescencia tecnológica del parque de equipos."""
    query = select(Equipment).options(
        selectinload(Equipment.current_warehouse)
    ).where(Equipment.is_active == True)

    if warehouse_id:
        query = query.where(Equipment.current_warehouse_id == warehouse_id)
    if category and category != "all":
        try:
            query = query.where(Equipment.category == EquipmentCategory(category))
        except ValueError:
            pass

    result = await db.execute(query)
    equipments = result.scalars().all()

    today = date.today()
    report_items = []
    total_original_value = Decimal(0)
    total_residual_value = Decimal(0)
    obsolete_count = 0
    warning_count = 0
    optimal_count = 0

    for eq in equipments:
        ref_date = eq.purchase_date or eq.created_at.date()
        age_years = round((today - ref_date).days / 365.25, 1) if ref_date else 0.0
        lifespan = eq.expected_lifespan_years or threshold_years or 3

        depreciation_pct = min(100.0, round((age_years / lifespan) * 100.0, 1))
        is_obsolete = (age_years >= threshold_years) or (depreciation_pct >= 100.0)

        # Estado de garantía
        if eq.warranty_expires:
            warranty_status = "Vigente" if eq.warranty_expires >= today else "Vencida"
        else:
            warranty_status = "Sin registrar"

        # Cálculo de valor residual
        orig_price = eq.purchase_price or Decimal(0)
        residual_price = orig_price * Decimal(max(0.0, 1.0 - (depreciation_pct / 100.0)))

        total_original_value += orig_price
        total_residual_value += residual_price

        if is_obsolete:
            obsolete_count += 1
            health_color = "red"
        elif depreciation_pct >= 75.0:
            warning_count += 1
            health_color = "yellow"
        else:
            optimal_count += 1
            health_color = "green"

        report_items.append({
            "equipment": EquipmentResponse.model_validate(eq),
            "age_years": age_years,
            "lifespan_years": lifespan,
            "depreciation_pct": depreciation_pct,
            "is_obsolete": is_obsolete,
            "health_color": health_color,
            "warranty_status": warranty_status,
            "purchase_price": float(orig_price),
            "residual_value": float(round(residual_price, 2)),
        })

    # Ordenar por depreciación / antigüedad descendente
    report_items.sort(key=lambda x: x["depreciation_pct"], reverse=True)

    return {
        "threshold_years": threshold_years,
        "total_analyzed": len(equipments),
        "optimal_count": optimal_count,
        "warning_count": warning_count,
        "obsolete_count": obsolete_count,
        "total_original_value": float(round(total_original_value, 2)),
        "total_residual_value": float(round(total_residual_value, 2)),
        "items": report_items
    }

@router.get("/employee-clearance")
async def get_employee_clearance(
    employee_name: str = Query(..., min_length=2),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Reporte de Paz y Salvo: todos los equipos bajo custodia de un trabajador y actas firmadas."""
    clean_name = employee_name.strip()
    
    # Buscar equipos asignados
    eq_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(
            Equipment.is_active == True,
            Equipment.assigned_to.ilike(f"%{clean_name}%")
        )
    )
    assigned_equipments = eq_res.scalars().all()

    # Buscar actas emitidas para este empleado
    act_res = await db.execute(
        select(DeliveryAct)
        .where(
            or_(
                DeliveryAct.receiver_name.ilike(f"%{clean_name}%"),
                DeliveryAct.receiver_id_card.ilike(f"%{clean_name}%")
            )
        )
        .order_by(DeliveryAct.delivery_date.desc())
    )
    acts = act_res.scalars().all()

    return {
        "employee_query": clean_name,
        "has_pending_assets": len(assigned_equipments) > 0,
        "total_assigned": len(assigned_equipments),
        "equipment": [EquipmentResponse.model_validate(e) for e in assigned_equipments],
        "delivery_acts": [
            {
                "id": a.id,
                "act_number": a.act_number,
                "receiver_name": a.receiver_name,
                "receiver_id_card": a.receiver_id_card,
                "delivery_date": a.delivery_date,
                "status": a.status
            }
            for a in acts
        ]
    }
