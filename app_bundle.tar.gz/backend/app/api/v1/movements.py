import uuid
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from typing import List, Optional
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.equipment import Equipment, EquipmentStatus
from app.models.movement import Movement, MovementType
from app.schemas.movement import MovementCreate, MovementResponse

router = APIRouter()

@router.get("/", response_model=List[MovementResponse])
async def list_movements(
    equipment_id: Optional[uuid.UUID] = Query(None),
    warehouse_id: Optional[uuid.UUID] = Query(None),
    movement_type: Optional[str] = Query(None),
    limit: int = Query(50, le=500),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    query = select(Movement).options(
        selectinload(Movement.equipment),
        selectinload(Movement.from_warehouse),
        selectinload(Movement.to_warehouse),
        selectinload(Movement.performed_by_user)
    )
    if equipment_id:
        query = query.where(Movement.equipment_id == equipment_id)
    if warehouse_id:
        query = query.where(
            (Movement.from_warehouse_id == warehouse_id) |
            (Movement.to_warehouse_id == warehouse_id)
        )
    if movement_type:
        query = query.where(Movement.type == movement_type)
    
    query = query.order_by(Movement.created_at.desc()).limit(limit).offset(offset)
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/", response_model=MovementResponse, status_code=status.HTTP_201_CREATED)
async def create_movement(
    data: MovementCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    eq_result = await db.execute(
        select(Equipment).where(Equipment.id == data.equipment_id, Equipment.is_active == True)
    )
    equipment = eq_result.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")
    
    from_wh = data.from_warehouse_id or equipment.current_warehouse_id

    # Actualizar estado y ubicación del equipo según el tipo de movimiento
    if data.type == MovementType.entry:
        equipment.status = EquipmentStatus.available
        equipment.current_warehouse_id = data.to_warehouse_id
        equipment.assigned_to = None
    elif data.type == MovementType.exit:
        equipment.status = EquipmentStatus.assigned
        equipment.assigned_to = data.assigned_to
        equipment.current_warehouse_id = None
    elif data.type == MovementType.transfer:
        equipment.current_warehouse_id = data.to_warehouse_id
    elif data.type == MovementType.return_item:
        equipment.status = EquipmentStatus.available
        equipment.assigned_to = None
        equipment.current_warehouse_id = data.to_warehouse_id
    elif data.type == MovementType.maintenance:
        equipment.status = EquipmentStatus.maintenance
    
    movement = Movement(
        type=data.type,
        equipment_id=data.equipment_id,
        from_warehouse_id=from_wh,
        to_warehouse_id=data.to_warehouse_id,
        performed_by=current_user.id,
        assigned_to=data.assigned_to,
        notes=data.notes
    )
    db.add(movement)
    await db.commit()
    await db.refresh(movement)
    
    result = await db.execute(
        select(Movement).options(
            selectinload(Movement.equipment),
            selectinload(Movement.from_warehouse),
            selectinload(Movement.to_warehouse),
            selectinload(Movement.performed_by_user)
        ).where(Movement.id == movement.id)
    )
    return result.scalar_one()

@router.get("/{movement_id}", response_model=MovementResponse)
async def get_movement(
    movement_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Movement).options(
            selectinload(Movement.equipment),
            selectinload(Movement.from_warehouse),
            selectinload(Movement.to_warehouse),
            selectinload(Movement.performed_by_user)
        ).where(Movement.id == movement_id)
    )
    movement = result.scalar_one_or_none()
    if not movement:
        raise HTTPException(status_code=404, detail="Movimiento no encontrado")
    return movement

