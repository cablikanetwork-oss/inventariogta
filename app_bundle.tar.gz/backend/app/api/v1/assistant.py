import os
import re
import unicodedata
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
import httpx
import edge_tts

from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.equipment import Equipment, EquipmentStatus, EquipmentMaintenance
from app.models.warehouse import Warehouse
from app.models.delivery_act import DeliveryAct, DeliveryActItem
from app.models.movement import Movement, MovementType

router = APIRouter()


# ==========================================
# ESQUEMAS DE SOLICITUD Y RESPUESTA DEL AGENTE
# ==========================================

class ChatHistoryItem(BaseModel):
    role: str  # 'user' | 'assistant'
    content: str


class AssistantQueryRequest(BaseModel):
    query: str
    scanned_code: Optional[str] = None
    history: Optional[List[ChatHistoryItem]] = None
    gemini_api_key: Optional[str] = None


class AssistantActionCard(BaseModel):
    card_type: str  # 'equipment' | 'person' | 'warehouse' | 'act' | 'stats'
    title: str
    subtitle: Optional[str] = None
    badge_text: Optional[str] = None
    badge_color: Optional[str] = None  # 'emerald' | 'sky' | 'amber' | 'rose' | 'slate'
    details: List[Dict[str, str]] = []
    link_url: Optional[str] = None
    link_label: Optional[str] = None
    secondary_link_url: Optional[str] = None
    secondary_link_label: Optional[str] = None
    action_command: Optional[str] = None
    action_label: Optional[str] = None


class AssistantQueryResponse(BaseModel):
    answer: str
    intent: str
    cards: List[AssistantActionCard] = []
    follow_up_suggestions: List[str] = []
    engine: str = "hybrid-ai"
    action_performed: bool = False


class AssistantSuggestionsResponse(BaseModel):
    suggestions: List[str]
    quick_stats: Dict[str, int]


class AssistantTTSRequest(BaseModel):
    text: str
    voice: Optional[str] = "es-VE-SebastianNeural"
    rate: Optional[str] = "+4%"


NEURAL_MALE_VOICES = {
    "sebastian": "es-VE-SebastianNeural",
    "gonzalo": "es-CO-GonzaloNeural",
    "jorge": "es-MX-JorgeNeural",
    "alvaro": "es-ES-AlvaroNeural",
    "es-VE-SebastianNeural": "es-VE-SebastianNeural",
    "es-CO-GonzaloNeural": "es-CO-GonzaloNeural",
    "es-MX-JorgeNeural": "es-MX-JorgeNeural",
    "es-ES-AlvaroNeural": "es-ES-AlvaroNeural",
}

_TTS_AUDIO_CACHE: Dict[str, bytes] = {}


@router.post("/tts")
async def synthesize_rosco_speech(
    req: AssistantTTSRequest,
    _: User = Depends(get_current_user),
):
    """
    Genera audio MP3 con voz masculina neural hiperrealista para Rosco
    (por defecto es-VE-SebastianNeural / es-CO-GonzaloNeural).
    """
    clean_text = (req.text or "").strip()
    if not clean_text:
        raise HTTPException(status_code=400, detail="Texto vacío")

    # Limitar longitud para respuesta rápida
    if len(clean_text) > 750:
        clean_text = clean_text[:750]

    voice_id = NEURAL_MALE_VOICES.get(req.voice or "sebastian", "es-VE-SebastianNeural")
    rate_str = req.rate if req.rate and req.rate.startswith(("+", "-")) else "+4%"
    cache_key = f"{voice_id}|{rate_str}|{clean_text}"

    if cache_key in _TTS_AUDIO_CACHE:
        return Response(content=_TTS_AUDIO_CACHE[cache_key], media_type="audio/mpeg")

    try:
        communicate = edge_tts.Communicate(text=clean_text, voice=voice_id, rate=rate_str)
        audio_bytes = b""
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                audio_bytes += chunk["data"]

        if not audio_bytes:
            raise RuntimeError("No se recibieron bytes de audio")

        if len(_TTS_AUDIO_CACHE) >= 50:
            oldest_key = next(iter(_TTS_AUDIO_CACHE))
            _TTS_AUDIO_CACHE.pop(oldest_key, None)
        _TTS_AUDIO_CACHE[cache_key] = audio_bytes

        return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"TTS Neural no disponible: {exc}")


# ==========================================
# UTILIDADES DE PROCESAMIENTO DE LENGUAJE NATURAL
# ==========================================

STATUS_LABELS = {
    "available": ("Disponible", "emerald"),
    "assigned": ("Asignado", "sky"),
    "maintenance": ("En Mantenimiento", "amber"),
    "retired": ("De Baja", "slate"),
    "lost": ("Extraviado", "rose"),
}

CATEGORY_SYNONYMS = {
    "laptop": ["laptop", "laptops", "portatil", "portatiles", "notebook", "notebooks"],
    "desktop": ["desktop", "desktops", "computador", "computadora", "computadoras", "pc", "pcs", "escritorio", "all in one"],
    "monitor": ["monitor", "monitores", "pantalla", "pantallas"],
    "phone": ["telefono", "telefonos", "celular", "celulares", "movil", "moviles", "smartphone"],
    "tablet": ["tablet", "tablets", "tableta", "ipad"],
    "printer": ["impresora", "impresoras", "multifuncional", "escaner"],
    "ups": ["ups", "regulador", "reguladores", "bateria"],
    "switch": ["switch", "switches", "conmutador"],
    "router": ["router", "routers", "modem", "access point", "wifi", "antena"],
    "server": ["servidor", "servidores", "nas"],
    "keyboard": ["teclado", "teclados"],
    "mouse": ["mouse", "mouses", "raton", "ratones"],
    "cable": ["cable", "cables", "cargador", "cargadores", "adaptador"],
}

CATEGORY_DISPLAY = {
    "laptop": "Laptop / Portátil",
    "desktop": "Computador de Escritorio",
    "monitor": "Monitor / Pantalla",
    "phone": "Teléfono Móvil",
    "tablet": "Tablet",
    "printer": "Impresora",
    "ups": "UPS / Regulador",
    "switch": "Switch de Red",
    "router": "Router / AP",
    "server": "Servidor / NAS",
    "keyboard": "Teclado",
    "mouse": "Mouse",
    "cable": "Cable / Cargador",
    "other": "Otro Equipo",
}

STOPWORDS = {
    "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al", "en", "con", "por",
    "para", "sin", "sobre", "tras", "que", "quien", "quienes", "cual", "cuales", "cuanto", "cuantos",
    "cuanta", "cuantas", "donde", "como", "cuando", "tiene", "tienen", "hay", "esta", "estan",
    "es", "son", "fue", "fueron", "equipo", "equipos", "asignado", "asignados", "asignada", "asignadas",
    "ubicacion", "ubicado", "encuentra", "persona", "trabajador", "empleado", "usuario", "sistema",
    "inventario", "almacen", "almacenes", "bodega", "sede", "dime", "mostrar", "muestrame", "buscar",
    "busca", "decir", "puedes", "podrias", "quiero", "saber", "consultar", "consulta", "informacion",
    "datos", "detalle", "detalles", "estado", "estatus", "actual", "actualmente", "favor", "hola",
    "buenos", "dias", "tardes", "noches", "serial", "serie", "numero", "codigo", "barra", "barras",
    "qr", "tiene", "posee", "cargo", "poder", "custodia", "quien", "pertenece", "corresponde"
}


def normalize_text(text: str) -> str:
    """Elimina tildes/diacríticos y convierte a minúsculas."""
    if not text:
        return ""
    nfkd = unicodedata.normalize("NFKD", text)
    no_accents = "".join([c for c in nfkd if not unicodedata.combining(c)])
    return no_accents.lower().strip()


def extract_meaningful_tokens(query: str) -> List[str]:
    norm = normalize_text(query)
    # Limpiar signos de puntuación excepto guiones y puntos internos de seriales/cédulas
    cleaned = re.sub(r"[¿?¡!,:;\"'()\[\]{}]", " ", norm)
    raw_tokens = cleaned.split()
    return [t for t in raw_tokens if t not in STOPWORDS and len(t) >= 2]


def status_str(status_val: Any) -> str:
    if hasattr(status_val, "value"):
        return str(status_val.value)
    return str(status_val)


# ==========================================
# ENDPOINT 1: SUGERENCIAS DINÁMICAS CON DATOS REALES
# ==========================================

@router.get("/suggestions", response_model=AssistantSuggestionsResponse)
async def get_assistant_suggestions(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Genera sugerencias inteligentes basadas en los equipos, personas y almacenes reales de la BD."""
    eq_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(Equipment.is_active == True)
        .order_by(Equipment.updated_at.desc())
    )
    all_equipment = eq_res.scalars().all()

    act_res = await db.execute(
        select(DeliveryAct).order_by(DeliveryAct.created_at.desc()).limit(10)
    )
    recent_acts = act_res.scalars().all()

    wh_res = await db.execute(
        select(Warehouse).where(Warehouse.is_active == True)
    )
    warehouses = wh_res.scalars().all()

    total_eq = len(all_equipment)
    available_eq = sum(1 for e in all_equipment if status_str(e.status) == "available")
    assigned_eq = sum(1 for e in all_equipment if status_str(e.status) == "assigned")
    maint_eq = sum(1 for e in all_equipment if status_str(e.status) == "maintenance")

    suggestions: List[str] = [
        "Dame un resumen general del inventario",
        "¿Cuántas laptops están disponibles actualmente?",
    ]

    # Sugerencia con un almacén real (sin nombres de personas)
    if warehouses:
        wh_name = warehouses[0].name
        suggestions.append(f"¿Qué equipos están disponibles en {wh_name}?")

    # Sugerencia con un serial de equipo real (sin nombres de personas)
    if all_equipment:
        sample_eq = all_equipment[0]
        suggestions.append(f"¿Cuál es el estado y ubicación del equipo {sample_eq.serial_number}?")

    # Sugerencias operativas generales sin exponer nombres propios
    suggestions.append("¿Cuántos equipos se encuentran asignados actualmente?")
    suggestions.append("Muéstrame las últimas actas de entrega emitidas")

    return AssistantSuggestionsResponse(
        suggestions=suggestions[:6],
        quick_stats={
            "total": total_eq,
            "available": available_eq,
            "assigned": assigned_eq,
            "maintenance": maint_eq,
            "warehouses": len(warehouses),
            "acts": len(recent_acts),
        }
    )


# ==========================================
# ENDPOINT 2: MOTOR DE CONSULTA CONVERSACIONAL IA
# ==========================================

@router.post("/query", response_model=AssistantQueryResponse)
async def query_assistant(
    req: AssistantQueryRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Analiza la pregunta en lenguaje natural del usuario, consulta en tiempo real el inventario,
    actas de entrega, almacenes y mantenimientos, y genera una respuesta precisa con tarjetas interactivas.
    """
    user_query = (req.query or "").strip()
    norm_q = normalize_text(user_query)
    tokens = extract_meaningful_tokens(user_query)

    # Cargar estado actual del inventario en memoria para cruce instantáneo
    eq_res = await db.execute(
        select(Equipment)
        .options(
            selectinload(Equipment.current_warehouse),
            selectinload(Equipment.maintenances),
        )
        .where(Equipment.is_active == True)
        .order_by(Equipment.updated_at.desc())
    )
    all_equipment = eq_res.scalars().all()

    wh_res = await db.execute(
        select(Warehouse).where(Warehouse.is_active == True)
    )
    all_warehouses = wh_res.scalars().all()

    act_res = await db.execute(
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .order_by(DeliveryAct.created_at.desc())
    )
    all_acts = act_res.scalars().all()

    mov_res = await db.execute(
        select(Movement)
        .options(
            selectinload(Movement.equipment),
            selectinload(Movement.from_warehouse),
            selectinload(Movement.to_warehouse),
            selectinload(Movement.performed_by_user),
        )
        .order_by(Movement.created_at.desc())
        .limit(15)
    )
    recent_movements = mov_res.scalars().all()

    # Mapa rápido de serial -> última acta de asignación
    serial_to_act: Dict[str, DeliveryAct] = {}
    for act in all_acts:
        if act.act_type == "assignment":
            for it in act.items:
                sn_norm = normalize_text(it.serial_number)
                if sn_norm and sn_norm not in serial_to_act:
                    serial_to_act[sn_norm] = act

    # ==========================================================
    # CASO 0: ESCANEO DIRECTO DESDE CÁMARA EN EL ASISTENTE
    # ==========================================================
    if req.scanned_code:
        code_clean = req.scanned_code.strip()
        code_norm = normalize_text(code_clean)

        # Verificar si es un código de Acta (ACT-...)
        matched_act = next(
            (a for a in all_acts if normalize_text(a.act_number) == code_norm),
            None
        )
        if matched_act:
            return _build_single_act_response(matched_act)

        # Buscar equipo por serial o barcode exacto
        matched_eq = next(
            (
                e for e in all_equipment
                if normalize_text(e.serial_number) == code_norm
                or (e.barcode and normalize_text(e.barcode) == code_norm)
            ),
            None
        )
        if matched_eq:
            return _build_equipment_detail_response([matched_eq], serial_to_act, all_equipment)

    # ==========================================================
    # CASO 0.5: EJECUCIÓN DE COMANDOS OPERATIVOS POR VOZ O TEXTO
    # (Traslados entre almacenes, asignaciones, devoluciones, mantenimiento)
    # ==========================================================
    action_response = await _try_execute_voice_action(
        user_query=user_query,
        norm_q=norm_q,
        tokens=tokens,
        req=req,
        db=db,
        current_user=current_user,
        all_equipment=all_equipment,
        all_warehouses=all_warehouses,
        serial_to_act=serial_to_act,
    )
    if action_response is not None:
        return action_response

    # ==========================================================
    # DETECCIÓN DE ENTIDADES ESPECÍFICAS EN LA PREGUNTA
    # ==========================================================

    # 1. ¿Menciona un número de Acta explícito (ej. ACT-2026-0001)?
    act_match = re.search(r"(act-\d{4}-\d+)", norm_q)
    if act_match:
        act_num = act_match.group(1)
        found_act = next((a for a in all_acts if normalize_text(a.act_number) == act_num), None)
        if found_act:
            return _build_single_act_response(found_act)

    # 2. ¿Coincide con el Serial o Código de Barras de algún equipo?
    exact_serial_matches: List[Equipment] = []
    for eq in all_equipment:
        sn_norm = normalize_text(eq.serial_number)
        bc_norm = normalize_text(eq.barcode or "")
        # Coincidencia si un token de >= 4 caracteres está contenido en el serial/barcode o viceversa
        for tok in tokens:
            if len(tok) >= 4 and (tok == sn_norm or tok == bc_norm or (len(tok) >= 5 and (tok in sn_norm or (bc_norm and tok in bc_norm)))):
                if eq not in exact_serial_matches:
                    exact_serial_matches.append(eq)

    if exact_serial_matches:
        return await _finalize_with_optional_llm(
            req,
            _build_equipment_detail_response(exact_serial_matches, serial_to_act, all_equipment),
            all_equipment,
            all_warehouses,
            all_acts,
        )

    # 3. ¿Coincide con el nombre o cédula de una Persona / Trabajador?
    # Recopilamos todas las personas conocidas (en Equipment.assigned_to y en DeliveryAct.recipient_name / recipient_id_card)
    person_matches = _find_matching_people(norm_q, tokens, all_equipment, all_acts)
    is_asking_about_person = any(
        w in norm_q
        for w in [
            "cuantos equipos", "que equipos", "asignado", "asignados", "tiene",
            "custodia", "cargo", "cedula", "trabajador", "persona", "actas de", "entregado a"
        ]
    )
    if person_matches and (is_asking_about_person or len(person_matches) >= 1):
        # Verificar que no sea simplemente el nombre de una marca (ej. Lenovo)
        brands_norm = {normalize_text(e.brand or "") for e in all_equipment if e.brand}
        non_brand_people = [p for p in person_matches if normalize_text(p["name"]) not in brands_norm]
        if non_brand_people:
            return await _finalize_with_optional_llm(
                req,
                _build_person_custody_response(non_brand_people[0], all_equipment, all_acts),
                all_equipment,
                all_warehouses,
                all_acts,
            )

    # 4. ¿Pregunta quiénes tienen equipos asignados en general?
    if any(
        phrase in norm_q
        for phrase in [
            "quienes tienen equipos",
            "personas con equipos",
            "lista de asignados",
            "equipos asignados",
            "a quienes se",
            "trabajadores con equipos",
            "custodios",
        ]
    ) and not tokens:
        return _build_all_custodians_response(all_equipment, all_acts)

    # 5. ¿Coincide con el nombre de un Almacén / Sede (ej. Torre Avila, Almacén Central)?
    matched_warehouse = _find_matching_warehouse(norm_q, tokens, all_warehouses)
    if matched_warehouse:
        return await _finalize_with_optional_llm(
            req,
            _build_warehouse_response(matched_warehouse, all_equipment),
            all_equipment,
            all_warehouses,
            all_acts,
        )

    # 6. ¿Pregunta por Almacenes en general?
    if any(w in norm_q for w in ["almacenes", "bodegas", "sedes", "cuantos almacenes"]):
        return _build_all_warehouses_response(all_warehouses, all_equipment)

    # 7. ¿Pregunta por Actas de Entrega o Paz y Salvo / Solvencia?
    if any(w in norm_q for w in ["acta", "actas", "solvencia", "paz y salvo", "escaneo", "firmada", "firmadas"]):
        return _build_acts_overview_response(norm_q, all_acts)

    # 8. ¿Pregunta por Mantenimientos / Reparaciones / Hoja de Vida?
    if any(w in norm_q for w in ["mantenimiento", "mantenimientos", "reparacion", "reparaciones", "upgrade", "hoja de vida", "garantia"]):
        return _build_maintenance_response(all_equipment)

    # 9. ¿Pregunta por Movimientos recientes / Traslados / Historial?
    if any(w in norm_q for w in ["movimiento", "movimientos", "traslado", "traslados", "entradas", "salidas", "historial"]):
        return _build_movements_response(recent_movements)

    # 10. ¿Busca equipos por Nombre, Marca, Modelo o Categoría + Estado?
    matched_category = _detect_category(norm_q)
    matched_status = _detect_status(norm_q)
    equipment_by_text = _search_equipment_by_tokens(tokens, all_equipment, matched_category, matched_status)

    if equipment_by_text:
        # Si es 1 a 3 equipos específicos o pregunta "quien tiene / donde esta", dar detalle directo
        if len(equipment_by_text) <= 4 or any(p in norm_q for p in ["quien tiene", "donde esta", "ubicacion", "cual es"]):
            return await _finalize_with_optional_llm(
                req,
                _build_equipment_detail_response(equipment_by_text, serial_to_act, all_equipment),
                all_equipment,
                all_warehouses,
                all_acts,
            )
        else:
            return await _finalize_with_optional_llm(
                req,
                _build_equipment_list_response(equipment_by_text, matched_category, matched_status, serial_to_act),
                all_equipment,
                all_warehouses,
                all_acts,
            )

    if matched_category or matched_status:
        filtered = [
            e for e in all_equipment
            if (not matched_category or normalize_text(e.category) == matched_category)
            and (not matched_status or status_str(e.status) == matched_status)
        ]
        return await _finalize_with_optional_llm(
            req,
            _build_equipment_list_response(filtered, matched_category, matched_status, serial_to_act),
            all_equipment,
            all_warehouses,
            all_acts,
        )

    # 11. ¿Pregunta quiénes tienen equipos asignados (con tokens como "asignados")?
    if "asignado" in norm_q or "asignados" in norm_q or "quien tiene" in norm_q:
        return _build_all_custodians_response(all_equipment, all_acts)

    # 12. ¿Pregunta por resumen, estadísticas, total de equipos o saludo inicial?
    if any(
        w in norm_q
        for w in [
            "resumen", "total", "cuantos equipos hay", "estadistica", "estadisticas",
            "estado del inventario", "reporte", "hola", "ayuda", "que puedes hacer", "como funciona"
        ]
    ) or not tokens:
        return await _finalize_with_optional_llm(
            req,
            _build_inventory_summary_response(all_equipment, all_warehouses, all_acts),
            all_equipment,
            all_warehouses,
            all_acts,
        )

    # 13. Fallback inteligente: si mencionó un nombre o término que no dio match exacto,
    # mostrar sugerencias útiles y el resumen actual del inventario
    return await _finalize_with_optional_llm(
        req,
        _build_not_found_helpful_response(user_query, all_equipment, all_warehouses, all_acts),
        all_equipment,
        all_warehouses,
        all_acts,
    )


# ==========================================
# MOTOR DE EJECUCIÓN DE ACCIONES Y COMANDOS POR VOZ / TEXTO
# ==========================================

ACTION_MOVE_KEYWORDS = [
    "mueve", "mover", "muevelo", "traslada", "trasladar", "trasladalo",
    "lleva", "llevar", "llevalo", "llevarlo", "voy a llevar",
    "cambia la ubicacion", "cambiar la ubicacion", "cambia su ubicacion", "cambiar su ubicacion",
    "cambia de ubicacion", "cambiar ubicacion", "cambia de almacen", "cambiar de almacen",
    "ubica", "ubicar", "ubicalo", "reubica", "reubicar", "reubicalo",
    "envia", "enviar", "envialo", "pasa", "pasar", "pasalo",
    "transfiere", "transferir", "transfierelo", "cambio de ubicacion",
]

ACTION_RETURN_KEYWORDS = [
    "devuelve", "devolver", "devuelvelo", "reingresa", "reingresar",
    "libera", "liberar", "liberalo", "pon disponible", "poner disponible",
    "ponlo disponible", "marca como disponible", "cambia a disponible",
]

ACTION_MAINT_KEYWORDS = [
    "a mantenimiento", "en mantenimiento", "a taller", "al taller",
    "a reparacion", "en reparacion",
]

ACTION_ASSIGN_KEYWORDS = [
    "asigna ", "asignar ", "asignalo ", "asignale ",
]

ACTION_VERBS_STOPWORDS = {
    "mueve", "mover", "muevelo", "muevelos", "traslada", "trasladar", "trasladalo", "trasladalos",
    "lleva", "llevar", "llevalo", "llevalos", "llevarlo", "voy", "cambia", "cambiar",
    "ubicacion", "almacen", "bodega", "sede", "ubica", "ubicar", "ubicalo",
    "reubica", "reubicar", "reubicalo", "envia", "enviar", "envialo", "envialos",
    "pasa", "pasar", "pasalo", "pasalos", "transfiere", "transferir", "transfierelo",
    "devuelve", "devolver", "devuelvelo", "reingresa", "reingresar",
    "libera", "liberar", "liberalo", "pon", "poner", "ponlo", "disponible",
    "mantenimiento", "taller", "reparacion", "asigna", "asignar", "asignalo",
    "asignale", "desde", "hasta", "hacia", "para", "tengo", "estoy", "este", "ese",
    "ahora", "vuelta", "regreso", "nuevo", "otra", "vez", "favor",
    "todo", "todos", "toda", "todas", "completo", "completa", "entero", "entera",
    "vacia", "vaciar", "equipo", "equipos", "unidad", "unidades", "cosa", "cosas",
    "primero", "primeros", "primera", "primeras", "menos", "excepto", "salvo",
    "estan", "esta", "hay", "que",
}

_PENDING_BULK_ACTIONS: Dict[str, Dict[str, Any]] = {}
BULK_CONFIRM_THRESHOLD = 10

SPANISH_NUMBER_WORDS = {
    "un": 1, "uno": 1, "una": 1,
    "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5,
    "seis": 6, "siete": 7, "ocho": 8, "nueve": 9, "diez": 10,
    "once": 11, "doce": 12, "quince": 15, "veinte": 20,
}


def _extract_quantity_for_bulk(norm_q: str, all_warehouses: List[Warehouse]) -> Optional[int]:
    """
    Extrae la cantidad solicitada en comandos como 'mueve 3 monitores',
    'pasa dos Apple TV' o 'traslada los primeros 5 equipos', ignorando números
    que formen parte de nombres de almacenes (Contenedor 1, Oficina P4, Almacén E1) o modelos (4K, 3S).
    """
    cleaned = norm_q
    for wh in all_warehouses:
        wh_norm = normalize_text(wh.name)
        cleaned = cleaned.replace(wh_norm, " ")
    # Limpiar modelos comunes con números para no confundirlos con cantidades
    cleaned = re.sub(r"\b(4k|3s|3a gen|cat6|e1|p4|s3)\b", " ", cleaned)
    # Limpiar posibles seriales alfanuméricos largos
    cleaned = re.sub(r"\b[a-z0-9]{6,}\b", " ", cleaned)

    m_digit = re.search(r"\b(?:los\s+primeros\s+|las\s+primeras\s+)?(\d{1,3})\b", cleaned)
    if m_digit:
        val = int(m_digit.group(1))
        if 1 <= val <= 500:
            return val

    for word, val in SPANISH_NUMBER_WORDS.items():
        if re.search(rf"\b(?:mueve|mover|traslada|trasladar|pasa|pasar|lleva|llevar|envia|enviar|transfiere|transferir|primeros|primeras)\s+(?:los\s+|las\s+)?{word}\b", cleaned):
            return val
        if re.search(rf"\b{word}\s+(?:equipos?|unidades?|monitores?|laptops?|computadoras?|apple|meta|teclados?|mouses?|cables?)\b", cleaned):
            return val
    return None


def _resolve_origin_from_history(req: AssistantQueryRequest, all_warehouses: List[Warehouse], target_wh: Optional[Warehouse]) -> Optional[Warehouse]:
    if not req.history:
        return None
    for h_item in reversed(req.history):
        h_norm = normalize_text(h_item.content)
        for wh in all_warehouses:
            if target_wh and wh.id == target_wh.id:
                continue
            if normalize_text(wh.name) in h_norm:
                return wh
    return None


async def _execute_bulk_transfer(
    targets: List[Equipment],
    target_wh: Warehouse,
    origin_label: str,
    user_query: str,
    db: AsyncSession,
    current_user: User,
) -> AssistantQueryResponse:
    moved_items: List[Equipment] = []
    for eq in targets:
        if eq.current_warehouse_id == target_wh.id:
            continue
        old_wh_id = eq.current_warehouse_id
        eq.current_warehouse_id = target_wh.id
        mov = Movement(
            type=MovementType.transfer,
            equipment_id=eq.id,
            from_warehouse_id=old_wh_id,
            to_warehouse_id=target_wh.id,
            performed_by=current_user.id,
            notes=f"Traslado masivo ejecutado por Rosco IA: {user_query}",
        )
        db.add(mov)
        moved_items.append(eq)

    await db.commit()

    if not moved_items:
        return AssistantQueryResponse(
            answer=f"ℹ️ Todos los equipos seleccionados ya se encontraban ubicados en **{target_wh.name}**.",
            intent="action_bulk_same_warehouse",
            cards=[],
            follow_up_suggestions=[f"¿Qué equipos hay en {target_wh.name}?", "Dame un resumen general del inventario"],
        )

    cards: List[AssistantActionCard] = []
    preview_lines: List[str] = []
    for eq in moved_items[:5]:
        preview_lines.append(f"• **{eq.name}** (`SN: {eq.serial_number}`)")
        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"SN: {eq.serial_number}",
                badge_text=target_wh.name,
                badge_color="emerald",
                details=[
                    {"label": "Origen", "value": origin_label},
                    {"label": "Nuevo Almacén", "value": target_wh.name},
                ],
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ver Ficha",
                secondary_link_url="/movements",
                secondary_link_label="Movimientos",
            )
        )

    extra_msg = f"\n*...y **{len(moved_items) - 5} equipo(s) más** trasladados.*" if len(moved_items) > 5 else ""
    return AssistantQueryResponse(
        answer=(
            f"✅ ¡Traslado masivo completado! He movido **{len(moved_items)} equipo(s)** desde **{origin_label}** "
            f"hacia **{target_wh.name}** y dejé registrado cada movimiento en la bitácora de auditoría.\n\n"
            + "\n".join(preview_lines)
            + extra_msg
        ),
        intent="action_bulk_transfer_done",
        action_performed=True,
        cards=cards,
        follow_up_suggestions=[
            f"¿Qué equipos hay ahora en {target_wh.name}?",
            "Muéstrame los últimos movimientos realizados",
            "Dame un resumen general del inventario",
        ],
    )


def _resolve_warehouses_in_command(
    norm_q: str,
    all_warehouses: List[Warehouse],
) -> tuple[Optional[Warehouse], Optional[Warehouse]]:
    """
    Detecta almacenes mencionados en la oración ordenados por su posición de aparición.
    Si se mencionan dos (ej. 'de Torre Avila a La Carlota'), el primero es origen y el último es destino.
    Si se menciona uno solo, es el almacén destino.
    """
    found_positions: List[tuple[int, Warehouse]] = []

    for wh in all_warehouses:
        wh_norm = normalize_text(wh.name)
        idx = norm_q.rfind(wh_norm)
        if idx != -1:
            found_positions.append((idx, wh))
            continue

        # Probar palabras distintivas del almacén (ej. 'carlota', 'avila', 'e1')
        distinct_words = [
            w for w in wh_norm.split()
            if w not in {"almacen", "sede", "bodega", "la", "el", "los", "las", "de", "del", "torre"}
            and len(w) >= 2
        ]
        for dw in distinct_words:
            m = re.search(rf"\b{re.escape(dw)}\b", norm_q)
            if m:
                found_positions.append((m.start(), wh))
                break

    if not found_positions:
        return None, None

    found_positions.sort(key=lambda x: x[0])
    if len(found_positions) == 1:
        return None, found_positions[0][1]
    return found_positions[0][1], found_positions[-1][1]


def _resolve_equipment_for_action(
    norm_q: str,
    tokens: List[str],
    req: AssistantQueryRequest,
    all_equipment: List[Equipment],
    all_warehouses: List[Warehouse],
    origin_wh: Optional[Warehouse],
) -> List[Equipment]:
    """
    Identifica el equipo objetivo del comando:
    1) Por serial o código de barras en la frase actual (incluyendo dictado con espacios o sufijo >= 5 chars).
    2) Por código recién escaneado.
    3) Por nombre/marca/modelo mencionado en la frase.
    4) Por memoria contextual del último equipo consultado en el historial del chat.
    """
    # 1. Buscar serial directo o sufijo en norm_q
    q_collapsed = re.sub(r"[^a-z0-9]", "", norm_q)
    serial_matches: List[Equipment] = []
    for eq in all_equipment:
        sn_norm = normalize_text(eq.serial_number)
        sn_collapsed = re.sub(r"[^a-z0-9]", "", sn_norm)
        bc_norm = normalize_text(eq.barcode or "")

        if sn_norm and (sn_norm in norm_q or (len(sn_collapsed) >= 5 and sn_collapsed in q_collapsed)):
            serial_matches.append(eq)
            continue

        for tok in tokens:
            tok_clean = re.sub(r"[^a-z0-9]", "", tok)
            if len(tok_clean) >= 5 and (
                tok_clean == sn_collapsed
                or sn_collapsed.endswith(tok_clean)
                or (bc_norm and tok_clean == re.sub(r"[^a-z0-9]", "", bc_norm))
            ):
                if eq not in serial_matches:
                    serial_matches.append(eq)

    if serial_matches:
        return serial_matches

    # 2. Si hay términos descriptivos del equipo (excluyendo verbos de acción y nombres de almacenes)
    wh_words = {
        w
        for wh in all_warehouses
        for w in normalize_text(wh.name).split()
        if len(w) >= 2
    }
    eq_tokens = [
        t for t in tokens
        if t not in ACTION_VERBS_STOPWORDS and t not in wh_words
    ]

    if eq_tokens:
        cat_filter = _detect_category(norm_q)
        candidates = _search_equipment_by_tokens(eq_tokens, all_equipment, cat_filter, None)
        if not candidates and cat_filter:
            candidates = [e for e in all_equipment if normalize_text(e.category) == cat_filter]

        if candidates:
            if origin_wh:
                in_origin = [e for e in candidates if e.current_warehouse_id == origin_wh.id]
                if in_origin:
                    return in_origin
            return candidates

    # 3. Memoria contextual: buscar el último serial mencionado en el historial de la conversación
    if req.history:
        for h_item in reversed(req.history):
            h_norm = normalize_text(h_item.content)
            for eq in all_equipment:
                sn_norm = normalize_text(eq.serial_number)
                if sn_norm and len(sn_norm) >= 5 and sn_norm in h_norm:
                    return [eq]

    return []


async def _try_execute_voice_action(
    user_query: str,
    norm_q: str,
    tokens: List[str],
    req: AssistantQueryRequest,
    db: AsyncSession,
    current_user: User,
    all_equipment: List[Equipment],
    all_warehouses: List[Warehouse],
    serial_to_act: Dict[str, DeliveryAct],
) -> Optional[AssistantQueryResponse]:
    """
    Evalúa si el mensaje del usuario es una orden operativa (traslado individual o masivo/selectivo
    entre almacenes, enviar a mantenimiento, devolver o asignar) y la ejecuta con registro de auditoría.
    """
    user_key = str(current_user.id)

    # 0. Verificar si hay una confirmación o cancelación pendiente de traslado masivo
    if user_key in _PENDING_BULK_ACTIONS:
        pending = _PENDING_BULK_ACTIONS[user_key]
        is_confirm = any(
            p in norm_q
            for p in ["si, confirmo", "si confirmo", "confirmo", "confirmar", "dale", "hazlo", "procede", "ejecuta", "aceptar", "si adelante"]
        ) or norm_q.strip() in {"si", "ok", "yes"}
        is_cancel = any(p in norm_q for p in ["cancelar", "cancela", "no", "olvidalo", "detener", "abortar"])

        if is_confirm:
            _PENDING_BULK_ACTIONS.pop(user_key, None)
            eq_ids = set(pending["equipment_ids"])
            targets = [e for e in all_equipment if str(e.id) in eq_ids]
            target_wh_obj = next((w for w in all_warehouses if str(w.id) == str(pending["target_wh_id"])), None)
            if targets and target_wh_obj:
                return await _execute_bulk_transfer(
                    targets=targets,
                    target_wh=target_wh_obj,
                    origin_label=pending["origin_label"],
                    user_query=pending["user_query"],
                    db=db,
                    current_user=current_user,
                )
        elif is_cancel:
            _PENDING_BULK_ACTIONS.pop(user_key, None)
            return AssistantQueryResponse(
                answer="🛑 Traslado masivo cancelado. No se realizó ningún movimiento en el inventario.",
                intent="action_bulk_cancelled",
                cards=[],
                follow_up_suggestions=["Dame un resumen general del inventario"],
            )

    is_maint_cmd = any(p in norm_q for p in ACTION_MAINT_KEYWORDS) and any(
        v in norm_q for v in ["pasa", "pasar", "pasalo", "envia", "enviar", "envialo", "manda", "pon", "poner", "ponlo", "cambia", "marca", "mueve", "lleva", "registra"]
    )
    is_return_cmd = any(p in norm_q for p in ACTION_RETURN_KEYWORDS)
    is_move_cmd = any(p in norm_q for p in ACTION_MOVE_KEYWORDS)
    is_assign_cmd = any(p in norm_q for p in ACTION_ASSIGN_KEYWORDS) and " a " in norm_q

    if not (is_maint_cmd or is_return_cmd or is_move_cmd or is_assign_cmd):
        return None

    origin_wh, target_wh = _resolve_warehouses_in_command(norm_q, all_warehouses)

    # Si es un comando de movimiento/traslado pero no menciona almacén destino ni es mantenimiento/devolución/asignación
    if is_move_cmd and not (target_wh or is_maint_cmd or is_return_cmd or is_assign_cmd):
        return None

    # ------------------------------------------------------------------
    # 0.5 DETECCIÓN DE TRASLADO MASIVO O SELECTIVO ENTRE ALMACENES
    # (Ej: "mueve todo lo de Oficina P4 a Torre Avila", "mueve 3 monitores
    #  de Torre Avila a La Carlota", "pasa los Apple TV de Oficina P4 a La Carlota")
    # ------------------------------------------------------------------
    is_move_all = any(
        re.search(rf"\b{kw}\b", norm_q)
        for kw in ["todo", "todos", "toda", "todas", "completo", "completa", "vaciar", "vacia", "entero"]
    )
    requested_qty = _extract_quantity_for_bulk(norm_q, all_warehouses)
    has_plural_hint = any(
        re.search(rf"\b{kw}\b", norm_q)
        for kw in [
            "los", "las", "primeros", "primeras", "equipos", "unidades",
            "monitores", "laptops", "computadoras", "teclados", "mouses", "cables",
        ]
    )

    # Si el usuario dijo "mueve los primeros 3 a Torre Avila", intentar inferir origen del historial
    if not origin_wh and target_wh and (is_move_all or requested_qty or "primeros" in norm_q or "primeras" in norm_q):
        origin_wh = _resolve_origin_from_history(req, all_warehouses, target_wh)

    # Caso: pidió "mover todo a <destino>" sin indicar almacén de origen
    if is_move_cmd and target_wh and is_move_all and not origin_wh and not any(t in norm_q for t in ["serial", "equipo "]):
        wh_options = [
            w for w in all_warehouses
            if w.id != target_wh.id and any(e.current_warehouse_id == w.id for e in all_equipment)
        ]
        follow_ups = [
            f"Mover todo lo de {w.name} a {target_wh.name}"
            for w in wh_options[:4]
        ]
        return AssistantQueryResponse(
            answer=(
                f"Entendí que deseas trasladar todo hacia **{target_wh.name}**, pero necesito saber **desde qué almacén de origen** quieres mover los equipos.\n\n"
                "Por favor indícame por voz o toca una de las opciones de abajo:"
            ),
            intent="action_bulk_need_origin",
            cards=[],
            follow_up_suggestions=follow_ups or ["Dame un resumen general del inventario"],
        )

    matched_eqs = _resolve_equipment_for_action(
        norm_q=norm_q,
        tokens=tokens,
        req=req,
        all_equipment=all_equipment,
        all_warehouses=all_warehouses,
        origin_wh=origin_wh,
    )

    # Evaluar si aplica traslado masivo/selectivo en bloque
    is_bulk_eligible = (
        is_move_cmd
        and target_wh is not None
        and not is_maint_cmd
        and not is_return_cmd
        and not is_assign_cmd
        and (
            is_move_all
            or requested_qty is not None
            or (origin_wh is not None and len(matched_eqs) > 1 and has_plural_hint)
            or (origin_wh is not None and len(matched_eqs) == 0 and any(w in norm_q for w in ["todo", "todos", "lo que esta", "lo de", "equipos"]))
        )
    )

    if is_bulk_eligible:
        # Determinar conjunto candidato en el almacén origen (o global si pidió cantidad de un modelo)
        if origin_wh:
            wh_pool = [e for e in all_equipment if e.current_warehouse_id == origin_wh.id]
            origin_label = origin_wh.name
        else:
            wh_pool = [e for e in all_equipment if e.current_warehouse_id != target_wh.id]
            origin_label = "varios almacenes"

        # Filtrar por tipo/marca/modelo si mencionó algo específico (ej. "monitores", "Apple TV", "Lenovo")
        wh_words = {
            w for wh in all_warehouses for w in normalize_text(wh.name).split() if len(w) >= 2
        }
        eq_filter_tokens = [
            t for t in tokens
            if t not in ACTION_VERBS_STOPWORDS and t not in wh_words and not t.isdigit()
        ]
        # Si mencionó exclusiones ("menos el serial X" / "excepto X"), separar el serial excluido
        excluded_serials = set()
        m_excl = re.search(r"\b(?:menos|excepto|salvo)\b(.+)$", norm_q)
        if m_excl:
            excl_part = m_excl.group(1)
            for eq in wh_pool:
                sn_norm = normalize_text(eq.serial_number)
                if sn_norm and sn_norm in excl_part:
                    excluded_serials.add(sn_norm)
            # Limpiar tokens de la cláusula de exclusión para no filtrar el resto por ese serial
            excl_tokens = set(extract_meaningful_tokens(excl_part))
            eq_filter_tokens = [t for t in eq_filter_tokens if t not in excl_tokens]

        cat_filter = _detect_category(norm_q)
        if eq_filter_tokens or cat_filter:
            filtered = _search_equipment_by_tokens(eq_filter_tokens, wh_pool, cat_filter, None)
            if not filtered and cat_filter:
                filtered = [e for e in wh_pool if normalize_text(e.category) == cat_filter]
            bulk_targets = filtered
        else:
            bulk_targets = wh_pool

        if excluded_serials:
            bulk_targets = [
                e for e in bulk_targets
                if normalize_text(e.serial_number) not in excluded_serials
            ]

        # Excluir los que ya están en destino
        bulk_targets = [e for e in bulk_targets if e.current_warehouse_id != target_wh.id]

        if not bulk_targets:
            return AssistantQueryResponse(
                answer=(
                    f"ℹ️ No encontré equipos pendientes por trasladar desde **{origin_label}** hacia **{target_wh.name}** "
                    "con ese criterio."
                ),
                intent="action_bulk_empty",
                cards=[],
                follow_up_suggestions=[
                    f"¿Qué equipos hay en {origin_label}?" if origin_wh else "Dame un resumen general del inventario",
                    f"¿Qué equipos hay en {target_wh.name}?",
                ],
            )

        # Aplicar límite por cantidad si pidió N unidades (ej. "mueve 3 monitores")
        if requested_qty is not None and requested_qty > 0:
            bulk_targets = bulk_targets[:requested_qty]

        # Confirmación de seguridad si supera el umbral (> 10 equipos)
        if len(bulk_targets) > BULK_CONFIRM_THRESHOLD:
            _PENDING_BULK_ACTIONS[user_key] = {
                "equipment_ids": [str(e.id) for e in bulk_targets],
                "origin_label": origin_label,
                "target_wh_id": str(target_wh.id),
                "target_wh_name": target_wh.name,
                "user_query": user_query,
            }
            return AssistantQueryResponse(
                answer=(
                    f"⚠️ **Confirmación de Seguridad:** Estás por trasladar **{len(bulk_targets)} equipos** "
                    f"desde **{origin_label}** hacia **{target_wh.name}**.\n\n"
                    "Para proteger tu inventario contra comandos accidentales, dime **\"Sí, confirmo\"** (o toca el botón de confirmar abajo) para ejecutar el traslado masivo."
                ),
                intent="action_bulk_confirm",
                cards=[
                    AssistantActionCard(
                        card_type="warehouse",
                        title=f"Traslado Masivo: {len(bulk_targets)} equipos",
                        subtitle=f"{origin_label} ➔ {target_wh.name}",
                        badge_text="Requiere Confirmación",
                        badge_color="amber",
                        details=[
                            {"label": "Origen", "value": origin_label},
                            {"label": "Destino", "value": target_wh.name},
                            {"label": "Cantidad", "value": f"{len(bulk_targets)} equipos"},
                        ],
                        action_command="Sí, confirmo el traslado",
                        action_label=f"✓ Confirmar ({len(bulk_targets)} equipos)",
                    )
                ],
                follow_up_suggestions=["Sí, confirmo el traslado", "Cancelar"],
            )

        return await _execute_bulk_transfer(
            targets=bulk_targets,
            target_wh=target_wh,
            origin_label=origin_label,
            user_query=user_query,
            db=db,
            current_user=current_user,
        )

    # Si no se especificó qué equipo mover
    if not matched_eqs:
        wh_dest_str = f" a **{target_wh.name}**" if target_wh else ""
        sample_eqs = [
            e for e in all_equipment
            if not origin_wh or e.current_warehouse_id == origin_wh.id
        ][:3]
        follow_ups = [
            f"Mover el equipo {e.serial_number} a {target_wh.name}"
            for e in sample_eqs
        ] if target_wh else ["Dame un resumen general del inventario"]

        return AssistantQueryResponse(
            answer=(
                f"Entendí que deseas realizar un movimiento{wh_dest_str}, pero necesito saber **cuál equipo o número de serie** deseas mover.\n\n"
                "Puedes decirme por voz por ejemplo: *\"Mueve el equipo CN2K2D72TN a La Carlota\"* o tocar uno de los botones sugeridos abajo:"
            ),
            intent="action_need_equipment",
            cards=[],
            follow_up_suggestions=follow_ups,
        )

    # Si hay varios equipos que coinciden con un nombre genérico (ej. 'Mueve el Apple TV a La Carlota')
    if len(matched_eqs) > 1 and target_wh:
        lines = [
            f"Encontré **{len(matched_eqs)} unidades** que coinciden con tu indicación para trasladar a **{target_wh.name}**.",
            "Por favor, toca en la tarjeta cuál de los seriales deseas mover ahora mismo (o dímelo por voz):",
            "",
        ]
        cards: List[AssistantActionCard] = []
        follow_ups: List[str] = []

        for eq in matched_eqs[:5]:
            cur_wh_name = eq.current_warehouse.name if eq.current_warehouse else "Sin almacén"
            cmd_str = f"Mover el equipo {eq.serial_number} a {target_wh.name}"
            lines.append(f"• **{eq.name}** (`SN: {eq.serial_number}`) — Ubicación actual: **{cur_wh_name}**")
            follow_ups.append(cmd_str)
            cards.append(
                AssistantActionCard(
                    card_type="equipment",
                    title=eq.name,
                    subtitle=f"SN: {eq.serial_number}",
                    badge_text=cur_wh_name,
                    badge_color="sky",
                    details=[
                        {"label": "Origen", "value": cur_wh_name},
                        {"label": "Destino", "value": target_wh.name},
                    ],
                    action_command=cmd_str,
                    action_label=f"⇄ Mover a {target_wh.name}",
                    link_url=f"/eq/{eq.serial_number}",
                    link_label="Ver Ficha",
                )
            )

        return AssistantQueryResponse(
            answer="\n".join(lines),
            intent="action_disambiguate",
            cards=cards,
            follow_up_suggestions=follow_ups[:3],
        )

    target_eq = matched_eqs[0]
    old_wh_id = target_eq.current_warehouse_id
    old_wh_name = target_eq.current_warehouse.name if target_eq.current_warehouse else "Sin almacén previo"

    # ----------------------------------------------------------
    # ACCIÓN 1: ENVIAR A MANTENIMIENTO
    # ----------------------------------------------------------
    if is_maint_cmd:
        target_eq.status = EquipmentStatus.maintenance
        mov = Movement(
            type=MovementType.maintenance,
            equipment_id=target_eq.id,
            from_warehouse_id=old_wh_id,
            to_warehouse_id=target_wh.id if target_wh else old_wh_id,
            performed_by=current_user.id,
            notes=f"Registrado por comando de voz IA: {user_query}",
        )
        if target_wh:
            target_eq.current_warehouse_id = target_wh.id
        db.add(mov)
        await db.commit()

        return AssistantQueryResponse(
            answer=(
                f"✅ ¡Listo! He cambiado el estado del equipo **{target_eq.name}** (`SN: {target_eq.serial_number}`) "
                f"a **En Mantenimiento** y registré el movimiento en el historial de auditoría."
            ),
            intent="action_maintenance_done",
            action_performed=True,
            cards=[
                AssistantActionCard(
                    card_type="equipment",
                    title=target_eq.name,
                    subtitle=f"SN: {target_eq.serial_number}",
                    badge_text="En Mantenimiento",
                    badge_color="amber",
                    details=[
                        {"label": "Nuevo Estado", "value": "En Mantenimiento"},
                        {"label": "Ubicación", "value": target_wh.name if target_wh else old_wh_name},
                    ],
                    link_url=f"/eq/{target_eq.serial_number}",
                    link_label="Ver Ficha Técnica",
                    secondary_link_url="/movements",
                    secondary_link_label="Ver Movimientos",
                )
            ],
            follow_up_suggestions=[
                f"¿Cuál es el estado y ubicación del equipo {target_eq.serial_number}?",
                "Dame un resumen general del inventario",
            ],
        )

    # ----------------------------------------------------------
    # ACCIÓN 2: ASIGNAR A UNA PERSONA POR VOZ
    # ----------------------------------------------------------
    if is_assign_cmd and not target_wh:
        # Extraer el nombre de la persona después de ' a '
        m_person = re.search(r"(?:asigna|asignar|asignalo|asignale).*?\ba\s+([a-záéíóúñ\s]{3,40})$", user_query, re.IGNORECASE)
        if m_person:
            person_name = m_person.group(1).strip().title()
            target_eq.status = EquipmentStatus.assigned
            target_eq.assigned_to = person_name
            mov = Movement(
                type=MovementType.exit,
                equipment_id=target_eq.id,
                from_warehouse_id=old_wh_id,
                to_warehouse_id=old_wh_id,
                performed_by=current_user.id,
                assigned_to=person_name,
                notes=f"Asignación por comando de voz IA: {user_query}",
            )
            db.add(mov)
            await db.commit()

            return AssistantQueryResponse(
                answer=(
                    f"✅ ¡Hecho! He asignado el equipo **{target_eq.name}** (`SN: {target_eq.serial_number}`) "
                    f"a **{person_name}** y registré la salida en el historial de movimientos."
                ),
                intent="action_assign_done",
                action_performed=True,
                cards=[
                    AssistantActionCard(
                        card_type="equipment",
                        title=target_eq.name,
                        subtitle=f"SN: {target_eq.serial_number}",
                        badge_text="Asignado",
                        badge_color="sky",
                        details=[
                            {"label": "Asignado a", "value": person_name},
                            {"label": "Sede Base", "value": old_wh_name},
                        ],
                        link_url=f"/eq/{target_eq.serial_number}",
                        link_label="Ver Ficha Técnica",
                        secondary_link_url="/movements",
                        secondary_link_label="Ver Movimientos",
                    )
                ],
                follow_up_suggestions=[
                    f"¿Cuál es el estado y ubicación del equipo {target_eq.serial_number}?",
                    "Dame un resumen general del inventario",
                ],
            )

    # ----------------------------------------------------------
    # ACCIÓN 3: DEVOLUCIÓN / LIBERAR EQUIPO A DISPONIBLE
    # ----------------------------------------------------------
    if is_return_cmd:
        dest_wh = target_wh or target_eq.current_warehouse or (all_warehouses[0] if all_warehouses else None)
        prev_custodian = target_eq.assigned_to
        target_eq.status = EquipmentStatus.available
        target_eq.assigned_to = None
        if dest_wh:
            target_eq.current_warehouse_id = dest_wh.id

        mov = Movement(
            type=MovementType.return_item,
            equipment_id=target_eq.id,
            from_warehouse_id=old_wh_id,
            to_warehouse_id=dest_wh.id if dest_wh else old_wh_id,
            performed_by=current_user.id,
            assigned_to=prev_custodian,
            notes=f"Devolución registrada por comando de voz IA: {user_query}",
        )
        db.add(mov)
        await db.commit()

        dest_name = dest_wh.name if dest_wh else old_wh_name
        return AssistantQueryResponse(
            answer=(
                f"✅ ¡Listo! He registrado la devolución del equipo **{target_eq.name}** (`SN: {target_eq.serial_number}`). "
                f"Ahora se encuentra **Disponible** en el almacén **{dest_name}**."
            ),
            intent="action_return_done",
            action_performed=True,
            cards=[
                AssistantActionCard(
                    card_type="equipment",
                    title=target_eq.name,
                    subtitle=f"SN: {target_eq.serial_number}",
                    badge_text="Disponible",
                    badge_color="emerald",
                    details=[
                        {"label": "Estado Actual", "value": "Disponible"},
                        {"label": "Almacén", "value": dest_name},
                    ],
                    link_url=f"/eq/{target_eq.serial_number}",
                    link_label="Ver Ficha Técnica",
                    secondary_link_url="/movements",
                    secondary_link_label="Ver Movimientos",
                )
            ],
            follow_up_suggestions=[
                f"¿Qué equipos están disponibles en {dest_name}?",
                "Dame un resumen general del inventario",
            ],
        )

    # ----------------------------------------------------------
    # ACCIÓN 4: TRASLADO / CAMBIO DE UBICACIÓN ENTRE ALMACENES
    # ----------------------------------------------------------
    if target_wh:
        if old_wh_id == target_wh.id:
            return AssistantQueryResponse(
                answer=(
                    f"ℹ️ El equipo **{target_eq.name}** (`SN: {target_eq.serial_number}`) "
                    f"**ya se encuentra ubicado en {target_wh.name}**."
                ),
                intent="action_transfer_same",
                cards=[
                    AssistantActionCard(
                        card_type="equipment",
                        title=target_eq.name,
                        subtitle=f"SN: {target_eq.serial_number}",
                        badge_text=target_wh.name,
                        badge_color="emerald",
                        details=[
                            {"label": "Ubicación Actual", "value": target_wh.name},
                            {"label": "Serial", "value": target_eq.serial_number},
                        ],
                        link_url=f"/eq/{target_eq.serial_number}",
                        link_label="Ver Ficha Técnica",
                    )
                ],
                follow_up_suggestions=[
                    f"¿Qué equipos están disponibles en {target_wh.name}?",
                    "Dame un resumen general del inventario",
                ],
            )

        target_eq.current_warehouse_id = target_wh.id
        # Si estaba en otro estado no asignado, asegurar que esté disponible en el nuevo almacén
        mov = Movement(
            type=MovementType.transfer,
            equipment_id=target_eq.id,
            from_warehouse_id=old_wh_id,
            to_warehouse_id=target_wh.id,
            performed_by=current_user.id,
            notes=f"Traslado ejecutado por comando de voz IA desde {old_wh_name} hacia {target_wh.name}",
        )
        db.add(mov)
        await db.commit()

        st_label, st_color = STATUS_LABELS.get(status_str(target_eq.status), ("Disponible", "emerald"))

        return AssistantQueryResponse(
            answer=(
                f"✅ ¡Traslado completado! He cambiado la ubicación del equipo **{target_eq.name}** "
                f"(`SN: {target_eq.serial_number}`) desde **{old_wh_name}** hacia **{target_wh.name}** "
                f"y dejé registrado el movimiento en el historial de auditoría."
            ),
            intent="action_transfer_done",
            action_performed=True,
            cards=[
                AssistantActionCard(
                    card_type="equipment",
                    title=target_eq.name,
                    subtitle=f"SN: {target_eq.serial_number}",
                    badge_text=st_label,
                    badge_color=st_color,
                    details=[
                        {"label": "Almacén Anterior", "value": old_wh_name},
                        {"label": "Nueva Ubicación", "value": target_wh.name},
                    ],
                    link_url=f"/eq/{target_eq.serial_number}",
                    link_label="Ver Ficha Actualizada",
                    secondary_link_url="/movements",
                    secondary_link_label="Ver en Movimientos",
                )
            ],
            follow_up_suggestions=[
                f"¿Qué equipos están disponibles en {target_wh.name}?",
                "Muéstrame los últimos movimientos registrados",
                "Dame un resumen general del inventario",
            ],
        )

    return None


# ==========================================
# FUNCIONES DE BÚSQUEDA Y CONSTRUCCIÓN DE RESPUESTAS
# ==========================================

def _find_matching_people(
    norm_q: str,
    tokens: List[str],
    all_equipment: List[Equipment],
    all_acts: List[DeliveryAct],
) -> List[Dict[str, Any]]:
    """Busca trabajadores por nombre o cédula tanto en equipos asignados como en actas emitidas."""
    people_map: Dict[str, Dict[str, Any]] = {}

    for act in all_acts:
        name = (act.recipient_name or "").strip()
        if not name:
            continue
        key = normalize_text(name)
        if key not in people_map:
            people_map[key] = {
                "name": name,
                "id_card": act.recipient_id_card or "",
                "position": act.recipient_position or "",
                "department": act.recipient_department or "",
            }

    for eq in all_equipment:
        if eq.assigned_to and eq.assigned_to.strip():
            name = eq.assigned_to.strip()
            key = normalize_text(name)
            if key not in people_map:
                people_map[key] = {
                    "name": name,
                    "id_card": "",
                    "position": "",
                    "department": "",
                }

    matches = []
    # Limpiar puntos de cédula para comparar números
    q_digits = re.sub(r"\D", "", norm_q)

    for key, info in people_map.items():
        name_parts = [p for p in key.split() if len(p) >= 3]
        id_digits = re.sub(r"\D", "", info["id_card"])

        # Match por cédula
        if q_digits and len(q_digits) >= 5 and id_digits and q_digits in id_digits:
            matches.append((100, info))
            continue

        # Match por nombre completo en la pregunta
        if key in norm_q:
            matches.append((90, info))
            continue

        # Match por partes del nombre (ej. "Michelle", "Arenas", "Siloes")
        matched_parts = sum(1 for part in name_parts if part in tokens or any( part in t for t in tokens if len(t) >= 4 ))
        if matched_parts > 0:
            score = matched_parts * 40
            matches.append((score, info))

    matches.sort(key=lambda x: x[0], reverse=True)
    return [m[1] for m in matches]


def _find_matching_warehouse(
    norm_q: str,
    tokens: List[str],
    warehouses: List[Warehouse],
) -> Optional[Warehouse]:
    best_wh = None
    best_score = 0
    for wh in warehouses:
        wh_norm = normalize_text(wh.name)
        loc_norm = normalize_text(wh.location or "")
        if wh_norm in norm_q:
            return wh
        wh_words = [w for w in wh_norm.split() if w not in STOPWORDS and len(w) >= 3]
        score = sum(1 for w in wh_words if w in tokens)
        if loc_norm:
            loc_words = [w for w in loc_norm.split() if w not in STOPWORDS and len(w) >= 3]
            score += sum(1 for w in loc_words if w in tokens)
        if score > best_score:
            best_score = score
            best_wh = wh
    return best_wh if best_score > 0 else None


def _detect_category(norm_q: str) -> Optional[str]:
    for cat_key, synonyms in CATEGORY_SYNONYMS.items():
        for syn in synonyms:
            if re.search(rf"\b{re.escape(syn)}\b", norm_q):
                return cat_key
    return None


def _detect_status(norm_q: str) -> Optional[str]:
    if any(w in norm_q for w in ["disponible", "disponibles", "en stock", "libres"]):
        return "available"
    if any(w in norm_q for w in ["en mantenimiento", "en reparacion", "averiado", "averiados", "danado"]):
        return "maintenance"
    if any(w in norm_q for w in ["de baja", "retirado", "retirados", "desincorporado"]):
        return "retired"
    if any(w in norm_q for w in ["extraviado", "extraviados", "perdido", "perdidos", "robado"]):
        return "lost"
    return None


def _search_equipment_by_tokens(
    tokens: List[str],
    all_equipment: List[Equipment],
    category_filter: Optional[str],
    status_filter: Optional[str],
) -> List[Equipment]:
    if not tokens:
        return []

    # Filtrar tokens que sean simplemente sinónimos de categoría o estado
    cat_words = {w for syns in CATEGORY_SYNONYMS.values() for w in syns}
    status_words = {"disponible", "disponibles", "asignado", "asignados", "mantenimiento", "baja", "perdido", "stock"}
    search_tokens = [t for t in tokens if t not in cat_words and t not in status_words]

    if not search_tokens:
        return []

    scored: List[tuple[int, Equipment]] = []
    for eq in all_equipment:
        if category_filter and normalize_text(eq.category) != category_filter:
            continue
        if status_filter and status_str(eq.status) != status_filter:
            continue

        haystack = " ".join([
            normalize_text(eq.name),
            normalize_text(eq.brand or ""),
            normalize_text(eq.model or ""),
            normalize_text(eq.serial_number),
            normalize_text(eq.barcode or ""),
            normalize_text(eq.notes or ""),
        ])

        score = 0
        for tok in search_tokens:
            if tok in haystack:
                score += 30
                if tok in normalize_text(eq.serial_number) or tok in normalize_text(eq.name):
                    score += 20

        if score > 0:
            scored.append((score, eq))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [item[1] for item in scored]


def _build_equipment_detail_response(
    items: List[Equipment],
    serial_to_act: Dict[str, DeliveryAct],
    all_equipment: List[Equipment],
) -> AssistantQueryResponse:
    cards: List[AssistantActionCard] = []
    lines: List[str] = []

    if len(items) == 1:
        eq = items[0]
        st = status_str(eq.status)
        st_label, st_color = STATUS_LABELS.get(st, (st, "slate"))
        act = serial_to_act.get(normalize_text(eq.serial_number))

        lines.append(f"He localizado el equipo **{eq.name}** (`SN: {eq.serial_number}`):")
        lines.append("")
        lines.append(f"• **Estado actual:** {st_label}")

        if st == "assigned" and eq.assigned_to:
            lines.append(f"• **Asignado a:** **{eq.assigned_to}**")
            if act:
                lines.append(
                    f"• **Datos del Custodio:** C.I: `{act.recipient_id_card}`"
                    + (f" • {act.recipient_position}" if act.recipient_position else "")
                    + (f" ({act.recipient_department})" if act.recipient_department else "")
                )
                lines.append(f"• **Acta de Entrega:** `{act.act_number}`")
        else:
            wh_name = eq.current_warehouse.name if eq.current_warehouse else "Sin almacén asignado"
            wh_loc = f" ({eq.current_warehouse.location})" if eq.current_warehouse and eq.current_warehouse.location else ""
            lines.append(f"• **Ubicación física:** Almacén **{wh_name}**{wh_loc}")
            if eq.assigned_to:
                lines.append(f"• **Referencia / Custodio:** {eq.assigned_to}")

        if eq.brand or eq.model:
            lines.append(f"• **Marca / Modelo:** {eq.brand or ''} {eq.model or ''}".strip())
        if eq.notes:
            lines.append(f"• **Especificaciones / Notas:** {eq.notes}")
        if eq.maintenances:
            lines.append(f"• **Hoja de Vida:** {len(eq.maintenances)} registro(s) de mantenimiento")

        details = [
            {"label": "Serial (SN)", "value": eq.serial_number},
            {"label": "Categoría", "value": CATEGORY_DISPLAY.get(normalize_text(eq.category), eq.category.upper())},
        ]
        if st == "assigned" and eq.assigned_to:
            details.append({"label": "En poder de", "value": eq.assigned_to})
            if act:
                details.append({"label": "Acta Firmada", "value": act.act_number})
        else:
            details.append({
                "label": "Ubicación",
                "value": eq.current_warehouse.name if eq.current_warehouse else "Sin almacén"
            })

        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"{eq.brand or ''} {eq.model or ''}".strip() or "Equipo Tecnológico",
                badge_text=st_label,
                badge_color=st_color,
                details=details,
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ver Ficha Técnica",
                secondary_link_url=f"/verify-act/{act.act_number}" if act else "/equipment",
                secondary_link_label=f"Ver {act.act_number}" if act else "Ir a Inventario",
            )
        )

        follow_ups = []
        if st == "assigned":
            follow_ups.append("¿Cuántos equipos se encuentran asignados actualmente?")
        if eq.current_warehouse:
            follow_ups.append(f"¿Qué otros equipos hay en {eq.current_warehouse.name}?")
        follow_ups.append("Dame un resumen general del inventario")

        return AssistantQueryResponse(
            answer="\n".join(lines),
            intent="equipment_detail",
            cards=cards,
            follow_up_suggestions=follow_ups[:3],
        )

    # Varios equipos encontrados
    lines.append(f"Encontré **{len(items)} equipos** que coinciden con tu consulta:")
    lines.append("")

    for eq in items[:6]:
        st = status_str(eq.status)
        st_label, st_color = STATUS_LABELS.get(st, (st, "slate"))
        act = serial_to_act.get(normalize_text(eq.serial_number))
        location_or_person = (
            f"Asignado a **{eq.assigned_to}**"
            if st == "assigned" and eq.assigned_to
            else f"Ubicado en **{eq.current_warehouse.name if eq.current_warehouse else 'Sin almacén'}**"
        )
        lines.append(f"• **{eq.name}** (`{eq.serial_number}`) — {st_label} • {location_or_person}")

        details = [
            {"label": "Serial", "value": eq.serial_number},
            {
                "label": "Custodio" if st == "assigned" and eq.assigned_to else "Almacén",
                "value": eq.assigned_to if st == "assigned" and eq.assigned_to else (eq.current_warehouse.name if eq.current_warehouse else "N/A"),
            },
        ]
        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"SN: {eq.serial_number}",
                badge_text=st_label,
                badge_color=st_color,
                details=details,
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ficha QR",
                secondary_link_url=f"/verify-act/{act.act_number}" if act else None,
                secondary_link_label=f"Acta {act.act_number}" if act else None,
            )
        )

    if len(items) > 6:
        lines.append(f"\n*(Mostrando los primeros 6 de {len(items)} resultados)*")

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="equipment_multiple",
        cards=cards,
        follow_up_suggestions=[
            f"¿Quién tiene el equipo {items[0].serial_number}?",
            "¿Qué equipos están disponibles?",
            "Dame un resumen general del inventario",
        ],
    )


def _build_person_custody_response(
    person_info: Dict[str, Any],
    all_equipment: List[Equipment],
    all_acts: List[DeliveryAct],
) -> AssistantQueryResponse:
    p_name = person_info["name"]
    p_norm = normalize_text(p_name)
    p_id = person_info.get("id_card") or ""

    # 1. Equipos actualmente marcados como 'assigned' a esta persona en la tabla Equipment
    assigned_eqs = [
        e for e in all_equipment
        if e.assigned_to and (p_norm in normalize_text(e.assigned_to) or normalize_text(e.assigned_to) in p_norm)
    ]

    # 2. Actas emitidas a nombre de esta persona
    person_acts = [
        a for a in all_acts
        if p_norm in normalize_text(a.recipient_name) or normalize_text(a.recipient_name) in p_norm
        or (p_id and p_id == a.recipient_id_card)
    ]
    assignment_acts = [a for a in person_acts if a.act_type == "assignment"]
    return_acts = [a for a in person_acts if a.act_type == "return"]

    # Recopilar equipos en actas por si alguno fue registrado manualmente en el acta
    act_items_map: Dict[str, DeliveryActItem] = {}
    for act in assignment_acts:
        for it in act.items:
            act_items_map[normalize_text(it.serial_number)] = it

    total_count = max(len(assigned_eqs), len(act_items_map))

    lines: List[str] = []
    header_meta = []
    if person_info.get("id_card"):
        header_meta.append(f"C.I: `{person_info['id_card']}`")
    if person_info.get("position"):
        header_meta.append(person_info["position"])
    if person_info.get("department"):
        header_meta.append(person_info["department"])
    meta_str = f" ({' • '.join(header_meta)})" if header_meta else ""

    if total_count == 0:
        lines.append(f"Actualmente **{p_name}**{meta_str} **no tiene equipos activos asignados** en el inventario.")
        if return_acts:
            lines.append(f"\n✅ Cuenta con **{len(return_acts)} acta(s) de devolución / solvencia** registrada(s).")
    else:
        plural = "equipo asignado" if total_count == 1 else "equipos asignados"
        lines.append(f"👤 **{p_name}**{meta_str} tiene actualmente **{total_count} {plural}**:")
        lines.append("")

        if assigned_eqs:
            for idx, eq in enumerate(assigned_eqs, 1):
                wh_info = f" • Sede: {eq.current_warehouse.name}" if eq.current_warehouse else ""
                lines.append(
                    f"{idx}. **{eq.name}** — `{eq.serial_number}` ({eq.brand or ''} {eq.model or ''}){wh_info}".strip()
                )
        else:
            for idx, it in enumerate(act_items_map.values(), 1):
                lines.append(
                    f"{idx}. **{it.equipment_name}** — `{it.serial_number}` ({it.brand or ''} {it.model or ''})".strip()
                )

    if assignment_acts:
        act_nums = ", ".join([f"`{a.act_number}`" for a in assignment_acts[:3]])
        lines.append(f"\n📄 **Actas de Entrega asociadas:** {act_nums}")

    cards: List[AssistantActionCard] = []

    # Tarjeta resumen del Custodio / Persona
    person_details = [
        {"label": "Equipos en Custodia", "value": str(total_count)},
        {"label": "Cédula / ID", "value": person_info.get("id_card") or "No registrada"},
    ]
    if person_info.get("department") or person_info.get("position"):
        person_details.append({
            "label": "Cargo / Área",
            "value": f"{person_info.get('position') or ''} {person_info.get('department') or ''}".strip()
        })

    latest_act = person_acts[0] if person_acts else None
    cards.append(
        AssistantActionCard(
            card_type="person",
            title=p_name,
            subtitle=person_info.get("position") or "Custodio de Equipos",
            badge_text=f"{total_count} Equipo(s)" if total_count > 0 else "Solvente",
            badge_color="sky" if total_count > 0 else "emerald",
            details=person_details,
            link_url=f"/verify-act/{latest_act.act_number}" if latest_act else "/acts",
            link_label=f"Ver Acta {latest_act.act_number}" if latest_act else "Ir a Actas",
            secondary_link_url="/equipment",
            secondary_link_label="Ver Inventario",
        )
    )

    # Tarjetas de sus equipos (máximo 4 para mantener limpio en móvil)
    for eq in assigned_eqs[:4]:
        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"SN: {eq.serial_number}",
                badge_text="Asignado",
                badge_color="sky",
                details=[
                    {"label": "Marca / Modelo", "value": f"{eq.brand or ''} {eq.model or ''}".strip() or "N/A"},
                    {"label": "Ubicación Base", "value": eq.current_warehouse.name if eq.current_warehouse else "N/A"},
                ],
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ver Ficha Técnica",
            )
        )

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="person_custody",
        cards=cards,
        follow_up_suggestions=[
            "¿Quiénes más tienen equipos asignados?",
            "Muéstrame las últimas actas de entrega emitidas",
            "Dame un resumen general del inventario",
        ],
    )


def _build_all_custodians_response(
    all_equipment: List[Equipment],
    all_acts: List[DeliveryAct],
) -> AssistantQueryResponse:
    custody_counts: Dict[str, Dict[str, Any]] = {}

    for eq in all_equipment:
        if status_str(eq.status) == "assigned" and eq.assigned_to:
            name = eq.assigned_to.strip()
            key = normalize_text(name)
            if key not in custody_counts:
                custody_counts[key] = {"name": name, "items": [], "id_card": "", "act_number": ""}
            custody_counts[key]["items"].append(eq)

    for act in all_acts:
        if act.act_type == "assignment" and act.recipient_name:
            key = normalize_text(act.recipient_name)
            if key in custody_counts:
                if not custody_counts[key]["id_card"]:
                    custody_counts[key]["id_card"] = act.recipient_id_card
                if not custody_counts[key]["act_number"]:
                    custody_counts[key]["act_number"] = act.act_number

    if not custody_counts:
        return AssistantQueryResponse(
            answer="Actualmente **no hay equipos asignados** a ningún trabajador. Todos los equipos se encuentran en almacén.",
            intent="all_custodians",
            cards=[],
            follow_up_suggestions=[
                "¿Qué equipos están disponibles?",
                "Dame un resumen general del inventario",
            ],
        )

    sorted_custodians = sorted(custody_counts.values(), key=lambda x: len(x["items"]), reverse=True)
    total_assigned = sum(len(c["items"]) for c in sorted_custodians)

    lines = [
        f"Actualmente hay **{total_assigned} equipo(s) asignado(s)** distribuidos entre **{len(sorted_custodians)} persona(s)**:",
        "",
    ]
    cards: List[AssistantActionCard] = []

    for c in sorted_custodians:
        count = len(c["items"])
        sample_names = ", ".join([e.name for e in c["items"][:2]])
        if count > 2:
            sample_names += f" (+{count - 2} más)"
        id_str = f" (C.I: `{c['id_card']}`)" if c["id_card"] else ""
        lines.append(f"• **{c['name']}**{id_str}: **{count} equipo(s)** — *{sample_names}*")

        cards.append(
            AssistantActionCard(
                card_type="person",
                title=c["name"],
                subtitle=f"C.I: {c['id_card']}" if c["id_card"] else "Custodio Activo",
                badge_text=f"{count} equipo(s)",
                badge_color="sky",
                details=[
                    {"label": "Equipos", "value": sample_names},
                    {"label": "Acta", "value": c["act_number"] or "En custodia"},
                ],
                link_url=f"/verify-act/{c['act_number']}" if c["act_number"] else "/acts",
                link_label="Ver Acta" if c["act_number"] else "Ver Actas",
            )
        )

    follow_ups = [
        "¿Qué equipos están disponibles en almacén?",
        "Muéstrame las últimas actas de entrega emitidas",
        "Dame un resumen general del inventario",
    ]

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="all_custodians",
        cards=cards[:5],
        follow_up_suggestions=follow_ups,
    )


def _build_warehouse_response(
    warehouse: Warehouse,
    all_equipment: List[Equipment],
) -> AssistantQueryResponse:
    wh_eqs = [e for e in all_equipment if e.current_warehouse_id == warehouse.id]
    avail = [e for e in wh_eqs if status_str(e.status) == "available"]
    assigned = [e for e in wh_eqs if status_str(e.status) == "assigned"]
    maint = [e for e in wh_eqs if status_str(e.status) == "maintenance"]

    lines = [
        f"🏢 El almacén **{warehouse.name}**"
        + (f" ({warehouse.location})" if warehouse.location else "")
        + f" registra un total de **{len(wh_eqs)} equipo(s)**:",
        "",
        f"• 🟢 **Disponibles en stock:** {len(avail)}",
        f"• 🔵 **Asignados (asociados a esta sede):** {len(assigned)}",
        f"• 🟠 **En mantenimiento:** {len(maint)}",
    ]

    if avail:
        lines.append("\n**Equipos disponibles para entrega inmediata:**")
        for eq in avail[:5]:
            lines.append(f"• **{eq.name}** (`SN: {eq.serial_number}`)")
        if len(avail) > 5:
            lines.append(f"*(y {len(avail) - 5} equipo(s) disponible(s) más)*")

    cards = [
        AssistantActionCard(
            card_type="warehouse",
            title=warehouse.name,
            subtitle=warehouse.location or "Sede / Almacén Activo",
            badge_text=f"{len(wh_eqs)} Equipos",
            badge_color="emerald" if len(avail) > 0 else "slate",
            details=[
                {"label": "Disponibles", "value": str(len(avail))},
                {"label": "Asignados", "value": str(len(assigned))},
                {"label": "En Mantenimiento", "value": str(len(maint))},
            ],
            link_url="/warehouses",
            link_label="Ver Almacenes",
            secondary_link_url="/equipment",
            secondary_link_label="Ver Equipos",
        )
    ]

    for eq in avail[:3]:
        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"SN: {eq.serial_number}",
                badge_text="Disponible",
                badge_color="emerald",
                details=[
                    {"label": "Almacén", "value": warehouse.name},
                    {"label": "Marca / Modelo", "value": f"{eq.brand or ''} {eq.model or ''}".strip() or "N/A"},
                ],
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ver Ficha",
            )
        )

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="warehouse_detail",
        cards=cards,
        follow_up_suggestions=[
            "¿Quiénes tienen equipos asignados?",
            "Dame un resumen general del inventario",
        ],
    )


def _build_all_warehouses_response(
    warehouses: List[Warehouse],
    all_equipment: List[Equipment],
) -> AssistantQueryResponse:
    lines = [f"El sistema cuenta con **{len(warehouses)} almacén(es) activo(s)**:", ""]
    cards: List[AssistantActionCard] = []

    for wh in warehouses:
        wh_eqs = [e for e in all_equipment if e.current_warehouse_id == wh.id]
        avail = sum(1 for e in wh_eqs if status_str(e.status) == "available")
        lines.append(
            f"• **{wh.name}** ({wh.location or 'Sede Principal'}): **{len(wh_eqs)} equipo(s)** ({avail} disponibles)"
        )
        cards.append(
            AssistantActionCard(
                card_type="warehouse",
                title=wh.name,
                subtitle=wh.location or "Almacén",
                badge_text=f"{avail} Disponibles",
                badge_color="emerald" if avail > 0 else "slate",
                details=[
                    {"label": "Total Equipos", "value": str(len(wh_eqs))},
                    {"label": "Disponibles", "value": str(avail)},
                ],
                link_url="/warehouses",
                link_label="Ver Almacén",
            )
        )

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="warehouses_list",
        cards=cards,
        follow_up_suggestions=[
            f"¿Qué equipos hay en {warehouses[0].name}?" if warehouses else "Resumen del inventario",
            "¿Quiénes tienen equipos asignados?",
        ],
    )


def _build_single_act_response(act: DeliveryAct) -> AssistantQueryResponse:
    tipo = "Acta de Asignación" if act.act_type == "assignment" else "Acta de Devolución / Solvencia"
    scan_status = "Respaldada Físicamente" if act.scanned_document_url else "Pendiente Escaneo Físico"

    lines = [
        f"📄 **{tipo} `{act.act_number}`**",
        "",
        f"• **Trabajador / Custodio:** **{act.recipient_name}** (C.I: `{act.recipient_id_card}`)",
        f"• **Cargo / Gerencia:** {act.recipient_position or 'N/A'} — {act.recipient_department or 'N/A'}",
        f"• **Emitida por TI:** {act.delivered_by_name} ({act.delivered_by_position})",
        f"• **Equipos incluidos ({len(act.items)}):**",
    ]
    for it in act.items:
        lines.append(f"  - **{it.equipment_name}** (`SN: {it.serial_number}`)")

    if act.accessories:
        lines.append(f"• **Accesorios:** {act.accessories}")

    card = AssistantActionCard(
        card_type="act",
        title=f"{act.act_number} • {act.recipient_name}",
        subtitle=f"{tipo} ({len(act.items)} equipo(s))",
        badge_text=scan_status,
        badge_color="emerald" if act.scanned_document_url else "amber",
        details=[
            {"label": "Cédula", "value": act.recipient_id_card},
            {"label": "Equipos", "value": str(len(act.items))},
            {"label": "Autorizado por", "value": act.delivered_by_name},
        ],
        link_url=f"/verify-act/{act.act_number}",
        link_label="Verificar Acta",
        secondary_link_url="/acts",
        secondary_link_label="Ir a Módulo de Actas",
    )

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="single_act",
        cards=[card],
        follow_up_suggestions=[
            "¿Cuántos equipos se encuentran asignados actualmente?",
            "Muéstrame las últimas actas de entrega emitidas",
        ],
    )


def _build_acts_overview_response(norm_q: str, all_acts: List[DeliveryAct]) -> AssistantQueryResponse:
    if not all_acts:
        return AssistantQueryResponse(
            answer="Aún no se han emitido actas de entrega en el sistema.",
            intent="acts_overview",
            cards=[],
            follow_up_suggestions=["Dame un resumen general del inventario"],
        )

    pending_scan = [a for a in all_acts if not a.scanned_document_url]
    scanned = [a for a in all_acts if a.scanned_document_url]

    lines = [
        f"📄 Se han emitido **{len(all_acts)} acta(s)** en el sistema ({len(scanned)} con respaldo físico escaneado y {len(pending_scan)} pendientes de escaneo):",
        "",
    ]

    cards: List[AssistantActionCard] = []
    for act in all_acts[:5]:
        tipo = "Entrega" if act.act_type == "assignment" else "Solvencia"
        lines.append(
            f"• **`{act.act_number}`** ({tipo}) — **{act.recipient_name}** (`{len(act.items)} equipo(s)`)"
        )
        cards.append(
            AssistantActionCard(
                card_type="act",
                title=f"{act.act_number} — {act.recipient_name}",
                subtitle=f"C.I: {act.recipient_id_card} • {len(act.items)} equipo(s)",
                badge_text="Respaldada" if act.scanned_document_url else "Pendiente Escaneo",
                badge_color="emerald" if act.scanned_document_url else "amber",
                details=[
                    {"label": "Tipo", "value": tipo},
                    {"label": "Responsable TI", "value": act.delivered_by_name},
                ],
                link_url=f"/verify-act/{act.act_number}",
                link_label="Ver / Verificar",
                secondary_link_url="/acts",
                secondary_link_label="Abrir en Actas",
            )
        )

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="acts_overview",
        cards=cards,
        follow_up_suggestions=[
            f"Muéstrame el acta {all_acts[0].act_number}",
            "¿Quiénes tienen equipos asignados?",
        ],
    )


def _build_maintenance_response(all_equipment: List[Equipment]) -> AssistantQueryResponse:
    in_maint = [e for e in all_equipment if status_str(e.status) == "maintenance"]
    all_records = []
    for eq in all_equipment:
        for m in eq.maintenances:
            all_records.append((eq, m))

    lines = [
        f"🔧 **Estado de Mantenimiento y Hoja de Vida:**",
        f"• Equipos actualmente en taller/mantenimiento: **{len(in_maint)}**",
        f"• Intervenciones históricas registradas: **{len(all_records)}**",
        "",
    ]

    cards: List[AssistantActionCard] = []
    for eq in in_maint[:4]:
        lines.append(f"• ⚠️ **{eq.name}** (`{eq.serial_number}`) — Actualmente en mantenimiento")
        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"SN: {eq.serial_number}",
                badge_text="En Mantenimiento",
                badge_color="amber",
                details=[
                    {"label": "Almacén", "value": eq.current_warehouse.name if eq.current_warehouse else "N/A"},
                ],
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ver Hoja de Vida",
            )
        )

    for eq, m in all_records[:4]:
        lines.append(f"• 🛠️ **{eq.name}**: *{m.title}* ({m.maintenance_type.capitalize()})")

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="maintenance_overview",
        cards=cards,
        follow_up_suggestions=[
            "¿Qué equipos están disponibles?",
            "Dame un resumen general del inventario",
        ],
    )


def _build_movements_response(movements: List[Movement]) -> AssistantQueryResponse:
    if not movements:
        return AssistantQueryResponse(
            answer="No hay movimientos recientes registrados en el historial.",
            intent="movements_list",
            cards=[],
            follow_up_suggestions=["Dame un resumen general del inventario"],
        )

    type_labels = {
        "entry": "Entrada",
        "exit": "Salida / Asignación",
        "transfer": "Traslado de Sede",
        "return": "Devolución",
        "maintenance": "Mantenimiento",
    }

    lines = [f"🔄 **Últimos {min(len(movements), 6)} movimientos registrados en el sistema:**", ""]
    for mov in movements[:6]:
        t_str = status_str(mov.type)
        t_label = type_labels.get(t_str, t_str)
        eq_name = mov.equipment.name if mov.equipment else "Equipo"
        dest = mov.assigned_to or (mov.to_warehouse.name if mov.to_warehouse else "")
        lines.append(f"• **{t_label}** — **{eq_name}**" + (f" $\\rightarrow$ {dest}" if dest else ""))

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="movements_list",
        cards=[
            AssistantActionCard(
                card_type="stats",
                title="Historial de Auditoría de Movimientos",
                subtitle=f"{len(movements)} movimientos recientes",
                badge_text="Trazabilidad",
                badge_color="sky",
                details=[
                    {"label": "Último equipo movido", "value": movements[0].equipment.name if movements[0].equipment else "N/A"},
                ],
                link_url="/movements",
                link_label="Ver Todos los Movimientos",
            )
        ],
        follow_up_suggestions=[
            "¿Quiénes tienen equipos asignados?",
            "Dame un resumen general del inventario",
        ],
    )


def _build_equipment_list_response(
    items: List[Equipment],
    category_filter: Optional[str],
    status_filter: Optional[str],
    serial_to_act: Dict[str, DeliveryAct],
) -> AssistantQueryResponse:
    cat_label = CATEGORY_DISPLAY.get(category_filter, category_filter) if category_filter else "equipos"
    st_label = STATUS_LABELS.get(status_filter, (status_filter, "slate"))[0] if status_filter else ""

    if not items:
        return AssistantQueryResponse(
            answer=f"No se encontraron **{cat_label}** {f'con estado **{st_label}**' if st_label else ''} en el inventario actual.",
            intent="equipment_filter_empty",
            cards=[],
            follow_up_suggestions=[
                "Dame un resumen general del inventario",
                "¿Qué equipos están disponibles?",
            ],
        )

    lines = [
        f"Encontré **{len(items)} {cat_label.lower()}** {f'({st_label.lower()})' if st_label else ''} en el sistema:",
        "",
    ]
    cards: List[AssistantActionCard] = []

    for eq in items[:5]:
        st = status_str(eq.status)
        s_text, s_color = STATUS_LABELS.get(st, (st, "slate"))
        loc = (
            f"Asignado a **{eq.assigned_to}**"
            if st == "assigned" and eq.assigned_to
            else f"Almacén **{eq.current_warehouse.name if eq.current_warehouse else 'Sin asignar'}**"
        )
        lines.append(f"• **{eq.name}** (`{eq.serial_number}`) — {s_text} • {loc}")

        act = serial_to_act.get(normalize_text(eq.serial_number))
        cards.append(
            AssistantActionCard(
                card_type="equipment",
                title=eq.name,
                subtitle=f"SN: {eq.serial_number}",
                badge_text=s_text,
                badge_color=s_color,
                details=[
                    {"label": "Marca / Modelo", "value": f"{eq.brand or ''} {eq.model or ''}".strip() or "N/A"},
                    {
                        "label": "Custodio" if st == "assigned" and eq.assigned_to else "Ubicación",
                        "value": eq.assigned_to if st == "assigned" and eq.assigned_to else (eq.current_warehouse.name if eq.current_warehouse else "N/A"),
                    },
                ],
                link_url=f"/eq/{eq.serial_number}",
                link_label="Ver Ficha",
                secondary_link_url=f"/verify-act/{act.act_number}" if act else None,
                secondary_link_label=f"Acta {act.act_number}" if act else None,
            )
        )

    if len(items) > 5:
        lines.append(f"\n*(Mostrando 5 de los {len(items)} equipos encontrados)*")

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="equipment_list",
        cards=cards,
        follow_up_suggestions=[
            f"¿Quién tiene el equipo {items[0].serial_number}?",
            "¿Quiénes tienen equipos asignados?",
        ],
    )


def _build_inventory_summary_response(
    all_equipment: List[Equipment],
    all_warehouses: List[Warehouse],
    all_acts: List[DeliveryAct],
) -> AssistantQueryResponse:
    total = len(all_equipment)
    avail = sum(1 for e in all_equipment if status_str(e.status) == "available")
    assigned = sum(1 for e in all_equipment if status_str(e.status) == "assigned")
    maint = sum(1 for e in all_equipment if status_str(e.status) == "maintenance")

    # Conteo por categoría
    by_cat: Dict[str, int] = {}
    for eq in all_equipment:
        c = CATEGORY_DISPLAY.get(normalize_text(eq.category), eq.category.capitalize())
        by_cat[c] = by_cat.get(c, 0) + 1

    top_cats = sorted(by_cat.items(), key=lambda x: x[1], reverse=True)[:4]
    cats_str = ", ".join([f"{cnt} {name}" for name, cnt in top_cats]) if top_cats else "Sin categorías"

    lines = [
        "📊 **Resumen en Tiempo Real del Inventario Tecnológico:**",
        "",
        f"• 📦 **Total de Equipos Registrados:** **{total}**",
        f"• 🟢 **Disponibles en Almacén:** **{avail}**",
        f"• 🔵 **Asignados a Trabajadores:** **{assigned}**",
        f"• 🟠 **En Mantenimiento / Taller:** **{maint}**",
        f"• 🏢 **Almacenes / Sedes Activas:** **{len(all_warehouses)}**",
        f"• 📄 **Actas de Entrega Emitidas:** **{len(all_acts)}**",
        "",
        f"**Distribución principal:** {cats_str}.",
        "",
        "💡 *Puedes preguntarme por cualquier número de serie, nombre de trabajador, almacén o escanear un código QR directamente con la cámara.*",
    ]

    cards = [
        AssistantActionCard(
            card_type="stats",
            title="Estado Global del Parque Tecnológico",
            subtitle=f"{total} activos registrados en {len(all_warehouses)} sede(s)",
            badge_text="En Línea",
            badge_color="emerald",
            details=[
                {"label": "Disponibles", "value": str(avail)},
                {"label": "Asignados", "value": str(assigned)},
                {"label": "Actas Emitidas", "value": str(len(all_acts))},
            ],
            link_url="/dashboard",
            link_label="Ver Panel Principal",
            secondary_link_url="/reports",
            secondary_link_label="Ir a Reportes",
        )
    ]

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="inventory_summary",
        cards=cards,
        follow_up_suggestions=[
            "¿Quiénes tienen equipos asignados?",
            "¿Qué equipos están disponibles?",
            "Muéstrame las últimas actas de entrega emitidas",
        ],
    )


def _build_not_found_helpful_response(
    user_query: str,
    all_equipment: List[Equipment],
    all_warehouses: List[Warehouse],
    all_acts: List[DeliveryAct],
) -> AssistantQueryResponse:
    total = len(all_equipment)
    avail = sum(1 for e in all_equipment if status_str(e.status) == "available")
    assigned = sum(1 for e in all_equipment if status_str(e.status) == "assigned")

    sample_serials = [e.serial_number for e in all_equipment[:2]]

    lines = [
        f"No encontré ningún equipo, trabajador o almacén que coincida exactamente con **\"{user_query}\"**.",
        "",
        f"Actualmente el inventario cuenta con **{total} equipos** ({avail} disponibles y {assigned} asignados).",
        "",
        "**Ejemplos de consultas que puedes hacerme con los datos actuales:**",
        "• *\"Dame un resumen general del inventario\"*",
    ]
    if sample_serials:
        lines.append(f"• *\"¿Cuál es el estado y ubicación del equipo {sample_serials[0]}?\"*")
    if all_warehouses:
        lines.append(f"• *\"¿Qué equipos están disponibles en {all_warehouses[0].name}?\"*")

    return AssistantQueryResponse(
        answer="\n".join(lines),
        intent="not_found_help",
        cards=[],
        follow_up_suggestions=[
            "¿Cuántas laptops están disponibles actualmente?",
            f"¿Dónde está el equipo {sample_serials[0]}?" if sample_serials else "¿Qué equipos están disponibles?",
            "Dame un resumen general del inventario",
        ],
    )


# ==========================================
# ENRIQUECIMIENTO OPCIONAL CON GEMINI API
# ==========================================

async def _finalize_with_optional_llm(
    req: AssistantQueryRequest,
    base_response: AssistantQueryResponse,
    all_equipment: List[Equipment],
    all_warehouses: List[Warehouse],
    all_acts: List[DeliveryAct],
) -> AssistantQueryResponse:
    """
    Si existe GEMINI_API_KEY (en variables de entorno o enviada por el cliente),
    utiliza Gemini 1.5 Flash con el contexto verificado de la base de datos para redactar
    la respuesta conversacional, conservando las tarjetas interactivas exactas.
    """
    api_key = (req.gemini_api_key or os.getenv("GEMINI_API_KEY") or "").strip()
    if not api_key:
        return base_response

    try:
        # Construir contexto compacto de la base de datos real
        eq_summary = []
        for e in all_equipment[:40]:
            st = status_str(e.status)
            wh = e.current_warehouse.name if e.current_warehouse else "Sin almacén"
            eq_summary.append(
                f"- {e.name} |Marca:{e.brand} |Modelo:{e.model} |SN:{e.serial_number} |Estado:{st} |Almacén:{wh} |AsignadoA:{e.assigned_to or 'Nadie'}"
            )

        acts_summary = []
        for a in all_acts[:20]:
            acts_summary.append(
                f"- Acta {a.act_number} ({a.act_type}): Trabajador={a.recipient_name} (CI:{a.recipient_id_card}, {a.recipient_position} - {a.recipient_department}), Equipos={len(a.items)}"
            )

        system_prompt = (
            "Te llamas Rosco y eres el Asistente de IA oficial del Sistema de Inventario Tecnológico de Grupo Tu Andamio. "
            "Responde siempre en español de forma concisa, profesional, clara y amigable, usando formato Markdown. "
            "Basa tu respuesta ESTRICTAMENTE en los datos reales del sistema provistos a continuación:\n\n"
            f"RESPUESTA PRE-CALCULADA DEL MOTOR DE DATOS:\n{base_response.answer}\n\n"
            f"LISTA DE EQUIPOS EN INVENTARIO:\n" + "\n".join(eq_summary) + "\n\n"
            f"LISTA DE ACTAS:\n" + "\n".join(acts_summary)
        )

        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
        payload = {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": f"{system_prompt}\n\nPregunta del usuario: {req.query}"}]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "maxOutputTokens": 500,
            }
        }

        async with httpx.AsyncClient(timeout=6.0) as client:
            resp = await client.post(url, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                candidates = data.get("candidates") or []
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    if parts and parts[0].get("text"):
                        base_response.answer = parts[0]["text"].strip()
                        base_response.engine = "gemini-1.5-flash"
    except Exception:
        # Fallback silencioso al motor determinístico NLU si no hay red o la key falla
        pass

    return base_response

