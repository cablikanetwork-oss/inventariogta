import uuid
from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.warehouse import Warehouse
from app.models.equipment import Equipment
from app.models.audit import AuditSession, AuditSessionStatus, AuditScan
from app.schemas.audit import (
    AuditSessionCreate,
    AuditScanCreate,
    AuditSessionResponse,
    AuditScanResult,
    AuditReportResponse,
    AuditScanResponse,
)
from app.schemas.equipment import EquipmentResponse

router = APIRouter()

@router.post("/sessions", response_model=AuditSessionResponse, status_code=status.HTTP_201_CREATED)
async def create_audit_session(
    data: AuditSessionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Crea una nueva sesión de toma física de inventario para un almacén."""
    wh_res = await db.execute(select(Warehouse).where(Warehouse.id == data.warehouse_id))
    wh = wh_res.scalar_one_or_none()
    if not wh:
        raise HTTPException(status_code=404, detail="Almacén no encontrado")

    # Contar equipos esperados actualmente en ese almacén
    count_res = await db.execute(
        select(func.count(Equipment.id)).where(
            Equipment.current_warehouse_id == data.warehouse_id,
            Equipment.is_active == True
        )
    )
    expected_total = count_res.scalar() or 0

    session = AuditSession(
        warehouse_id=data.warehouse_id,
        created_by=current_user.id,
        status=AuditSessionStatus.active,
        notes=data.notes
    )
    db.add(session)
    await db.commit()
    await db.refresh(session)

    return AuditSessionResponse(
        id=session.id,
        warehouse_id=session.warehouse_id,
        warehouse_name=wh.name,
        created_by=session.created_by,
        creator_name=current_user.full_name,
        status=session.status,
        notes=session.notes,
        created_at=session.created_at,
        closed_at=session.closed_at,
        expected_total=expected_total,
        scanned_count=0
    )

@router.get("/sessions", response_model=List[AuditSessionResponse])
async def list_audit_sessions(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Lista el historial de sesiones de toma física de inventario."""
    result = await db.execute(
        select(AuditSession)
        .options(
            selectinload(AuditSession.warehouse),
            selectinload(AuditSession.created_by_user),
            selectinload(AuditSession.scans)
        )
        .order_by(AuditSession.created_at.desc())
    )
    sessions = result.scalars().all()

    response_items = []
    for s in sessions:
        # Calcular esperados
        count_res = await db.execute(
            select(func.count(Equipment.id)).where(
                Equipment.current_warehouse_id == s.warehouse_id,
                Equipment.is_active == True
            )
        )
        expected = count_res.scalar() or 0

        response_items.append(
            AuditSessionResponse(
                id=s.id,
                warehouse_id=s.warehouse_id,
                warehouse_name=s.warehouse.name if s.warehouse else "Desconocido",
                created_by=s.created_by,
                creator_name=s.created_by_user.full_name if s.created_by_user else "Usuario",
                status=s.status,
                notes=s.notes,
                created_at=s.created_at,
                closed_at=s.closed_at,
                expected_total=expected,
                scanned_count=len(s.scans)
            )
        )
    return response_items

@router.get("/sessions/{session_id}", response_model=AuditSessionResponse)
async def get_audit_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Detalles y estado actual de una sesión de auditoría."""
    res = await db.execute(
        select(AuditSession)
        .options(
            selectinload(AuditSession.warehouse),
            selectinload(AuditSession.created_by_user),
            selectinload(AuditSession.scans)
        )
        .where(AuditSession.id == session_id)
    )
    s = res.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=404, detail="Sesión de auditoría no encontrada")

    count_res = await db.execute(
        select(func.count(Equipment.id)).where(
            Equipment.current_warehouse_id == s.warehouse_id,
            Equipment.is_active == True
        )
    )
    expected = count_res.scalar() or 0

    return AuditSessionResponse(
        id=s.id,
        warehouse_id=s.warehouse_id,
        warehouse_name=s.warehouse.name if s.warehouse else "Desconocido",
        created_by=s.created_by,
        creator_name=s.created_by_user.full_name if s.created_by_user else "Usuario",
        status=s.status,
        notes=s.notes,
        created_at=s.created_at,
        closed_at=s.closed_at,
        expected_total=expected,
        scanned_count=len(s.scans)
    )

@router.post("/sessions/{session_id}/scan", response_model=AuditScanResult)
async def scan_equipment_in_session(
    session_id: uuid.UUID,
    data: AuditScanCreate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Procesa el escaneo de un código de barras o serial dentro de la sesión."""
    sess_res = await db.execute(select(AuditSession).where(AuditSession.id == session_id))
    session = sess_res.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Sesión no encontrada")
    if session.status == AuditSessionStatus.closed:
        raise HTTPException(status_code=400, detail="Esta sesión de auditoría ya fue cerrada")

    clean_serial = data.serial_number.strip()
    if not clean_serial:
        raise HTTPException(status_code=400, detail="El serial no puede estar vacío")

    # Verificar si ya fue escaneado en esta misma sesión
    prev_scan_res = await db.execute(
        select(AuditScan).where(
            AuditScan.session_id == session_id,
            AuditScan.scanned_serial.ilike(clean_serial)
        )
    )
    is_duplicate = prev_scan_res.scalar_one_or_none() is not None

    # Buscar equipo en la base de datos por serial o código de barras
    eq_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(
            Equipment.is_active == True,
            (Equipment.serial_number.ilike(clean_serial)) | (Equipment.barcode.ilike(clean_serial))
        )
    )
    equipment = eq_res.scalar_one_or_none()

    found = equipment is not None
    is_expected = False
    message = ""

    if found:
        is_expected = (equipment.current_warehouse_id == session.warehouse_id)
        if is_duplicate:
            message = f"⚠️ Serial '{clean_serial}' ya fue escaneado previamente en esta sesión."
        elif is_expected:
            message = f"✅ Equipo verificado: {equipment.name} ({equipment.serial_number})"
        else:
            orig_wh = equipment.current_warehouse.name if equipment.current_warehouse else "Sin almacén"
            message = f"🔄 Discrepancia: El equipo pertenece a '{orig_wh}', no a este almacén."
    else:
        message = f"❌ Serial '{clean_serial}' no está registrado en el sistema."

    # Guardar escaneo si no es duplicado
    if not is_duplicate:
        audit_scan = AuditScan(
            session_id=session_id,
            equipment_id=equipment.id if equipment else None,
            scanned_serial=clean_serial,
            found_in_warehouse=is_expected
        )
        db.add(audit_scan)
        await db.commit()

    eq_resp = EquipmentResponse.model_validate(equipment) if equipment else None

    return AuditScanResult(
        found=found,
        is_expected=is_expected,
        is_duplicate=is_duplicate,
        scanned_serial=clean_serial,
        equipment=eq_resp,
        message=message
    )

@router.post("/sessions/{session_id}/close", response_model=AuditSessionResponse)
async def close_audit_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Finaliza y sella formalmente una sesión de auditoría."""
    sess_res = await db.execute(
        select(AuditSession)
        .options(
            selectinload(AuditSession.warehouse),
            selectinload(AuditSession.created_by_user),
            selectinload(AuditSession.scans)
        )
        .where(AuditSession.id == session_id)
    )
    session = sess_res.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Sesión no encontrada")

    session.status = AuditSessionStatus.closed
    session.closed_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(session)

    count_res = await db.execute(
        select(func.count(Equipment.id)).where(
            Equipment.current_warehouse_id == session.warehouse_id,
            Equipment.is_active == True
        )
    )
    expected = count_res.scalar() or 0

    return AuditSessionResponse(
        id=session.id,
        warehouse_id=session.warehouse_id,
        warehouse_name=session.warehouse.name if session.warehouse else "Desconocido",
        created_by=session.created_by,
        creator_name=session.created_by_user.full_name if session.created_by_user else "Usuario",
        status=session.status,
        notes=session.notes,
        created_at=session.created_at,
        closed_at=session.closed_at,
        expected_total=expected,
        scanned_count=len(session.scans)
    )

@router.get("/sessions/{session_id}/report", response_model=AuditReportResponse)
async def get_audit_session_report(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Genera el reporte final de discrepancias: faltantes, sobrantes y verificados."""
    sess_res = await db.execute(
        select(AuditSession)
        .options(
            selectinload(AuditSession.warehouse),
            selectinload(AuditSession.scans).selectinload(AuditScan.equipment)
        )
        .where(AuditSession.id == session_id)
    )
    session = sess_res.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Sesión no encontrada")

    # Equipos que deberían estar en el almacén
    expected_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(
            Equipment.current_warehouse_id == session.warehouse_id,
            Equipment.is_active == True
        )
    )
    expected_equipments = expected_res.scalars().all()
    expected_ids = {e.id for e in expected_equipments}

    scanned_eq_ids = {s.equipment_id for s in session.scans if s.equipment_id}
    
    # Matched: esperados que fueron escaneados
    matched_items = [e for e in expected_equipments if e.id in scanned_eq_ids]
    
    # Missing: esperados que NO fueron escaneados
    missing_items = [e for e in expected_equipments if e.id not in scanned_eq_ids]

    # Extra: escaneados que no pertenecían a este almacén o desconocidos
    extra_scans = [s for s in session.scans if not s.found_in_warehouse]

    return AuditReportResponse(
        session_id=session.id,
        warehouse_name=session.warehouse.name if session.warehouse else "Desconocido",
        status=session.status,
        created_at=session.created_at,
        closed_at=session.closed_at,
        expected_total=len(expected_equipments),
        found_count=len(matched_items),
        missing_count=len(missing_items),
        extra_count=len(extra_scans),
        matched_items=[EquipmentResponse.model_validate(m) for m in matched_items],
        missing_items=[EquipmentResponse.model_validate(m) for m in missing_items],
        extra_items=[AuditScanResponse.model_validate(s) for s in extra_scans]
    )

