import uuid
import hashlib
import re
from datetime import datetime, date, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_
from sqlalchemy.orm import selectinload
from typing import List, Optional
from app.core.database import get_db
from app.api.deps import get_current_user, require_admin
from app.models.user import User
from app.models.equipment import Equipment, EquipmentCategory, EquipmentStatus, EquipmentMaintenance, EquipmentCatalogItem
from app.models.company import CompanyConfig
from app.models.warehouse import Warehouse
from app.models.movement import Movement, MovementType
from app.models.delivery_act import DeliveryAct, DeliveryActItem
from app.schemas.equipment import (
    EquipmentCreate,
    EquipmentUpdate,
    EquipmentResponse,
    EquipmentImportItem,
    EquipmentImportPreviewResponse,
    EquipmentImportCommitRequest,
    EquipmentImportCommitResponse,
    EquipmentMaintenanceCreate,
    EquipmentMaintenanceResponse,
    CatalogItemCreate,
    CatalogItemResponse,
    EquipmentCatalogsResponse,
    EquipmentBatchCreate,
    EquipmentBatchResponse,
)
from app.services.excel_import import (
    generate_excel_template,
    parse_uploaded_file,
    parse_category,
    parse_status,
)
from app.services.excel_export import generate_inventory_excel_workbook
from app.services.label_generator import generate_equipment_qr_image, generate_labels_pdf_sheet
from pydantic import BaseModel

class LabelsPdfRequest(BaseModel):
    equipment_ids: List[uuid.UUID]
    base_url: Optional[str] = None


class VerifyPresenceRequest(BaseModel):
    notes: Optional[str] = None
    verified_at: Optional[str] = None


def _build_ar_equipment_item(
    equipment: Equipment,
    latest_act: Optional[DeliveryAct],
    company_payload: dict
) -> dict:
    today = date.today()
    lifespan_years = equipment.expected_lifespan_years or 3
    total_months = max(lifespan_years * 12, 12)

    if equipment.purchase_date:
        delta_days = max((today - equipment.purchase_date).days, 0)
        age_months = int(delta_days // 30)
    elif equipment.created_at:
        created_d = equipment.created_at.date() if hasattr(equipment.created_at, "date") else today
        delta_days = max((today - created_d).days, 0)
        age_months = int(delta_days // 30)
    else:
        age_months = 0

    health_pct = max(0, min(100, int(round(100 - (age_months / total_months) * 100))))

    warranty_active = None
    if equipment.warranty_expires:
        warranty_active = equipment.warranty_expires >= today

    custody_info = None
    if equipment.status == EquipmentStatus.assigned or equipment.assigned_to or latest_act:
        verif_hash = None
        validity_status = "VALID_ACTIVE_ASSIGNMENT"
        if latest_act:
            verif_hash = hashlib.sha256(
                f"{latest_act.id}:{latest_act.act_number}:{latest_act.recipient_id_card}:{latest_act.created_at}".encode()
            ).hexdigest()[:16].upper()
            if latest_act.act_type == "return":
                validity_status = "VALID_RETURN_SOLVENCY"
            elif (
                equipment.status == EquipmentStatus.assigned
                and equipment.assigned_to
                and latest_act.recipient_name
                and equipment.assigned_to.strip().lower() == latest_act.recipient_name.strip().lower()
            ):
                validity_status = "VALID_ACTIVE_ASSIGNMENT"
            else:
                validity_status = "EXPIRED_OR_RETURNED_ASSIGNMENT"

        custody_info = {
            "assigned_to": equipment.assigned_to or (latest_act.recipient_name if latest_act else None),
            "recipient_name": latest_act.recipient_name if latest_act else equipment.assigned_to,
            "recipient_id_card": latest_act.recipient_id_card if latest_act else None,
            "recipient_position": latest_act.recipient_position if latest_act else None,
            "recipient_department": latest_act.recipient_department if latest_act else None,
            "recipient_signature": latest_act.recipient_signature if latest_act else None,
            "delivered_by_name": (latest_act.delivered_by_name if latest_act else None) or "Raimundo Gil",
            "delivered_by_position": (latest_act.delivered_by_position if latest_act else None) or "Gerente de Tecnología",
            "delivered_by_id_card": (latest_act.delivered_by_id_card if latest_act else None) or "14.287.629",
            "assigned_date": latest_act.created_at.isoformat() if latest_act else None,
            "act_number": latest_act.act_number if latest_act else None,
            "act_id": str(latest_act.id) if latest_act else None,
            "act_type": latest_act.act_type if latest_act else "assignment",
            "accessories": latest_act.accessories if latest_act else None,
            "scanned_document_url": latest_act.scanned_document_url if latest_act else None,
            "scanned_at": latest_act.scanned_at.isoformat() if (latest_act and latest_act.scanned_at) else None,
            "evidence_photos_list": latest_act.evidence_photos_list if latest_act else [],
            "verification_hash": verif_hash,
            "validity_status": validity_status,
        }

    return {
        "equipment": {
            "id": str(equipment.id),
            "serial_number": equipment.serial_number,
            "barcode": equipment.barcode,
            "name": equipment.name,
            "brand": equipment.brand,
            "model": equipment.model,
            "category": equipment.category.value if hasattr(equipment.category, "value") else str(equipment.category),
            "status": equipment.status.value if hasattr(equipment.status, "value") else str(equipment.status),
            "notes": equipment.notes,
            "warranty_expires": equipment.warranty_expires.isoformat() if equipment.warranty_expires else None,
            "warranty_active": warranty_active,
            "purchase_date": equipment.purchase_date.isoformat() if equipment.purchase_date else None,
            "expected_lifespan_years": lifespan_years,
            "health_pct": health_pct,
            "age_months": age_months,
            "updated_at": equipment.updated_at.isoformat() if equipment.updated_at else None,
            "warehouse_id": str(equipment.current_warehouse_id) if equipment.current_warehouse_id else None,
            "warehouse_name": equipment.current_warehouse.name if equipment.current_warehouse else None,
            "warehouse_location": equipment.current_warehouse.location if equipment.current_warehouse else None,
        },
        "custody": custody_info,
        "company": company_payload,
    }


router = APIRouter()

DEFAULT_BRANDS = [
    # Computación y Laptops
    {"value": "Lenovo", "label": "Lenovo", "group_name": "Computación"},
    {"value": "HP", "label": "HP", "group_name": "Computación"},
    {"value": "Dell", "label": "Dell", "group_name": "Computación"},
    {"value": "ASUS", "label": "ASUS", "group_name": "Computación"},
    {"value": "Acer", "label": "Acer", "group_name": "Computación"},
    {"value": "MSI", "label": "MSI", "group_name": "Computación"},
    {"value": "Apple", "label": "Apple", "group_name": "Computación"},
    {"value": "Samsung", "label": "Samsung", "group_name": "Computación / Móvil"},
    {"value": "Microsoft", "label": "Microsoft", "group_name": "Computación"},
    {"value": "LG", "label": "LG", "group_name": "Monitores / TV"},
    {"value": "Huawei", "label": "Huawei", "group_name": "Móvil / Redes"},
    {"value": "Xiaomi", "label": "Xiaomi", "group_name": "Móvil"},
    {"value": "Gigabyte", "label": "Gigabyte", "group_name": "Computación"},
    {"value": "Toshiba", "label": "Toshiba", "group_name": "Computación"},
    {"value": "Sony", "label": "Sony", "group_name": "Audio / Video"},
    # Redes, Telecom y Seguridad
    {"value": "Ubiquiti", "label": "Ubiquiti", "group_name": "Redes"},
    {"value": "Cisco", "label": "Cisco", "group_name": "Redes"},
    {"value": "MikroTik", "label": "MikroTik", "group_name": "Redes"},
    {"value": "TP-Link", "label": "TP-Link", "group_name": "Redes"},
    {"value": "Fortinet", "label": "Fortinet", "group_name": "Redes"},
    {"value": "Aruba", "label": "Aruba", "group_name": "Redes"},
    {"value": "D-Link", "label": "D-Link", "group_name": "Redes"},
    {"value": "Starlink", "label": "Starlink", "group_name": "Redes"},
    {"value": "Hikvision", "label": "Hikvision", "group_name": "Seguridad / CCTV"},
    {"value": "Dahua", "label": "Dahua", "group_name": "Seguridad / CCTV"},
    {"value": "Grandstream", "label": "Grandstream", "group_name": "Telefonía IP"},
    {"value": "Yealink", "label": "Yealink", "group_name": "Telefonía IP"},
    {"value": "Motorola", "label": "Motorola", "group_name": "Móvil / Radios"},
    {"value": "Zebra", "label": "Zebra", "group_name": "Escáneres / Impresión"},
    # Impresión, Periféricos y Energía
    {"value": "Epson", "label": "Epson", "group_name": "Impresión / Proyección"},
    {"value": "Brother", "label": "Brother", "group_name": "Impresión"},
    {"value": "Canon", "label": "Canon", "group_name": "Impresión"},
    {"value": "Kyocera", "label": "Kyocera", "group_name": "Impresión"},
    {"value": "Ricoh", "label": "Ricoh", "group_name": "Impresión"},
    {"value": "Logitech", "label": "Logitech", "group_name": "Periféricos"},
    {"value": "Jabra", "label": "Jabra", "group_name": "Audio / Headsets"},
    {"value": "BenQ", "label": "BenQ", "group_name": "Monitores / Proyección"},
    {"value": "ViewSonic", "label": "ViewSonic", "group_name": "Monitores / Proyección"},
    {"value": "APC", "label": "APC", "group_name": "Energía / UPS"},
    {"value": "Forza", "label": "Forza", "group_name": "Energía / UPS"},
    {"value": "CyberPower", "label": "CyberPower", "group_name": "Energía / UPS"},
    {"value": "Tripp Lite", "label": "Tripp Lite", "group_name": "Energía / UPS"},
    {"value": "Kingston", "label": "Kingston", "group_name": "Almacenamiento"},
    {"value": "Crucial", "label": "Crucial", "group_name": "Almacenamiento"},
    {"value": "Western Digital", "label": "Western Digital", "group_name": "Almacenamiento"},
    {"value": "Seagate", "label": "Seagate", "group_name": "Almacenamiento"},
]

DEFAULT_CATEGORIES = [
    {"value": "laptop", "label": "Laptop / Portátil"},
    {"value": "desktop", "label": "Computador Escritorio"},
    {"value": "monitor", "label": "Monitor / Pantalla"},
    {"value": "phone", "label": "Teléfono Móvil"},
    {"value": "tablet", "label": "Tablet"},
    {"value": "printer", "label": "Impresora / Multifuncional"},
    {"value": "ups", "label": "UPS / Regulador"},
    {"value": "switch", "label": "Switch de Red"},
    {"value": "router", "label": "Router / Access Point"},
    {"value": "server", "label": "Servidor / NAS"},
    {"value": "keyboard", "label": "Teclado"},
    {"value": "mouse", "label": "Mouse"},
    {"value": "cable", "label": "Cableado / Cargador / Adaptador"},
    {"value": "other", "label": "Otro"},
]


async def _ensure_catalog_entries(
    db: AsyncSession,
    brand: Optional[str] = None,
    category: Optional[str] = None
) -> None:
    """Guarda automáticamente en equipment_catalogs cualquier marca o categoría nueva escrita por el usuario."""
    if brand and brand.strip():
        clean_brand = brand.strip()
        default_brand_lowers = {b["value"].lower() for b in DEFAULT_BRANDS}
        if clean_brand.lower() not in default_brand_lowers:
            existing_b = await db.execute(
                select(EquipmentCatalogItem).where(
                    EquipmentCatalogItem.item_type == "brand",
                    EquipmentCatalogItem.value.ilike(clean_brand)
                )
            )
            if not existing_b.scalar_one_or_none():
                db.add(
                    EquipmentCatalogItem(
                        item_type="brand",
                        value=clean_brand,
                        label=clean_brand,
                        group_name="Personalizadas",
                        is_custom=True,
                    )
                )

    if category and category.strip():
        clean_cat = category.strip()
        default_cat_lowers = {c["value"].lower() for c in DEFAULT_CATEGORIES} | {
            c["label"].lower() for c in DEFAULT_CATEGORIES
        }
        if clean_cat.lower() not in default_cat_lowers:
            existing_c = await db.execute(
                select(EquipmentCatalogItem).where(
                    EquipmentCatalogItem.item_type == "category",
                    or_(
                        EquipmentCatalogItem.value.ilike(clean_cat),
                        EquipmentCatalogItem.label.ilike(clean_cat),
                    )
                )
            )
            if not existing_c.scalar_one_or_none():
                db.add(
                    EquipmentCatalogItem(
                        item_type="category",
                        value=clean_cat,
                        label=clean_cat,
                        group_name="Personalizadas",
                        is_custom=True,
                    )
                )


@router.get("/catalogs", response_model=EquipmentCatalogsResponse)
async def get_equipment_catalogs(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Devuelve el catálogo completo de marcas conocidas y categorías (incluyendo las personalizadas guardadas)."""
    saved_res = await db.execute(
        select(EquipmentCatalogItem).order_by(EquipmentCatalogItem.created_at.asc())
    )
    saved_items = saved_res.scalars().all()

    # También recolectar marcas y categorías distintas que ya existan en equipos activos
    eq_res = await db.execute(
        select(Equipment.brand, Equipment.category).where(Equipment.is_active == True)
    )
    eq_rows = eq_res.all()

    brands: list[CatalogItemResponse] = []
    seen_brands: set[str] = set()

    for b in DEFAULT_BRANDS:
        key = b["value"].lower()
        if key not in seen_brands:
            seen_brands.add(key)
            brands.append(
                CatalogItemResponse(
                    item_type="brand",
                    value=b["value"],
                    label=b["label"],
                    group_name=b["group_name"],
                    is_custom=False,
                )
            )

    for item in saved_items:
        if item.item_type == "brand":
            key = item.value.strip().lower()
            if key and key not in seen_brands:
                seen_brands.add(key)
                brands.append(
                    CatalogItemResponse(
                        id=str(item.id),
                        item_type="brand",
                        value=item.value.strip(),
                        label=item.label.strip(),
                        group_name=item.group_name or "Personalizadas",
                        is_custom=True,
                    )
                )

    for row_brand, _ in eq_rows:
        if row_brand and row_brand.strip():
            clean_b = row_brand.strip()
            key = clean_b.lower()
            if key not in seen_brands:
                seen_brands.add(key)
                brands.append(
                    CatalogItemResponse(
                        item_type="brand",
                        value=clean_b,
                        label=clean_b,
                        group_name="En Inventario",
                        is_custom=True,
                    )
                )

    categories: list[CatalogItemResponse] = []
    seen_cats: set[str] = set()

    for c in DEFAULT_CATEGORIES:
        key = c["value"].lower()
        seen_cats.add(key)
        seen_cats.add(c["label"].lower())
        categories.append(
            CatalogItemResponse(
                item_type="category",
                value=c["value"],
                label=c["label"],
                group_name="Estándar",
                is_custom=False,
            )
        )

    for item in saved_items:
        if item.item_type == "category":
            key = item.value.strip().lower()
            if key and key not in seen_cats:
                seen_cats.add(key)
                seen_cats.add(item.label.strip().lower())
                categories.append(
                    CatalogItemResponse(
                        id=str(item.id),
                        item_type="category",
                        value=item.value.strip(),
                        label=item.label.strip(),
                        group_name=item.group_name or "Personalizadas",
                        is_custom=True,
                    )
                )

    for _, row_cat in eq_rows:
        if row_cat:
            clean_c = str(row_cat.value if hasattr(row_cat, "value") else row_cat).strip()
            key = clean_c.lower()
            if clean_c and key not in seen_cats:
                seen_cats.add(key)
                categories.append(
                    CatalogItemResponse(
                        item_type="category",
                        value=clean_c,
                        label=clean_c,
                        group_name="Personalizadas",
                        is_custom=True,
                    )
                )

    return EquipmentCatalogsResponse(brands=brands, categories=categories)


@router.post("/catalogs", response_model=CatalogItemResponse, status_code=status.HTTP_201_CREATED)
async def add_equipment_catalog_item(
    data: CatalogItemCreate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Permite guardar explícitamente una nueva marca o categoría en el catálogo."""
    item_type = data.item_type.strip().lower()
    if item_type not in ("brand", "category"):
        raise HTTPException(status_code=400, detail="item_type debe ser 'brand' o 'category'")

    clean_label = data.label.strip()
    clean_value = (data.value or clean_label).strip()
    if not clean_label:
        raise HTTPException(status_code=400, detail="El nombre no puede estar vacío")

    existing_res = await db.execute(
        select(EquipmentCatalogItem).where(
            EquipmentCatalogItem.item_type == item_type,
            or_(
                EquipmentCatalogItem.value.ilike(clean_value),
                EquipmentCatalogItem.label.ilike(clean_label),
            )
        )
    )
    existing = existing_res.scalar_one_or_none()
    if existing:
        return CatalogItemResponse(
            id=str(existing.id),
            item_type=existing.item_type,
            value=existing.value,
            label=existing.label,
            group_name=existing.group_name,
            is_custom=existing.is_custom,
        )

    new_item = EquipmentCatalogItem(
        item_type=item_type,
        value=clean_value,
        label=clean_label,
        group_name=data.group_name or "Personalizadas",
        is_custom=True,
    )
    db.add(new_item)
    await db.commit()
    await db.refresh(new_item)

    return CatalogItemResponse(
        id=str(new_item.id),
        item_type=new_item.item_type,
        value=new_item.value,
        label=new_item.label,
        group_name=new_item.group_name,
        is_custom=True,
    )

@router.get("/", response_model=List[EquipmentResponse])
async def list_equipment(
    warehouse_id: Optional[uuid.UUID] = Query(None),
    search: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    query = select(Equipment).options(
        selectinload(Equipment.current_warehouse)
    ).where(Equipment.is_active == True)
    
    if warehouse_id:
        query = query.where(Equipment.current_warehouse_id == warehouse_id)
    if search:
        s = search.strip()
        query = query.where(
            or_(
                Equipment.serial_number.ilike(f"%{s}%"),
                Equipment.name.ilike(f"%{s}%"),
                Equipment.barcode.ilike(f"%{s}%"),
                Equipment.brand.ilike(f"%{s}%"),
                Equipment.model.ilike(f"%{s}%"),
                Equipment.assigned_to.ilike(f"%{s}%")
            )
        )
    if category:
        query = query.where(Equipment.category == category)
    if status:
        query = query.where(Equipment.status == status)
    
    result = await db.execute(query.order_by(Equipment.created_at.desc()))
    return result.scalars().all()

@router.get("/ar-catalog")
async def get_ar_offline_catalog(
    db: AsyncSession = Depends(get_db)
):
    """Catálogo completo enriquecido para Pre-Caché Offline-First (0 ms) del Escáner AR / HUD."""
    eq_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(Equipment.is_active == True)
        .order_by(Equipment.created_at.desc())
    )
    equipments = eq_res.scalars().all()

    acts_res = await db.execute(
        select(DeliveryAct)
        .options(selectinload(DeliveryAct.items))
        .order_by(DeliveryAct.created_at.desc())
    )
    all_acts = acts_res.scalars().all()

    # Mapear equipo -> última acta por serial_number o equipment_id
    act_by_eq_id = {}
    act_by_serial = {}
    for act in all_acts:
        for item in act.items:
            if item.equipment_id and item.equipment_id not in act_by_eq_id:
                act_by_eq_id[item.equipment_id] = act
            if item.serial_number and item.serial_number.upper() not in act_by_serial:
                act_by_serial[item.serial_number.upper()] = act

    cfg_res = await db.execute(select(CompanyConfig).limit(1))
    company_cfg = cfg_res.scalar_one_or_none()
    company_payload = {
        "name": company_cfg.name if (company_cfg and company_cfg.name) else "TUANDAMIO",
        "logo_url": company_cfg.logo_url if company_cfg else None,
        "primary_color": company_cfg.primary_color if company_cfg else "#2563EB",
        "support_message": "En caso de extravío o requerimiento técnico, comunicarse con la Gerencia de Tecnología."
    }

    items = []
    for eq in equipments:
        latest_act = act_by_eq_id.get(eq.id) or act_by_serial.get(eq.serial_number.upper())
        items.append(_build_ar_equipment_item(eq, latest_act, company_payload))

    return {
        "synced_at": datetime.now(timezone.utc).isoformat(),
        "count": len(items),
        "company": company_payload,
        "items": items
    }


@router.get("/public-lookup/{identifier}")
async def public_equipment_lookup(
    identifier: str,
    db: AsyncSession = Depends(get_db)
):
    """Consulta rápida pública (sin autenticación requerida) para escaneo QR móvil."""
    cleaned = identifier.strip()

    # Intentar parsear UUID si aplica
    parsed_uuid = None
    try:
        parsed_uuid = uuid.UUID(cleaned)
    except Exception:
        parsed_uuid = None

    conditions = [
        Equipment.serial_number.ilike(cleaned),
        Equipment.barcode.ilike(cleaned),
    ]
    if parsed_uuid:
        conditions.append(Equipment.id == parsed_uuid)

    res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(or_(*conditions), Equipment.is_active == True)
    )
    equipment = res.scalar_one_or_none()
    matched_act_from_code: Optional[DeliveryAct] = None

    # Si el usuario escaneó el QR de un Acta (ACT-2026-XXXX, UUID de acta o SOLV-<cedula>)
    if not equipment:
        act_conds = [DeliveryAct.act_number.ilike(cleaned)]
        if parsed_uuid:
            act_conds.append(DeliveryAct.id == parsed_uuid)
        if cleaned.upper().startswith("SOLV-"):
            target_ci = cleaned[5:].strip()
            act_conds.append(DeliveryAct.recipient_id_card.ilike(f"%{target_ci}%"))

        act_lookup_res = await db.execute(
            select(DeliveryAct)
            .options(selectinload(DeliveryAct.items))
            .where(or_(*act_conds))
            .order_by(DeliveryAct.created_at.desc())
        )
        matched_act_from_code = act_lookup_res.scalars().first()

        if matched_act_from_code and matched_act_from_code.items:
            first_item = matched_act_from_code.items[0]
            eq_conds = [Equipment.serial_number.ilike(first_item.serial_number)]
            if first_item.equipment_id:
                eq_conds.append(Equipment.id == first_item.equipment_id)
            eq_from_act_res = await db.execute(
                select(Equipment)
                .options(selectinload(Equipment.current_warehouse))
                .where(or_(*eq_conds))
            )
            equipment = eq_from_act_res.scalars().first()

    if not equipment:
        raise HTTPException(
            status_code=404,
            detail=f"No se encontró ningún equipo ni acta oficial registrada con el código '{cleaned}'"
        )

    # Buscar última acta de asignación para saber el custodio y detalles (o usar el acta escaneada)
    if matched_act_from_code:
        latest_act = matched_act_from_code
    else:
        act_res = await db.execute(
            select(DeliveryAct)
            .join(DeliveryActItem, DeliveryAct.id == DeliveryActItem.act_id)
            .where(
                or_(
                    DeliveryActItem.equipment_id == equipment.id,
                    DeliveryActItem.serial_number == equipment.serial_number
                )
            )
            .order_by(DeliveryAct.created_at.desc())
        )
        latest_act = act_res.scalars().first()

    # Configuración de Marca Blanca
    cfg_res = await db.execute(select(CompanyConfig).limit(1))
    company_cfg = cfg_res.scalar_one_or_none()
    company_payload = {
        "name": company_cfg.name if (company_cfg and company_cfg.name) else "TUANDAMIO",
        "logo_url": company_cfg.logo_url if company_cfg else None,
        "primary_color": company_cfg.primary_color if company_cfg else "#2563EB",
        "support_message": "En caso de extravío o requerimiento técnico, comunicarse con la Gerencia de Tecnología."
    }

    return _build_ar_equipment_item(equipment, latest_act, company_payload)


@router.get("/barcode/{barcode}", response_model=EquipmentResponse)
async def get_equipment_by_barcode(
    barcode: str,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    cleaned = barcode.strip()
    result = await db.execute(
        select(Equipment).options(selectinload(Equipment.current_warehouse))
        .where(
            or_(Equipment.barcode == cleaned, Equipment.serial_number == cleaned),
            Equipment.is_active == True
        )
    )
    equipment = result.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado con ese código/serie")
    return equipment

@router.post("/", response_model=EquipmentResponse, status_code=status.HTTP_201_CREATED)
async def create_equipment(
    data: EquipmentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    clean_serial = data.serial_number.strip()
    existing = await db.execute(
        select(Equipment).where(Equipment.serial_number == clean_serial)
    )
    existing_eq = existing.scalar_one_or_none()
    if existing_eq:
        if existing_eq.is_active:
            raise HTTPException(status_code=400, detail="El número de serie ya está registrado en otro equipo activo")
        else:
            # Reactivar equipo que estaba previamente inactivo o borrado suave
            equipment_data = data.model_dump()
            equipment_data["serial_number"] = clean_serial
            if equipment_data.get("barcode"):
                equipment_data["barcode"] = equipment_data["barcode"].strip()
            equipment_data["category"] = (equipment_data.get("category") or "laptop").strip()
            await _ensure_catalog_entries(db, equipment_data.get("brand"), equipment_data.get("category"))
            equipment_data["is_active"] = True
            for k, v in equipment_data.items():
                setattr(existing_eq, k, v)
            await db.commit()
            await db.refresh(existing_eq)
            result = await db.execute(
                select(Equipment).options(selectinload(Equipment.current_warehouse))
                .where(Equipment.id == existing_eq.id)
            )
            return result.scalar_one()
    
    equipment_data = data.model_dump()
    equipment_data["serial_number"] = clean_serial
    if equipment_data.get("barcode"):
        equipment_data["barcode"] = equipment_data["barcode"].strip()
    equipment_data["category"] = (equipment_data.get("category") or "laptop").strip()
    await _ensure_catalog_entries(db, equipment_data.get("brand"), equipment_data.get("category"))

    equipment = Equipment(**equipment_data)
    db.add(equipment)
    await db.flush()

    if equipment.current_warehouse_id:
        movement = Movement(
            type=MovementType.entry,
            equipment_id=equipment.id,
            to_warehouse_id=equipment.current_warehouse_id,
            notes="Ingreso de nuevo equipo al inventario",
            performed_by=current_user.id
        )
        db.add(movement)

    await db.commit()
    await db.refresh(equipment)
    
    result = await db.execute(
        select(Equipment).options(selectinload(Equipment.current_warehouse))
        .where(Equipment.id == equipment.id)
    )
    return result.scalar_one()


@router.post("/batch", response_model=EquipmentBatchResponse, status_code=status.HTTP_201_CREATED)
async def create_equipment_batch(
    data: EquipmentBatchCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Registra en bloque un lote de equipos idénticos (misma marca, modelo, categoría y especificaciones) variando únicamente el serial."""
    raw_serials = [s.strip() for s in (data.serial_numbers or []) if s and s.strip()]
    # Deduplicar preservando el orden
    unique_serials: list[str] = []
    seen_lower: set[str] = set()
    for s in raw_serials:
        low = s.lower()
        if low not in seen_lower:
            seen_lower.add(low)
            unique_serials.append(s)

    if not unique_serials:
        raise HTTPException(status_code=400, detail="Debes indicar al menos un número de serie para el lote.")

    clean_category = (data.category or "laptop").strip()
    clean_brand = data.brand.strip() if data.brand else None
    clean_model = data.model.strip() if data.model else None
    clean_name = data.name.strip()

    await _ensure_catalog_entries(db, clean_brand, clean_category)

    created_ids: list[uuid.UUID] = []
    skipped_serials: list[str] = []

    for serial in unique_serials:
        existing_res = await db.execute(
            select(Equipment).where(Equipment.serial_number == serial)
        )
        existing_eq = existing_res.scalar_one_or_none()
        if existing_eq:
            if existing_eq.is_active:
                skipped_serials.append(serial)
                continue
            else:
                existing_eq.name = clean_name
                existing_eq.brand = clean_brand
                existing_eq.model = clean_model
                existing_eq.category = clean_category
                existing_eq.barcode = serial
                existing_eq.status = data.status or EquipmentStatus.available
                existing_eq.current_warehouse_id = data.current_warehouse_id
                existing_eq.assigned_to = data.assigned_to.strip() if data.assigned_to else None
                existing_eq.notes = data.notes.strip() if data.notes else None
                existing_eq.purchase_date = data.purchase_date
                existing_eq.purchase_price = data.purchase_price
                existing_eq.expected_lifespan_years = data.expected_lifespan_years or 3
                existing_eq.warranty_expires = data.warranty_expires
                existing_eq.is_active = True
                eq = existing_eq
        else:
            eq = Equipment(
                serial_number=serial,
                barcode=serial,
                name=clean_name,
                brand=clean_brand,
                model=clean_model,
                category=clean_category,
                status=data.status or EquipmentStatus.available,
                current_warehouse_id=data.current_warehouse_id,
                assigned_to=data.assigned_to.strip() if data.assigned_to else None,
                notes=data.notes.strip() if data.notes else None,
                purchase_date=data.purchase_date,
                purchase_price=data.purchase_price,
                expected_lifespan_years=data.expected_lifespan_years or 3,
                warranty_expires=data.warranty_expires,
                is_active=True,
            )
            db.add(eq)
            await db.flush()

        if eq.current_warehouse_id:
            movement = Movement(
                type=MovementType.entry,
                equipment_id=eq.id,
                to_warehouse_id=eq.current_warehouse_id,
                notes=f"Ingreso por lote de seriales ({len(unique_serials)} unidades)",
                performed_by=current_user.id,
            )
            db.add(movement)

        created_ids.append(eq.id)

    if not created_ids and skipped_serials:
        raise HTTPException(
            status_code=400,
            detail=f"Todos los seriales escaneados ya existen en el inventario activo: {', '.join(skipped_serials[:5])}"
        )

    await db.commit()

    items_res = await db.execute(
        select(Equipment)
        .options(selectinload(Equipment.current_warehouse))
        .where(Equipment.id.in_(created_ids))
        .order_by(Equipment.created_at.desc())
    )
    created_items = list(items_res.scalars().all())

    return EquipmentBatchResponse(
        created_count=len(created_items),
        skipped_serials=skipped_serials,
        items=created_items,
    )

@router.get("/import-template")
async def download_import_template(
    _: User = Depends(get_current_user)
):
    """Descarga la plantilla de Excel (.xlsx) con columnas oficiales y datos de ejemplo."""
    excel_stream = generate_excel_template()
    return StreamingResponse(
        excel_stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": 'attachment; filename="plantilla_inventario_equipos.xlsx"'
        }
    )


@router.post("/import-preview", response_model=EquipmentImportPreviewResponse)
async def preview_import_equipment(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    """Parsea el archivo Excel/CSV y valida cada fila contra la base de datos sin persistir cambios."""
    if not file.filename.lower().endswith((".xlsx", ".xls", ".csv", ".txt")):
        raise HTTPException(
            status_code=400,
            detail="Formato de archivo no compatible. Por favor sube un archivo Excel (.xlsx, .xls) o .csv"
        )

    contents = await file.read()
    raw_rows = parse_uploaded_file(contents, file.filename)

    if not raw_rows:
        raise HTTPException(
            status_code=400,
            detail="El archivo está vacío o no contiene filas con datos válidos."
        )

    # 1. Obtener todos los números de serie activos existentes en la BD
    existing_serials_query = await db.execute(
        select(Equipment.serial_number).where(Equipment.is_active == True)
    )
    existing_serials = {s.lower().strip() for s in existing_serials_query.scalars().all()}

    # 2. Obtener mapa de almacenes existentes por nombre
    warehouses_query = await db.execute(select(Warehouse))
    warehouses = warehouses_query.scalars().all()
    warehouse_name_map = {w.name.lower().strip(): w for w in warehouses}
    default_wh = warehouses[0] if warehouses else None

    seen_in_file_serials = set()
    preview_items: List[EquipmentImportItem] = []
    valid_count = 0
    error_count = 0

    for idx, row in enumerate(raw_rows, start=2): # Empieza en fila 2 por el encabezado
        serial = str(row.get("serial_number", "")).strip()
        name = str(row.get("name", "")).strip()
        brand = str(row.get("brand", "")).strip() or None
        model = str(row.get("model", "")).strip() or None
        category_raw = row.get("category", "")
        barcode = str(row.get("barcode", "")).strip() or None
        wh_raw = str(row.get("warehouse", "")).strip()
        status_raw = row.get("status", "")
        assigned_to = str(row.get("assigned_to", "")).strip() or None
        notes = str(row.get("notes", "")).strip() or None

        category = parse_category(category_raw)
        status_val = parse_status(status_raw)

        # Si viene assigned_to pero status era 'available', ajustar a 'assigned'
        if assigned_to and status_val == "available":
            status_val = "assigned"

        # Resolver almacén
        matched_wh = None
        if wh_raw:
            matched_wh = warehouse_name_map.get(wh_raw.lower())
        if not matched_wh:
            matched_wh = default_wh

        is_valid = True
        error_msg = None

        if not serial:
            is_valid = False
            error_msg = "Número de serie requerido"
        elif not name:
            is_valid = False
            error_msg = "Nombre de equipo requerido"
        elif serial.lower() in existing_serials:
            is_valid = False
            error_msg = f"El serial '{serial}' ya existe en la base de datos"
        elif serial.lower() in seen_in_file_serials:
            is_valid = False
            error_msg = f"Serial duplicado en el mismo archivo (Fila {idx})"
        else:
            seen_in_file_serials.add(serial.lower())

        if is_valid:
            valid_count += 1
        else:
            error_count += 1

        preview_items.append(
            EquipmentImportItem(
                row_index=idx,
                serial_number=serial or f"SIN_SERIE_FILA_{idx}",
                name=name or f"Equipo Fila {idx}",
                brand=brand,
                model=model,
                category=category,
                barcode=barcode,
                warehouse_name=matched_wh.name if matched_wh else (wh_raw or "Almacén Central"),
                warehouse_id=matched_wh.id if matched_wh else None,
                status=status_val,
                assigned_to=assigned_to,
                notes=notes,
                is_valid=is_valid,
                error_message=error_msg,
            )
        )

    return EquipmentImportPreviewResponse(
        total_rows=len(preview_items),
        valid_count=valid_count,
        error_count=error_count,
        items=preview_items
    )


@router.post("/import-commit", response_model=EquipmentImportCommitResponse)
async def commit_import_equipment(
    data: EquipmentImportCommitRequest,
    db: AsyncSession = Depends(get_db),
    admin_user: User = Depends(require_admin)
):
    """Guarda en bloque todos los equipos válidos confirmados por el usuario."""
    valid_items = [i for i in data.items if i.is_valid]
    if not valid_items:
        raise HTTPException(
            status_code=400,
            detail="No hay equipos válidos para importar."
        )

    # Almacén por defecto si alguno no lo tiene
    default_wh_id = data.default_warehouse_id
    if not default_wh_id:
        first_wh_res = await db.execute(select(Warehouse).limit(1))
        first_wh = first_wh_res.scalar_one_or_none()
        if first_wh:
            default_wh_id = first_wh.id

    try:
        imported_count = 0
        for item in valid_items:
            clean_serial = item.serial_number.strip()
            target_wh_id = item.warehouse_id or default_wh_id

            cat_val = (item.category or "other").strip()
            await _ensure_catalog_entries(db, item.brand, cat_val)

            try:
                status_enum = EquipmentStatus(item.status)
            except ValueError:
                status_enum = EquipmentStatus.available

            # Comprobar si ya existe en la base de datos (por ejemplo, si estaba inactivo o borrado suave)
            existing_res = await db.execute(
                select(Equipment).where(Equipment.serial_number == clean_serial)
            )
            existing_eq = existing_res.scalar_one_or_none()

            if existing_eq:
                # Reactivar y actualizar con los datos del archivo importado
                existing_eq.name = item.name.strip()
                existing_eq.brand = item.brand
                existing_eq.model = item.model
                existing_eq.category = cat_val
                existing_eq.barcode = item.barcode
                existing_eq.current_warehouse_id = target_wh_id
                existing_eq.status = status_enum
                existing_eq.assigned_to = item.assigned_to
                existing_eq.notes = item.notes
                existing_eq.is_active = True
                eq = existing_eq
            else:
                eq = Equipment(
                    serial_number=clean_serial,
                    name=item.name.strip(),
                    brand=item.brand,
                    model=item.model,
                    category=cat_val,
                    barcode=item.barcode,
                    current_warehouse_id=target_wh_id,
                    status=status_enum,
                    assigned_to=item.assigned_to,
                    notes=item.notes,
                    is_active=True
                )
                db.add(eq)
                await db.flush()

            # Registrar traza de entrada inicial en movimientos
            movement = Movement(
                type=MovementType.entry,
                equipment_id=eq.id,
                to_warehouse_id=target_wh_id,
                notes="Carga Masiva desde archivo Excel / CSV",
                performed_by=admin_user.id
            )
            db.add(movement)
            imported_count += 1

        await db.commit()

        return EquipmentImportCommitResponse(
            imported_count=imported_count,
            message=f"Se importaron exitosamente {imported_count} equipos al inventario."
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=400,
            detail=f"Error al guardar los equipos en la base de datos: {str(e)}"
        )


@router.get("/export-excel")
async def export_inventory_excel(
    warehouse_id: Optional[uuid.UUID] = Query(None),
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Exporta el inventario completo o filtrado en un libro Excel formateado profesionalmente."""
    query = select(Equipment).options(
        selectinload(Equipment.current_warehouse)
    ).where(Equipment.is_active == True)

    filter_desc = "Inventario Completo"
    if warehouse_id:
        query = query.where(Equipment.current_warehouse_id == warehouse_id)
        wh_res = await db.execute(select(Warehouse).where(Warehouse.id == warehouse_id))
        wh = wh_res.scalar_one_or_none()
        if wh:
            filter_desc = f"Almacén: {wh.name}"

    if status and status != "all":
        try:
            query = query.where(Equipment.status == EquipmentStatus(status))
            filter_desc += f" | Estado: {status}"
        except ValueError:
            pass

    if category and category != "all":
        query = query.where(Equipment.category == category)
        filter_desc += f" | Tipo: {category}"

    query = query.order_by(Equipment.category, Equipment.name)
    result = await db.execute(query)
    equipments = result.scalars().all()

    # Obtener nombre de la empresa
    company_res = await db.execute(select(CompanyConfig).limit(1))
    company_cfg = company_res.scalar_one_or_none()
    company_name = company_cfg.name if company_cfg and company_cfg.name else "InventoryOS"

    excel_stream = generate_inventory_excel_workbook(
        equipment_list=equipments,
        company_name=company_name,
        filter_label=filter_desc
    )

    clean_comp_name = "".join(c for c in company_name if c.isalnum() or c in ("-", "_")).lower()
    filename = f"inventario_{clean_comp_name or 'equipos'}.xlsx"

    return StreamingResponse(
        excel_stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )


@router.post("/labels-pdf")
async def generate_labels_pdf(
    data: LabelsPdfRequest,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Genera una plancha PDF de etiquetas (10 por hoja carta) para los activos seleccionados."""
    if not data.equipment_ids:
        raise HTTPException(status_code=400, detail="Debe seleccionar al menos un equipo")

    query = select(Equipment).options(
        selectinload(Equipment.current_warehouse)
    ).where(Equipment.id.in_(data.equipment_ids))

    res = await db.execute(query)
    equipments = res.scalars().all()
    if not equipments:
        raise HTTPException(status_code=404, detail="No se encontraron los equipos seleccionados")

    company_res = await db.execute(select(CompanyConfig).limit(1))
    company_cfg = company_res.scalar_one_or_none()
    company_name = company_cfg.name if company_cfg and company_cfg.name else "InventoryOS"

    pdf_stream = generate_labels_pdf_sheet(
        equipments,
        company_name=company_name,
        base_url=data.base_url
    )
    return StreamingResponse(
        pdf_stream,
        media_type="application/pdf",
        headers={
            "Content-Disposition": 'inline; filename="etiquetas_activos.pdf"'
        }
    )


@router.get("/{equipment_id}/qr-label")
async def get_equipment_qr_label(
    equipment_id: uuid.UUID,
    base_url: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """Genera la imagen PNG individual del código QR con datos del activo (URL directa o Serial)."""
    res = await db.execute(
        select(Equipment).options(selectinload(Equipment.current_warehouse))
        .where(Equipment.id == equipment_id)
    )
    equipment = res.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")

    company_res = await db.execute(select(CompanyConfig).limit(1))
    company_cfg = company_res.scalar_one_or_none()
    company_name = company_cfg.name if company_cfg and company_cfg.name else "InventoryOS"

    png_stream = generate_equipment_qr_image(
        equipment,
        company_name=company_name,
        base_url=base_url
    )
    return StreamingResponse(
        png_stream,
        media_type="image/png",
        headers={
            "Content-Disposition": f'inline; filename="qr_{equipment.serial_number}.png"'
        }
    )


@router.post("/{equipment_id}/verify-presence")
async def verify_equipment_presence(
    equipment_id: uuid.UUID,
    data: Optional[VerifyPresenceRequest] = None,
    db: AsyncSession = Depends(get_db)
):
    """Registra una verificación rápida de presencia física desde el Escáner AR / HUD (soporta sincronización offline)."""
    res = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    equipment = res.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")

    now_utc = datetime.now(timezone.utc)
    equipment.updated_at = now_utc
    await db.commit()

    return {
        "status": "verified",
        "equipment_id": str(equipment.id),
        "serial_number": equipment.serial_number,
        "verified_at": now_utc.isoformat()
    }


@router.get("/{equipment_id}", response_model=EquipmentResponse)
async def get_equipment(
    equipment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Equipment).options(selectinload(Equipment.current_warehouse))
        .where(Equipment.id == equipment_id, Equipment.is_active == True)
    )
    equipment = result.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")
    return equipment

@router.put("/{equipment_id}", response_model=EquipmentResponse)
async def update_equipment(
    equipment_id: uuid.UUID,
    data: EquipmentUpdate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    result = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    equipment = result.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")

    update_dict = data.model_dump(exclude_unset=True)

    # Validar número de serie si cambia
    if "serial_number" in update_dict and update_dict["serial_number"]:
        clean_serial = update_dict["serial_number"].strip()
        if clean_serial != equipment.serial_number:
            conflict = await db.execute(
                select(Equipment).where(
                    Equipment.serial_number == clean_serial,
                    Equipment.id != equipment_id
                )
            )
            conflict_eq = conflict.scalar_one_or_none()
            if conflict_eq:
                raise HTTPException(status_code=400, detail="Ese número de serie ya está en uso por otro equipo en el sistema")
            update_dict["serial_number"] = clean_serial

    if "barcode" in update_dict and update_dict["barcode"]:
        update_dict["barcode"] = update_dict["barcode"].strip()

    if "category" in update_dict and update_dict["category"]:
        update_dict["category"] = update_dict["category"].strip()

    await _ensure_catalog_entries(
        db,
        update_dict.get("brand"),
        update_dict.get("category")
    )

    for field, value in update_dict.items():
        setattr(equipment, field, value)

    await db.commit()
    
    result = await db.execute(
        select(Equipment).options(selectinload(Equipment.current_warehouse))
        .where(Equipment.id == equipment_id)
    )
    return result.scalar_one()

@router.delete("/{equipment_id}", status_code=status.HTTP_200_OK)
async def delete_equipment(
    equipment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    result = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    equipment = result.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")

    # Borrado suave para mantener el historial de auditoría de movimientos pasados
    equipment.is_active = False
    await db.commit()

    return {"message": "Equipo eliminado correctamente", "id": equipment_id}


@router.get("/{equipment_id}/maintenances", response_model=List[EquipmentMaintenanceResponse])
async def list_equipment_maintenances(
    equipment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Lista la Hoja de Vida técnica (mantenimientos preventivos, reparaciones y upgrades) de un equipo."""
    res = await db.execute(
        select(EquipmentMaintenance)
        .where(EquipmentMaintenance.equipment_id == equipment_id)
        .order_by(EquipmentMaintenance.performed_at.desc(), EquipmentMaintenance.created_at.desc())
    )
    return res.scalars().all()


@router.post("/{equipment_id}/maintenances", response_model=EquipmentMaintenanceResponse, status_code=status.HTTP_201_CREATED)
async def create_equipment_maintenance(
    equipment_id: uuid.UUID,
    data: EquipmentMaintenanceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Registra un evento en la Hoja de Vida del equipo y opcionalmente actualiza su ficha técnica (notes)."""
    eq_res = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    equipment = eq_res.scalar_one_or_none()
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipo no encontrado")

    maint = EquipmentMaintenance(
        equipment_id=equipment_id,
        maintenance_type=data.maintenance_type or "preventive",
        title=data.title.strip(),
        description=data.description.strip() if data.description else None,
        cost=data.cost or 0,
        performed_by=(data.performed_by or current_user.full_name or "Raimundo Gil").strip(),
        performed_at=data.performed_at or date.today(),
        new_specs=data.new_specs.strip() if data.new_specs else None,
    )
    db.add(maint)

    if data.update_equipment_specs and data.new_specs and data.new_specs.strip():
        equipment.notes = data.new_specs.strip()

    await db.commit()
    await db.refresh(maint)
    return maint


@router.delete("/{equipment_id}/maintenances/{maintenance_id}", status_code=status.HTTP_200_OK)
async def delete_equipment_maintenance(
    equipment_id: uuid.UUID,
    maintenance_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Elimina un registro de mantenimiento de la Hoja de Vida del equipo."""
    res = await db.execute(
        select(EquipmentMaintenance).where(
            EquipmentMaintenance.id == maintenance_id,
            EquipmentMaintenance.equipment_id == equipment_id
        )
    )
    maint = res.scalar_one_or_none()
    if not maint:
        raise HTTPException(status_code=404, detail="Registro de mantenimiento no encontrado")

    await db.delete(maint)
    await db.commit()
    return {"message": "Registro eliminado correctamente"}


