import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from typing import List
from app.core.database import get_db
from app.api.deps import get_current_user, require_admin
from app.models.user import User
from app.models.warehouse import Warehouse
from app.models.equipment import Equipment
from app.schemas.warehouse import WarehouseCreate, WarehouseUpdate, WarehouseResponse

router = APIRouter()

@router.get("/", response_model=List[WarehouseResponse])
async def list_warehouses(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    # Cargar todos los almacenes activos ordenados (primero primarios, luego sub-almacenes)
    result = await db.execute(
        select(Warehouse)
        .where(Warehouse.is_active == True)
        .order_by(Warehouse.parent_id.nulls_first(), Warehouse.name)
    )
    warehouses = result.scalars().all()
    warehouse_map = {w.id: w for w in warehouses}

    # Contar equipos directos por cada almacén
    eq_counts_res = await db.execute(
        select(Equipment.current_warehouse_id, func.count(Equipment.id))
        .where(Equipment.is_active == True, Equipment.current_warehouse_id.is_not(None))
        .group_by(Equipment.current_warehouse_id)
    )
    direct_counts = {wh_id: count for wh_id, count in eq_counts_res.all()}

    # Agrupar sub-almacenes por padre
    children_map: dict[uuid.UUID, list[Warehouse]] = {}
    for w in warehouses:
        if w.parent_id:
            children_map.setdefault(w.parent_id, []).append(w)

    response = []
    for w in warehouses:
        direct_count = direct_counts.get(w.id, 0)
        sub_list = children_map.get(w.id, [])
        sub_count = len(sub_list)

        # Total = equipos directos + equipos en todos sus sub-almacenes
        sub_eq_total = sum(direct_counts.get(child.id, 0) for child in sub_list)
        total_count = direct_count + sub_eq_total

        resp = WarehouseResponse(
            id=w.id,
            name=w.name,
            location=w.location,
            description=w.description,
            is_active=w.is_active,
            parent_id=w.parent_id,
            parent_name=warehouse_map[w.parent_id].name if w.parent_id and w.parent_id in warehouse_map else None,
            created_at=w.created_at,
            equipment_count=direct_count,
            total_equipment_count=total_count,
            sub_warehouses_count=sub_count,
        )
        response.append(resp)

    return response

@router.post("/", response_model=WarehouseResponse, status_code=status.HTTP_201_CREATED)
async def create_warehouse(
    data: WarehouseCreate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    # Validar que si viene parent_id, el almacén padre exista
    parent_name = None
    if data.parent_id:
        p_res = await db.execute(select(Warehouse).where(Warehouse.id == data.parent_id, Warehouse.is_active == True))
        parent = p_res.scalar_one_or_none()
        if not parent:
            raise HTTPException(status_code=400, detail="El almacén principal especificado no existe")
        parent_name = parent.name

    warehouse = Warehouse(**data.model_dump())
    db.add(warehouse)
    await db.commit()
    await db.refresh(warehouse)

    return WarehouseResponse(
        id=warehouse.id,
        name=warehouse.name,
        location=warehouse.location,
        description=warehouse.description,
        is_active=warehouse.is_active,
        parent_id=warehouse.parent_id,
        parent_name=parent_name,
        created_at=warehouse.created_at,
        equipment_count=0,
        total_equipment_count=0,
        sub_warehouses_count=0,
    )

@router.get("/{warehouse_id}", response_model=WarehouseResponse)
async def get_warehouse(
    warehouse_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user)
):
    result = await db.execute(select(Warehouse).where(Warehouse.id == warehouse_id))
    warehouse = result.scalar_one_or_none()
    if not warehouse:
        raise HTTPException(status_code=404, detail="Almacén no encontrado")

    parent_name = None
    if warehouse.parent_id:
        p_res = await db.execute(select(Warehouse.name).where(Warehouse.id == warehouse.parent_id))
        parent_name = p_res.scalar_one_or_none()

    count_result = await db.execute(
        select(func.count(Equipment.id)).where(
            Equipment.current_warehouse_id == warehouse_id,
            Equipment.is_active == True
        )
    )
    count = count_result.scalar() or 0

    sub_res = await db.execute(select(func.count(Warehouse.id)).where(Warehouse.parent_id == warehouse_id, Warehouse.is_active == True))
    sub_count = sub_res.scalar() or 0

    return WarehouseResponse(
        id=warehouse.id,
        name=warehouse.name,
        location=warehouse.location,
        description=warehouse.description,
        is_active=warehouse.is_active,
        parent_id=warehouse.parent_id,
        parent_name=parent_name,
        created_at=warehouse.created_at,
        equipment_count=count,
        total_equipment_count=count,
        sub_warehouses_count=sub_count,
    )

@router.put("/{warehouse_id}", response_model=WarehouseResponse)
async def update_warehouse(
    warehouse_id: uuid.UUID,
    data: WarehouseUpdate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    result = await db.execute(select(Warehouse).where(Warehouse.id == warehouse_id))
    warehouse = result.scalar_one_or_none()
    if not warehouse:
        raise HTTPException(status_code=404, detail="Almacén no encontrado")

    update_dict = data.model_dump(exclude_unset=True)

    # Validar que no se asigne a sí mismo como padre
    if "parent_id" in update_dict and update_dict["parent_id"] == warehouse_id:
        raise HTTPException(status_code=400, detail="Un almacén no puede ser sub-almacén de sí mismo")

    parent_name = None
    if update_dict.get("parent_id"):
        p_res = await db.execute(select(Warehouse.name).where(Warehouse.id == update_dict["parent_id"]))
        parent_name = p_res.scalar_one_or_none()

    for field, value in update_dict.items():
        setattr(warehouse, field, value)

    await db.commit()
    await db.refresh(warehouse)

    count_result = await db.execute(
        select(func.count(Equipment.id)).where(
            Equipment.current_warehouse_id == warehouse_id,
            Equipment.is_active == True
        )
    )
    count = count_result.scalar() or 0

    return WarehouseResponse(
        id=warehouse.id,
        name=warehouse.name,
        location=warehouse.location,
        description=warehouse.description,
        is_active=warehouse.is_active,
        parent_id=warehouse.parent_id,
        parent_name=parent_name,
        created_at=warehouse.created_at,
        equipment_count=count,
        total_equipment_count=count,
        sub_warehouses_count=0,
    )

@router.delete("/{warehouse_id}", status_code=status.HTTP_200_OK)
async def delete_warehouse(
    warehouse_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin)
):
    result = await db.execute(select(Warehouse).where(Warehouse.id == warehouse_id))
    warehouse = result.scalar_one_or_none()
    if not warehouse:
        raise HTTPException(status_code=404, detail="Almacén no encontrado")

    # 1. Verificar si tiene equipos activos asignados
    count_result = await db.execute(
        select(func.count(Equipment.id)).where(
            Equipment.current_warehouse_id == warehouse_id,
            Equipment.is_active == True
        )
    )
    equipment_count = count_result.scalar() or 0
    if equipment_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"No se puede eliminar el almacén porque contiene {equipment_count} equipo(s). Trasládalos a otro almacén antes de eliminarlo."
        )

    # 2. Verificar si tiene sub-almacenes
    sub_count_res = await db.execute(
        select(func.count(Warehouse.id)).where(
            Warehouse.parent_id == warehouse_id,
            Warehouse.is_active == True
        )
    )
    sub_count = sub_count_res.scalar() or 0
    if sub_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"No se puede eliminar este almacén porque tiene {sub_count} sub-almacén(es) asociados. Reasígnalos o elimínalos primero."
        )

    # Borrado suave (o físico si no tiene dependencias)
    warehouse.is_active = False
    await db.commit()

    return {"message": "Almacén eliminado correctamente", "id": warehouse_id}
