from datetime import date, datetime, timezone
from decimal import Decimal
import json
from typing import Optional
import uuid
import urllib.request
from fastapi import APIRouter, Depends, Header, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.models import (
    CompanyConfig,
    DeliveryAct,
    DeliveryActItem,
    Equipment,
    EquipmentCatalogItem,
    EquipmentMaintenance,
    Movement,
    User,
    Warehouse,
)

router = APIRouter()

# Almacenamiento en memoria / archivo del webhook de Google Apps Script si el usuario lo configura desde la UI
_WEBHOOK_CONFIG_FILE = "/app/uploads/google_webhook_config.json"


def _get_saved_webhook_url() -> Optional[str]:
    try:
        if os.path.exists(_WEBHOOK_CONFIG_FILE):
            with open(_WEBHOOK_CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("webhook_url") or settings.GOOGLE_APPS_SCRIPT_WEBHOOK_URL
    except Exception:
        pass
    return settings.GOOGLE_APPS_SCRIPT_WEBHOOK_URL


def _save_webhook_url(url: Optional[str]) -> None:
    try:
        os.makedirs(os.path.dirname(_WEBHOOK_CONFIG_FILE), exist_ok=True)
        with open(_WEBHOOK_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump({"webhook_url": (url or "").strip()}, f)
    except Exception:
        pass


import os


def _serialize_val(val):
    if val is None:
        return None
    if isinstance(val, uuid.UUID):
        return str(val)
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, Decimal):
        return float(val)
    if hasattr(val, "value"):
        return val.value
    return val


def _model_to_dict(obj):
    data = {}
    for col in obj.__table__.columns:
        data[col.name] = _serialize_val(getattr(obj, col.name))
    return data


STATUS_LABELS_ES = {
    "available": "Disponible",
    "assigned": "Asignado",
    "maintenance": "En Mantenimiento",
    "retired": "Retirado / Baja",
    "lost": "Extraviado",
}

MOVEMENT_LABELS_ES = {
    "entry": "Entrada / Registro",
    "exit": "Asignación / Salida",
    "transfer": "Transferencia entre Almacenes",
    "return": "Devolución a Stock",
    "maintenance": "Envío a Mantenimiento",
}


async def _build_cloud_backup_payload(db: AsyncSession) -> dict:
    # 1. Raw database snapshot (compatible con initial_seed_data.json)
    raw_snapshot = {}

    cfg_res = await db.execute(select(CompanyConfig))
    configs = cfg_res.scalars().all()
    raw_snapshot["company_config"] = [_model_to_dict(x) for x in configs]
    company_name = configs[0].name if configs else "Grupo Tu Andamio"

    usr_res = await db.execute(select(User))
    users = usr_res.scalars().all()
    raw_snapshot["users"] = [_model_to_dict(x) for x in users]
    user_map = {str(u.id): u.full_name or u.username for u in users}

    wh_res = await db.execute(select(Warehouse))
    warehouses = wh_res.scalars().all()
    raw_snapshot["warehouses"] = [_model_to_dict(x) for x in warehouses]
    wh_map = {str(w.id): w.name for w in warehouses}

    cat_res = await db.execute(select(EquipmentCatalogItem))
    catalogs = cat_res.scalars().all()
    raw_snapshot["equipment_catalogs"] = [_model_to_dict(x) for x in catalogs]

    eq_res = await db.execute(select(Equipment).order_by(Equipment.created_at.desc()))
    all_equipment = eq_res.scalars().all()
    raw_snapshot["equipment"] = [_model_to_dict(x) for x in all_equipment]
    active_equipment = [e for e in all_equipment if e.is_active]
    eq_map = {str(e.id): e for e in all_equipment}

    maint_res = await db.execute(select(EquipmentMaintenance))
    raw_snapshot["equipment_maintenances"] = [_model_to_dict(x) for x in maint_res.scalars().all()]

    act_res = await db.execute(select(DeliveryAct).order_by(DeliveryAct.created_at.desc()))
    acts = act_res.scalars().all()
    raw_snapshot["delivery_acts"] = [_model_to_dict(x) for x in acts]

    act_items_res = await db.execute(select(DeliveryActItem))
    act_items = act_items_res.scalars().all()
    raw_snapshot["delivery_act_items"] = [_model_to_dict(x) for x in act_items]

    mv_res = await db.execute(select(Movement).order_by(Movement.created_at.desc()))
    movements = mv_res.scalars().all()
    raw_snapshot["movements"] = [_model_to_dict(x) for x in movements]

    # 2. Tablas formateadas listas para Google Sheets
    # Hoja 1: Equipos Activos
    equipos_rows = []
    for idx, e in enumerate(active_equipment, start=1):
        st_code = e.status.value if hasattr(e.status, "value") else str(e.status)
        wh_name = wh_map.get(str(e.current_warehouse_id), "Sin Almacén") if e.current_warehouse_id else "En Tránsito / Asignado"
        equipos_rows.append([
            idx,
            e.serial_number or "",
            e.name or "",
            e.brand or "",
            e.model or "",
            (e.category or "").upper(),
            STATUS_LABELS_ES.get(st_code, st_code),
            wh_name,
            e.assigned_to or "—",
            float(e.purchase_price) if e.purchase_price is not None else 0.0,
            e.purchase_date.isoformat() if e.purchase_date else "—",
            e.warranty_expires.isoformat() if e.warranty_expires else "—",
            e.notes or "",
            e.updated_at.strftime("%Y-%m-%d %H:%M") if e.updated_at else "",
        ])

    # Hoja 2: Resumen por Almacén
    almacenes_rows = []
    for w in [w for w in warehouses if w.is_active]:
        w_eqs = [e for e in active_equipment if str(e.current_warehouse_id) == str(w.id)]
        disp = sum(1 for e in w_eqs if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "available")
        asig = sum(1 for e in w_eqs if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "assigned")
        mant = sum(1 for e in w_eqs if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "maintenance")
        val_usd = sum(float(e.purchase_price or 0) for e in w_eqs)
        parent_name = wh_map.get(str(w.parent_id), "Sede Principal") if w.parent_id else "Sede Principal"
        almacenes_rows.append([
            w.name,
            parent_name,
            w.location or "Caracas",
            len(w_eqs),
            disp,
            asig,
            mant,
            round(val_usd, 2),
            w.description or "",
        ])

    # Hoja 3: Historial de Movimientos (últimos 250)
    movimientos_rows = []
    for m in movements[:250]:
        eq_obj = eq_map.get(str(m.equipment_id))
        m_code = m.type.value if hasattr(m.type, "value") else str(m.type)
        movimientos_rows.append([
            m.created_at.strftime("%Y-%m-%d %H:%M") if m.created_at else "",
            MOVEMENT_LABELS_ES.get(m_code, m_code),
            eq_obj.serial_number if eq_obj else "—",
            eq_obj.name if eq_obj else "Equipo Eliminado",
            wh_map.get(str(m.from_warehouse_id), "—") if m.from_warehouse_id else "—",
            wh_map.get(str(m.to_warehouse_id), "—") if m.to_warehouse_id else "—",
            m.assigned_to or "—",
            user_map.get(str(m.performed_by), "Sistema"),
            m.notes or "",
        ])

    # Hoja 4: Actas de Entrega
    items_by_act = {}
    for it in act_items:
        aid = str(it.act_id)
        items_by_act.setdefault(aid, []).append(f"{it.equipment_name} (S/N: {it.serial_number})")

    actas_rows = []
    for a in acts:
        eq_summary = " | ".join(items_by_act.get(str(a.id), []))
        actas_rows.append([
            a.act_number,
            "Asignación" if a.act_type == "assignment" else "Devolución",
            a.created_at.strftime("%Y-%m-%d %H:%M") if a.created_at else "",
            a.recipient_name,
            a.recipient_id_card,
            a.recipient_position or "—",
            a.recipient_department or "—",
            a.delivered_by_name or "Raimundo Gil",
            len(items_by_act.get(str(a.id), [])),
            eq_summary,
            a.accessories or "—",
        ])

    now_iso = datetime.now(timezone.utc).isoformat()
    return {
        "status": "ok",
        "company": company_name,
        "generated_at": now_iso,
        "summary": {
            "total_active_equipment": len(active_equipment),
            "total_warehouses": len([w for w in warehouses if w.is_active]),
            "total_delivery_acts": len(acts),
            "total_movements": len(movements),
        },
        "sheets": {
            "equipos": {
                "title": "Inventario de Equipos",
                "headers": [
                    "#", "Serial", "Nombre del Equipo", "Marca", "Modelo",
                    "Categoría", "Estado", "Almacén Actual", "Asignado A",
                    "Precio USD", "Fecha Compra", "Vence Garantía", "Notas", "Última Actualización"
                ],
                "rows": equipos_rows,
            },
            "almacenes": {
                "title": "Resumen por Almacén",
                "headers": [
                    "Almacén", "Jerarquía / Sede Padre", "Ubicación", "Total Equipos",
                    "Disponibles", "Asignados", "En Mantenimiento", "Valor Total USD", "Descripción"
                ],
                "rows": almacenes_rows,
            },
            "movimientos": {
                "title": "Historial de Movimientos",
                "headers": [
                    "Fecha y Hora", "Tipo de Movimiento", "Serial Equipo", "Nombre Equipo",
                    "Almacén Origen", "Almacén Destino", "Responsable / Asignado", "Ejecutado Por", "Notas"
                ],
                "rows": movimientos_rows,
            },
            "actas": {
                "title": "Actas de Entrega",
                "headers": [
                    "N° de Acta", "Tipo", "Fecha Emisión", "Receptor (Trabajador)",
                    "Cédula", "Cargo", "Departamento", "Entregado Por (TI)",
                    "Cant. Equipos", "Equipos Incluidos", "Accesorios"
                ],
                "rows": actas_rows,
            },
        },
        "raw_database_snapshot": raw_snapshot,
    }


@router.get("/cloud")
async def export_cloud_backup_for_google(
    key: Optional[str] = Query(default=None, description="Clave de sincronización para Google Drive / Sheets"),
    x_backup_key: Optional[str] = Header(default=None),
    db: AsyncSession = Depends(get_db),
):
    """
    Endpoint consumido por Google Apps Script para sincronizar las 4 pestañas de Google Sheets
    y guardar automáticamente un archivo de respaldo JSON completo en Google Drive.
    """
    provided_key = (key or x_backup_key or "").strip()
    if provided_key != settings.BACKUP_SYNC_KEY:
        raise HTTPException(status_code=401, detail="Clave de sincronización Cloud inválida (BACKUP_SYNC_KEY).")
    return await _build_cloud_backup_payload(db)


@router.get("/download-json")
async def download_full_backup_json(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Permite descargar manualmente la copia completa de la base de datos en formato JSON."""
    payload = await _build_cloud_backup_payload(db)
    filename = f"Backup_InventarioGTA_{datetime.now().strftime('%Y-%m-%d_%H%M')}.json"
    content = json.dumps(payload["raw_database_snapshot"], ensure_ascii=False, indent=2)
    return Response(
        content=content,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


class WebhookConfigUpdate(BaseModel):
    webhook_url: Optional[str] = None


@router.get("/status")
async def get_backup_integration_status(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    payload = await _build_cloud_backup_payload(db)
    return {
        "sync_key": settings.BACKUP_SYNC_KEY,
        "cloud_endpoint_path": f"/api/v1/backup/cloud?key={settings.BACKUP_SYNC_KEY}",
        "webhook_url": _get_saved_webhook_url() or "",
        "summary": payload["summary"],
        "generated_at": payload["generated_at"],
    }


@router.post("/webhook-config")
async def update_google_webhook_config(
    body: WebhookConfigUpdate,
    current_user: User = Depends(get_current_user),
):
    _save_webhook_url(body.webhook_url)
    return {"status": "saved", "webhook_url": _get_saved_webhook_url() or ""}


@router.post("/push-to-google")
async def push_backup_to_google_now(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Envía inmediatamente (Push) toda la base de datos hacia el Web App de Google Apps Script
    si el usuario pegó la URL de su script, actualizando Google Sheets y guardando copia en Google Drive al instante.
    """
    webhook_url = _get_saved_webhook_url()
    if not webhook_url:
        raise HTTPException(
            status_code=400,
            detail="Aún no has pegado la URL del Web App de Google Apps Script (o puedes ejecutar la sincronización directamente desde el menú '🏢 Inventario GTA' dentro de tu Google Sheet).",
        )
    payload = await _build_cloud_backup_payload(db)
    data_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        webhook_url,
        data=data_bytes,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            resp_body = resp.read().decode("utf-8", errors="ignore")
        return {
            "status": "pushed",
            "message": "Sincronización enviada exitosamente a Google Sheets y Google Drive.",
            "google_response": resp_body[:300],
            "summary": payload["summary"],
        }
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"No se pudo contactar con el Web App de Google Apps Script: {exc}",
        )
