import io
import csv
import re
import unicodedata
from typing import List, Dict, Any, Tuple
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Mapeo flexible de columnas para admitir diversos nombres en español e inglés
COLUMN_ALIASES = {
    "serial_number": ["serial_number", "serial", "serie", "numero_de_serie", "nro_serie", "sn", "s_n", "no_serie"],
    "name": ["name", "nombre", "equipo", "nombre_del_equipo", "descripcion", "activo"],
    "brand": ["brand", "marca", "fabricante"],
    "model": ["model", "modelo"],
    "category": ["category", "categoria", "tipo", "tipo_de_equipo"],
    "barcode": ["barcode", "codigo_de_barras", "codigo", "cod_barras", "upc", "ean"],
    "warehouse": ["warehouse", "almacen", "sucursal", "ubicacion", "bodega", "localidad"],
    "status": ["status", "estado", "estatus", "condicion"],
    "assigned_to": ["assigned_to", "asignado_a", "responsable", "trabajador", "custodio", "empleado"],
    "notes": ["notes", "observaciones", "especificaciones", "detalles", "comentarios", "specs", "observaciones_especificaciones"],
}

CATEGORY_MAP = {
    "laptop": "laptop",
    "portatil": "laptop",
    "computadora portatil": "laptop",
    "notebook": "laptop",
    "desktop": "desktop",
    "escritorio": "desktop",
    "pc": "desktop",
    "computador": "desktop",
    "computadora": "desktop",
    "all in one": "desktop",
    "aio": "desktop",
    "monitor": "monitor",
    "pantalla": "monitor",
    "switch": "switch",
    "conmutador": "switch",
    "router": "router",
    "enrutador": "router",
    "server": "server",
    "servidor": "server",
    "phone": "phone",
    "telefono": "phone",
    "movil": "phone",
    "celular": "phone",
    "smartphone": "phone",
    "tablet": "tablet",
    "tableta": "tablet",
    "printer": "printer",
    "impresora": "printer",
    "ups": "ups",
    "no break": "ups",
    "bateria": "ups",
    "cable": "cable",
    "cargador": "cable",
    "adaptador": "cable",
    "teclado": "keyboard",
    "keyboard": "keyboard",
    "mouse": "mouse",
    "raton": "mouse",
    "other": "other",
    "otro": "other",
}

STATUS_MAP = {
    "disponible": "available",
    "available": "available",
    "libre": "available",
    "en almacen": "available",
    "almacen": "available",
    "bueno": "available",
    "operativo": "available",
    "excelente": "available",
    "regular": "available",
    "nuevo": "available",
    "asignado": "assigned",
    "assigned": "assigned",
    "en uso": "assigned",
    "entregado": "assigned",
    "mantenimiento": "maintenance",
    "maintenance": "maintenance",
    "en reparacion": "maintenance",
    "reparacion": "maintenance",
    "malo": "maintenance",
    "averiado": "maintenance",
    "danado": "maintenance",
    "retirado": "retired",
    "retired": "retired",
    "baja": "retired",
    "de baja": "retired",
    "desincorporado": "retired",
    "extraviado": "lost",
    "lost": "lost",
    "perdido": "lost",
}

def remove_accents(text: Any) -> str:
    nfkd = unicodedata.normalize('NFKD', str(text or ''))
    return ''.join([c for c in nfkd if not unicodedata.combining(c)])

def normalize_key(text: str) -> str:
    clean = remove_accents(text).lower().strip()
    clean = re.sub(r'[^a-zA-Z0-9]', '_', clean)
    clean = re.sub(r'_+', '_', clean).strip('_')
    for standard_col, aliases in COLUMN_ALIASES.items():
        if clean in aliases:
            return standard_col
    return clean

def parse_category(val: Any) -> str:
    if not val:
        return "other"
    raw = str(val).strip()
    if not raw:
        return "other"
    v = remove_accents(raw).lower().strip()
    return CATEGORY_MAP.get(v, raw)

def parse_status(val: Any) -> str:
    if not val:
        return "available"
    v = remove_accents(val).lower().strip()
    return STATUS_MAP.get(v, "available")

def generate_excel_template() -> io.BytesIO:
    """Genera un archivo Excel .xlsx profesional con encabezados y datos de muestra."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Equipos para Importar"
    ws.views.sheetView[0].showGridLines = True

    # Estilos
    header_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    sample_font = Font(name="Calibri", size=10)
    thin_border = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1")
    )
    center_align = Alignment(horizontal="center", vertical="center")
    left_align = Alignment(horizontal="left", vertical="center")

    headers = [
        "Número de Serie *",
        "Nombre del Equipo *",
        "Marca",
        "Modelo",
        "Categoría",
        "Código de Barras",
        "Almacén",
        "Estado",
        "Asignado a",
        "Observaciones / Especificaciones"
    ]

    ws.append(headers)
    for col_num in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_num)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center_align
        cell.border = thin_border
    ws.row_dimensions[1].height = 28

    sample_rows = [
        [
            "PF-3X99AB",
            "Laptop Lenovo ThinkPad T14",
            "Lenovo",
            "T14 Gen 4",
            "Laptop",
            "750123456789",
            "Almacén Central",
            "Disponible",
            "",
            "Core i7, 16GB RAM, 512GB SSD NVMe"
        ],
        [
            "58D61F646ECE",
            "Switch Ubiquiti USW Enterprise 8 PoE",
            "Ubiquiti",
            "USW-Enterprise-8-PoE",
            "Switch",
            "810010074218",
            "Almacén Central",
            "Disponible",
            "",
            "8 puertos 2.5G PoE+, 2 puertos SFP+ 10G"
        ],
        [
            "CN-0ABC12",
            "Monitor Dell UltraSharp 27 pulgadas",
            "Dell",
            "U2723QE",
            "Monitor",
            "",
            "Almacén Central",
            "Disponible",
            "",
            "Resolución 4K UHD, IPS Black, USB-C 90W Hub"
        ],
        [
            "8CC55224PG",
            "Computadora All in One HP 27",
            "HP",
            "27-cr0278la",
            "Desktop",
            "",
            "Almacén Central",
            "Asignado",
            "Marbelys Ochoa",
            "AMD Ryzen 7 7730U, 16GB RAM, 1TB SSD"
        ],
    ]

    for row_idx, row_data in enumerate(sample_rows, start=2):
        ws.append(row_data)
        ws.row_dimensions[row_idx].height = 22
        for col_idx in range(1, len(row_data) + 1):
            c = ws.cell(row=row_idx, column=col_idx)
            c.font = sample_font
            c.border = thin_border
            if col_idx in (1, 6): # Seriales / códigos
                c.alignment = center_align
            else:
                c.alignment = left_align

    # Ajuste automático del ancho de columnas
    for col in ws.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 14)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output

def parse_uploaded_file(contents: bytes, filename: str) -> List[Dict[str, Any]]:
    """Parsea el contenido de un archivo .xlsx, .xls o .csv a una lista de diccionarios normalizados."""
    fname = filename.lower()
    rows = []

    if fname.endswith((".xlsx", ".xls")):
        wb = openpyxl.load_workbook(io.BytesIO(contents), data_only=True)
        ws = wb.active
        all_rows = list(ws.iter_rows(values_only=True))
        if not all_rows:
            return []

        raw_headers = [str(h or '').strip() for h in all_rows[0]]
        mapped_headers = [normalize_key(h) for h in raw_headers]

        for r in all_rows[1:]:
            if not any(r): # fila completamente vacía
                continue
            row_dict = {}
            for idx, col_name in enumerate(mapped_headers):
                val = r[idx] if idx < len(r) else None
                val_str = str(val).strip() if val is not None else ""
                if val_str:
                    row_dict[col_name] = val_str
            if row_dict:
                rows.append(row_dict)

    elif fname.endswith(".csv") or fname.endswith(".txt"):
        # Intentar detectar delimitador (, o ;)
        text_content = contents.decode("utf-8-sig", errors="replace")
        sample_line = text_content.splitlines()[0] if text_content.splitlines() else ""
        delimiter = ";" if ";" in sample_line and sample_line.count(";") > sample_line.count(",") else ","

        reader = csv.reader(text_content.splitlines(), delimiter=delimiter)
        csv_rows = list(reader)
        if not csv_rows:
            return []

        raw_headers = [h.strip() for h in csv_rows[0]]
        mapped_headers = [normalize_key(h) for h in raw_headers]

        for r in csv_rows[1:]:
            if not any(r):
                continue
            row_dict = {}
            for idx, col_name in enumerate(mapped_headers):
                val = r[idx] if idx < len(r) else ""
                val_str = val.strip()
                if val_str:
                    row_dict[col_name] = val_str
            if row_dict:
                rows.append(row_dict)

    return rows

