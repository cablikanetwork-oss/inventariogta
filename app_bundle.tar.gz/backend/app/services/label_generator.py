import io
from typing import List, Optional
import qrcode
from PIL import Image, ImageDraw, ImageFont

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch, mm
from reportlab.pdfgen import canvas
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics.barcode import qr as reportlab_qr

from app.models.equipment import Equipment

def generate_equipment_qr_image(
    equipment: Equipment,
    company_name: str = "InventoryOS",
    base_url: Optional[str] = None
) -> io.BytesIO:
    """Genera una imagen PNG nítida de 400x400 px con código QR (URL directa o Serial) y datos del activo."""
    # 1. Generar QR Code
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=2,
    )
    # Codificar URL directa para escaneo universal o serial puro
    if base_url and base_url.strip():
        qr_content = f"{base_url.strip().rstrip('/')}/eq/{equipment.serial_number}"
    else:
        qr_content = equipment.serial_number
    qr.add_data(qr_content)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGB")

    # 2. Lienzo compuesto
    canvas_w, canvas_h = 420, 520
    img = Image.new("RGB", (canvas_w, canvas_h), color="#FFFFFF")
    draw = ImageDraw.Draw(img)

    # 3. Marco exterior redondeado
    draw.rounded_rectangle([(8, 8), (canvas_w - 8, canvas_h - 8)], radius=12, outline="#1E293B", width=3)

    # 4. Cabecera institucional
    draw.rectangle([(8, 8), (canvas_w - 8, 48)], fill="#0F172A")
    draw.text((canvas_w // 2, 28), company_name.upper(), fill="#FFFFFF", anchor="mm")

    # 5. Pegar QR al centro
    qr_resized = qr_img.resize((300, 300))
    paste_x = (canvas_w - 300) // 2
    img.paste(qr_resized, (paste_x, 60))

    # 6. Datos del equipo debajo del QR
    # Serial (clave primaria de identificación)
    serial_str = equipment.serial_number
    draw.text((canvas_w // 2, 385), f"S/N: {serial_str}", fill="#0F172A", anchor="mm")

    # Nombre y Modelo
    eq_name = equipment.name[:35]
    draw.text((canvas_w // 2, 420), eq_name, fill="#334155", anchor="mm")

    brand_model = " • ".join(filter(None, [equipment.brand, equipment.model]))[:40]
    if brand_model:
        draw.text((canvas_w // 2, 445), brand_model, fill="#64748B", anchor="mm")

    # Código de barras alternativo si existe
    if equipment.barcode:
        draw.text((canvas_w // 2, 475), f"BARCODE: {equipment.barcode}", fill="#475569", anchor="mm")

    # Almacén
    wh_name = equipment.current_warehouse.name if equipment.current_warehouse else "Sin almacén"
    draw.text((canvas_w // 2, 498), f"[{wh_name.upper()}]", fill="#2563EB", anchor="mm")

    buffer = io.BytesIO()
    img.save(buffer, format="PNG", dpi=(300, 300))
    buffer.seek(0)
    return buffer


def generate_labels_pdf_sheet(
    equipments: List[Equipment],
    company_name: str = "InventoryOS",
    base_url: Optional[str] = None
) -> io.BytesIO:
    """Genera un archivo PDF tamaño Carta con 10 etiquetas por hoja (2 columnas x 5 filas)."""
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    page_w, page_h = letter # 612 x 792 pt

    cols = 2
    rows = 5
    labels_per_page = cols * rows

    margin_x = 0.5 * inch
    margin_y = 0.5 * inch

    available_w = page_w - (2 * margin_x)
    available_h = page_h - (2 * margin_y)

    gap_x = 0.2 * inch
    gap_y = 0.15 * inch

    label_w = (available_w - gap_x) / 2 # ~275 pt (~97 mm)
    label_h = (available_h - (rows - 1) * gap_y) / rows # ~136 pt (~48 mm)

    for i, eq in enumerate(equipments):
        if i > 0 and i % labels_per_page == 0:
            c.showPage()

        idx_on_page = i % labels_per_page
        col = idx_on_page % cols
        row = idx_on_page // cols

        x = margin_x + col * (label_w + gap_x)
        # En ReportLab el eje Y empieza abajo (0,0 es esquina inferior izquierda)
        y = page_h - margin_y - (row + 1) * label_h - (row * gap_y)

        # 1. Borde de la etiqueta
        c.setStrokeColor(colors.HexColor("#CBD5E1"))
        c.setFillColor(colors.white)
        c.roundRect(x, y, label_w, label_h, 6, stroke=1, fill=1)

        # 2. Barra de cabecera con nombre de empresa
        c.setFillColor(colors.HexColor("#0F172A"))
        c.rect(x, y + label_h - 18, label_w, 18, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(x + 8, y + label_h - 13, company_name.upper())

        # Categoría en la cabecera derecha
        cat_str = str(eq.category.value if hasattr(eq.category, "value") else eq.category).upper()
        c.drawRightString(x + label_w - 8, y + label_h - 13, cat_str)

        # 3. Código QR a la izquierda
        qr_size = label_h - 30
        if base_url and base_url.strip():
            qr_data = f"{base_url.strip().rstrip('/')}/eq/{eq.serial_number}"
        else:
            qr_data = eq.serial_number
        qr_widget = reportlab_qr.QrCodeWidget(qr_data)
        qr_widget.barWidth = qr_size
        qr_widget.barHeight = qr_size

        d = Drawing(qr_size, qr_size)
        d.add(qr_widget)
        # Dibujar QR
        d.drawOn(c, x + 6, y + 6)

        # 4. Datos del activo a la derecha del QR
        text_x = x + qr_size + 14
        text_w = label_w - qr_size - 20

        # Serial (destacado)
        c.setFillColor(colors.HexColor("#0F172A"))
        c.setFont("Helvetica-Bold", 10)
        c.drawString(text_x, y + label_h - 32, "S/N:")
        c.setFont("Courier-Bold", 9)
        c.drawString(text_x + 24, y + label_h - 32, eq.serial_number[:22])

        # Nombre del equipo
        c.setFillColor(colors.HexColor("#1E293B"))
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(text_x, y + label_h - 48, eq.name[:28])

        # Marca y Modelo
        c.setFillColor(colors.HexColor("#64748B"))
        c.setFont("Helvetica", 7.5)
        brand_model = " • ".join(filter(None, [eq.brand, eq.model]))[:32]
        c.drawString(text_x, y + label_h - 60, brand_model or "—")

        # Código de barras si tiene
        if eq.barcode:
            c.setFont("Courier", 7)
            c.drawString(text_x, y + label_h - 72, f"CÓD: {eq.barcode[:20]}")

        # Almacén
        wh_name = eq.current_warehouse.name if eq.current_warehouse else "Sin almacén"
        c.setFillColor(colors.HexColor("#2563EB"))
        c.setFont("Helvetica-Bold", 7.5)
        c.drawString(text_x, y + 10, f"UBICACIÓN: {wh_name.upper()[:24]}")

    c.save()
    buffer.seek(0)
    return buffer

