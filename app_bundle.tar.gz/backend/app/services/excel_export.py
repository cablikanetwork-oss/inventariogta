import io
from datetime import datetime, timezone
from typing import List, Optional
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from app.models.equipment import Equipment, EquipmentStatus

def create_table_headers(ws, headers: List[str], start_row: int, bg_color: str = "1E3A8A"):
    fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type="solid")
    font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    thin_border = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1")
    )
    center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.row_dimensions[start_row].height = 26
    for col_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=start_row, column=col_idx, value=h)
        cell.fill = fill
        cell.font = font
        cell.alignment = center_align
        cell.border = thin_border

def write_equipment_sheet(
    ws,
    title: str,
    equipment_list: List[Equipment],
    company_name: str,
    subtitle: str,
    header_color: str = "1E3A8A"
):
    ws.views.sheetView[0].showGridLines = True

    # 1. Cabecera Institucional
    ws.merge_cells("A1:K1")
    title_cell = ws.cell(row=1, column=1, value=f"{company_name.upper()} — {title.upper()}")
    title_cell.font = Font(name="Calibri", size=14, bold=True, color="1E3A8A")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 28

    ws.merge_cells("A2:K2")
    now_str = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M UTC")
    sub_cell = ws.cell(row=2, column=1, value=f"{subtitle} | Generado el: {now_str} | Total Equipos: {len(equipment_list)}")
    sub_cell.font = Font(name="Calibri", size=10, italic=True, color="64748B")
    sub_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 20

    headers = [
        "N°",
        "Serial / SN",
        "Código Barras",
        "Nombre del Equipo",
        "Categoría",
        "Marca",
        "Modelo",
        "Almacén",
        "Estado",
        "Asignado a",
        "Observaciones / Specs"
    ]

    header_row = 4
    create_table_headers(ws, headers, header_row, bg_color=header_color)

    # 2. Filas de Equipos
    thin_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0")
    )
    zebra_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")

    status_labels = {
        "available": "Disponible",
        "assigned": "Asignado",
        "maintenance": "En Mantenimiento",
        "retired": "De Baja",
        "lost": "Extraviado"
    }

    status_colors = {
        "available": "15803D",   # Verde
        "assigned": "0369A1",    # Azul
        "maintenance": "B45309", # Naranja
        "retired": "B91C1C",     # Rojo
        "lost": "475569"         # Gris
    }

    current_row = 5
    for idx, eq in enumerate(equipment_list, start=1):
        status_key = eq.status.value if hasattr(eq.status, "value") else str(eq.status)
        status_txt = status_labels.get(status_key, status_key.capitalize())
        color_hex = status_colors.get(status_key, "000000")

        wh_name = "—"
        if eq.current_warehouse:
            wh_name = eq.current_warehouse.name

        row_vals = [
            idx,
            eq.serial_number,
            eq.barcode or "—",
            eq.name,
            eq.category.value.upper() if hasattr(eq.category, "value") else str(eq.category).upper(),
            eq.brand or "—",
            eq.model or "—",
            wh_name,
            status_txt,
            eq.assigned_to or "—",
            eq.notes or "—"
        ]

        ws.append(row_vals)
        ws.row_dimensions[current_row].height = 20

        is_even = (idx % 2 == 0)
        for c_idx in range(1, len(row_vals) + 1):
            cell = ws.cell(row=current_row, column=c_idx)
            cell.font = Font(name="Calibri", size=9)
            cell.border = thin_border
            if is_even:
                cell.fill = zebra_fill

            # Alineaciones específicas
            if c_idx == 1:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif c_idx in (2, 3):
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.font = Font(name="Consolas", size=9, bold=True)
            elif c_idx == 9: # Estado
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.font = Font(name="Calibri", size=9, bold=True, color=color_hex)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

        current_row += 1

    # Auto-filtro en encabezados
    last_col_letter = get_column_letter(len(headers))
    ws.auto_filter.ref = f"A{header_row}:{last_col_letter}{current_row - 1}"

    # Anchos de columna automáticos
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or "")
            if len(val_str) > max_len and "\n" not in val_str:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 3, 11)

def write_executive_summary_sheet(ws, equipment_list: List[Equipment], company_name: str):
    ws.title = "Resumen Ejecutivo"
    ws.views.sheetView[0].showGridLines = True

    # Título
    ws.merge_cells("A1:F1")
    title_cell = ws.cell(row=1, column=1, value=f"{company_name.upper()} — RESUMEN EJECUTIVO DE INVENTARIO")
    title_cell.font = Font(name="Calibri", size=14, bold=True, color="1E3A8A")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 28

    # Tarjetas de Totales
    total = len(equipment_list)
    available = sum(1 for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "available")
    assigned = sum(1 for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "assigned")
    maintenance = sum(1 for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "maintenance")
    retired = sum(1 for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "retired")

    kpis = [
        ("TOTAL EQUIPOS", total, "1E3A8A"),
        ("DISPONIBLES", available, "15803D"),
        ("ASIGNADOS", assigned, "0369A1"),
        ("EN MANTENIMIENTO", maintenance, "B45309"),
        ("DE BAJA / RETIRADOS", retired, "B91C1C"),
    ]

    for idx, (label, val, col_hex) in enumerate(kpis, start=1):
        cell_lbl = ws.cell(row=3, column=idx, value=label)
        cell_lbl.font = Font(name="Calibri", size=9, bold=True, color="FFFFFF")
        cell_lbl.fill = PatternFill(start_color=col_hex, end_color=col_hex, fill_type="solid")
        cell_lbl.alignment = Alignment(horizontal="center", vertical="center")

        cell_val = ws.cell(row=4, column=idx, value=val)
        cell_val.font = Font(name="Calibri", size=16, bold=True, color=col_hex)
        cell_val.alignment = Alignment(horizontal="center", vertical="center")
        cell_val.fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")

    ws.row_dimensions[3].height = 22
    ws.row_dimensions[4].height = 32

    # Tabla: Desglose por Categoría
    ws.cell(row=7, column=1, value="DESGLOSE POR TIPO DE EQUIPO").font = Font(name="Calibri", size=11, bold=True, color="1E3A8A")
    cat_headers = ["Tipo / Categoría", "Total", "Disponibles", "Asignados", "Mantenimiento"]
    create_table_headers(ws, cat_headers, 8, "0F172A")

    categories = {}
    for eq in equipment_list:
        cat_key = eq.category.value.upper() if hasattr(eq.category, "value") else str(eq.category).upper()
        if cat_key not in categories:
            categories[cat_key] = {"total": 0, "available": 0, "assigned": 0, "maintenance": 0}
        categories[cat_key]["total"] += 1
        st_key = eq.status.value if hasattr(eq.status, "value") else str(eq.status)
        if st_key in categories[cat_key]:
            categories[cat_key][st_key] += 1

    r = 9
    for cat_name, data in sorted(categories.items()):
        ws.cell(row=r, column=1, value=cat_name).font = Font(name="Calibri", size=10, bold=True)
        ws.cell(row=r, column=2, value=data["total"]).alignment = Alignment(horizontal="center")
        ws.cell(row=r, column=3, value=data["available"]).alignment = Alignment(horizontal="center")
        ws.cell(row=r, column=4, value=data["assigned"]).alignment = Alignment(horizontal="center")
        ws.cell(row=r, column=5, value=data["maintenance"]).alignment = Alignment(horizontal="center")
        for c in range(1, 6):
            ws.cell(row=r, column=c).border = Border(
                left=Side(style="thin", color="CBD5E1"),
                right=Side(style="thin", color="CBD5E1"),
                top=Side(style="thin", color="CBD5E1"),
                bottom=Side(style="thin", color="CBD5E1")
            )
        r += 1

    for c in range(1, 7):
        col_letter = get_column_letter(c)
        ws.column_dimensions[col_letter].width = 22

def generate_inventory_excel_workbook(
    equipment_list: List[Equipment],
    company_name: str = "InventoryOS",
    filter_label: str = "Inventario Completo"
) -> io.BytesIO:
    """Genera un archivo Excel multidimensional con pestañas organizadas por Estado y Resumen."""
    wb = openpyxl.Workbook()

    # 1. Pestaña de Resumen Ejecutivo
    ws_summary = wb.active
    write_executive_summary_sheet(ws_summary, equipment_list, company_name)

    # 2. Pestaña: Inventario Total
    ws_total = wb.create_sheet(title="Inventario Total")
    write_equipment_sheet(ws_total, "Inventario Total", equipment_list, company_name, filter_label, "1E3A8A")

    # 3. Pestaña: Disponibles
    avail_list = [e for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "available"]
    ws_avail = wb.create_sheet(title="Disponibles")
    write_equipment_sheet(ws_avail, "Equipos Disponibles", avail_list, company_name, "Equipos listos para entrega o asignación", "15803D")

    # 4. Pestaña: Asignados
    assigned_list = [e for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "assigned"]
    ws_assigned = wb.create_sheet(title="Asignados")
    write_equipment_sheet(ws_assigned, "Equipos Asignados", assigned_list, company_name, "Equipos en custodia de trabajadores o proyectos", "0369A1")

    # 5. Pestaña: Mantenimiento
    maint_list = [e for e in equipment_list if (e.status.value if hasattr(e.status, "value") else str(e.status)) == "maintenance"]
    ws_maint = wb.create_sheet(title="En Mantenimiento")
    write_equipment_sheet(ws_maint, "Equipos en Mantenimiento", maint_list, company_name, "Equipos en revisión, diagnóstico o reparación", "B45309")

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output

