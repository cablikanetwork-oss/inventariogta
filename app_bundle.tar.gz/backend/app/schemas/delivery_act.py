from datetime import datetime
from uuid import UUID
from typing import Optional, List
from pydantic import BaseModel, ConfigDict

class DeliveryActItemCreate(BaseModel):
    equipment_id: Optional[UUID] = None
    equipment_name: str
    equipment_type: Optional[str] = "Equipo Tecnológico"
    brand: Optional[str] = None
    model: Optional[str] = None
    serial_number: str
    specs: Optional[str] = None

class DeliveryActItemResponse(BaseModel):
    id: UUID
    act_id: UUID
    equipment_id: Optional[UUID] = None
    equipment_name: str
    equipment_type: str
    brand: Optional[str] = None
    model: Optional[str] = None
    serial_number: str
    specs: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

class DeliveryActCreate(BaseModel):
    act_type: Optional[str] = "assignment"
    city: Optional[str] = "Caracas"
    recipient_name: str
    recipient_id_card: str
    recipient_position: Optional[str] = None
    recipient_department: Optional[str] = None
    recipient_signature: Optional[str] = None
    delivered_by_name: Optional[str] = "Raimundo Gil"
    delivered_by_position: Optional[str] = "Gerente de Tecnología"
    delivered_by_id_card: Optional[str] = "14.287.629"
    terms_clause: Optional[str] = None
    notes: Optional[str] = None
    accessories: Optional[str] = None
    evidence_photos: Optional[List[str]] = None
    items: List[DeliveryActItemCreate]
    auto_assign_equipment: Optional[bool] = True

class DeliveryActUpdate(BaseModel):
    act_type: Optional[str] = None
    city: Optional[str] = None
    recipient_name: Optional[str] = None
    recipient_id_card: Optional[str] = None
    recipient_position: Optional[str] = None
    recipient_department: Optional[str] = None
    recipient_signature: Optional[str] = None
    delivered_by_name: Optional[str] = None
    delivered_by_position: Optional[str] = None
    delivered_by_id_card: Optional[str] = None
    terms_clause: Optional[str] = None
    notes: Optional[str] = None
    accessories: Optional[str] = None
    items: Optional[List[DeliveryActItemCreate]] = None
    auto_assign_equipment: Optional[bool] = True

class DeliveryActResponse(BaseModel):
    id: UUID
    act_number: str
    act_type: str
    city: str
    recipient_name: str
    recipient_id_card: str
    recipient_position: Optional[str] = None
    recipient_department: Optional[str] = None
    recipient_signature: Optional[str] = None
    delivered_by_user_id: Optional[UUID] = None
    delivered_by_name: str
    delivered_by_position: Optional[str] = None
    delivered_by_id_card: Optional[str] = None
    terms_clause: str
    notes: Optional[str] = None
    accessories: Optional[str] = None
    scanned_document_url: Optional[str] = None
    scanned_at: Optional[datetime] = None
    evidence_photos_list: List[str] = []
    created_at: datetime
    updated_at: datetime
    items: List[DeliveryActItemResponse] = []

    model_config = ConfigDict(from_attributes=True)

