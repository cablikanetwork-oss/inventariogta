import uuid
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel
from app.models.audit import AuditSessionStatus
from app.schemas.equipment import EquipmentResponse

class AuditSessionCreate(BaseModel):
    warehouse_id: uuid.UUID
    notes: Optional[str] = None

class AuditScanCreate(BaseModel):
    serial_number: str

class AuditScanResponse(BaseModel):
    id: uuid.UUID
    session_id: uuid.UUID
    equipment_id: Optional[uuid.UUID]
    scanned_serial: str
    found_in_warehouse: bool
    scanned_at: datetime
    equipment: Optional[EquipmentResponse] = None

    model_config = {"from_attributes": True}

class AuditScanResult(BaseModel):
    found: bool
    is_expected: bool
    is_duplicate: bool
    scanned_serial: str
    equipment: Optional[EquipmentResponse] = None
    message: str

class AuditSessionResponse(BaseModel):
    id: uuid.UUID
    warehouse_id: uuid.UUID
    warehouse_name: Optional[str] = None
    created_by: uuid.UUID
    creator_name: Optional[str] = None
    status: AuditSessionStatus
    notes: Optional[str]
    created_at: datetime
    closed_at: Optional[datetime]
    expected_total: int = 0
    scanned_count: int = 0

    model_config = {"from_attributes": True}

class AuditReportResponse(BaseModel):
    session_id: uuid.UUID
    warehouse_name: str
    status: AuditSessionStatus
    created_at: datetime
    closed_at: Optional[datetime]
    expected_total: int
    found_count: int
    missing_count: int
    extra_count: int
    matched_items: List[EquipmentResponse]
    missing_items: List[EquipmentResponse]
    extra_items: List[AuditScanResponse]

