import uuid
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel

class WarehouseCreate(BaseModel):
    name: str
    location: Optional[str] = None
    description: Optional[str] = None
    parent_id: Optional[uuid.UUID] = None

class WarehouseUpdate(BaseModel):
    name: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    parent_id: Optional[uuid.UUID] = None
    is_active: Optional[bool] = None

class WarehouseResponse(BaseModel):
    id: uuid.UUID
    name: str
    location: Optional[str] = None
    description: Optional[str] = None
    is_active: bool
    parent_id: Optional[uuid.UUID] = None
    parent_name: Optional[str] = None
    created_at: datetime
    equipment_count: int = 0
    total_equipment_count: int = 0
    sub_warehouses_count: int = 0

    model_config = {"from_attributes": True}
