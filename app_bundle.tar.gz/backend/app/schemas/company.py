import uuid
from datetime import datetime
from pydantic import BaseModel
from typing import Optional

class CompanyConfigBase(BaseModel):
    name: str
    logo_url: Optional[str] = None
    primary_color: str = "#2563EB"
    secondary_color: str = "#1E40AF"
    accent_color: str = "#F59E0B"

class CompanyConfigUpdate(CompanyConfigBase):
    pass

class CompanyConfigResponse(CompanyConfigBase):
    id: uuid.UUID
    updated_at: datetime

    model_config = {"from_attributes": True}

