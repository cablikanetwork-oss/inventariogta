import uuid
from datetime import datetime, date
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel
from app.models.equipment import EquipmentCategory, EquipmentStatus

class EquipmentCreate(BaseModel):
    serial_number: str
    barcode: Optional[str] = None
    name: str
    brand: Optional[str] = None
    model: Optional[str] = None
    category: str = "laptop"
    status: Optional[EquipmentStatus] = EquipmentStatus.available
    current_warehouse_id: Optional[uuid.UUID] = None
    assigned_to: Optional[str] = None
    notes: Optional[str] = None
    purchase_date: Optional[date] = None
    purchase_price: Optional[Decimal] = None
    expected_lifespan_years: int = 3
    warranty_expires: Optional[date] = None

class EquipmentUpdate(BaseModel):
    serial_number: Optional[str] = None
    barcode: Optional[str] = None
    name: Optional[str] = None
    brand: Optional[str] = None
    model: Optional[str] = None
    category: Optional[str] = None
    status: Optional[EquipmentStatus] = None
    current_warehouse_id: Optional[uuid.UUID] = None
    assigned_to: Optional[str] = None
    notes: Optional[str] = None
    purchase_date: Optional[date] = None
    purchase_price: Optional[Decimal] = None
    expected_lifespan_years: Optional[int] = None
    warranty_expires: Optional[date] = None

class WarehouseBasic(BaseModel):
    id: uuid.UUID
    name: str
    location: Optional[str] = None
    model_config = {"from_attributes": True}

class EquipmentResponse(BaseModel):
    id: uuid.UUID
    serial_number: str
    barcode: Optional[str]
    name: str
    brand: Optional[str]
    model: Optional[str]
    category: str
    status: EquipmentStatus
    current_warehouse_id: Optional[uuid.UUID]
    current_warehouse: Optional[WarehouseBasic] = None
    assigned_to: Optional[str]
    notes: Optional[str]
    purchase_date: Optional[date] = None
    purchase_price: Optional[Decimal] = None
    expected_lifespan_years: int = 3
    warranty_expires: Optional[date] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}

class EquipmentImportItem(BaseModel):
    row_index: int
    serial_number: str
    name: str
    brand: Optional[str] = None
    model: Optional[str] = None
    category: str = "other"
    barcode: Optional[str] = None
    warehouse_name: Optional[str] = None
    warehouse_id: Optional[uuid.UUID] = None
    status: str = "available"
    assigned_to: Optional[str] = None
    notes: Optional[str] = None
    is_valid: bool = True
    error_message: Optional[str] = None

class EquipmentImportPreviewResponse(BaseModel):
    total_rows: int
    valid_count: int
    error_count: int
    items: list[EquipmentImportItem]

class EquipmentImportCommitRequest(BaseModel):
    items: list[EquipmentImportItem]
    default_warehouse_id: Optional[uuid.UUID] = None

class EquipmentImportCommitResponse(BaseModel):
    imported_count: int
    message: str


class EquipmentMaintenanceCreate(BaseModel):
    maintenance_type: str = "preventive"  # preventive, corrective, upgrade
    title: str
    description: Optional[str] = None
    cost: Optional[Decimal] = Decimal("0")
    performed_by: Optional[str] = "Raimundo Gil"
    performed_at: Optional[date] = None
    new_specs: Optional[str] = None
    update_equipment_specs: Optional[bool] = True


class EquipmentMaintenanceResponse(BaseModel):
    id: uuid.UUID
    equipment_id: uuid.UUID
    maintenance_type: str
    title: str
    description: Optional[str] = None
    cost: Optional[Decimal] = Decimal("0")
    performed_by: Optional[str] = None
    performed_at: date
    new_specs: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class CatalogItemCreate(BaseModel):
    item_type: str  # 'brand' | 'category'
    label: str
    value: Optional[str] = None
    group_name: Optional[str] = None


class CatalogItemResponse(BaseModel):
    id: Optional[str] = None
    item_type: str
    value: str
    label: str
    group_name: Optional[str] = None
    is_custom: bool = False


class EquipmentCatalogsResponse(BaseModel):
    brands: list[CatalogItemResponse]
    categories: list[CatalogItemResponse]


class EquipmentBatchCreate(BaseModel):
    serial_numbers: list[str]
    name: str
    brand: Optional[str] = None
    model: Optional[str] = None
    category: str = "laptop"
    status: Optional[EquipmentStatus] = EquipmentStatus.available
    current_warehouse_id: Optional[uuid.UUID] = None
    assigned_to: Optional[str] = None
    notes: Optional[str] = None
    purchase_date: Optional[date] = None
    purchase_price: Optional[Decimal] = None
    expected_lifespan_years: int = 3
    warranty_expires: Optional[date] = None


class EquipmentBatchResponse(BaseModel):
    created_count: int
    skipped_serials: list[str] = []
    items: list[EquipmentResponse]

