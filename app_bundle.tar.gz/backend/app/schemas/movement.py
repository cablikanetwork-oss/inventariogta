import uuid
from datetime import datetime
from typing import Optional
from pydantic import BaseModel
from app.models.movement import MovementType

class MovementCreate(BaseModel):
    type: MovementType
    equipment_id: uuid.UUID
    from_warehouse_id: Optional[uuid.UUID] = None
    to_warehouse_id: Optional[uuid.UUID] = None
    assigned_to: Optional[str] = None
    notes: Optional[str] = None

class EquipmentBasic(BaseModel):
    id: uuid.UUID
    serial_number: str
    name: str
    model_config = {"from_attributes": True}

class WarehouseBasic(BaseModel):
    id: uuid.UUID
    name: str
    model_config = {"from_attributes": True}

class UserBasic(BaseModel):
    id: uuid.UUID
    username: str
    full_name: str
    model_config = {"from_attributes": True}

class MovementResponse(BaseModel):
    id: uuid.UUID
    type: MovementType
    equipment_id: uuid.UUID
    equipment: Optional[EquipmentBasic] = None
    from_warehouse_id: Optional[uuid.UUID] = None
    from_warehouse: Optional[WarehouseBasic] = None
    to_warehouse_id: Optional[uuid.UUID] = None
    to_warehouse: Optional[WarehouseBasic] = None
    performed_by: uuid.UUID
    performed_by_user: Optional[UserBasic] = None
    assigned_to: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime

    model_config = {"from_attributes": True}

