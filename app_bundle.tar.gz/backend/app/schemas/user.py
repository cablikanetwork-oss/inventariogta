import uuid
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, field_validator
from app.models.user import UserRole

class UserCreate(BaseModel):
    username: str
    full_name: str
    pin: str
    role: UserRole = UserRole.user
    id_card: Optional[str] = None
    recovery_key: Optional[str] = None

    @field_validator("pin")
    @classmethod
    def validate_pin(cls, v: str) -> str:
        if not v.isdigit():
            raise ValueError("El PIN debe contener únicamente dígitos")
        if not (4 <= len(v) <= 6):
            raise ValueError("El PIN debe tener entre 4 y 6 dígitos")
        return v

    @field_validator("username")
    @classmethod
    def validate_username(cls, v: str) -> str:
        if len(v.strip()) < 3:
            raise ValueError("El usuario debe tener al menos 3 caracteres")
        return v.lower().strip()

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    pin: Optional[str] = None
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None
    id_card: Optional[str] = None
    recovery_key: Optional[str] = None

    @field_validator("pin")
    @classmethod
    def validate_pin(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            if not v.isdigit():
                raise ValueError("El PIN debe contener únicamente dígitos")
            if not (4 <= len(v) <= 6):
                raise ValueError("El PIN debe tener entre 4 y 6 dígitos")
        return v

class UserResponse(BaseModel):
    id: uuid.UUID
    username: str
    full_name: str
    role: UserRole
    is_active: bool
    id_card: Optional[str] = None
    has_recovery_key: bool = False
    created_at: datetime

    model_config = {"from_attributes": True}

class LoginRequest(BaseModel):
    username: str
    pin: str

class RecoverPinRequest(BaseModel):
    username: str
    id_card: str
    recovery_key: str
    new_pin: str

    @field_validator("new_pin")
    @classmethod
    def validate_new_pin(cls, v: str) -> str:
        cleaned = v.strip()
        if not cleaned.isdigit():
            raise ValueError("El nuevo PIN debe contener únicamente números")
        if not (4 <= len(cleaned) <= 6):
            raise ValueError("El nuevo PIN debe tener entre 4 y 6 dígitos")
        return cleaned

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

