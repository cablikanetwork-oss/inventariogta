import uuid
from datetime import datetime, timezone
from enum import Enum as PyEnum
from sqlalchemy import String, DateTime, ForeignKey, Enum, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

class MovementType(str, PyEnum):
    entry = "entry"           # Entrada (compra/proveedor)
    exit = "exit"             # Salida (asignación)
    transfer = "transfer"     # Transferencia entre almacenes
    return_item = "return"    # Devolución
    maintenance = "maintenance"

class Movement(Base):
    __tablename__ = "movements"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    type: Mapped[MovementType] = mapped_column(Enum(MovementType), nullable=False)
    equipment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("equipment.id"), nullable=False)
    from_warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id"), nullable=True)
    to_warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id"), nullable=True)
    performed_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"), nullable=False)
    assigned_to: Mapped[str] = mapped_column(String(200), nullable=True)
    notes: Mapped[str] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )

    # Relationships
    equipment: Mapped["Equipment"] = relationship("Equipment", back_populates="movements")
    from_warehouse: Mapped["Warehouse"] = relationship("Warehouse", back_populates="movements_from", foreign_keys=[from_warehouse_id])
    to_warehouse: Mapped["Warehouse"] = relationship("Warehouse", back_populates="movements_to", foreign_keys=[to_warehouse_id])
    performed_by_user: Mapped["User"] = relationship("User", back_populates="movements", foreign_keys=[performed_by])

