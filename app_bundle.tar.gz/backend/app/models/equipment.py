import uuid
import datetime as dt
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum as PyEnum
from typing import Optional
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Enum, Text, Date, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

class EquipmentCategory(str, PyEnum):
    laptop = "laptop"
    desktop = "desktop"
    monitor = "monitor"
    keyboard = "keyboard"
    mouse = "mouse"
    switch = "switch"
    router = "router"
    server = "server"
    phone = "phone"
    tablet = "tablet"
    printer = "printer"
    ups = "ups"
    cable = "cable"
    other = "other"

class EquipmentStatus(str, PyEnum):
    available = "available"
    assigned = "assigned"
    maintenance = "maintenance"
    retired = "retired"
    lost = "lost"

class Equipment(Base):
    __tablename__ = "equipment"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    serial_number: Mapped[str] = mapped_column(String(200), unique=True, nullable=False, index=True)
    barcode: Mapped[str] = mapped_column(String(200), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    brand: Mapped[str] = mapped_column(String(100), nullable=True)
    model: Mapped[str] = mapped_column(String(200), nullable=True)
    category: Mapped[str] = mapped_column(String(100), nullable=False, default="laptop")
    status: Mapped[EquipmentStatus] = mapped_column(Enum(EquipmentStatus), nullable=False, default=EquipmentStatus.available)
    current_warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id"), nullable=True)
    assigned_to: Mapped[str] = mapped_column(String(200), nullable=True)  # Employee name or project
    notes: Mapped[str] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )

    purchase_date: Mapped[Optional[dt.date]] = mapped_column(Date, nullable=True)
    purchase_price: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2), nullable=True)
    expected_lifespan_years: Mapped[int] = mapped_column(nullable=False, default=3)
    warranty_expires: Mapped[Optional[dt.date]] = mapped_column(Date, nullable=True)

    # Relationships
    current_warehouse: Mapped["Warehouse"] = relationship("Warehouse", back_populates="equipment")
    movements: Mapped[list["Movement"]] = relationship("Movement", back_populates="equipment")
    maintenances: Mapped[list["EquipmentMaintenance"]] = relationship(
        "EquipmentMaintenance",
        back_populates="equipment",
        cascade="all, delete-orphan"
    )


class EquipmentMaintenance(Base):
    __tablename__ = "equipment_maintenances"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    equipment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("equipment.id", ondelete="CASCADE"), nullable=False, index=True)
    maintenance_type: Mapped[str] = mapped_column(String(50), nullable=False, default="preventivo") # preventivo | correctivo | upgrade | garantia
    title: Mapped[str] = mapped_column(String(250), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    cost: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2), nullable=True, default=0)
    performed_by: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    performed_at: Mapped[dt.date] = mapped_column(Date, nullable=False, default=dt.date.today)
    new_specs: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )

    equipment: Mapped["Equipment"] = relationship("Equipment", back_populates="maintenances")


class EquipmentCatalogItem(Base):
    __tablename__ = "equipment_catalogs"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    item_type: Mapped[str] = mapped_column(String(30), nullable=False, index=True)  # 'brand' | 'category'
    value: Mapped[str] = mapped_column(String(120), nullable=False)
    label: Mapped[str] = mapped_column(String(150), nullable=False)
    group_name: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    is_custom: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )



