import uuid
from datetime import datetime, timezone
from enum import Enum as PyEnum
from typing import Optional, List
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Enum, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

class AuditSessionStatus(str, PyEnum):
    active = "active"
    closed = "closed"

class AuditSession(Base):
    __tablename__ = "audit_sessions"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("warehouses.id"), nullable=False)
    created_by: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[AuditSessionStatus] = mapped_column(
        Enum(AuditSessionStatus), nullable=False, default=AuditSessionStatus.active
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    created_by_user: Mapped["User"] = relationship("User")
    scans: Mapped[List["AuditScan"]] = relationship("AuditScan", back_populates="session", cascade="all, delete-orphan")


class AuditScan(Base):
    __tablename__ = "audit_scans"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("audit_sessions.id", ondelete="CASCADE"), nullable=False
    )
    equipment_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        ForeignKey("equipment.id", ondelete="SET NULL"), nullable=True
    )
    scanned_serial: Mapped[str] = mapped_column(String(200), nullable=False)
    found_in_warehouse: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    scanned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    # Relationships
    session: Mapped["AuditSession"] = relationship("AuditSession", back_populates="scans")
    equipment: Mapped[Optional["Equipment"]] = relationship("Equipment")

