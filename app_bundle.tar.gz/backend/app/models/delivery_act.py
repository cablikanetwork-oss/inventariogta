import uuid
import json
from typing import Optional
from datetime import datetime, timezone
from sqlalchemy import String, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

DEFAULT_TERMS_CLAUSE = (
    "A partir de este momento el trabajador se hace responsable por el uso adecuado y "
    "cuidado del equipo. Cualquier daño ocasionado al equipo, debe ser reportado a la "
    "brevedad posible a la Gerencia de Sistemas de la empresa. Estoy de acuerdo y acepto "
    "el equipo asignado y las políticas y condiciones anteriormente especificadas."
)

class DeliveryAct(Base):
    __tablename__ = "delivery_acts"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    act_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    act_type: Mapped[str] = mapped_column(String(50), default="assignment", nullable=False) # assignment | return
    city: Mapped[str] = mapped_column(String(100), default="Caracas", nullable=False)
    
    # Datos del Receptor (Trabajador)
    recipient_name: Mapped[str] = mapped_column(String(200), nullable=False)
    recipient_id_card: Mapped[str] = mapped_column(String(50), nullable=False)
    recipient_position: Mapped[str] = mapped_column(String(200), nullable=True)
    recipient_department: Mapped[str] = mapped_column(String(200), nullable=True)
    recipient_signature: Mapped[str] = mapped_column(Text, nullable=True) # Base64 touch signature

    # Datos del Emisor / Responsable de Entrega
    delivered_by_user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"), nullable=True)
    delivered_by_name: Mapped[str] = mapped_column(String(200), nullable=False, default="Raimundo Gil")
    delivered_by_position: Mapped[str] = mapped_column(String(200), nullable=True, default="Gerente de Tecnología")
    delivered_by_id_card: Mapped[str] = mapped_column(String(50), nullable=True, default="14.287.629")

    # Cláusula, Accesorios, Respaldo Físico Escaneado y Fotos de Evidencia
    terms_clause: Mapped[str] = mapped_column(Text, default=DEFAULT_TERMS_CLAUSE, nullable=False)
    notes: Mapped[str] = mapped_column(Text, nullable=True)
    accessories: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    scanned_document_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    scanned_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    evidence_photos: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    @property
    def evidence_photos_list(self) -> list[str]:
        if not self.evidence_photos:
            return []
        try:
            parsed = json.loads(self.evidence_photos)
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )

    # Relaciones
    items: Mapped[list["DeliveryActItem"]] = relationship(
        "DeliveryActItem",
        back_populates="delivery_act",
        cascade="all, delete-orphan",
        lazy="selectin"
    )


class DeliveryActItem(Base):
    __tablename__ = "delivery_act_items"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    act_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("delivery_acts.id", ondelete="CASCADE"), nullable=False)
    equipment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("equipment.id", ondelete="SET NULL"), nullable=True)

    # Snapshot técnico del equipo en el momento del acta
    equipment_name: Mapped[str] = mapped_column(String(300), nullable=False)
    equipment_type: Mapped[str] = mapped_column(String(100), default="Equipo Tecnológico", nullable=False)
    brand: Mapped[str] = mapped_column(String(100), nullable=True)
    model: Mapped[str] = mapped_column(String(200), nullable=True)
    serial_number: Mapped[str] = mapped_column(String(200), nullable=False)
    specs: Mapped[str] = mapped_column(Text, nullable=True)

    # Relación
    delivery_act: Mapped["DeliveryAct"] = relationship("DeliveryAct", back_populates="items")

