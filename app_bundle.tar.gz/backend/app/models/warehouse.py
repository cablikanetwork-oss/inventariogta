import uuid
from typing import Optional
from datetime import datetime, timezone
from sqlalchemy import String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

class Warehouse(Base):
    __tablename__ = "warehouses"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    location: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    
    # Jerarquía: Almacén Primario o Localidad Padre
    parent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        ForeignKey("warehouses.id", ondelete="SET NULL"),
        nullable=True,
        index=True
    )
    
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )

    # Relationships de jerarquía
    parent: Mapped[Optional["Warehouse"]] = relationship(
        "Warehouse",
        remote_side="Warehouse.id",
        back_populates="sub_warehouses"
    )
    sub_warehouses: Mapped[list["Warehouse"]] = relationship(
        "Warehouse",
        back_populates="parent"
    )

    # Relationships de equipos y movimientos
    equipment: Mapped[list["Equipment"]] = relationship("Equipment", back_populates="current_warehouse")
    movements_from: Mapped[list["Movement"]] = relationship("Movement", back_populates="from_warehouse", foreign_keys="Movement.from_warehouse_id")
    movements_to: Mapped[list["Movement"]] = relationship("Movement", back_populates="to_warehouse", foreign_keys="Movement.to_warehouse_id")
