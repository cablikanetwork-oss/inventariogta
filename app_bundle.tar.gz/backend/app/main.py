from contextlib import asynccontextmanager
from datetime import date, datetime
from decimal import Decimal
import json
import os
import uuid
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select, text, func
from app.core.config import settings
from app.core.database import engine, Base, AsyncSessionLocal
from app.api.v1.router import api_router
from app.core.security import hash_pin

# Importar modelos para registro en metadata
from app.models import (
    CompanyConfig,
    User,
    UserRole,
    Warehouse,
    Equipment,
    EquipmentStatus,
    Movement,
    MovementType,
    DeliveryAct,
    DeliveryActItem,
    EquipmentMaintenance,
    EquipmentCatalogItem,
)


def _parse_uuid(val):
    if not val:
        return None
    return uuid.UUID(str(val)) if not isinstance(val, uuid.UUID) else val


def _parse_dt(val):
    if not val:
        return None
    if isinstance(val, datetime):
        return val
    return datetime.fromisoformat(str(val))


def _parse_date(val):
    if not val:
        return None
    if isinstance(val, date):
        return val
    return date.fromisoformat(str(val)[:10])


async def _seed_from_snapshot_if_available(session) -> bool:
    """Restaura el snapshot completo (137 equipos, 5 almacenes, actas y config) si la base de datos es nueva."""
    seed_file = os.path.join(os.path.dirname(__file__), "initial_seed_data.json")
    if not os.path.exists(seed_file):
        return False

    eq_count_res = await session.execute(select(func.count()).select_from(Equipment))
    if (eq_count_res.scalar() or 0) > 0:
        return True

    try:
        with open(seed_file, "r", encoding="utf-8") as f:
            snap = json.load(f)
    except Exception as exc:
        print(f"[Seed] Error leyendo initial_seed_data.json: {exc}")
        return False

    # 1. CompanyConfig
    existing_cfg = (await session.execute(select(CompanyConfig).limit(1))).scalar_one_or_none()
    if not existing_cfg and snap.get("company_config"):
        c = snap["company_config"][0]
        session.add(
            CompanyConfig(
                id=_parse_uuid(c.get("id")) or uuid.uuid4(),
                name=c.get("name", "Grupo Tu Andamio"),
                logo_url=c.get("logo_url", "/logotuandamio.png"),
                primary_color=c.get("primary_color", "#0F70B7"),
                secondary_color=c.get("secondary_color", "#0A4D82"),
                accent_color=c.get("accent_color", "#38BDF8"),
            )
        )

    # 2. Users
    for u in snap.get("users", []):
        exists = (
            await session.execute(select(User).where(User.username == u["username"]))
        ).scalar_one_or_none()
        if not exists:
            role_val = UserRole.admin if u.get("role") == "admin" else UserRole.user
            session.add(
                User(
                    id=_parse_uuid(u.get("id")) or uuid.uuid4(),
                    username=u["username"],
                    full_name=u.get("full_name", u["username"]),
                    pin_hash=u.get("pin_hash") or hash_pin("1234"),
                    role=role_val,
                    is_active=bool(u.get("is_active", True)),
                )
            )
    await session.flush()

    # 3. Warehouses (primero padres, luego hijos)
    warehouses_raw = snap.get("warehouses", [])
    parents = [w for w in warehouses_raw if not w.get("parent_id")]
    children = [w for w in warehouses_raw if w.get("parent_id")]
    for w in parents + children:
        w_id = _parse_uuid(w.get("id"))
        exists = (
            await session.execute(select(Warehouse).where(Warehouse.id == w_id))
        ).scalar_one_or_none()
        if not exists:
            session.add(
                Warehouse(
                    id=w_id,
                    name=w["name"],
                    location=w.get("location"),
                    description=w.get("description"),
                    is_active=bool(w.get("is_active", True)),
                    parent_id=_parse_uuid(w.get("parent_id")),
                    created_at=_parse_dt(w.get("created_at")) or datetime.now(),
                )
            )
    await session.flush()

    # 4. Catalogs
    for cat in snap.get("equipment_catalogs", []):
        cat_id = _parse_uuid(cat.get("id"))
        exists = (
            await session.execute(select(EquipmentCatalogItem).where(EquipmentCatalogItem.id == cat_id))
        ).scalar_one_or_none()
        if not exists:
            session.add(
                EquipmentCatalogItem(
                    id=cat_id,
                    item_type=cat["item_type"],
                    value=cat["value"],
                    label=cat["label"],
                    group_name=cat.get("group_name"),
                    is_custom=bool(cat.get("is_custom", True)),
                )
            )
    await session.flush()

    # 5. Equipment (137 equipos)
    for eq in snap.get("equipment", []):
        eq_id = _parse_uuid(eq.get("id"))
        status_str = eq.get("status", "available")
        try:
            status_enum = EquipmentStatus(status_str)
        except Exception:
            status_enum = EquipmentStatus.available

        session.add(
            Equipment(
                id=eq_id,
                serial_number=eq["serial_number"],
                barcode=eq.get("barcode"),
                name=eq["name"],
                brand=eq.get("brand"),
                model=eq.get("model"),
                category=eq.get("category", "other"),
                status=status_enum,
                current_warehouse_id=_parse_uuid(eq.get("current_warehouse_id")),
                assigned_to=eq.get("assigned_to"),
                notes=eq.get("notes"),
                is_active=bool(eq.get("is_active", True)),
                purchase_date=_parse_date(eq.get("purchase_date")),
                purchase_price=Decimal(str(eq["purchase_price"])) if eq.get("purchase_price") is not None else None,
                expected_lifespan_years=int(eq.get("expected_lifespan_years") or 3),
                warranty_expires=_parse_date(eq.get("warranty_expires")),
                created_at=_parse_dt(eq.get("created_at")) or datetime.now(),
                updated_at=_parse_dt(eq.get("updated_at")) or datetime.now(),
            )
        )
    await session.flush()

    # 6. Maintenances
    for m in snap.get("equipment_maintenances", []):
        session.add(
            EquipmentMaintenance(
                id=_parse_uuid(m.get("id")) or uuid.uuid4(),
                equipment_id=_parse_uuid(m["equipment_id"]),
                maintenance_type=m.get("maintenance_type", "preventivo"),
                title=m["title"],
                description=m.get("description"),
                cost=Decimal(str(m["cost"])) if m.get("cost") is not None else Decimal("0"),
                performed_by=m.get("performed_by"),
                performed_at=_parse_date(m.get("performed_at")) or date.today(),
                new_specs=m.get("new_specs"),
                created_at=_parse_dt(m.get("created_at")) or datetime.now(),
            )
        )

    # 7. Delivery Acts & Items
    for act in snap.get("delivery_acts", []):
        session.add(
            DeliveryAct(
                id=_parse_uuid(act["id"]),
                act_number=act["act_number"],
                act_type=act.get("act_type", "assignment"),
                city=act.get("city", "Caracas"),
                recipient_name=act["recipient_name"],
                recipient_id_card=act["recipient_id_card"],
                recipient_position=act.get("recipient_position"),
                recipient_department=act.get("recipient_department"),
                recipient_signature=act.get("recipient_signature"),
                delivered_by_user_id=_parse_uuid(act.get("delivered_by_user_id")),
                delivered_by_name=act.get("delivered_by_name", "Raimundo Gil"),
                delivered_by_position=act.get("delivered_by_position", "Gerente de Tecnología"),
                delivered_by_id_card=act.get("delivered_by_id_card", "14.287.629"),
                terms_clause=act.get("terms_clause") or "",
                notes=act.get("notes"),
                accessories=act.get("accessories"),
                scanned_document_url=act.get("scanned_document_url"),
                scanned_at=_parse_dt(act.get("scanned_at")),
                evidence_photos=act.get("evidence_photos"),
                created_at=_parse_dt(act.get("created_at")) or datetime.now(),
                updated_at=_parse_dt(act.get("updated_at")) or datetime.now(),
            )
        )
    await session.flush()

    for item in snap.get("delivery_act_items", []):
        session.add(
            DeliveryActItem(
                id=_parse_uuid(item["id"]),
                act_id=_parse_uuid(item["act_id"]),
                equipment_id=_parse_uuid(item.get("equipment_id")),
                equipment_name=item["equipment_name"],
                equipment_type=item.get("equipment_type", "Equipo Tecnológico"),
                brand=item.get("brand"),
                model=item.get("model"),
                serial_number=item["serial_number"],
                specs=item.get("specs"),
            )
        )

    # 8. Movements
    for mv in snap.get("movements", []):
        mv_type_str = mv.get("type", "entry")
        try:
            mv_enum = MovementType(mv_type_str)
        except Exception:
            mv_enum = MovementType.entry
        session.add(
            Movement(
                id=_parse_uuid(mv["id"]),
                type=mv_enum,
                equipment_id=_parse_uuid(mv["equipment_id"]),
                from_warehouse_id=_parse_uuid(mv.get("from_warehouse_id")),
                to_warehouse_id=_parse_uuid(mv.get("to_warehouse_id")),
                performed_by=_parse_uuid(mv["performed_by"]),
                assigned_to=mv.get("assigned_to"),
                notes=mv.get("notes"),
                created_at=_parse_dt(mv.get("created_at")) or datetime.now(),
            )
        )

    await session.commit()
    print(f"[Seed] Snapshot restaurado exitosamente ({len(snap.get('equipment', []))} equipos).")
    return True


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Asegurar directorio de uploads
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

    # 2. Crear tablas en PostgreSQL y migrar columna category a VARCHAR si era ENUM
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        try:
            await conn.execute(
                text("ALTER TABLE equipment ALTER COLUMN category TYPE VARCHAR(100) USING category::text;")
            )
        except Exception:
            pass

    # 3. Sembrar snapshot completo o datos esenciales si no existen
    async with AsyncSessionLocal() as session:
        seeded = await _seed_from_snapshot_if_available(session)

        # Garantizar usuarios base y configuración corporativa incluso si ya existían datos
        result = await session.execute(select(CompanyConfig).limit(1))
        if not result.scalar_one_or_none():
            config = CompanyConfig(
                name="Grupo Tu Andamio",
                logo_url="/logotuandamio.png",
                primary_color="#0F70B7",
                secondary_color="#0A4D82",
                accent_color="#38BDF8",
            )
            session.add(config)

        result = await session.execute(select(User).where(User.username == "admin"))
        if not result.scalar_one_or_none():
            admin = User(
                username="admin",
                full_name="Administrador de Sistema",
                pin_hash=hash_pin("1234"),
                role=UserRole.admin,
                is_active=True,
            )
            session.add(admin)

        result = await session.execute(select(User).where(User.username == "operador"))
        if not result.scalar_one_or_none():
            operador = User(
                username="operador",
                full_name="Operador de Almacén",
                pin_hash=hash_pin("4321"),
                role=UserRole.user,
                is_active=True,
            )
            session.add(operador)

        if not seeded:
            result = await session.execute(select(Warehouse).limit(1))
            if not result.scalar_one_or_none():
                warehouse = Warehouse(
                    name="Torre Avila",
                    location="Sede Principal Caracas",
                    description="Almacén principal Grupo Tu Andamio",
                )
                session.add(warehouse)

        await session.commit()

    yield
    await engine.dispose()


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Sistema de Inventario Multi-Almacén de Marca Blanca para Equipos Tecnológicos",
    lifespan=lifespan,
)

# Configuración CORS para PWA
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Archivos estáticos de uploads
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")

# Montar API router v1
app.include_router(api_router, prefix="/api/v1")


@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
    }


# ─────────────────────────────────────────────────────────────
# Servir PWA React compilada (Modo Unificado Render / Cloud)
# ─────────────────────────────────────────────────────────────
STATIC_DIST_DIR = os.environ.get("STATIC_DIST_DIR", "/app/static_dist")

if os.path.isdir(STATIC_DIST_DIR):
    assets_dir = os.path.join(STATIC_DIST_DIR, "assets")
    if os.path.isdir(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="frontend_assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str):
        if full_path.startswith("api/") or full_path.startswith("uploads/"):
            raise HTTPException(status_code=404, detail="Recurso no encontrado")
        candidate = os.path.normpath(os.path.join(STATIC_DIST_DIR, full_path))
        if (
            full_path
            and candidate.startswith(os.path.normpath(STATIC_DIST_DIR))
            and os.path.isfile(candidate)
        ):
            return FileResponse(candidate)
        index_html = os.path.join(STATIC_DIST_DIR, "index.html")
        if os.path.isfile(index_html):
            return FileResponse(index_html)
        raise HTTPException(status_code=404, detail="Frontend no encontrado")
