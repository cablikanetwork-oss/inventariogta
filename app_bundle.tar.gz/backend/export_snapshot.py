import asyncio
import json
import os
import sys
from datetime import date, datetime
from decimal import Decimal
import uuid

sys.path.insert(0, "/app")

from sqlalchemy import select
from app.core.database import AsyncSessionLocal
from app.models import (
    CompanyConfig,
    User,
    Warehouse,
    Equipment,
    EquipmentCatalogItem,
    EquipmentMaintenance,
    DeliveryAct,
    DeliveryActItem,
    Movement,
)

def serialize_val(val):
    if val is None:
        return None
    if isinstance(val, (uuid.UUID,)):
        return str(val)
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, Decimal):
        return float(val)
    if hasattr(val, "value"):
        return val.value
    return val

def model_to_dict(obj):
    data = {}
    for col in obj.__table__.columns:
        data[col.name] = serialize_val(getattr(obj, col.name))
    return data

async def main():
    async with AsyncSessionLocal() as session:
        snapshot = {}

        res = await session.execute(select(CompanyConfig))
        snapshot["company_config"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(User))
        snapshot["users"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(Warehouse))
        snapshot["warehouses"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(EquipmentCatalogItem))
        snapshot["equipment_catalogs"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(Equipment))
        snapshot["equipment"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(EquipmentMaintenance))
        snapshot["equipment_maintenances"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(DeliveryAct))
        snapshot["delivery_acts"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(DeliveryActItem))
        snapshot["delivery_act_items"] = [model_to_dict(x) for x in res.scalars().all()]

        res = await session.execute(select(Movement))
        snapshot["movements"] = [model_to_dict(x) for x in res.scalars().all()]

        out_path = "/app/app/initial_seed_data.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(snapshot, f, ensure_ascii=False, indent=2)

        print(
            f"Exported: {len(snapshot['warehouses'])} warehouses, "
            f"{len(snapshot['equipment'])} equipment items, "
            f"{len(snapshot['delivery_acts'])} acts, "
            f"{len(snapshot['movements'])} movements -> {out_path}"
        )

if __name__ == "__main__":
    asyncio.run(main())
