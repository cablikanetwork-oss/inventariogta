import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useCompanyConfig } from './hooks/useCompanyConfig'
import { syncArCatalogOfflineFirst } from './services/arOfflineStore'
import { useAuthStore } from './store/authStore'
import { Layout } from './components/Layout/Layout'
import { LoginPage } from './pages/Login/LoginPage'
import { DashboardPage } from './pages/Dashboard/DashboardPage'
import { EquipmentPage } from './pages/Equipment/EquipmentPage'
import { MovementsPage } from './pages/Movements/MovementsPage'
import { WarehousesPage } from './pages/Warehouses/WarehousesPage'
import { ActsPage } from './pages/Acts/ActsPage'
import { ReportsPage } from './pages/Reports/ReportsPage'
import { AuditPage } from './pages/Audit/AuditPage'
import { LabelsPage } from './pages/Labels/LabelsPage'
import { UsersPage } from './pages/Users/UsersPage'
import { SettingsPage } from './pages/Settings/SettingsPage'
import { EquipmentQuickViewPage } from './pages/Equipment/EquipmentQuickViewPage'
import { QuickScanHUDPage } from './pages/Scan/QuickScanHUDPage'
import { ActPublicVerifyPage } from './pages/Acts/ActPublicVerifyPage'

function ProtectedRoute({
  children,
  adminOnly = false,
}: {
  children: React.ReactNode
  adminOnly?: boolean
}) {
  const { isAuthenticated, user } = useAuthStore()

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  if (adminOnly && user?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />
  }

  return <>{children}</>
}

function AppRoutes() {
  const { isAuthenticated } = useAuthStore()

  return (
    <Routes>
      {/* Rutas Públicas de Consulta Rápida y Escáner AR / HUD (accesibles sin login previo) */}
      <Route path="/eq/:identifier" element={<EquipmentQuickViewPage />} />
      <Route path="/scan/:identifier" element={<EquipmentQuickViewPage />} />
      <Route path="/verify-act/:identifier" element={<ActPublicVerifyPage />} />
      <Route path="/scan" element={<QuickScanHUDPage />} />

      <Route
        path="/login"
        element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <LoginPage />}
      />

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="equipment" element={<EquipmentPage />} />
        <Route path="labels" element={<LabelsPage />} />
        <Route path="audit" element={<AuditPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="acts" element={<ActsPage />} />
        <Route path="movements" element={<MovementsPage />} />
        <Route path="warehouses" element={<WarehousesPage />} />

        {/* Rutas exclusivas para Administradores */}
        <Route
          path="users"
          element={
            <ProtectedRoute adminOnly>
              <UsersPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="settings"
          element={
            <ProtectedRoute adminOnly>
              <SettingsPage />
            </ProtectedRoute>
          }
        />
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}

export default function App() {
  // Carga e inyecta dinámicamente las variables de Marca Blanca (colores, logo, nombre)
  useCompanyConfig()

  // Pre-sincroniza silenciosamente el catálogo completo de activos en RAM + IndexedDB para escaneo AR en 0ms y modo Offline
  useEffect(() => {
    syncArCatalogOfflineFirst()
    const handleOnline = () => {
      syncArCatalogOfflineFirst()
    }
    window.addEventListener('online', handleOnline)
    return () => window.removeEventListener('online', handleOnline)
  }, [])

  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  )
}
