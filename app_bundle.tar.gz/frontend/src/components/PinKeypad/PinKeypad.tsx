import { useState, useCallback } from 'react'
import { Delete, Check } from 'lucide-react'

interface PinKeypadProps {
  onSubmit: (pin: string) => void
  isLoading?: boolean
  error?: string | null
  maxLength?: number
}

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'ok']

export function PinKeypad({ onSubmit, isLoading = false, error, maxLength = 6 }: PinKeypadProps) {
  const [pin, setPin] = useState('')

  const handleKey = useCallback((key: string) => {
    if (isLoading) return
    if (key === 'del') {
      setPin((p) => p.slice(0, -1))
    } else if (key === 'ok') {
      if (pin.length >= 4) {
        onSubmit(pin)
        setPin('')
      }
    } else if (pin.length < maxLength) {
      const next = pin + key
      setPin(next)
      // Auto-submit opcional al completar 4 dígitos si no se configuran 6
      if (next.length === 4 && maxLength === 4) {
        onSubmit(next)
        setPin('')
      }
    }
  }, [pin, maxLength, isLoading, onSubmit])

  const handleSubmit = useCallback(() => {
    if (pin.length >= 4 && !isLoading) {
      onSubmit(pin)
      setPin('')
    }
  }, [pin, onSubmit, isLoading])

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-xs mx-auto">
      {/* Indicador de dígitos ingresados */}
      <div className="flex gap-3 justify-center py-2">
        {Array.from({ length: maxLength }).map((_, i) => (
          <div
            key={i}
            className={`w-4 h-4 rounded-full border-2 transition-all duration-150 ${
              i < pin.length
                ? 'bg-primary border-primary scale-125 shadow-md'
                : 'bg-slate-900 border-slate-700'
            }`}
          />
        ))}
      </div>

      {/* Mensaje de error con shake visual */}
      {error && (
        <div className="text-rose-400 text-sm font-medium text-center bg-rose-950/40 border border-rose-900/50 py-2 px-4 rounded-xl w-full">
          {error}
        </div>
      )}

      {/* Matriz del Teclado Numérico */}
      <div className="grid grid-cols-3 gap-3">
        {KEYS.map((key) => {
          if (key === 'del') {
            return (
              <button
                key="del"
                type="button"
                onClick={() => handleKey('del')}
                className="pin-key-action"
                disabled={isLoading || pin.length === 0}
                aria-label="Borrar dígito"
              >
                <Delete className="w-6 h-6" />
              </button>
            )
          }
          if (key === 'ok') {
            return (
              <button
                key="ok"
                type="button"
                onClick={handleSubmit}
                className="pin-key bg-primary text-white border-primary/60 hover:opacity-90 active:scale-95 disabled:opacity-40"
                disabled={isLoading || pin.length < 4}
                aria-label="Confirmar PIN"
              >
                <Check className="w-7 h-7 stroke-[3]" />
              </button>
            )
          }
          return (
            <button
              key={key}
              type="button"
              onClick={() => handleKey(key)}
              className="pin-key"
              disabled={isLoading}
            >
              {key}
            </button>
          )
        })}
      </div>

      {/* Botón de acceso rápido */}
      <button
        type="button"
        onClick={handleSubmit}
        disabled={pin.length < 4 || isLoading}
        className="btn-primary w-full disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {isLoading ? (
          <>
            <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
            Accediendo...
          </>
        ) : (
          `Entrar (${pin.length}/${maxLength})`
        )}
      </button>
    </div>
  )
}

