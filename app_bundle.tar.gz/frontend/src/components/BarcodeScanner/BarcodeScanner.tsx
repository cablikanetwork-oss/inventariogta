import { useRef, useEffect, useCallback, useState } from 'react'
import { X, Camera, ScanLine, Check, Layers, Trash2 } from 'lucide-react'
import { useBarcodeScanner } from '../../hooks/useBarcodeScanner'

interface BarcodeScannerProps {
  onResult: (result: string) => void
  onClose: () => void
  continuousMode?: boolean
  scannedList?: string[]
  onRemoveFromList?: (code: string) => void
  batchTitle?: string
}

function playBeep(type: 'success' | 'duplicate') {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext
    if (!AudioCtx) return
    const ctx = new AudioCtx()
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.connect(gain)
    gain.connect(ctx.destination)

    if (type === 'success') {
      osc.type = 'sine'
      osc.frequency.setValueAtTime(1250, ctx.currentTime)
      gain.gain.setValueAtTime(0.18, ctx.currentTime)
      osc.start()
      osc.stop(ctx.currentTime + 0.09)
    } else {
      osc.type = 'triangle'
      osc.frequency.setValueAtTime(320, ctx.currentTime)
      gain.gain.setValueAtTime(0.15, ctx.currentTime)
      osc.start()
      osc.stop(ctx.currentTime + 0.16)
    }
  } catch {
    // Ignorar si el navegador bloquea audio sin gesto previo
  }
}

export function BarcodeScanner({
  onResult,
  onClose,
  continuousMode = false,
  scannedList = [],
  onRemoveFromList,
  batchTitle,
}: BarcodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const { isScanning, error, startScanning, stopScanning } = useBarcodeScanner()

  const [flashColor, setFlashColor] = useState<'emerald' | 'amber' | null>(null)
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; type: 'ok' | 'dup' } | null>(null)

  const lastScanRef = useRef<{ code: string; time: number }>({ code: '', time: 0 })
  const scannedSetRef = useRef<Set<string>>(new Set())

  useEffect(() => {
    scannedSetRef.current = new Set(scannedList.map((s) => s.trim().toLowerCase()))
  }, [scannedList])

  const cleanRawCode = (raw: string) => {
    let cleaned = raw.trim()
    if (cleaned.startsWith('http://') || cleaned.startsWith('https://')) {
      try {
        const url = new URL(cleaned)
        const segments = url.pathname.split('/').filter(Boolean)
        if (segments.length > 0) {
          cleaned = segments[segments.length - 1]
        }
      } catch {
        // fallback
      }
    }
    return cleaned
  }

  const handleResult = useCallback(
    (result: string) => {
      const cleaned = cleanRawCode(result)
      if (!cleaned) return

      if (!continuousMode) {
        stopScanning()
        playBeep('success')
        if (navigator.vibrate) navigator.vibrate(70)
        onResult(cleaned)
        onClose()
        return
      }

      // Modo Ráfaga Continua: evitar lecturas repetidas en menos de 1.6s del mismo código frente a la lente
      const now = Date.now()
      if (
        lastScanRef.current.code.toLowerCase() === cleaned.toLowerCase() &&
        now - lastScanRef.current.time < 1600
      ) {
        return
      }
      lastScanRef.current = { code: cleaned, time: now }

      if (scannedSetRef.current.has(cleaned.toLowerCase())) {
        playBeep('duplicate')
        if (navigator.vibrate) navigator.vibrate([40, 40, 40])
        setFlashColor('amber')
        setFeedbackMsg({
          text: `⚠️ Serial "${cleaned}" ya está en la lista`,
          type: 'dup',
        })
        setTimeout(() => setFlashColor(null), 350)
        return
      }

      // Nuevo serial válido en ráfaga
      scannedSetRef.current.add(cleaned.toLowerCase())
      playBeep('success')
      if (navigator.vibrate) navigator.vibrate(80)
      setFlashColor('emerald')
      setFeedbackMsg({
        text: `✅ Serial agregado: ${cleaned}`,
        type: 'ok',
      })
      setTimeout(() => setFlashColor(null), 300)
      onResult(cleaned)
    },
    [continuousMode, stopScanning, onResult, onClose]
  )

  useEffect(() => {
    if (videoRef.current) {
      startScanning(videoRef, handleResult, continuousMode)
    }
    return () => {
      stopScanning()
    }
  }, [handleResult, startScanning, stopScanning, continuousMode])

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between">
      {/* Barra superior de control */}
      <div className="flex items-center justify-between p-4 bg-slate-950/90 backdrop-blur-md safe-top z-10 border-b border-slate-800">
        <div className="flex items-center gap-2.5 text-white min-w-0">
          <div className="p-2 rounded-xl bg-primary/20 text-primary">
            {continuousMode ? <Layers className="w-5 h-5" /> : <Camera className="w-5 h-5" />}
          </div>
          <div className="min-w-0">
            <span className="font-bold text-sm block truncate">
              {continuousMode
                ? 'Escáner en Ráfaga (Modo Lote Continuo)'
                : 'Escáner de Código / QR'}
            </span>
            {continuousMode && (
              <span className="text-[11px] text-emerald-400 font-semibold block truncate">
                {batchTitle || 'Apunta a cada caja/equipo sin cerrar la cámara'} • {scannedList.length}{' '}
                escaneados
              </span>
            )}
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            stopScanning()
            onClose()
          }}
          className="p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
          aria-label="Cerrar escáner"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Visor de cámara y mira de escaneo */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-black">
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          playsInline
          muted
          autoPlay
        />

        {/* Banner flotante de confirmación instantánea en Modo Ráfaga */}
        {feedbackMsg && (
          <div
            className={`absolute top-4 left-4 right-4 max-w-md mx-auto px-4 py-2.5 rounded-xl font-mono text-xs font-bold text-center shadow-2xl border backdrop-blur-md transition-all ${
              feedbackMsg.type === 'ok'
                ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/60'
                : 'bg-amber-950/90 text-amber-300 border-amber-500/60'
            }`}
          >
            {feedbackMsg.text}
          </div>
        )}

        {/* Retícula de encuadre */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div
            className={`relative w-72 h-56 rounded-2xl overflow-hidden shadow-2xl transition-all duration-150 ${
              flashColor === 'emerald'
                ? 'border-4 border-emerald-400 bg-emerald-500/20 scale-105'
                : flashColor === 'amber'
                ? 'border-4 border-amber-400 bg-amber-500/20'
                : 'border-2 border-white/20'
            }`}
          >
            {/* Esquinas destacadas */}
            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-lg" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-lg" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-lg" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-lg" />

            {/* Línea láser de escaneo animada */}
            {isScanning && (
              <div
                className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-90 animate-pulse"
                style={{ top: '50%', transform: 'translateY(-50%)' }}
              />
            )}
          </div>
        </div>
      </div>

      {/* Pie con cola en vivo de seriales (Modo Ráfaga) o instrucciones */}
      <div className="p-4 bg-slate-950/95 safe-bottom z-10 border-t border-slate-800 space-y-3">
        {error ? (
          <p className="text-rose-400 text-sm font-medium text-center">{error}</p>
        ) : continuousMode ? (
          <div className="max-w-lg mx-auto space-y-2.5">
            {scannedList.length > 0 ? (
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {scannedList.map((code, idx) => (
                  <span
                    key={code}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-emerald-700/50 text-emerald-300 font-mono text-xs whitespace-nowrap"
                  >
                    <span className="text-[10px] text-slate-500">#{idx + 1}</span>
                    <span>{code}</span>
                    {onRemoveFromList && (
                      <button
                        type="button"
                        onClick={() => onRemoveFromList(code)}
                        className="text-slate-500 hover:text-rose-400 ml-0.5"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </span>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2 text-slate-400 text-xs">
                <ScanLine className="w-4 h-4 text-primary animate-pulse" />
                <span>Enfoca el código de barras de cada serial para ir sumándolos a la lista</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                stopScanning()
                onClose()
              }}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <Check className="w-4 h-4" />
              <span>
                Finalizar Escaneo ({scannedList.length}{' '}
                {scannedList.length === 1 ? 'serial capturado' : 'seriales capturados'})
              </span>
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-2 text-slate-400 text-sm">
            <ScanLine className="w-4 h-4 text-primary animate-pulse" />
            <span>Apunta la cámara al código de barras o QR del equipo tecnológico</span>
          </div>
        )}
      </div>
    </div>
  )
}
