import type { EquipmentStatus } from '../../api/equipment'

const STATUS_LABELS: Record<EquipmentStatus, string> = {
  available: 'Disponible',
  assigned: 'Asignado',
  maintenance: 'Mantenimiento',
  retired: 'Retirado',
  lost: 'Extraviado',
}

const STATUS_CLASSES: Record<EquipmentStatus, string> = {
  available: 'badge-available',
  assigned: 'badge-assigned',
  maintenance: 'badge-maintenance',
  retired: 'badge-retired',
  lost: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-950/80 text-rose-400 border border-rose-800/60',
}

interface StatusBadgeProps {
  status: EquipmentStatus
}

export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span className={STATUS_CLASSES[status] || STATUS_CLASSES.available}>
      {STATUS_LABELS[status] || status}
    </span>
  )
}

