import type { MovementType } from '../../api/movements'

const TYPE_LABELS: Record<MovementType, string> = {
  entry: 'Entrada',
  exit: 'Salida',
  transfer: 'Transferencia',
  return: 'Devolución',
  maintenance: 'Mantenimiento',
}

const TYPE_CLASSES: Record<MovementType, string> = {
  entry: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800/60',
  exit: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-950/80 text-orange-400 border border-orange-800/60',
  transfer: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-950/80 text-sky-400 border border-sky-800/60',
  return: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-950/80 text-purple-400 border border-purple-800/60',
  maintenance: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-950/80 text-amber-400 border border-amber-800/60',
}

export function MovementTypeBadge({ type }: { type: MovementType }) {
  return (
    <span className={TYPE_CLASSES[type] || TYPE_CLASSES.entry}>
      {TYPE_LABELS[type] || type}
    </span>
  )
}

