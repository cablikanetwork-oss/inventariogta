import { useState, useEffect, useCallback } from 'react'
import { WifiOff, Wifi } from 'lucide-react'

// Hook exportable para que otros componentes puedan conocer el estado de conexión
export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(navigator.onLine)

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  return isOnline
}

export function OfflineBanner() {
  const isOnline = useOnlineStatus()
  const [wasOffline, setWasOffline] = useState(false)
  const [showReconnected, setShowReconnected] = useState(false)
  const [visible, setVisible] = useState(false)

  const hide = useCallback(() => {
    setVisible(false)
    setShowReconnected(false)
    setWasOffline(false)
  }, [])

  useEffect(() => {
    if (!isOnline) {
      setWasOffline(true)
      setShowReconnected(false)
      setVisible(true)
    } else if (wasOffline && isOnline) {
      // Volvió la conexión
      setShowReconnected(true)
      setVisible(true)
      // Auto-ocultar tras 3 segundos
      const timer = setTimeout(hide, 3000)
      return () => clearTimeout(timer)
    }
  }, [isOnline, wasOffline, hide])

  if (!visible) return null

  if (showReconnected) {
    return (
      <div
        className="fixed top-0 left-0 right-0 z-50 bg-emerald-700/95 backdrop-blur-md text-white text-sm font-semibold flex items-center justify-center gap-2.5 py-2.5 px-4 shadow-lg animate-in fade-in slide-in-from-top-2 duration-300"
        role="status"
      >
        <Wifi className="w-4 h-4 flex-shrink-0 text-emerald-200" />
        <span>✅ Conexión restaurada — Sincronizando...</span>
        <button
          onClick={hide}
          className="ml-auto text-emerald-200 hover:text-white text-lg leading-none"
          aria-label="Cerrar"
        >
          ✕
        </button>
      </div>
    )
  }

  return (
    <div
      className="fixed top-0 left-0 right-0 z-50 bg-amber-700/95 backdrop-blur-md text-white text-sm font-semibold flex items-center justify-center gap-2.5 py-2.5 px-4 shadow-lg animate-in fade-in slide-in-from-top-2 duration-300"
      role="alert"
    >
      <WifiOff className="w-4 h-4 flex-shrink-0 text-amber-200" />
      <span>
        📡 Sin conexión — Trabajando en modo offline. Las acciones se sincronizarán cuando se
        restaure la conexión.
      </span>
    </div>
  )
}
