import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Sparkles,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  QrCode,
  X,
  ChevronRight,
  Package,
  User,
  Warehouse,
  FileText,
  BarChart3,
  Trash2,
  KeyRound,
  Maximize2,
  Minimize2,
  ExternalLink,
  Sliders,
  Square,
  Play,
  ShieldCheck,
} from 'lucide-react'
import {
  assistantApi,
  type AssistantActionCard,
  type ChatHistoryItem,
} from '../../api/assistant'
import { BarcodeScanner } from '../BarcodeScanner/BarcodeScanner'

interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
  cards?: AssistantActionCard[]
  followUps?: string[]
  engine?: string
}

type VoicePersona = 'sebastian' | 'gonzalo' | 'jorge'

// Limpia el texto técnico y emojis para que la locución por voz de Rosco suene 100% humana y natural
function formatTextForSpeech(rawText: string): string {
  return (
    rawText
      .replace(/\*\*/g, '')
      .replace(/`/g, '')
      .replace(/\*/g, '')
      .replace(/C\.I:\s*/gi, 'Cédula ')
      .replace(/\bSN:\s*/gi, 'Serial ')
      .replace(/\bACT-(\d{4})-0*(\d+)\b/gi, 'Acta $1 número $2')
      .replace(/\\rightarrow/g, ' hacia ')
      .replace(/[•📊📦🟢🔵🟠🏢📄👤💡🔧🛠️🔄✅⚠️📸✨ℹ️]/g, ' ')
      .replace(/\n+/g, '. ')
      .replace(/\s{2,}/g, ' ')
      .trim()
  )
}

// Formateador ligero de Markdown (**negritas**, *cursivas*, `código` y saltos de línea)
function renderFormattedText(text: string) {
  const lines = text.split('\n')
  return lines.map((line, lineIdx) => {
    if (!line.trim()) {
      return <div key={lineIdx} className="h-2" />
    }

    const parts = line.split(/(\*\*.*?\*\*|`.*?`|\*.*?\*)/g)
    return (
      <p key={lineIdx} className="leading-relaxed">
        {parts.map((part, i) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return (
              <strong key={i} className="font-bold text-white">
                {part.slice(2, -2)}
              </strong>
            )
          }
          if (part.startsWith('`') && part.endsWith('`')) {
            return (
              <code
                key={i}
                className="px-1.5 py-0.5 rounded bg-slate-800 text-sky-300 font-mono text-[11px] border border-slate-700/70"
              >
                {part.slice(1, -1)}
              </code>
            )
          }
          if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
            return (
              <em key={i} className="italic text-slate-300">
                {part.slice(1, -1)}
              </em>
            )
          }
          return <span key={i}>{part}</span>
        })}
      </p>
    )
  })
}

function getBadgeClasses(color?: string | null) {
  switch (color) {
    case 'emerald':
      return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
    case 'sky':
      return 'bg-sky-500/15 text-sky-400 border-sky-500/30'
    case 'amber':
      return 'bg-amber-500/15 text-amber-400 border-amber-500/30'
    case 'rose':
      return 'bg-rose-500/15 text-rose-400 border-rose-500/30'
    default:
      return 'bg-slate-800 text-slate-300 border-slate-700'
  }
}

function getCardIcon(type: string) {
  switch (type) {
    case 'equipment':
      return <Package className="w-4 h-4 text-primary" />
    case 'person':
      return <User className="w-4 h-4 text-sky-400" />
    case 'warehouse':
      return <Warehouse className="w-4 h-4 text-emerald-400" />
    case 'act':
      return <FileText className="w-4 h-4 text-amber-400" />
    default:
      return <BarChart3 className="w-4 h-4 text-primary" />
  }
}

export function AiAssistantWidget() {
  const navigate = useNavigate()

  const [isOpen, setIsOpen] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([
    'Dame un resumen general del inventario',
    '¿Cuántas laptops están disponibles actualmente?',
    '¿Cuántos equipos se encuentran asignados actualmente?',
  ])
  const [quickStats, setQuickStats] = useState<{
    total: number
    available: number
    assigned: number
  } | null>(null)

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content:
        '¡Hola! Soy **Rosco**, el asistente de inteligencia artificial de **Grupo Tu Andamio**. Puedo responderte al instante dónde está cualquier equipo, consultar actas o **registrar traslados y movimientos de almacén por voz**.\n\n*Toca el **micrófono** para hablar conmigo, escribe tu consulta o escanea un código QR.*',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ])

  // Estados para Voz de Rosco (Entrada y Salida)
  const [isListening, setIsListening] = useState(false)
  const [isPromptingMic, setIsPromptingMic] = useState(false)
  const [liveTranscript, setLiveTranscript] = useState('')
  const [micStatusMessage, setMicStatusMessage] = useState<string | null>(null)
  const [needsHttpsForMic, setNeedsHttpsForMic] = useState(false)
  const [hasGreetedMic, setHasGreetedMic] = useState(false)

  const [voiceOutputEnabled, setVoiceOutputEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('inventory_voice_enabled')
    return saved !== null ? saved === 'true' : true
  })
  const [voicePersona, setVoicePersona] = useState<VoicePersona>(() => {
    const saved = localStorage.getItem('inventory_voice_persona')
    if (saved === 'gonzalo' || saved === 'jorge') return saved
    return 'sebastian'
  })
  const [voiceRate, setVoiceRate] = useState<number>(() => {
    const saved = parseFloat(localStorage.getItem('inventory_voice_rate') || '1.02')
    return isNaN(saved) ? 1.02 : saved
  })
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null)
  const [showVoiceSettings, setShowVoiceSettings] = useState(false)

  // Escáner, Animación de Giro Horario y API Key opcional
  const [showScanner, setShowScanner] = useState(false)
  const [showKeyConfig, setShowKeyConfig] = useState(false)
  const [isOpeningSpin, setIsOpeningSpin] = useState(false)
  const [isSpinning, setIsSpinning] = useState(false)
  const [geminiKey, setGeminiKey] = useState(
    () => localStorage.getItem('inventory_gemini_api_key') || ''
  )

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const triggerClockwiseSpin = (durationMs = 1100) => {
    setIsSpinning(true)
    setTimeout(() => setIsSpinning(false), durationMs)
  }

  const handleOpenWithSpin = () => {
    if (isOpeningSpin) return
    setIsOpeningSpin(true)
    setTimeout(() => {
      setIsOpen(true)
      setIsOpeningSpin(false)
      triggerClockwiseSpin(1000)
    }, 420)
  }

  // Escuchar evento global para abrir a Rosco desde la barra lateral o cabecera móvil
  useEffect(() => {
    const handleOpenEvent = () => {
      setIsOpen(true)
      triggerClockwiseSpin(1100)
    }
    window.addEventListener('open-ai-assistant', handleOpenEvent)
    return () => window.removeEventListener('open-ai-assistant', handleOpenEvent)
  }, [])

  // Cargar sugerencias dinámicas y pre-calentar en caché el saludo de voz neural masculina al abrir
  useEffect(() => {
    if (isOpen) {
      assistantApi
        .getSuggestions()
        .then((data) => {
          if (data.suggestions && data.suggestions.length > 0) {
            setSuggestions(data.suggestions)
          }
          if (data.quick_stats) {
            setQuickStats(data.quick_stats)
          }
        })
        .catch(() => {})

      // Pre-generar en caché RAM del backend los saludos del micrófono para respuesta en 0ms
      assistantApi
        .synthesizeSpeech({
          text: 'Hola, soy Rosco. Te escucho, dime tu consulta o qué movimiento deseas realizar.',
          voice: voicePersona,
          rate: '+4%',
        })
        .catch(() => {})
    }
  }, [isOpen, voicePersona])

  // Auto-scroll al último mensaje
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages, isLoading, isOpen, micStatusMessage])

  // Detener voz y micrófono al cerrar el asistente
  useEffect(() => {
    if (!isOpen) {
      stopSpeaking()
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop()
        } catch {}
      }
      setIsListening(false)
      setIsPromptingMic(false)
      setMicStatusMessage(null)
    }
  }, [isOpen])

  const stopSpeaking = () => {
    if (audioRef.current) {
      try {
        audioRef.current.pause()
        audioRef.current.currentTime = 0
      } catch {}
      audioRef.current = null
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
    }
    setSpeakingMessageId(null)
  }

  // Fallback local con voz masculina del navegador solo si el servidor no tiene red
  const speakBrowserMaleFallback = (
    speechClean: string,
    messageId?: string,
    onDoneCallback?: () => void
  ) => {
    if (!('speechSynthesis' in window)) {
      if (onDoneCallback) onDoneCallback()
      return
    }
    try {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(speechClean)
      const all = window.speechSynthesis.getVoices()
      const esVoices = all.filter((v) => v.lang.toLowerCase().startsWith('es'))
      const pool = esVoices.length > 0 ? esVoices : all
      const maleKeywords = ['jorge', 'alvaro', 'álvaro', 'raul', 'raúl', 'pablo', 'alonso', 'lorenzo', 'diego', 'carlos', 'male']
      let picked: SpeechSynthesisVoice | null = null
      for (const kw of maleKeywords) {
        const match = pool.find((v) => v.name.toLowerCase().includes(kw))
        if (match) {
          picked = match
          break
        }
      }
      if (picked) {
        utterance.voice = picked
        utterance.lang = picked.lang
        utterance.pitch = 0.95
      } else if (pool[0]) {
        utterance.voice = pool[0]
        utterance.lang = pool[0].lang
        utterance.pitch = 0.8
      } else {
        utterance.lang = 'es-ES'
        utterance.pitch = 0.8
      }
      utterance.rate = voiceRate

      let done = false
      const finish = () => {
        if (done) return
        done = true
        setSpeakingMessageId(null)
        if (onDoneCallback) onDoneCallback()
      }
      utterance.onstart = () => {
        if (messageId) setSpeakingMessageId(messageId)
      }
      utterance.onend = finish
      utterance.onerror = finish
      window.speechSynthesis.speak(utterance)
    } catch {
      setSpeakingMessageId(null)
      if (onDoneCallback) onDoneCallback()
    }
  }

  // Locución Neural Masculina Humanizada (vía Backend Edge Neural TTS + Audio HTML5)
  const speakText = async (
    rawText: string,
    messageId?: string,
    forceSpeak = false,
    onDoneCallback?: () => void
  ) => {
    if (!voiceOutputEnabled && !forceSpeak) {
      if (onDoneCallback) onDoneCallback()
      return
    }

    stopSpeaking()

    const speechClean = formatTextForSpeech(rawText)
    if (!speechClean) {
      if (onDoneCallback) onDoneCallback()
      return
    }

    const ratePercent =
      voiceRate >= 1.14 ? '+14%' : voiceRate >= 1.05 ? '+6%' : '+2%'

    if (messageId) setSpeakingMessageId(messageId)

    try {
      const audioBlob = await assistantApi.synthesizeSpeech({
        text: speechClean,
        voice: voicePersona,
        rate: ratePercent,
      })

      const audioUrl = URL.createObjectURL(audioBlob)
      const audio = new Audio(audioUrl)
      audioRef.current = audio

      let finished = false
      const cleanupAndCallback = () => {
        if (finished) return
        finished = true
        URL.revokeObjectURL(audioUrl)
        setSpeakingMessageId(null)
        if (onDoneCallback) onDoneCallback()
      }

      audio.onended = cleanupAndCallback
      audio.onerror = () => {
        URL.revokeObjectURL(audioUrl)
        speakBrowserMaleFallback(speechClean, messageId, onDoneCallback)
      }

      await audio.play()
    } catch {
      speakBrowserMaleFallback(speechClean, messageId, onDoneCallback)
    }
  }

  const handleToggleVoiceOutput = () => {
    const next = !voiceOutputEnabled
    setVoiceOutputEnabled(next)
    localStorage.setItem('inventory_voice_enabled', String(next))
    if (!next) {
      stopSpeaking()
    }
  }

  const handleChangePersona = (persona: VoicePersona) => {
    setVoicePersona(persona)
    localStorage.setItem('inventory_voice_persona', persona)
  }

  const handleChangeRate = (newRate: number) => {
    setVoiceRate(newRate)
    localStorage.setItem('inventory_voice_rate', String(newRate))
  }

  const handleTestVoice = () => {
    const sample =
      'Hola, soy Rosco, el asistente de inteligencia artificial de Grupo Tu Andamio. Estoy listo para escuchar tus consultas y registrar movimientos por voz.'
    speakText(sample, 'test-voice', true)
  }

  const handleSendQuery = async (queryText: string, scannedCode?: string) => {
    const trimmed = queryText.trim()
    if (!trimmed && !scannedCode) return

    setMicStatusMessage(null)
    setLiveTranscript('')

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: trimmed || `Código escaneado: ${scannedCode}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }

    setMessages((prev) => [...prev, userMsg])
    setInput('')
    setIsLoading(true)
    triggerClockwiseSpin(1200)

    try {
      const historyPayload: ChatHistoryItem[] = messages.slice(-6).map((m) => ({
        role: m.role,
        content: m.content,
      }))

      const res = await assistantApi.query({
        query: trimmed || `Información del código ${scannedCode}`,
        scanned_code: scannedCode,
        history: historyPayload,
        gemini_api_key: geminiKey.trim() || undefined,
      })

      const botMsgId = `bot-${Date.now()}`
      const botMsg: ChatMessage = {
        id: botMsgId,
        role: 'assistant',
        content: res.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        cards: res.cards,
        followUps: res.follow_up_suggestions,
        engine: res.engine,
      }

      setMessages((prev) => [...prev, botMsg])
      speakText(res.answer, botMsgId)

      if (res.action_performed) {
        window.dispatchEvent(new Event('inventory-updated'))
        assistantApi
          .getSuggestions()
          .then((data) => {
            if (data.quick_stats) setQuickStats(data.quick_stats)
          })
          .catch(() => {})
      }
    } catch {
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content:
          '⚠️ Ocurrió un inconveniente al consultar el servidor. Verifica tu conexión e inténtalo de nuevo.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }
      setMessages((prev) => [...prev, errMsg])
    } finally {
      setIsLoading(false)
    }
  }

  // Inicia la captura real del micrófono tras el saludo hablado de Rosco
  const startSpeechRecognitionCapture = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition

    const isInsecureLanHttp =
      window.location.protocol === 'http:' &&
      window.location.hostname !== 'localhost' &&
      window.location.hostname !== '127.0.0.1'

    if (!SpeechRecognition) {
      setIsPromptingMic(false)
      setIsListening(false)
      setNeedsHttpsForMic(isInsecureLanHttp)
      setMicStatusMessage(
        '🎙️ Rosco te escucha: Usa el micrófono del teclado de tu teléfono o escribe tu instrucción aquí abajo.'
      )
      inputRef.current?.focus()
      return
    }

    try {
      const recognition = new SpeechRecognition()
      recognition.lang = 'es-ES'
      recognition.interimResults = true
      recognition.maxAlternatives = 1

      let finalCaptured = ''

      recognition.onstart = () => {
        setIsPromptingMic(false)
        setIsListening(true)
        setLiveTranscript('')
        setNeedsHttpsForMic(false)
        setMicStatusMessage('🎙️ Rosco te está escuchando... Habla ahora')
      }

      recognition.onresult = (event: any) => {
        let interim = ''
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcriptPiece = event.results[i][0].transcript
          if (event.results[i].isFinal) {
            finalCaptured += transcriptPiece
          } else {
            interim += transcriptPiece
          }
        }
        const currentText = (finalCaptured || interim).trim()
        setLiveTranscript(currentText)
        setInput(currentText)

        if (finalCaptured.trim()) {
          setIsListening(false)
          setMicStatusMessage(null)
          handleSendQuery(finalCaptured.trim())
        }
      }

      recognition.onerror = (event: any) => {
        setIsPromptingMic(false)
        setIsListening(false)
        const errCode = event?.error || ''

        if (errCode === 'not-allowed' || errCode === 'service-not-allowed') {
          if (isInsecureLanHttp) {
            setNeedsHttpsForMic(true)
            setMicStatusMessage(
              '🔒 Chrome en Android requiere conexión segura (HTTPS) para abrir el micrófono directo, o puedes pulsar el micrófono del teclado de tu teléfono abajo.'
            )
            inputRef.current?.focus()
          } else {
            setMicStatusMessage(
              '⚠️ Permiso de micrófono bloqueado en el navegador. Activa el permiso de micrófono o usa el dictado de tu teclado.'
            )
            inputRef.current?.focus()
          }
        } else if (errCode === 'no-speech') {
          setMicStatusMessage(
            '🎙️ No alcancé a escuchar tu voz. Toca el micrófono de nuevo cuando quieras hablarme.'
          )
        } else {
          setNeedsHttpsForMic(isInsecureLanHttp)
          setMicStatusMessage(
            '🎙️ Dictado listo: puedes usar el micrófono del teclado de tu móvil o activar el modo HTTPS.'
          )
          inputRef.current?.focus()
        }
      }

      recognition.onend = () => {
        setIsPromptingMic(false)
        setIsListening(false)
      }

      recognitionRef.current = recognition
      recognition.start()
    } catch {
      setIsPromptingMic(false)
      setIsListening(false)
      setNeedsHttpsForMic(isInsecureLanHttp)
      setMicStatusMessage(
        '🎙️ Usa el micrófono del teclado de tu teléfono para dictarle la instrucción a Rosco.'
      )
      inputRef.current?.focus()
    }
  }

  // Al presionar el botón de micrófono: Rosco te saluda en voz alta y luego abre la escucha
  const toggleVoiceInput = () => {
    if (isListening || isPromptingMic) {
      stopSpeaking()
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop()
        } catch {}
      }
      setIsListening(false)
      setIsPromptingMic(false)
      setMicStatusMessage(null)
      return
    }

    stopSpeaking()
    triggerClockwiseSpin(1400)
    setIsPromptingMic(true)
    setNeedsHttpsForMic(false)

    const promptPhrase = !hasGreetedMic
      ? 'Hola, soy Rosco. Te escucho, dime tu consulta o qué movimiento deseas realizar.'
      : 'Te escucho, dime tu instrucción.'
    setHasGreetedMic(true)

    setMicStatusMessage(`🔊 Rosco: "${promptPhrase}"`)

    // Rosco pronuncia el saludo y, al terminar, abre el micrófono para escuchar al usuario
    speakText(promptPhrase, 'mic-greeting', true, () => {
      startSpeechRecognitionCapture()
    })
  }

  const handleSwitchToHttps = () => {
    const httpsUrl = `https://${window.location.hostname}:3443${window.location.pathname}`
    window.location.href = httpsUrl
  }

  // Escaneo de código QR o de barras desde Rosco
  const handleScanResult = (code: string) => {
    setShowScanner(false)
    const clean = code.trim()
    if (!clean) return
    handleSendQuery(`¿Qué información tienes sobre el código ${clean}?`, clean)
  }

  const handleSaveApiKey = () => {
    localStorage.setItem('inventory_gemini_api_key', geminiKey.trim())
    setShowKeyConfig(false)
  }

  const handleClearChat = () => {
    stopSpeaking()
    setMicStatusMessage(null)
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        content:
          'Hola, soy **Rosco**. Conversación reiniciada. ¿Qué equipo, serial, trabajador o traslado de almacén deseas realizar?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ])
  }

  const handleNavigate = (url: string) => {
    if (window.innerWidth < 640) {
      setIsOpen(false)
    }
    navigate(url)
  }

  return (
    <div className="print:hidden">
      {/* BOTÓN FLOTANTE (FAB) CON LA FORMA DEL LOGO IA Y GIRO HORARIO AL TOCAR */}
      {!isOpen && (
        <button
          type="button"
          onClick={handleOpenWithSpin}
          className="fixed bottom-20 lg:bottom-6 right-4 lg:right-6 z-40 group w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white p-1 shadow-2xl shadow-blue-600/50 hover:shadow-blue-400/80 ring-2 ring-blue-500/60 hover:ring-blue-400 hover:scale-110 active:scale-95 transition-all flex items-center justify-center"
          title="Abrir a Rosco — Asistente IA"
        >
          <img
            src="/logoia.png"
            alt="Rosco IA"
            className={`w-full h-full object-contain rounded-full transition-transform duration-700 ${
              isOpeningSpin
                ? 'animate-[spin_0.45s_linear_infinite]'
                : 'group-hover:rotate-180'
            }`}
          />
          <span className="w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-950 absolute bottom-0 right-0 shadow-sm" />
        </button>
      )}

      {/* VENTANA / BOTTOM-SHEET DE ROSCO IA */}
      {isOpen && (
        <div className="fixed inset-0 sm:inset-auto sm:bottom-5 sm:right-5 z-50 flex flex-col justify-end sm:justify-start bg-black/60 sm:bg-transparent backdrop-blur-xs sm:backdrop-blur-none">
          <div
            className={`w-full ${
              isExpanded
                ? 'sm:w-[680px] sm:h-[82vh]'
                : 'sm:w-[440px] sm:h-[640px]'
            } h-[90vh] max-h-[92vh] bg-slate-950 border-t sm:border border-slate-800 rounded-t-3xl sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-200`}
          >
            {/* CABECERA DE ROSCO (Limpia, sin solapamiento en móviles y con iconos blancos nítidos) */}
            <div className="assistant-dark-header p-3 bg-gradient-to-r from-[#082F54] via-[#0F70B7] to-[#0B3B66] border-b border-blue-500/30 flex items-center justify-between gap-2 flex-shrink-0 text-white">
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                <div
                  onClick={() => triggerClockwiseSpin(1100)}
                  className="w-10 h-10 rounded-full bg-white p-0.5 flex items-center justify-center shadow-md flex-shrink-0 relative ring-2 ring-white/50 cursor-pointer"
                  title="Toca para girar a Rosco"
                >
                  <img
                    src="/logoia.png"
                    alt="Rosco IA"
                    className={`w-full h-full object-contain rounded-full transition-transform duration-700 ${
                      isLoading ||
                      isListening ||
                      isPromptingMic ||
                      Boolean(speakingMessageId) ||
                      isSpinning
                        ? 'animate-[spin_1s_linear_infinite]'
                        : 'hover:rotate-180'
                    }`}
                  />
                  <span
                    className={`w-2.5 h-2.5 rounded-full border-2 border-slate-950 absolute -bottom-0.5 -right-0.5 ${
                      speakingMessageId || isListening || isPromptingMic
                        ? 'bg-amber-400 animate-ping'
                        : 'bg-emerald-400'
                    }`}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-black !text-white whitespace-nowrap">
                      Rosco
                    </h3>
                    <span className="px-2 py-0.5 text-[10px] font-extrabold rounded-full bg-white/20 !text-white border border-white/30 whitespace-nowrap">
                      Asistente IA
                    </span>
                  </div>
                  <p className="text-[11px] !text-blue-100 truncate">
                    {quickStats
                      ? `${quickStats.total} equipos • ${quickStats.available} disp. • ${quickStats.assigned} asig.`
                      : 'Consultas y movimientos por voz'}
                  </p>
                </div>
              </div>

              {/* Controles de Cabecera en Blanco Nítido */}
              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  type="button"
                  onClick={handleToggleVoiceOutput}
                  className={`p-1.5 rounded-xl text-xs !text-white transition-colors ${
                    voiceOutputEnabled
                      ? 'bg-emerald-500/35 border border-white/40'
                      : 'hover:bg-white/20'
                  }`}
                  title={
                    voiceOutputEnabled
                      ? 'Voz de Rosco activada (Clic para silenciar)'
                      : 'Voz de Rosco silenciada (Clic para activar)'
                  }
                >
                  {voiceOutputEnabled ? (
                    <Volume2 className="w-4 h-4 !text-white" />
                  ) : (
                    <VolumeX className="w-4 h-4 !text-white" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowVoiceSettings((prev) => !prev)
                    setShowKeyConfig(false)
                  }}
                  className={`p-1.5 rounded-xl text-xs !text-white transition-colors ${
                    showVoiceSettings
                      ? 'bg-white/25 border border-white/40'
                      : 'hover:bg-white/20'
                  }`}
                  title="Configurar voz y velocidad de Rosco"
                >
                  <Sliders className="w-4 h-4 !text-white" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowKeyConfig((prev) => !prev)
                    setShowVoiceSettings(false)
                  }}
                  className={`p-1.5 rounded-xl text-xs !text-white transition-colors ${
                    geminiKey
                      ? 'bg-amber-500/35 border border-white/40'
                      : 'hover:bg-white/20'
                  }`}
                  title="Configurar API Key de Gemini (Opcional)"
                >
                  <KeyRound className="w-4 h-4 !text-white" />
                </button>

                <button
                  type="button"
                  onClick={handleClearChat}
                  className="p-1.5 rounded-xl !text-white hover:bg-rose-500/40 transition-colors"
                  title="Limpiar conversación"
                >
                  <Trash2 className="w-4 h-4 !text-white" />
                </button>

                <button
                  type="button"
                  onClick={() => setIsExpanded((prev) => !prev)}
                  className="hidden sm:flex p-1.5 rounded-xl !text-white hover:bg-white/20 transition-colors"
                  title={isExpanded ? 'Contraer ventana' : 'Expandir ventana'}
                >
                  {isExpanded ? (
                    <Minimize2 className="w-4 h-4 !text-white" />
                  ) : (
                    <Maximize2 className="w-4 h-4 !text-white" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-xl !text-white hover:bg-white/20 transition-colors"
                  title="Cerrar asistente"
                >
                  <X className="w-5 h-5 !text-white" />
                </button>
              </div>
            </div>

            {/* PANEL CONFIGURADOR DE VOZ MASCULINA NEURAL DE ROSCO */}
            {showVoiceSettings && (
              <div className="p-3.5 bg-slate-900/95 border-b border-slate-800 space-y-3 text-xs flex-shrink-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Volume2 className="w-4 h-4 text-indigo-400" />
                    <span>Voz Masculina Humanizada (Neural) de Rosco</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowVoiceSettings(false)}
                    className="text-slate-400 hover:text-white text-[11px]"
                  >
                    Listo
                  </button>
                </div>

                {/* Selección de Timbre Masculino Neural para Rosco */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleChangePersona('sebastian')}
                    className={`p-2 rounded-xl border text-left transition-all ${
                      voicePersona === 'sebastian'
                        ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-xs">👨 Voz 1 (VE)</div>
                    <div className="text-[10px] text-slate-400">Natural Humanizada</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleChangePersona('gonzalo')}
                    className={`p-2 rounded-xl border text-left transition-all ${
                      voicePersona === 'gonzalo'
                        ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-xs">👨 Voz 2 (CO)</div>
                    <div className="text-[10px] text-slate-400">Ejecutiva Cálida</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleChangePersona('jorge')}
                    className={`p-2 rounded-xl border text-left transition-all ${
                      voicePersona === 'jorge'
                        ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-xs">👨 Voz 3 (LAT)</div>
                    <div className="text-[10px] text-slate-400">Firme y Clara</div>
                  </button>
                </div>

                <div className="flex items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] text-slate-400">Velocidad:</span>
                    {[
                      { label: 'Normal', val: 1.0 },
                      { label: 'Ágil', val: 1.08 },
                      { label: 'Rápida', val: 1.18 },
                    ].map((opt) => (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => handleChangeRate(opt.val)}
                        className={`px-2 py-1 rounded-lg text-[11px] font-semibold border ${
                          Math.abs(voiceRate - opt.val) < 0.04
                            ? 'bg-primary/20 text-primary border-primary/40'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={handleTestVoice}
                    className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Probar a Rosco</span>
                  </button>
                </div>
              </div>
            )}

            {/* PANEL OPCIONAL DE GEMINI API KEY */}
            {showKeyConfig && (
              <div className="p-3 bg-slate-900 border-b border-slate-800 space-y-2 text-xs flex-shrink-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>API Key de Google Gemini (Opcional)</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowKeyConfig(false)}
                    className="text-slate-400 hover:text-white"
                  >
                    Cerrar
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  Rosco funciona 100% de forma nativa sin clave. Si agregas una clave de Gemini 1.5 Flash, enriquecerá aún más la redacción.
                </p>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={geminiKey}
                    onChange={(e) => setGeminiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="input-field py-1.5 text-xs flex-1"
                  />
                  <button
                    type="button"
                    onClick={handleSaveApiKey}
                    className="btn-primary py-1.5 px-3 text-xs"
                  >
                    Guardar
                  </button>
                </div>
              </div>
            )}

            {/* ÁREA DE MENSAJES Y TARJETAS INTERACTIVAS */}
            <div className="flex-1 overflow-y-auto p-3.5 space-y-4">
              {messages.map((msg) => {
                const isThisSpeaking = speakingMessageId === msg.id
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[90%] rounded-2xl p-3 text-xs sm:text-[13px] space-y-1.5 ${
                        msg.role === 'user'
                          ? 'bg-primary text-white rounded-br-xs shadow-md'
                          : 'bg-slate-900/95 border border-slate-800 text-slate-200 rounded-bl-xs shadow-lg'
                      }`}
                    >
                      {renderFormattedText(msg.content)}

                      {/* TARJETAS INTERACTIVAS DE EQUIPOS / CUSTODIOS / ACTAS */}
                      {msg.cards && msg.cards.length > 0 && (
                        <div className="pt-2 space-y-2">
                          {msg.cards.map((card, cIdx) => (
                            <div
                              key={cIdx}
                              className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800/90 hover:border-slate-700 transition-colors space-y-2"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 min-w-0">
                                  <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 flex-shrink-0">
                                    {getCardIcon(card.card_type)}
                                  </div>
                                  <div className="min-w-0">
                                    <h4 className="font-bold text-white text-xs truncate">
                                      {card.title}
                                    </h4>
                                    {card.subtitle && (
                                      <p className="text-[11px] text-slate-400 font-mono truncate">
                                        {card.subtitle}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                {card.badge_text && (
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex-shrink-0 ${getBadgeClasses(
                                      card.badge_color
                                    )}`}
                                  >
                                    {card.badge_text}
                                  </span>
                                )}
                              </div>

                              {card.details && card.details.length > 0 && (
                                <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-slate-900 text-[11px]">
                                  {card.details.map((d, dIdx) => (
                                    <div key={dIdx} className="truncate">
                                      <span className="text-slate-500">{d.label}: </span>
                                      <span className="text-slate-200 font-semibold">{d.value}</span>
                                    </div>
                                  ))}
                                </div>
                              )}

                              {(card.action_command ||
                                card.link_url ||
                                card.secondary_link_url) && (
                                <div className="flex items-center gap-2 pt-1">
                                  {card.action_command && (
                                    <button
                                      type="button"
                                      disabled={isLoading}
                                      onClick={() => handleSendQuery(card.action_command!)}
                                      className="flex-1 py-1.5 px-2.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                                    >
                                      <span>{card.action_label || 'Ejecutar'}</span>
                                    </button>
                                  )}
                                  {card.link_url && (
                                    <button
                                      type="button"
                                      onClick={() => handleNavigate(card.link_url!)}
                                      className="flex-1 py-1.5 px-2.5 rounded-lg bg-primary/15 hover:bg-primary/25 text-primary border border-primary/30 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                                    >
                                      <span>{card.link_label || 'Ver Detalle'}</span>
                                      <ChevronRight className="w-3 h-3" />
                                    </button>
                                  )}
                                  {card.secondary_link_url && (
                                    <button
                                      type="button"
                                      onClick={() => handleNavigate(card.secondary_link_url!)}
                                      className="py-1.5 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-semibold flex items-center gap-1 transition-colors"
                                    >
                                      <span>{card.secondary_link_label || 'Abrir'}</span>
                                      <ExternalLink className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Pie del mensaje: Hora + Botón Escuchar / Detener Voz */}
                    <div className="flex items-center gap-2 mt-1 px-1">
                      <span className="text-[10px] text-slate-600">{msg.timestamp}</span>
                      {msg.role === 'assistant' && (
                        <button
                          type="button"
                          onClick={() =>
                            isThisSpeaking
                              ? stopSpeaking()
                              : speakText(msg.content, msg.id, true)
                          }
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold transition-colors ${
                            isThisSpeaking
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                              : 'text-slate-400 hover:text-indigo-300 hover:bg-slate-900'
                          }`}
                          title={
                            isThisSpeaking
                              ? 'Detener lectura de voz'
                              : 'Escuchar esta respuesta con la voz de Rosco'
                          }
                        >
                          {isThisSpeaking ? (
                            <>
                              <Square className="w-2.5 h-2.5 fill-current" />
                              <span>Rosco hablando... (Detener)</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3 h-3" />
                              <span>Escuchar</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>

                    {/* Chips de preguntas de seguimiento sugeridas */}
                    {msg.role === 'assistant' &&
                      msg.followUps &&
                      msg.followUps.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2 max-w-[95%]">
                          {msg.followUps.map((fUp, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleSendQuery(fUp)}
                              disabled={isLoading}
                              className="text-left px-2.5 py-1 rounded-full bg-indigo-950/50 hover:bg-indigo-900/60 text-indigo-300 border border-indigo-800/50 text-[11px] font-medium transition-colors flex items-center gap-1"
                            >
                              <Sparkles className="w-3 h-3 text-indigo-400 flex-shrink-0" />
                              <span>{fUp}</span>
                            </button>
                          ))}
                        </div>
                      )}
                  </div>
                )
              })}

              {/* CHIPS DE SUGERENCIAS RÁPIDAS INICIALES */}
              {messages.length === 1 && suggestions.length > 0 && (
                <div className="space-y-2 pt-1">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
                    Preguntas frecuentes en tiempo real:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {suggestions.map((sug, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSendQuery(sug)}
                        disabled={isLoading}
                        className="text-left px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-primary/50 text-xs transition-all flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                        <span>{sug}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Indicador de carga */}
              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/80 border border-slate-800 rounded-2xl px-3.5 py-2.5 w-fit">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 rounded-full bg-primary animate-bounce" />
                    <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
                    <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
                  </div>
                  <span>Rosco está procesando tu solicitud...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* BANNER INTERACTIVO DE ESCUCHA Y RESPUESTA DE MICRÓFONO */}
            {(isPromptingMic || isListening || micStatusMessage) && (
              <div className="px-3.5 py-2.5 bg-indigo-950/90 border-t border-indigo-500/40 text-xs space-y-2 flex-shrink-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                        isListening
                          ? 'bg-rose-500 animate-ping'
                          : isPromptingMic
                          ? 'bg-amber-400 animate-pulse'
                          : 'bg-sky-400'
                      }`}
                    />
                    <span className="text-slate-100 font-semibold leading-snug">
                      {micStatusMessage}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      stopSpeaking()
                      if (recognitionRef.current) {
                        try {
                          recognitionRef.current.stop()
                        } catch {}
                      }
                      setIsListening(false)
                      setIsPromptingMic(false)
                      setMicStatusMessage(null)
                    }}
                    className="text-slate-400 hover:text-white text-[11px] flex-shrink-0"
                  >
                    Cerrar
                  </button>
                </div>

                {liveTranscript && (
                  <p className="text-sky-300 font-mono text-[11px] bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-800">
                    "{liveTranscript}"
                  </p>
                )}

                {needsHttpsForMic && (
                  <button
                    type="button"
                    onClick={handleSwitchToHttps}
                    className="w-full py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Activar Micrófono y Cámara Directos (Modo Seguro HTTPS)</span>
                  </button>
                )}
              </div>
            )}

            {/* BARRA INFERIOR DE ENTRADA: CÁMARA QR + MICRÓFONO + TEXTO */}
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSendQuery(input)
              }}
              className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 flex-shrink-0 safe-bottom"
            >
              {/* Botón Escanear QR / Código de Barras desde el Chat */}
              <button
                type="button"
                onClick={() => setShowScanner(true)}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 transition-colors flex-shrink-0"
                title="Escanear código de barras o QR de un equipo con la cámara"
              >
                <QrCode className="w-4 h-4" />
              </button>

              {/* Botón de Dictado por Voz con Saludo de Rosco */}
              <button
                type="button"
                onClick={toggleVoiceInput}
                className={`p-2.5 rounded-xl border transition-all flex-shrink-0 ${
                  isListening || isPromptingMic
                    ? 'bg-rose-600 text-white border-rose-400 animate-pulse shadow-lg shadow-rose-600/40'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
                title={
                  isListening || isPromptingMic
                    ? 'Rosco te está escuchando... Toca para detener'
                    : 'Hablar con Rosco por micrófono'
                }
              >
                {isListening || isPromptingMic ? (
                  <MicOff className="w-4 h-4" />
                ) : (
                  <Mic className="w-4 h-4" />
                )}
              </button>

              {/* Campo de Texto */}
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  isListening
                    ? 'Habla ahora, Rosco te escucha...'
                    : 'Escribe o habla con Rosco...'
                }
                disabled={isLoading}
                className="flex-1 bg-slate-950 border border-slate-800 focus:border-primary rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 outline-none"
              />

              {/* Botón Enviar */}
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="p-2.5 rounded-xl bg-primary hover:brightness-110 disabled:opacity-40 text-white transition-all flex-shrink-0 shadow-md"
                title="Enviar a Rosco"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL ESCÁNER DE CÁMARA INTEGRADO EN ROSCO */}
      {showScanner && (
        <BarcodeScanner
          onResult={handleScanResult}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  )
}
