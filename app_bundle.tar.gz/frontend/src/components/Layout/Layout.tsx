import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  Package,
  Warehouse,
  ArrowLeftRight,
  Users,
  Settings,
  LogOut,
  QrCode,
  FileText,
  Tag,
  ClipboardCheck,
  BarChart3,
  Sparkles,
  Sun,
  Moon
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { useThemeStore } from '../../store/themeStore'
import { OfflineBanner } from '../ui/OfflineBanner'
import { AiAssistantWidget } from '../Assistant/AiAssistantWidget'
import clsx from 'clsx'

const MAIN_NAV = [
  { to: '/dashboard', label: 'Inicio', icon: LayoutDashboard },
  { to: '/equipment', label: 'Equipos', icon: Package },
  { to: '/scan', label: 'Escáner AR', icon: QrCode },
  { to: '/labels', label: 'Etiquetas', icon: Tag },
  { to: '/audit', label: 'Auditoría', icon: ClipboardCheck },
  { to: '/reports', label: 'Reportes', icon: BarChart3 },
  { to: '/acts', label: 'Actas', icon: FileText },
  { to: '/movements', label: 'Movimientos', icon: ArrowLeftRight },
  { to: '/warehouses', label: 'Almacenes', icon: Warehouse },
]

export function Layout() {
  const { user, logout } = useAuthStore()
  const { config, visualMode, toggleVisualMode } = useThemeStore()
  const navigate = useNavigate()
  const isAdmin = user?.role === 'admin'

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const desktopNavLinkClass = ({ isActive }: { isActive: boolean }) =>
    clsx(
      'flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition-all duration-150',
      isActive
        ? 'bg-primary text-white shadow-lg'
        : 'text-slate-400 hover:bg-slate-800/80 hover:text-white'
    )

  const mobileNavLinkClass = ({ isActive }: { isActive: boolean }) =>
    clsx(
      'flex flex-col items-center justify-center flex-1 py-2 text-xs font-medium transition-colors',
      isActive ? 'text-primary' : 'text-slate-500 hover:text-slate-300'
    )

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden print:h-auto print:overflow-visible print:bg-white print:block">
      {/* Sidebar de escritorio */}
      <aside className="hidden lg:flex flex-col w-64 bg-slate-900/80 border-r border-slate-800 backdrop-blur-md flex-shrink-0 print:hidden">
        {/* Cabecera con Marca Blanca (+50% tamaño con logotuandamio.png) */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3">
          <img
            src="/logotuandamio.png"
            alt={config?.name ?? 'Grupo Tu Andamio'}
            className="w-14 h-14 object-contain rounded-xl bg-white p-1 shadow-sm border border-slate-200/50 flex-shrink-0"
          />
          <div className="min-w-0">
            <h1 className="font-bold text-white text-sm truncate">{config?.name ?? 'Grupo Tu Andamio'}</h1>
            <p className="text-xs text-slate-500">Gestión Multi-Almacén</p>
          </div>
        </div>

        {/* Navegación Principal */}
        <nav className="flex-1 p-3 space-y-1.5 overflow-y-auto">
          {MAIN_NAV.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={desktopNavLinkClass}>
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span>{label}</span>
            </NavLink>
          ))}

          {/* Acceso directo a Rosco IA en Escritorio */}
          <button
            type="button"
            onClick={() => window.dispatchEvent(new Event('open-ai-assistant'))}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-600/20 to-violet-600/20 text-indigo-300 hover:text-white hover:from-indigo-600/30 hover:to-violet-600/30 border border-indigo-500/30 transition-all duration-150 mt-2"
          >
            <div className="flex items-center gap-3">
              <img
                src="/logoia.png"
                alt="Rosco IA"
                className="w-5 h-5 rounded-full bg-white p-0.5 object-contain flex-shrink-0"
              />
              <span>Rosco IA</span>
            </div>
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          </button>

          {isAdmin && (
            <>
              <div className="pt-4 pb-1 px-4">
                <span className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">
                  Administración
                </span>
              </div>
              <NavLink to="/users" className={desktopNavLinkClass}>
                <Users className="w-4 h-4 flex-shrink-0" />
                <span>Usuarios</span>
              </NavLink>
              <NavLink to="/settings" className={desktopNavLinkClass}>
                <Settings className="w-4 h-4 flex-shrink-0" />
                <span>Marca Blanca</span>
              </NavLink>
            </>
          )}
        </nav>

        {/* Perfil del operador / admin, Selector de Modo Visual y Cerrar Sesión */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40 space-y-2">
          <div className="flex items-center gap-3 mb-2">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-xs uppercase shadow-inner"
              style={{ background: 'var(--color-primary)' }}
            >
              {user?.full_name?.charAt(0) ?? 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-white truncate">{user?.full_name}</p>
              <p className="text-xs text-slate-400 capitalize">{user?.role === 'admin' ? 'Administrador' : 'Operador'}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={toggleVisualMode}
            className="flex items-center justify-between w-full px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/60 text-xs font-semibold transition-colors"
            title="Alternar entre Modo Claro Corporativo (Azul/Blanco) y Modo Oscuro"
          >
            <div className="flex items-center gap-2">
              {visualMode === 'light' ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-sky-400" />
              )}
              <span>{visualMode === 'light' ? 'Modo Claro (Azul/Blanco)' : 'Modo Oscuro'}</span>
            </div>
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-3 py-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-950/20 text-xs font-semibold transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Cerrar sesión</span>
          </button>
        </div>
      </aside>

      {/* Contenedor Principal */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden print:h-auto print:overflow-visible print:block">
        <div className="print:hidden">
          <OfflineBanner />
        </div>
        {/* Cabecera Móvil */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800 safe-top flex-shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <img
              src="/logotuandamio.png"
              alt={config?.name ?? 'Grupo Tu Andamio'}
              className="w-11 h-11 object-contain rounded-lg bg-white p-0.5 shadow-xs border border-slate-200/50 flex-shrink-0"
            />
            <span className="font-bold text-white text-sm truncate">{config?.name ?? 'Grupo Tu Andamio'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleVisualMode}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
              title={visualMode === 'light' ? 'Cambiar a Modo Oscuro' : 'Cambiar a Modo Claro (Azul/Blanco)'}
            >
              {visualMode === 'light' ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-sky-400" />
              )}
            </button>
            <button
              type="button"
              onClick={() => window.dispatchEvent(new Event('open-ai-assistant'))}
              className="p-1.5 px-2.5 rounded-xl bg-gradient-to-r from-indigo-600/30 to-violet-600/30 text-indigo-300 border border-indigo-500/40 flex items-center gap-1.5 text-xs font-bold"
              title="Abrir a Rosco IA"
            >
              <img
                src="/logoia.png"
                alt="Rosco"
                className="w-5 h-5 rounded-full bg-white p-0.5 object-contain"
              />
              <span>Rosco</span>
            </button>
            <NavLink
              to="/scan"
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
              title="Escáner AR"
            >
              <QrCode className="w-4 h-4" />
            </NavLink>
            <button
              onClick={handleLogout}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400"
              title="Salir"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Vista activa */}
        <main className="flex-1 overflow-y-auto pb-20 lg:pb-6 print:overflow-visible print:p-0">
          <Outlet />
        </main>

        {/* Copiloto IA Flotante (Móvil y Escritorio) */}
        <AiAssistantWidget />

        {/* Barra de Navegación Inferior (Móvil / PWA) */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 flex items-center justify-around safe-bottom z-30 print:hidden">
          {MAIN_NAV.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={mobileNavLinkClass}>
              <Icon className="w-5 h-5 mb-1" />
              <span>{label}</span>
            </NavLink>
          ))}
          {isAdmin && (
            <NavLink to="/settings" className={mobileNavLinkClass}>
              <Settings className="w-5 h-5 mb-1" />
              <span>Ajustes</span>
            </NavLink>
          )}
        </nav>
      </div>
    </div>
  )
}

