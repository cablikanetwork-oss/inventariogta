import { useRef, useEffect, useState, forwardRef, useImperativeHandle } from 'react'
import { Eraser } from 'lucide-react'

export interface SignaturePadRef {
  getSignatureDataUrl: () => string | null
  clear: () => void
  isEmpty: () => boolean
}

interface Props {
  width?: number
  height?: number
  onChange?: (hasSignature: boolean) => void
}

export const SignaturePad = forwardRef<SignaturePadRef, Props>(({ width = 450, height = 150, onChange }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [hasContent, setHasContent] = useState(false)

  useImperativeHandle(ref, () => ({
    getSignatureDataUrl: () => {
      if (!hasContent || !canvasRef.current) return null
      return canvasRef.current.toDataURL('image/png')
    },
    clear: () => {
      clearCanvas()
    },
    isEmpty: () => !hasContent,
  }))

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    setHasContent(false)
    onChange?.(false)
  }

  const getCoordinates = (e: MouseEvent | TouchEvent) => {
    const canvas = canvasRef.current
    if (!canvas) return { x: 0, y: 0 }
    const rect = canvas.getBoundingClientRect()
    const scaleX = canvas.width / rect.width
    const scaleY = canvas.height / rect.height

    if ('touches' in e && e.touches.length > 0) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      }
    }
    const mouseEvent = e as MouseEvent
    return {
      x: (mouseEvent.clientX - rect.left) * scaleX,
      y: (mouseEvent.clientY - rect.top) * scaleY,
    }
  }

  const startDrawing = (e: any) => {
    e.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const { x, y } = getCoordinates(e)
    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.strokeStyle = '#0f172a' // Tinta oscura formal
    ctx.lineWidth = 2.5
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    setIsDrawing(true)
  }

  const draw = (e: any) => {
    if (!isDrawing) return
    e.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const { x, y } = getCoordinates(e)
    ctx.lineTo(x, y)
    ctx.stroke()
    if (!hasContent) {
      setHasContent(true)
      onChange?.(true)
    }
  }

  const stopDrawing = () => {
    setIsDrawing(false)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Prevenir scrolling al dibujar en móviles táctiles
    const preventScroll = (e: TouchEvent) => {
      if (e.target === canvas) {
        e.preventDefault()
      }
    }

    canvas.addEventListener('touchstart', preventScroll, { passive: false })
    canvas.addEventListener('touchmove', preventScroll, { passive: false })

    return () => {
      canvas.removeEventListener('touchstart', preventScroll)
      canvas.removeEventListener('touchmove', preventScroll)
    }
  }, [])

  return (
    <div className="space-y-1.5">
      <div className="relative border-2 border-dashed border-slate-700 hover:border-primary/60 rounded-xl overflow-hidden bg-white/95 transition-colors">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className="w-full h-36 cursor-crosshair touch-none"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />
        {!hasContent && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-slate-400 text-xs">
            ✍️ Firma del Trabajador (Dibuja aquí con el dedo o mouse)
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <button
          type="button"
          onClick={clearCanvas}
          className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors px-2 py-1 rounded"
        >
          <Eraser className="w-3.5 h-3.5" />
          <span>Limpiar Firma</span>
        </button>
      </div>
    </div>
  )
})

