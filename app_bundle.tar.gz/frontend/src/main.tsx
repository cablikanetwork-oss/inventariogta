import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// Forzar actualización inmediata del Service Worker para evitar que versiones en caché redirijan rutas nuevas
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then((registrations) => {
    for (const reg of registrations) {
      reg.update().catch(() => {})
      if (reg.waiting) {
        reg.waiting.postMessage({ type: 'SKIP_WAITING' })
      }
    }
  })
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
