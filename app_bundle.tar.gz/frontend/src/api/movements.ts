import apiClient from './client'

export type MovementType = 'entry' | 'exit' | 'transfer' | 'return' | 'maintenance'

export interface Movement {
  id: string
  type: MovementType
  equipment_id: string
  equipment: { id: string; serial_number: string; name: string } | null
  from_warehouse_id: string | null
  from_warehouse: { id: string; name: string } | null
  to_warehouse_id: string | null
  to_warehouse: { id: string; name: string } | null
  performed_by: string
  performed_by_user: { id: string; username: string; full_name: string } | null
  assigned_to: string | null
  notes: string | null
  created_at: string
}

export interface MovementCreate {
  type: MovementType
  equipment_id: string
  from_warehouse_id?: string
  to_warehouse_id?: string
  assigned_to?: string
  notes?: string
}

export const movementsApi = {
  list: async (filters?: {
    equipment_id?: string
    warehouse_id?: string
    movement_type?: string
    limit?: number
  }): Promise<Movement[]> => {
    const response = await apiClient.get<Movement[]>('/movements/', { params: filters })
    return response.data
  },
  create: async (data: MovementCreate): Promise<Movement> => {
    const response = await apiClient.post<Movement>('/movements/', data)
    return response.data
  },
  get: async (id: string): Promise<Movement> => {
    const response = await apiClient.get<Movement>(`/movements/${id}`)
    return response.data
  },
}

