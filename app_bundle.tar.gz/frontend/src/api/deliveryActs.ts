import { apiClient } from './client'

export interface DeliveryActItem {
  id: string
  act_id: string
  equipment_id?: string | null
  equipment_name: string
  equipment_type: string
  brand?: string | null
  model?: string | null
  serial_number: string
  specs?: string | null
}

export interface DeliveryAct {
  id: string
  act_number: string
  act_type: string
  city: string
  recipient_name: string
  recipient_id_card: string
  recipient_position?: string | null
  recipient_department?: string | null
  recipient_signature?: string | null
  delivered_by_user_id?: string | null
  delivered_by_name: string
  delivered_by_position?: string | null
  delivered_by_id_card?: string | null
  terms_clause: string
  notes?: string | null
  accessories?: string | null
  scanned_document_url?: string | null
  scanned_at?: string | null
  evidence_photos_list?: string[]
  created_at: string
  updated_at: string
  items: DeliveryActItem[]
}

export interface DeliveryActItemCreate {
  equipment_id?: string
  equipment_name: string
  equipment_type?: string
  brand?: string
  model?: string
  serial_number: string
  specs?: string
}

export interface DeliveryActCreate {
  act_type?: string
  city?: string
  recipient_name: string
  recipient_id_card: string
  recipient_position?: string
  recipient_department?: string
  recipient_signature?: string
  delivered_by_name?: string
  delivered_by_position?: string
  delivered_by_id_card?: string
  terms_clause?: string
  notes?: string
  accessories?: string
  evidence_photos?: string
  items: DeliveryActItemCreate[]
  auto_assign_equipment?: boolean
}

export interface DeliveryActUpdate {
  act_type?: string
  city?: string
  recipient_name?: string
  recipient_id_card?: string
  recipient_position?: string
  recipient_department?: string
  recipient_signature?: string
  delivered_by_name?: string
  delivered_by_position?: string
  delivered_by_id_card?: string
  terms_clause?: string
  notes?: string
  accessories?: string
  items?: DeliveryActItemCreate[]
  auto_assign_equipment?: boolean
}

export interface EmployeeSolvencyEquipment {
  equipment_id?: string | null
  equipment_name: string
  serial_number: string
  brand?: string | null
  model?: string | null
  specs?: string | null
  act_number: string
  act_date?: string | null
}

export interface EmployeeSolvencyItem {
  recipient_name: string
  recipient_id_card: string
  recipient_position?: string | null
  recipient_department?: string | null
  active_count: number
  returned_count: number
  is_solvent: boolean
  active_equipment: EmployeeSolvencyEquipment[]
  returned_equipment: EmployeeSolvencyEquipment[]
  acts: {
    id: string
    act_number: string
    act_type: string
    created_at: string
    scanned_document_url?: string | null
    items_count?: number
  }[]
}

export const deliveryActsApi = {
  list: async (params?: { search?: string; act_type?: string }) => {
    const response = await apiClient.get<DeliveryAct[]>('/delivery-acts/', { params })
    return response.data
  },

  get: async (id: string) => {
    const response = await apiClient.get<DeliveryAct>(`/delivery-acts/${id}`)
    return response.data
  },

  create: async (data: DeliveryActCreate) => {
    const response = await apiClient.post<DeliveryAct>('/delivery-acts/', data)
    return response.data
  },

  update: async (id: string, data: DeliveryActUpdate) => {
    const response = await apiClient.put<DeliveryAct>(`/delivery-acts/${id}`, data)
    return response.data
  },

  delete: async (id: string) => {
    await apiClient.delete(`/delivery-acts/${id}`)
  },

  uploadScanFile: async (actId: string, file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    const response = await apiClient.post<DeliveryAct>(
      `/delivery-acts/${actId}/upload-scan`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
    return response.data
  },

  uploadScanBase64: async (actId: string, dataUrl: string) => {
    const response = await apiClient.post<DeliveryAct>(
      `/delivery-acts/${actId}/upload-scan-base64`,
      { data_url: dataUrl }
    )
    return response.data
  },

  uploadEvidencePhoto: async (actId: string, file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    const response = await apiClient.post<DeliveryAct>(
      `/delivery-acts/${actId}/upload-evidence`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
    return response.data
  },

  deleteEvidencePhoto: async (actId: string, photoIdx: number) => {
    const response = await apiClient.delete<DeliveryAct>(
      `/delivery-acts/${actId}/evidence/${photoIdx}`
    )
    return response.data
  },

  getEmployeesSolvency: async (search?: string) => {
    const response = await apiClient.get<EmployeeSolvencyItem[]>(
      '/delivery-acts/employees/solvency',
      { params: search ? { search } : undefined }
    )
    return response.data
  },

  publicVerifyAct: async (identifier: string): Promise<PublicActVerificationResponse> => {
    const response = await apiClient.get<PublicActVerificationResponse>(
      `/delivery-acts/public-verify/${encodeURIComponent(identifier.trim())}`
    )
    return response.data
  },
}

export interface PublicActVerificationItem {
  id?: string
  equipment_id?: string | null
  equipment_name: string
  equipment_type?: string
  brand?: string | null
  model?: string | null
  serial_number: string
  specs?: string | null
  act_number?: string
  live_status: string
  live_assigned_to?: string | null
  currently_assigned_to_recipient: boolean
}

export interface PublicActVerificationResponse {
  document_kind: 'delivery_act' | 'solvency_certificate' | string
  is_authentic: boolean
  verification_hash: string
  verified_at: string
  validity_status:
    | 'VALID_ACTIVE_ASSIGNMENT'
    | 'VALID_RETURN_SOLVENCY'
    | 'EXPIRED_OR_RETURNED_ASSIGNMENT'
    | 'ACTIVE_CUSTODY_PENDING'
    | string
  security_verdict: string
  allow_exit: boolean
  act: {
    id: string
    act_number: string
    act_type: string
    city: string
    recipient_name: string
    recipient_id_card: string
    recipient_position?: string | null
    recipient_department?: string | null
    recipient_signature?: string | null
    delivered_by_name: string
    delivered_by_position: string
    delivered_by_id_card: string
    accessories?: string | null
    scanned_document_url?: string | null
    scanned_at?: string | null
    evidence_photos_list?: string[]
    created_at: string
    items: PublicActVerificationItem[]
  }
  company: {
    name: string
    logo_url?: string | null
    primary_color?: string
  }
}
