import apiClient from './client'
import type { User } from './auth'

export interface UserCreate {
  username: string
  full_name: string
  pin: string
  role?: 'admin' | 'user'
  id_card?: string
  recovery_key?: string
}

export interface UserUpdate {
  full_name?: string
  pin?: string
  role?: 'admin' | 'user'
  is_active?: boolean
  id_card?: string
  recovery_key?: string
}

export const usersApi = {
  list: async (): Promise<User[]> => {
    const response = await apiClient.get<User[]>('/users/')
    return response.data
  },
  get: async (id: string): Promise<User> => {
    const response = await apiClient.get<User>(`/users/${id}`)
    return response.data
  },
  create: async (data: UserCreate): Promise<User> => {
    const response = await apiClient.post<User>('/users/', data)
    return response.data
  },
  update: async (id: string, data: UserUpdate): Promise<User> => {
    const response = await apiClient.put<User>(`/users/${id}`, data)
    return response.data
  },
  delete: async (id: string): Promise<void> => {
    await apiClient.delete(`/users/${id}`)
  },
}

