import { apiClient } from './client'

export interface AssistantCardDetail {
  label: string
  value: string
}

export interface AssistantActionCard {
  card_type: 'equipment' | 'person' | 'warehouse' | 'act' | 'stats' | string
  title: string
  subtitle?: string | null
  badge_text?: string | null
  badge_color?: 'emerald' | 'sky' | 'amber' | 'rose' | 'slate' | string | null
  details: AssistantCardDetail[]
  link_url?: string | null
  link_label?: string | null
  secondary_link_url?: string | null
  secondary_link_label?: string | null
  action_command?: string | null
  action_label?: string | null
}

export interface AssistantQueryResponse {
  answer: string
  intent: string
  cards: AssistantActionCard[]
  follow_up_suggestions: string[]
  engine: string
  action_performed?: boolean
}

export interface AssistantSuggestionsResponse {
  suggestions: string[]
  quick_stats: {
    total: number
    available: number
    assigned: number
    maintenance: number
    warehouses: number
    acts: number
  }
}

export interface ChatHistoryItem {
  role: 'user' | 'assistant'
  content: string
}

export const assistantApi = {
  getSuggestions: async (): Promise<AssistantSuggestionsResponse> => {
    const response = await apiClient.get<AssistantSuggestionsResponse>('/assistant/suggestions')
    return response.data
  },

  query: async (params: {
    query: string
    scanned_code?: string
    history?: ChatHistoryItem[]
    gemini_api_key?: string
  }): Promise<AssistantQueryResponse> => {
    const response = await apiClient.post<AssistantQueryResponse>('/assistant/query', params)
    return response.data
  },

  synthesizeSpeech: async (params: {
    text: string
    voice?: string
    rate?: string
  }): Promise<Blob> => {
    const response = await apiClient.post('/assistant/tts', params, {
      responseType: 'blob',
    })
    return response.data
  },
}
