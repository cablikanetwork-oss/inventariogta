import apiClient from './client'

export interface CompanyConfig {
  id: string
  name: string
  logo_url: string | null
  primary_color: string
  secondary_color: string
  accent_color: string
  updated_at: string
}

export const companyApi = {
  getConfig: async (): Promise<CompanyConfig> => {
    const response = await apiClient.get<CompanyConfig>('/company/config')
    return response.data
  },
  updateConfig: async (data: Partial<CompanyConfig>): Promise<CompanyConfig> => {
    const response = await apiClient.put<CompanyConfig>('/company/config', data)
    return response.data
  },
  uploadLogo: async (file: File): Promise<CompanyConfig> => {
    const formData = new FormData()
    formData.append('file', file)
    const response = await apiClient.post<CompanyConfig>('/company/config/logo', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data
  },
  deleteLogo: async (): Promise<CompanyConfig> => {
    const response = await apiClient.delete<CompanyConfig>('/company/config/logo')
    return response.data
  },
}
