import apiClient from './client'

export interface Warehouse {
  id: string
  name: string
  location: string | null
  description: string | null
  is_active: boolean
  parent_id?: string | null
  parent_name?: string | null
  created_at: string
  equipment_count: number
  total_equipment_count: number
  sub_warehouses_count: number
}

export interface WarehouseCreate {
  name: string
  location?: string
  description?: string
  parent_id?: string | null
}

export const warehousesApi = {
  list: async (): Promise<Warehouse[]> => {
    const response = await apiClient.get<Warehouse[]>('/warehouses/')
    return response.data
  },
  get: async (id: string): Promise<Warehouse> => {
    const response = await apiClient.get<Warehouse>(`/warehouses/${id}`)
    return response.data
  },
  create: async (data: WarehouseCreate): Promise<Warehouse> => {
    const response = await apiClient.post<Warehouse>('/warehouses/', data)
    return response.data
  },
  update: async (id: string, data: Partial<WarehouseCreate> & { is_active?: boolean }): Promise<Warehouse> => {
    const response = await apiClient.put<Warehouse>(`/warehouses/${id}`, data)
    return response.data
  },
  delete: async (id: string): Promise<{ message: string; id: string }> => {
    const response = await apiClient.delete<{ message: string; id: string }>(`/warehouses/${id}`)
    return response.data
  },
}
