import apiClient from './client'

export interface BackupStatusResponse {
  sync_key: string
  cloud_endpoint_path: string
  webhook_url: string
  summary: {
    total_active_equipment: number
    total_warehouses: number
    total_delivery_acts: number
    total_movements: number
  }
  generated_at: string
}

export const backupApi = {
  getStatus: async (): Promise<BackupStatusResponse> => {
    const response = await apiClient.get<BackupStatusResponse>('/backup/status')
    return response.data
  },
  saveWebhookConfig: async (webhookUrl: string): Promise<{ status: string; webhook_url: string }> => {
    const response = await apiClient.post('/backup/webhook-config', { webhook_url: webhookUrl })
    return response.data
  },
  pushToGoogleNow: async (): Promise<{ status: string; message: string; google_response?: string }> => {
    const response = await apiClient.post('/backup/push-to-google')
    return response.data
  },
  downloadJsonBackup: async (): Promise<void> => {
    const response = await apiClient.get('/backup/download-json', { responseType: 'blob' })
    const blob = new Blob([response.data], { type: 'application/json' })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    const dateStr = new Date().toISOString().slice(0, 10)
    link.href = url
    link.setAttribute('download', `Backup_InventarioGTA_${dateStr}.json`)
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.URL.revokeObjectURL(url)
  },
}
