import apiClient from './client'
import { type Equipment } from './equipment'

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface AuditSession {
  id: string
  warehouse_id: string
  warehouse_name: string
  status: 'open' | 'closed'
  created_at: string
  closed_at: string | null
  notes: string | null
  expected_total?: number
  scanned_count?: number
  creator_name?: string
}

export interface AuditScan {
  id: string
  session_id: string
  serial_number: string
  scanned_at: string
  equipment?: Equipment | null
  is_duplicate: boolean
  is_expected: boolean
}

export interface AuditScanResult {
  found: boolean
  is_expected: boolean
  is_duplicate: boolean
  scanned_serial?: string
  message?: string
  equipment?: Equipment
  scan?: AuditScan
}

export interface AuditReport {
  session_id?: string
  warehouse_name?: string
  expected_total: number
  found_count: number
  missing_count: number
  extra_count: number
  missing_items?: Equipment[]
  missing?: Equipment[]
  matched_items?: Equipment[]
  found?: any[]
  extra_items?: any[]
  extra?: any[]
}

// ─── API ──────────────────────────────────────────────────────────────────────

export const auditApi = {
  /**
   * Crear nueva sesión de auditoría para un almacén.
   * POST /audit/sessions
   */
  createSession: async (warehouseId: string, notes?: string): Promise<AuditSession> => {
    const response = await apiClient.post<AuditSession>('/audit/sessions', {
      warehouse_id: warehouseId,
      notes: notes ?? null,
    })
    return response.data
  },

  /**
   * Listar todas las sesiones de auditoría.
   * GET /audit/sessions
   */
  listSessions: async (): Promise<AuditSession[]> => {
    const response = await apiClient.get<AuditSession[]>('/audit/sessions')
    return response.data
  },

  /**
   * Obtener detalle de una sesión.
   * GET /audit/sessions/{id}
   */
  getSession: async (id: string): Promise<AuditSession> => {
    const response = await apiClient.get<AuditSession>(`/audit/sessions/${id}`)
    return response.data
  },

  /**
   * Registrar escaneo de un serial en la sesión activa.
   * POST /audit/sessions/{id}/scan
   */
  scanEquipment: async (sessionId: string, serialNumber: string): Promise<AuditScanResult> => {
    const response = await apiClient.post<AuditScanResult>(`/audit/sessions/${sessionId}/scan`, {
      serial_number: serialNumber,
    })
    return response.data
  },

  /**
   * Cerrar la sesión de auditoría.
   * POST /audit/sessions/{id}/close
   */
  closeSession: async (id: string): Promise<AuditSession> => {
    const response = await apiClient.post<AuditSession>(`/audit/sessions/${id}/close`)
    return response.data
  },

  /**
   * Obtener el reporte de discrepancias de una sesión cerrada.
   * GET /audit/sessions/{id}/report
   */
  getReport: async (id: string): Promise<AuditReport> => {
    const response = await apiClient.get<AuditReport>(`/audit/sessions/${id}/report`)
    return response.data
  },
}
