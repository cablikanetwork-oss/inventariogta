import axios from 'axios'
import { cacheEquipment, getCachedEquipment, cacheWarehouses, getCachedWarehouses } from '../services/offlineDb'

const API_BASE = '/api/v1'

export const apiClient = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Adjuntar token JWT en peticiones autenticadas
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// ─── Interceptor de respuesta: cache offline + fallback ──────────────────────
apiClient.interceptors.response.use(
  async (response) => {
    // Poblar cache offline solo para listados (GET de colecciones)
    const url = response.config.url ?? ''
    const method = (response.config.method ?? '').toLowerCase()

    if (method === 'get' && Array.isArray(response.data) && response.data.length > 0) {
      // Solo para los endpoints de listado, sin IDs específicos al final
      if (/^\/equipment\/?(\?.*)?$/.test(url) || url === '/equipment/') {
        cacheEquipment(response.data).catch(() => {/* no bloqueante */})
      } else if (/^\/warehouses\/?(\?.*)?$/.test(url) || url === '/warehouses/') {
        cacheWarehouses(response.data).catch(() => {/* no bloqueante */})
      }
    }

    return response
  },
  async (error) => {
    // 401 → logout
    if (error.response?.status === 401 && window.location.pathname !== '/login') {
      localStorage.removeItem('access_token')
      localStorage.removeItem('user')
      window.location.href = '/login'
      return Promise.reject(error)
    }

    // Error de red (sin respuesta del servidor)
    if (!error.response) {
      const url: string = error.config?.url ?? ''
      const method = (error.config?.method ?? '').toLowerCase()

      if (method === 'get') {
        // Intentar servir desde cache
        if (/^\/equipment\/?(\?.*)?$/.test(url) || url === '/equipment/') {
          const cached = await getCachedEquipment()
          if (cached.length > 0) {
            // Retornar como respuesta simulada
            return { data: cached, status: 200, statusText: 'OK (cached)', config: error.config, headers: {}, request: null }
          }
        } else if (/^\/warehouses\/?(\?.*)?$/.test(url) || url === '/warehouses/') {
          const cached = await getCachedWarehouses()
          if (cached.length > 0) {
            return { data: cached, status: 200, statusText: 'OK (cached)', config: error.config, headers: {}, request: null }
          }
        }
      }
    }

    return Promise.reject(error)
  }
)

export default apiClient
