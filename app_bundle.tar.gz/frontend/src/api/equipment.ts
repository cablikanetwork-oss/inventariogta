import apiClient from './client'

export type EquipmentCategory =
  | 'laptop'
  | 'desktop'
  | 'monitor'
  | 'keyboard'
  | 'mouse'
  | 'switch'
  | 'router'
  | 'server'
  | 'phone'
  | 'tablet'
  | 'printer'
  | 'ups'
  | 'cable'
  | 'other'
  | (string & {})

export interface CatalogItem {
  id?: string
  item_type: 'brand' | 'category' | string
  value: string
  label: string
  group_name?: string | null
  is_custom?: boolean
}

export interface EquipmentCatalogsResponse {
  brands: CatalogItem[]
  categories: CatalogItem[]
}

export const DEFAULT_BRAND_CATALOG: CatalogItem[] = [
  // Computación y Laptops
  { item_type: 'brand', value: 'Lenovo', label: 'Lenovo', group_name: 'Computación' },
  { item_type: 'brand', value: 'HP', label: 'HP', group_name: 'Computación' },
  { item_type: 'brand', value: 'Dell', label: 'Dell', group_name: 'Computación' },
  { item_type: 'brand', value: 'ASUS', label: 'ASUS', group_name: 'Computación' },
  { item_type: 'brand', value: 'Acer', label: 'Acer', group_name: 'Computación' },
  { item_type: 'brand', value: 'MSI', label: 'MSI', group_name: 'Computación' },
  { item_type: 'brand', value: 'Apple', label: 'Apple', group_name: 'Computación' },
  { item_type: 'brand', value: 'Samsung', label: 'Samsung', group_name: 'Computación / Móvil' },
  { item_type: 'brand', value: 'Microsoft', label: 'Microsoft', group_name: 'Computación' },
  { item_type: 'brand', value: 'LG', label: 'LG', group_name: 'Monitores / TV' },
  { item_type: 'brand', value: 'Huawei', label: 'Huawei', group_name: 'Móvil / Redes' },
  { item_type: 'brand', value: 'Xiaomi', label: 'Xiaomi', group_name: 'Móvil' },
  { item_type: 'brand', value: 'Gigabyte', label: 'Gigabyte', group_name: 'Computación' },
  { item_type: 'brand', value: 'Toshiba', label: 'Toshiba', group_name: 'Computación' },
  { item_type: 'brand', value: 'Sony', label: 'Sony', group_name: 'Audio / Video' },
  // Redes, Telecom y Seguridad
  { item_type: 'brand', value: 'Ubiquiti', label: 'Ubiquiti', group_name: 'Redes' },
  { item_type: 'brand', value: 'Cisco', label: 'Cisco', group_name: 'Redes' },
  { item_type: 'brand', value: 'MikroTik', label: 'MikroTik', group_name: 'Redes' },
  { item_type: 'brand', value: 'TP-Link', label: 'TP-Link', group_name: 'Redes' },
  { item_type: 'brand', value: 'Fortinet', label: 'Fortinet', group_name: 'Redes' },
  { item_type: 'brand', value: 'Aruba', label: 'Aruba', group_name: 'Redes' },
  { item_type: 'brand', value: 'D-Link', label: 'D-Link', group_name: 'Redes' },
  { item_type: 'brand', value: 'Starlink', label: 'Starlink', group_name: 'Redes' },
  { item_type: 'brand', value: 'Hikvision', label: 'Hikvision', group_name: 'Seguridad / CCTV' },
  { item_type: 'brand', value: 'Dahua', label: 'Dahua', group_name: 'Seguridad / CCTV' },
  { item_type: 'brand', value: 'Grandstream', label: 'Grandstream', group_name: 'Telefonía IP' },
  { item_type: 'brand', value: 'Yealink', label: 'Yealink', group_name: 'Telefonía IP' },
  { item_type: 'brand', value: 'Motorola', label: 'Motorola', group_name: 'Móvil / Radios' },
  { item_type: 'brand', value: 'Zebra', label: 'Zebra', group_name: 'Escáneres / Impresión' },
  // Impresión, Periféricos y Energía
  { item_type: 'brand', value: 'Epson', label: 'Epson', group_name: 'Impresión / Proyección' },
  { item_type: 'brand', value: 'Brother', label: 'Brother', group_name: 'Impresión' },
  { item_type: 'brand', value: 'Canon', label: 'Canon', group_name: 'Impresión' },
  { item_type: 'brand', value: 'Kyocera', label: 'Kyocera', group_name: 'Impresión' },
  { item_type: 'brand', value: 'Ricoh', label: 'Ricoh', group_name: 'Impresión' },
  { item_type: 'brand', value: 'Logitech', label: 'Logitech', group_name: 'Periféricos' },
  { item_type: 'brand', value: 'Jabra', label: 'Jabra', group_name: 'Audio / Headsets' },
  { item_type: 'brand', value: 'BenQ', label: 'BenQ', group_name: 'Monitores / Proyección' },
  { item_type: 'brand', value: 'ViewSonic', label: 'ViewSonic', group_name: 'Monitores / Proyección' },
  { item_type: 'brand', value: 'APC', label: 'APC', group_name: 'Energía / UPS' },
  { item_type: 'brand', value: 'Forza', label: 'Forza', group_name: 'Energía / UPS' },
  { item_type: 'brand', value: 'CyberPower', label: 'CyberPower', group_name: 'Energía / UPS' },
  { item_type: 'brand', value: 'Tripp Lite', label: 'Tripp Lite', group_name: 'Energía / UPS' },
  { item_type: 'brand', value: 'Kingston', label: 'Kingston', group_name: 'Almacenamiento' },
  { item_type: 'brand', value: 'Crucial', label: 'Crucial', group_name: 'Almacenamiento' },
  { item_type: 'brand', value: 'Western Digital', label: 'Western Digital', group_name: 'Almacenamiento' },
  { item_type: 'brand', value: 'Seagate', label: 'Seagate', group_name: 'Almacenamiento' },
]

export const DEFAULT_CATEGORY_CATALOG: CatalogItem[] = [
  { item_type: 'category', value: 'laptop', label: 'Laptop / Portátil' },
  { item_type: 'category', value: 'desktop', label: 'Computador Escritorio' },
  { item_type: 'category', value: 'monitor', label: 'Monitor / Pantalla' },
  { item_type: 'category', value: 'phone', label: 'Teléfono Móvil' },
  { item_type: 'category', value: 'tablet', label: 'Tablet' },
  { item_type: 'category', value: 'printer', label: 'Impresora / Multifuncional' },
  { item_type: 'category', value: 'ups', label: 'UPS / Regulador' },
  { item_type: 'category', value: 'switch', label: 'Switch de Red' },
  { item_type: 'category', value: 'router', label: 'Router / Access Point' },
  { item_type: 'category', value: 'server', label: 'Servidor / NAS' },
  { item_type: 'category', value: 'keyboard', label: 'Teclado' },
  { item_type: 'category', value: 'mouse', label: 'Mouse' },
  { item_type: 'category', value: 'cable', label: 'Cableado / Cargador / Adaptador' },
  { item_type: 'category', value: 'other', label: 'Otro' },
]

export function getCategoryLabel(category: string | null | undefined): string {
  if (!category) return 'Otro'
  const found = DEFAULT_CATEGORY_CATALOG.find(
    (c) => c.value.toLowerCase() === category.toLowerCase()
  )
  return found ? found.label : category
}

export type EquipmentStatus = 'available' | 'assigned' | 'maintenance' | 'retired' | 'lost'

export interface Equipment {
  id: string
  serial_number: string
  barcode: string | null
  name: string
  brand: string | null
  model: string | null
  category: EquipmentCategory
  status: EquipmentStatus
  current_warehouse_id: string | null
  current_warehouse: { id: string; name: string } | null
  assigned_to: string | null
  notes: string | null
  created_at: string
  updated_at: string
  // Campos de adquisición y garantía
  purchase_date: string | null       // date ISO
  purchase_price: number | null
  expected_lifespan_years: number    // default 3
  warranty_expires: string | null    // date ISO
}

export interface EquipmentCreate {
  serial_number: string
  barcode?: string
  name: string
  brand?: string
  model?: string
  category?: EquipmentCategory
  status?: EquipmentStatus
  current_warehouse_id?: string
  assigned_to?: string
  notes?: string
  // Adquisición y garantía (opcionales)
  purchase_date?: string | null
  purchase_price?: number | null
  expected_lifespan_years?: number
  warranty_expires?: string | null
}

export interface EquipmentBatchCreate {
  serial_numbers: string[]
  name: string
  brand?: string
  model?: string
  category?: EquipmentCategory
  status?: EquipmentStatus
  current_warehouse_id?: string
  assigned_to?: string
  notes?: string
  purchase_date?: string | null
  purchase_price?: number | null
  expected_lifespan_years?: number
  warranty_expires?: string | null
}

export interface EquipmentBatchResponse {
  created_count: number
  skipped_serials: string[]
  items: Equipment[]
}

export interface EquipmentUpdate {
  serial_number?: string
  barcode?: string
  name?: string
  brand?: string
  model?: string
  category?: EquipmentCategory
  status?: EquipmentStatus
  current_warehouse_id?: string
  assigned_to?: string
  notes?: string
  // Adquisición y garantía (opcionales)
  purchase_date?: string | null
  purchase_price?: number | null
  expected_lifespan_years?: number
  warranty_expires?: string | null
}

export interface EquipmentFilters {
  warehouse_id?: string
  search?: string
  category?: string
  status?: string
}

export interface EquipmentImportItem {
  row_index: number
  serial_number: string
  name: string
  brand?: string | null
  model?: string | null
  category: string
  barcode?: string | null
  warehouse_name?: string | null
  warehouse_id?: string | null
  status: string
  assigned_to?: string | null
  notes?: string | null
  is_valid: boolean
  error_message?: string | null
}

export interface EquipmentImportPreviewResponse {
  total_rows: number
  valid_count: number
  error_count: number
  items: EquipmentImportItem[]
}

export interface EquipmentImportCommitResponse {
  imported_count: number
  message: string
}

export interface PublicCustodyInfo {
  assigned_to: string | null
  recipient_name: string | null
  recipient_id_card: string | null
  recipient_position: string | null
  recipient_department: string | null
  recipient_signature?: string | null
  delivered_by_name?: string | null
  delivered_by_position?: string | null
  delivered_by_id_card?: string | null
  assigned_date: string | null
  act_number: string | null
  act_id: string | null
  act_type: string | null
  accessories?: string | null
  scanned_document_url?: string | null
  scanned_at?: string | null
  evidence_photos_list?: string[]
  verification_hash?: string | null
  validity_status?: 'VALID_ACTIVE_ASSIGNMENT' | 'VALID_RETURN_SOLVENCY' | 'EXPIRED_OR_RETURNED_ASSIGNMENT' | string
}

export interface EquipmentMaintenance {
  id: string
  equipment_id: string
  maintenance_type: 'preventive' | 'corrective' | 'upgrade' | string
  title: string
  description: string | null
  cost: number | null
  performed_by: string | null
  performed_at: string
  new_specs: string | null
  created_at: string
}

export interface EquipmentMaintenanceCreate {
  maintenance_type: string
  title: string
  description?: string
  cost?: number
  performed_by?: string
  performed_at?: string
  new_specs?: string
  update_equipment_specs?: boolean
}

export interface PublicEquipmentData {
  id: string
  serial_number: string
  barcode: string | null
  name: string
  brand: string | null
  model: string | null
  category: string
  status: string
  notes: string | null
  warranty_expires: string | null
  warranty_active?: boolean | null
  purchase_date: string | null
  expected_lifespan_years: number
  health_pct?: number
  age_months?: number
  updated_at?: string | null
  warehouse_id?: string | null
  warehouse_name: string | null
  warehouse_location: string | null
}

export interface PublicCompanyInfo {
  name: string
  logo_url: string | null
  primary_color: string
  support_message?: string
}

export interface PublicEquipmentLookupResponse {
  equipment: PublicEquipmentData
  custody: PublicCustodyInfo | null
  company: PublicCompanyInfo
}

export interface ArCatalogResponse {
  synced_at: string
  count: number
  company: PublicCompanyInfo
  items: PublicEquipmentLookupResponse[]
}

export const equipmentApi = {
  list: async (filters?: EquipmentFilters): Promise<Equipment[]> => {
    const response = await apiClient.get<Equipment[]>('/equipment/', { params: filters })
    return response.data
  },
  get: async (id: string): Promise<Equipment> => {
    const response = await apiClient.get<Equipment>(`/equipment/${id}`)
    return response.data
  },
  getByBarcode: async (barcode: string): Promise<Equipment> => {
    const response = await apiClient.get<Equipment>(`/equipment/barcode/${encodeURIComponent(barcode)}`)
    return response.data
  },
  create: async (data: EquipmentCreate): Promise<Equipment> => {
    const response = await apiClient.post<Equipment>('/equipment/', data)
    return response.data
  },
  createBatch: async (data: EquipmentBatchCreate): Promise<EquipmentBatchResponse> => {
    const response = await apiClient.post<EquipmentBatchResponse>('/equipment/batch', data)
    return response.data
  },
  update: async (id: string, data: EquipmentUpdate): Promise<Equipment> => {
    const response = await apiClient.put<Equipment>(`/equipment/${id}`, data)
    return response.data
  },
  delete: async (id: string): Promise<{ message: string; id: string }> => {
    const response = await apiClient.delete<{ message: string; id: string }>(`/equipment/${id}`)
    return response.data
  },
  downloadTemplate: async () => {
    const response = await apiClient.get('/equipment/import-template', {
      responseType: 'blob',
    })
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', 'plantilla_inventario_equipos.xlsx')
    document.body.appendChild(link)
    link.click()
    link.remove()
  },
  importPreview: async (file: File): Promise<EquipmentImportPreviewResponse> => {
    const formData = new FormData()
    formData.append('file', file)
    const response = await apiClient.post<EquipmentImportPreviewResponse>(
      '/equipment/import-preview',
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    )
    return response.data
  },
  importCommit: async (
    items: EquipmentImportItem[],
    defaultWarehouseId?: string
  ): Promise<EquipmentImportCommitResponse> => {
    const response = await apiClient.post<EquipmentImportCommitResponse>(
      '/equipment/import-commit',
      { items, default_warehouse_id: defaultWarehouseId }
    )
    return response.data
  },
  exportExcel: async (filters?: EquipmentFilters) => {
    const response = await apiClient.get('/equipment/export-excel', {
      params: filters,
      responseType: 'blob',
    })
    const blob = new Blob([response.data], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `inventario_${new Date().toISOString().slice(0, 10)}.xlsx`)
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.URL.revokeObjectURL(url)
  },

  /**
   * Consulta pública sin autenticación requerida para escaneo de etiquetas QR.
   * GET /equipment/public-lookup/{identifier}
   */
  publicLookup: async (identifier: string): Promise<PublicEquipmentLookupResponse> => {
    const response = await apiClient.get<PublicEquipmentLookupResponse>(
      `/equipment/public-lookup/${encodeURIComponent(identifier.trim())}`
    )
    return response.data
  },

  /**
   * Descarga el catálogo completo enriquecido para Pre-Caché Offline-First (0 ms) del Escáner AR / HUD.
   * GET /equipment/ar-catalog
   */
  getArCatalog: async (): Promise<ArCatalogResponse> => {
    const response = await apiClient.get<ArCatalogResponse>('/equipment/ar-catalog')
    return response.data
  },

  /**
   * Registra verificación física rápida (1-Tap) desde el Escáner AR / HUD.
   * POST /equipment/{id}/verify-presence
   */
  verifyPresence: async (
    id: string,
    notes?: string
  ): Promise<{ status: string; equipment_id: string; serial_number: string; verified_at: string }> => {
    const response = await apiClient.post(`/equipment/${id}/verify-presence`, {
      notes,
      verified_at: new Date().toISOString(),
    })
    return response.data
  },

  /**
   * Genera y devuelve la imagen QR de etiqueta para un equipo específico.
   * GET /equipment/{id}/qr-label
   */
  generateQrLabel: async (id: string, baseUrl?: string): Promise<Blob> => {
    const response = await apiClient.get(`/equipment/${id}/qr-label`, {
      params: baseUrl ? { base_url: baseUrl } : undefined,
      responseType: 'blob',
    })
    return response.data as Blob
  },

  /**
   * Descarga un PDF con la plancha de etiquetas QR para los equipos indicados.
   * POST /equipment/labels-pdf
   */
  downloadLabelsPdf: async (ids: string[], baseUrl?: string): Promise<void> => {
    const response = await apiClient.post(
      '/equipment/labels-pdf',
      { equipment_ids: ids, base_url: baseUrl },
      { responseType: 'blob' }
    )
    const blob = new Blob([response.data as BlobPart], { type: 'application/pdf' })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `etiquetas_qr_${new Date().toISOString().slice(0, 10)}.pdf`)
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.URL.revokeObjectURL(url)
  },

  listMaintenances: async (equipmentId: string): Promise<EquipmentMaintenance[]> => {
    const response = await apiClient.get<EquipmentMaintenance[]>(`/equipment/${equipmentId}/maintenances`)
    return response.data
  },

  createMaintenance: async (
    equipmentId: string,
    data: EquipmentMaintenanceCreate
  ): Promise<EquipmentMaintenance> => {
    const response = await apiClient.post<EquipmentMaintenance>(
      `/equipment/${equipmentId}/maintenances`,
      data
    )
    return response.data
  },

  deleteMaintenance: async (equipmentId: string, maintenanceId: string): Promise<void> => {
    await apiClient.delete(`/equipment/${equipmentId}/maintenances/${maintenanceId}`)
  },

  getCatalogs: async (): Promise<EquipmentCatalogsResponse> => {
    const response = await apiClient.get<EquipmentCatalogsResponse>('/equipment/catalogs')
    return response.data
  },

  addCatalogItem: async (data: {
    item_type: 'brand' | 'category'
    label: string
    value?: string
    group_name?: string
  }): Promise<CatalogItem> => {
    const response = await apiClient.post<CatalogItem>('/equipment/catalogs', data)
    return response.data
  },
}
