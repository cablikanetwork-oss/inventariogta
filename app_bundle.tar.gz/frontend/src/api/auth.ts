import apiClient from './client'

export interface LoginRequest {
  username: string
  pin: string
}

export interface RecoverPinRequest {
  username: string
  id_card: string
  recovery_key: string
  new_pin: string
}

export interface User {
  id: string
  username: string
  full_name: string
  role: 'admin' | 'user'
  is_active: boolean
  id_card?: string | null
  has_recovery_key?: boolean
  created_at: string
}

export interface TokenResponse {
  access_token: string
  token_type: string
  user: User
}

export const authApi = {
  login: async (data: LoginRequest): Promise<TokenResponse> => {
    const response = await apiClient.post<TokenResponse>('/auth/login', data)
    return response.data
  },
  recoverPin: async (data: RecoverPinRequest): Promise<TokenResponse> => {
    const response = await apiClient.post<TokenResponse>('/auth/recover-pin', data)
    return response.data
  },
}

