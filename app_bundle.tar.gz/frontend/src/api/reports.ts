import apiClient from './client'
import { type Equipment } from './equipment'

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface MovementRecord {
  id: string
  type: string
  equipment_id: string
  from_warehouse_id: string | null
  to_warehouse_id: string | null
  assigned_to: string | null
  notes: string | null
  performed_by: string | null
  created_at: string
  from_warehouse?: { id: string; name: string } | null
  to_warehouse?: { id: string; name: string } | null
}

export interface EquipmentLifecycle {
  equipment: Equipment
  movements: MovementRecord[]
  age_days: number
  time_in_each_status: Record<string, number>
}

export interface ObsolescenceItem {
  equipment: Equipment
  age_years: number | null
  depreciation_pct: number | null
  is_obsolete: boolean
  warranty_status: 'Vigente' | 'Vencida' | 'Sin datos'
}

export interface ObsolescenceFilters {
  threshold_years?: number
  warehouse_id?: string
  category?: string
}

export interface EmployeeClearance {
  employee_name: string
  assigned_equipment: Equipment[]
  has_pending: boolean
}

// ─── API ──────────────────────────────────────────────────────────────────────

export const reportsApi = {
  /**
   * Hoja de Vida del Equipo: historial completo de movimientos y tiempo en cada estado.
   * GET /reports/equipment/{id}/lifecycle
   */
  getEquipmentLifecycle: async (id: string): Promise<EquipmentLifecycle> => {
    const response = await apiClient.get<EquipmentLifecycle>(`/reports/equipment/${id}/lifecycle`)
    return response.data
  },

  /**
   * Reporte de obsolescencia con semáforo por edad y depreciación.
   * GET /reports/obsolescence
   */
  getObsolescence: async (params: ObsolescenceFilters): Promise<ObsolescenceItem[]> => {
    const response = await apiClient.get<ObsolescenceItem[]>('/reports/obsolescence', { params })
    return response.data
  },

  /**
   * Paz y Salvo / Equipos asignados por empleado.
   * GET /reports/employee-clearance?employee_name=...
   */
  getEmployeeClearance: async (employeeName: string): Promise<EmployeeClearance> => {
    const response = await apiClient.get<EmployeeClearance>('/reports/employee-clearance', {
      params: { employee_name: employeeName },
    })
    return response.data
  },
}
