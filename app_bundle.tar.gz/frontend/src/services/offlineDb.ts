// Cache local de equipos, almacenes y cola outbox para operatividad offline
// Implementado con el API estándar de IndexedDB (sin dependencias externas)

const DB_NAME = 'inventory_offline_v1'
const DB_VERSION = 1

export interface OutboxEntry {
  id: string
  method: 'POST' | 'PUT' | 'DELETE'
  url: string
  body?: any
  createdAt: string
  retries: number
}

let dbInstance: IDBDatabase | null = null

export function initOfflineDb(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance)

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result

      if (!db.objectStoreNames.contains('equipment')) {
        const eqStore = db.createObjectStore('equipment', { keyPath: 'id' })
        eqStore.createIndex('serial_number', 'serial_number', { unique: false })
        eqStore.createIndex('warehouse_id', 'current_warehouse_id', { unique: false })
      }

      if (!db.objectStoreNames.contains('warehouses')) {
        db.createObjectStore('warehouses', { keyPath: 'id' })
      }

      if (!db.objectStoreNames.contains('outbox')) {
        const outboxStore = db.createObjectStore('outbox', { keyPath: 'id' })
        outboxStore.createIndex('createdAt', 'createdAt', { unique: false })
      }
    }

    request.onsuccess = () => {
      dbInstance = request.result
      resolve(dbInstance)
    }

    request.onerror = () => {
      console.error('Error abriendo IndexedDB offline:', request.error)
      reject(request.error)
    }
  })
}

export async function cacheEquipment(items: any[]): Promise<void> {
  if (!items || !items.length) return
  try {
    const db = await initOfflineDb()
    const tx = db.transaction('equipment', 'readwrite')
    const store = tx.objectStore('equipment')
    for (const item of items) {
      if (item && item.id) {
        store.put(item)
      }
    }
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
  } catch (err) {
    console.warn('No se pudo guardar en cache offline de equipos:', err)
  }
}

export async function getCachedEquipment(): Promise<any[]> {
  try {
    const db = await initOfflineDb()
    const tx = db.transaction('equipment', 'readonly')
    const store = tx.objectStore('equipment')
    const request = store.getAll()
    return new Promise((resolve) => {
      request.onsuccess = () => resolve(request.result || [])
      request.onerror = () => resolve([])
    })
  } catch {
    return []
  }
}

export async function cacheWarehouses(items: any[]): Promise<void> {
  if (!items || !items.length) return
  try {
    const db = await initOfflineDb()
    const tx = db.transaction('warehouses', 'readwrite')
    const store = tx.objectStore('warehouses')
    for (const item of items) {
      if (item && item.id) {
        store.put(item)
      }
    }
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
  } catch (err) {
    console.warn('No se pudo guardar en cache offline de almacenes:', err)
  }
}

export async function getCachedWarehouses(): Promise<any[]> {
  try {
    const db = await initOfflineDb()
    const tx = db.transaction('warehouses', 'readonly')
    const store = tx.objectStore('warehouses')
    const request = store.getAll()
    return new Promise((resolve) => {
      request.onsuccess = () => resolve(request.result || [])
      request.onerror = () => resolve([])
    })
  } catch {
    return []
  }
}

export async function addToOutbox(
  entry: Omit<OutboxEntry, 'id' | 'createdAt' | 'retries'>
): Promise<string> {
  const db = await initOfflineDb()
  const tx = db.transaction('outbox', 'readwrite')
  const store = tx.objectStore('outbox')
  const id = 'outbox_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6)
  const fullEntry: OutboxEntry = {
    ...entry,
    id,
    createdAt: new Date().toISOString(),
    retries: 0,
  }
  store.add(fullEntry)
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve(id)
    tx.onerror = () => reject(tx.error)
  })
}

export async function getOutboxEntries(): Promise<OutboxEntry[]> {
  try {
    const db = await initOfflineDb()
    const tx = db.transaction('outbox', 'readonly')
    const store = tx.objectStore('outbox')
    const request = store.getAll()
    return new Promise((resolve) => {
      request.onsuccess = () => resolve(request.result || [])
      request.onerror = () => resolve([])
    })
  } catch {
    return []
  }
}

export async function removeFromOutbox(id: string): Promise<void> {
  try {
    const db = await initOfflineDb()
    const tx = db.transaction('outbox', 'readwrite')
    const store = tx.objectStore('outbox')
    store.delete(id)
    return new Promise((resolve) => {
      tx.oncomplete = () => resolve()
      tx.onerror = () => resolve()
    })
  } catch {}
}
