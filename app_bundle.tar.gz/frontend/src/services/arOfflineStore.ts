import { equipmentApi, type PublicEquipmentLookupResponse } from '../api/equipment'
import { addToOutbox } from './offlineDb'

const AR_DB_NAME = 'inventory_ar_hud_cache_v1'
const AR_DB_VERSION = 1
const LS_LIGHT_KEY = 'ar_hud_light_catalog_v1'
const LS_META_KEY = 'ar_hud_sync_meta_v1'

// Mapa en memoria RAM para acceso en 0.01 milisegundos durante el renderizado AR a 60 FPS
const memoryMap = new Map<string, PublicEquipmentLookupResponse>()
let isHydrated = false
let lastSyncTime: string | null = localStorage.getItem(LS_META_KEY)

/**
 * Extrae el identificador limpio (Serial, Barcode o UUID) tanto de una URL completa
 * (ej. https://dominio.com/eq/V2509N0002754) como de un código plano.
 */
export function parseQrCodeIdentifier(rawText: string): string {
  const trimmed = (rawText || '').trim()
  if (!trimmed) return ''
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    try {
      const url = new URL(trimmed)
      const parts = url.pathname.split('/').filter(Boolean)
      if (parts.length > 0) {
        return decodeURIComponent(parts[parts.length - 1]).trim()
      }
    } catch {
      // Fallback
    }
  }
  return trimmed
}

function indexItemInMemory(item: PublicEquipmentLookupResponse) {
  if (!item || !item.equipment) return
  const eq = item.equipment
  if (eq.serial_number) {
    memoryMap.set(eq.serial_number.trim().toUpperCase(), item)
  }
  if (eq.barcode) {
    memoryMap.set(eq.barcode.trim().toUpperCase(), item)
  }
  if (eq.id) {
    memoryMap.set(eq.id.trim().toUpperCase(), item)
  }
  if (item.custody?.act_number) {
    memoryMap.set(item.custody.act_number.trim().toUpperCase(), item)
  }
  if (item.custody?.act_id) {
    memoryMap.set(item.custody.act_id.trim().toUpperCase(), item)
  }
  if (item.custody?.recipient_id_card) {
    memoryMap.set(`SOLV-${item.custody.recipient_id_card.trim().toUpperCase()}`, item)
  }
}

// Hidratación síncrona inicial desde localStorage para tener 0ms desde el primer frame
function hydrateFromLocalStorageSync() {
  if (isHydrated) return
  isHydrated = true
  try {
    const raw = localStorage.getItem(LS_LIGHT_KEY)
    if (raw) {
      const items: PublicEquipmentLookupResponse[] = JSON.parse(raw)
      if (Array.isArray(items)) {
        for (const item of items) {
          indexItemInMemory(item)
        }
      }
    }
  } catch {
    // Ignore parse errors
  }
}

hydrateFromLocalStorageSync()

function openArIndexedDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(AR_DB_NAME, AR_DB_VERSION)
    req.onupgradeneeded = (ev) => {
      const db = (ev.target as IDBOpenDBRequest).result
      if (!db.objectStoreNames.contains('ar_items')) {
        db.createObjectStore('ar_items', { keyPath: 'equipment.id' })
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

async function saveCatalogToIndexedDb(items: PublicEquipmentLookupResponse[]): Promise<void> {
  try {
    const db = await openArIndexedDb()
    const tx = db.transaction('ar_items', 'readwrite')
    const store = tx.objectStore('ar_items')
    for (const item of items) {
      if (item?.equipment?.id) {
        store.put(item)
      }
    }
  } catch (err) {
    console.warn('Error guardando catálogo AR en IndexedDB:', err)
  }
}

async function loadCatalogFromIndexedDb(): Promise<PublicEquipmentLookupResponse[]> {
  try {
    const db = await openArIndexedDb()
    const tx = db.transaction('ar_items', 'readonly')
    const store = tx.objectStore('ar_items')
    const req = store.getAll()
    return new Promise((resolve) => {
      req.onsuccess = () => resolve(req.result || [])
      req.onerror = () => resolve([])
    })
  } catch {
    return []
  }
}

/**
 * Consulta SÍNCRONA en 0 milisegundos directamente desde RAM.
 * Diseñada para ejecutarse dentro del bucle requestAnimationFrame (60 FPS) del Canvas AR.
 */
export function getEquipmentSync0ms(rawCode: string): PublicEquipmentLookupResponse | null {
  hydrateFromLocalStorageSync()
  const clean = parseQrCodeIdentifier(rawCode).toUpperCase()
  if (!clean) return null
  return memoryMap.get(clean) || null
}

/**
 * Devuelve estadísticas del estado actual del caché AR Offline.
 */
export function getArCacheStatus(): {
  cachedCount: number
  lastSyncTime: string | null
  isReady: boolean
} {
  hydrateFromLocalStorageSync()
  // Contamos equipos únicos por ID
  const uniqueIds = new Set<string>()
  memoryMap.forEach((v) => {
    if (v?.equipment?.id) uniqueIds.add(v.equipment.id)
  })
  return {
    cachedCount: uniqueIds.size,
    lastSyncTime,
    isReady: uniqueIds.size > 0,
  }
}

/**
 * Sincroniza el catálogo completo desde el servidor hacia RAM + IndexedDB + LocalStorage.
 * Si el dispositivo está Offline, hidrata desde IndexedDB sin fallar.
 */
export async function syncArCatalogOfflineFirst(): Promise<{
  count: number
  syncedAt: string | null
  isOffline: boolean
}> {
  hydrateFromLocalStorageSync()

  // 1. Cargar primero lo que haya en IndexedDB (incluye firmas completas)
  const idbItems = await loadCatalogFromIndexedDb()
  for (const item of idbItems) {
    indexItemInMemory(item)
  }

  // 2. Si hay red, actualizar desde el endpoint masivo /equipment/ar-catalog
  if (typeof navigator === 'undefined' || navigator.onLine) {
    try {
      const res = await equipmentApi.getArCatalog()
      if (res && Array.isArray(res.items)) {
        for (const item of res.items) {
          indexItemInMemory(item)
        }
        lastSyncTime = res.synced_at || new Date().toISOString()
        localStorage.setItem(LS_META_KEY, lastSyncTime)

        // Guardar versión completa (con firmas) en IndexedDB
        await saveCatalogToIndexedDb(res.items)

        // Guardar versión en localStorage para arranque en 0ms
        try {
          localStorage.setItem(LS_LIGHT_KEY, JSON.stringify(res.items))
        } catch {
          // Si excede cuota por firmas pesadas, guardar sin firmas en localStorage
          const light = res.items.map((it) => ({
            ...it,
            custody: it.custody ? { ...it.custody, recipient_signature: null } : null,
          }))
          try {
            localStorage.setItem(LS_LIGHT_KEY, JSON.stringify(light))
          } catch {}
        }

        return {
          count: res.items.length,
          syncedAt: lastSyncTime,
          isOffline: false,
        }
      }
    } catch {
      // Si falla la red, continuamos en modo offline transparente
    }
  }

  const status = getArCacheStatus()
  return {
    count: status.cachedCount,
    syncedAt: status.lastSyncTime,
    isOffline: true,
  }
}

/**
 * Busca un activo con prioridad 0ms en RAM, fallback a IndexedDB y fallback a API en vivo.
 */
export async function lookupEquipmentOfflineFirst(rawCode: string): Promise<{
  data: PublicEquipmentLookupResponse
  latencyMs: number
  source: '0ms-ram' | 'offline-cache' | 'live-api'
}> {
  const t0 = performance.now()
  const cleanCode = parseQrCodeIdentifier(rawCode)
  if (!cleanCode) {
    throw new Error('Código vacío o inválido')
  }

  // 1. Intento en 0ms desde RAM
  const ramHit = getEquipmentSync0ms(cleanCode)
  if (ramHit) {
    const latencyMs = Math.max(0, Math.round((performance.now() - t0) * 10) / 10)
    // Refrescar silenciosamente en segundo plano si estamos online
    if (navigator.onLine) {
      equipmentApi
        .publicLookup(cleanCode)
        .then((fresh) => {
          indexItemInMemory(fresh)
          saveCatalogToIndexedDb([fresh])
        })
        .catch(() => {})
    }
    return {
      data: ramHit,
      latencyMs,
      source: navigator.onLine ? '0ms-ram' : 'offline-cache',
    }
  }

  // 2. Intento en IndexedDB por si aún no había terminado de hidratar
  const idbItems = await loadCatalogFromIndexedDb()
  for (const item of idbItems) {
    indexItemInMemory(item)
  }
  const idbHit = getEquipmentSync0ms(cleanCode)
  if (idbHit) {
    const latencyMs = Math.round(performance.now() - t0)
    return {
      data: idbHit,
      latencyMs,
      source: 'offline-cache',
    }
  }

  // 3. Consulta en vivo al API (y guarda en caché para el futuro)
  const fresh = await equipmentApi.publicLookup(cleanCode)
  indexItemInMemory(fresh)
  await saveCatalogToIndexedDb([fresh])
  const latencyMs = Math.round(performance.now() - t0)
  return {
    data: fresh,
    latencyMs,
    source: 'live-api',
  }
}

/**
 * Registra verificación de presencia física (1-Tap) funcionando tanto Online como Offline (Outbox).
 */
export async function verifyPresenceOfflineFirst(
  equipmentId: string,
  serialNumber: string
): Promise<{ mode: 'online' | 'offline-outbox'; verifiedAt: string }> {
  const nowIso = new Date().toISOString()

  // Actualizar inmediatamente en memoria local para feedback visual en 0ms
  const existing = getEquipmentSync0ms(serialNumber) || getEquipmentSync0ms(equipmentId)
  if (existing) {
    existing.equipment.updated_at = nowIso
    indexItemInMemory(existing)
    saveCatalogToIndexedDb([existing])
  }

  if (navigator.onLine) {
    try {
      const res = await equipmentApi.verifyPresence(equipmentId, 'Verificación óptica AR / HUD')
      return {
        mode: 'online',
        verifiedAt: res.verified_at || nowIso,
      }
    } catch {
      // Fallback a Outbox si falla la petición
    }
  }

  // Encolar en Outbox Offline para sincronización automática al recuperar señal
  await addToOutbox({
    method: 'POST',
    url: `/equipment/${equipmentId}/verify-presence`,
    body: {
      notes: 'Verificación óptica AR / HUD (Sincronizado desde modo Offline)',
      verified_at: nowIso,
    },
  })

  return {
    mode: 'offline-outbox',
    verifiedAt: nowIso,
  }
}

