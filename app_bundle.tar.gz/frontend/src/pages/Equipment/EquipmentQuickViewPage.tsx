import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import {
  User,
  ShieldCheck,
  Building,
  Calendar,
  CreditCard,
  Copy,
  Check,
  Camera,
  ArrowLeft,
  FileText,
  AlertCircle,
  ExternalLink,
  Cpu,
  Sparkles,
  Zap,
  CheckCircle2,
  Wifi,
  WifiOff,
  FileSignature
} from 'lucide-react'
import { type PublicEquipmentLookupResponse } from '../../api/equipment'
import {
  lookupEquipmentOfflineFirst,
  verifyPresenceOfflineFirst
} from '../../services/arOfflineStore'
import { useAuthStore } from '../../store/authStore'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

export function EquipmentQuickViewPage() {
  const { identifier } = useParams<{ identifier: string }>()
  const navigate = useNavigate()
  const { isAuthenticated } = useAuthStore()

  const [data, setData] = useState<PublicEquipmentLookupResponse | null>(null)
  const [lookupMeta, setLookupMeta] = useState<{
    latencyMs: number
    source: string
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  )

  // Verificación 1-Tap
  const [isVerifying, setIsVerifying] = useState(false)
  const [verifiedBanner, setVerifiedBanner] = useState<{
    mode: 'online' | 'offline-outbox'
    time: string
  } | null>(null)

  useEffect(() => {
    const onOnline = () => setIsOnline(true)
    const onOffline = () => setIsOnline(false)
    window.addEventListener('online', onOnline)
    window.addEventListener('offline', onOffline)
    return () => {
      window.removeEventListener('online', onOnline)
      window.removeEventListener('offline', onOffline)
    }
  }, [])

  useEffect(() => {
    if (!identifier) {
      setError('No se especificó un número de serie o código de activo.')
      setLoading(false)
      return
    }

    const cleanId = identifier.trim()
    if (
      cleanId.toUpperCase().startsWith('ACT-') ||
      cleanId.toUpperCase().startsWith('SOLV-')
    ) {
      navigate(`/verify-act/${encodeURIComponent(cleanId)}`, { replace: true })
      return
    }

    let isMounted = true
    setLoading(true)
    setError(null)
    setVerifiedBanner(null)

    lookupEquipmentOfflineFirst(identifier)
      .then((res) => {
        if (isMounted) {
          setData(res.data)
          setLookupMeta({ latencyMs: res.latencyMs, source: res.source })
          setLoading(false)
        }
      })
      .catch((err: any) => {
        if (isMounted) {
          setError(
            err?.response?.data?.detail ||
              'No se encontró el equipo tecnológico con el código o serial escaneado.'
          )
          setLoading(false)
        }
      })

    return () => {
      isMounted = false
    }
  }, [identifier])

  const handleCopySerial = () => {
    if (data?.equipment?.serial_number) {
      navigator.clipboard.writeText(data.equipment.serial_number)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleOneTapVerify = async () => {
    if (!data || isVerifying) return
    setIsVerifying(true)
    try {
      const res = await verifyPresenceOfflineFirst(
        data.equipment.id,
        data.equipment.serial_number
      )
      setVerifiedBanner({
        mode: res.mode,
        time: new Date(res.verifiedAt).toLocaleTimeString('es-VE', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      })
    } finally {
      setIsVerifying(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center text-white">
        <LoadingSpinner size="lg" />
        <p className="mt-4 text-slate-400 text-sm animate-pulse">
          Consultando ficha del activo tecnológico...
        </p>
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center text-white">
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mb-4">
          <AlertCircle className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold mb-2">Activo No Encontrado</h2>
        <p className="text-slate-400 text-sm max-w-sm mb-6">{error}</p>
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => navigate('/scan')}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-white font-medium text-sm hover:opacity-90 transition-opacity"
          >
            <Camera className="w-4 h-4" />
            Escanear otro código
          </button>
          <button
            onClick={() => navigate('/')}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium text-sm hover:bg-slate-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Ir al inicio
          </button>
        </div>
      </div>
    )
  }

  const { equipment, custody, company } = data
  const isAssigned = equipment.status === 'assigned' || !!custody
  const healthPct = equipment.health_pct ?? 100
  const healthColor =
    healthPct >= 60 ? '#10b981' : healthPct >= 30 ? '#f59e0b' : '#f43f5e'

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col items-center justify-start p-4 sm:p-6 pb-24">
      {/* Cabecera institucional con Marca Blanca y Estado Offline-First */}
      <div className="w-full max-w-xl flex items-center justify-between py-3 border-b border-slate-800/80 mb-6">
        <div className="flex items-center gap-3">
          {company.logo_url ? (
            <img
              src={company.logo_url}
              alt={company.name}
              className="h-9 w-auto max-w-[140px] object-contain rounded bg-white/5 p-1"
            />
          ) : (
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center font-bold text-white shadow-lg shadow-primary/20">
              {company.name.charAt(0)}
            </div>
          )}
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold tracking-tight text-white">{company.name}</h1>
              <span
                className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold border ${
                  isOnline
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                }`}
              >
                {isOnline ? <Wifi className="w-2.5 h-2.5" /> : <WifiOff className="w-2.5 h-2.5" />}
                {isOnline ? 'ONLINE' : 'MODO OFFLINE'}
              </span>
            </div>
            <p className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Activo Tecnológico Verificado
              {lookupMeta && (
                <span className="text-[10px] font-mono text-cyan-400 ml-1">
                  ({lookupMeta.latencyMs}ms • {lookupMeta.source})
                </span>
              )}
            </p>
          </div>
        </div>

        <button
          onClick={() => navigate('/scan')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 transition-colors"
          title="Abrir Escáner de Cámara AR / HUD"
        >
          <Camera className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Visor AR</span>
        </button>
      </div>

      <div className="w-full max-w-xl space-y-4">
        {/* Banner de Estado del Activo + Medidor Circular de Vida Útil */}
        <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/90 backdrop-blur-xl p-5 shadow-2xl">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5 mb-1">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                Ficha Holográfica del Activo
              </span>
              <h2 className="text-xl font-bold text-white truncate">{equipment.name}</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {[equipment.brand, equipment.model].filter(Boolean).join(' • ')}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Anillo SVG de Salud / Vida Útil */}
              <div className="flex items-center gap-1.5 bg-slate-950/70 border border-slate-800 px-2.5 py-1 rounded-xl">
                <div className="relative w-8 h-8 flex items-center justify-center">
                  <svg className="w-8 h-8 -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-slate-800"
                      strokeWidth="3.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <path
                      stroke={healthColor}
                      strokeWidth="3.5"
                      strokeDasharray={`${healthPct}, 100`}
                      strokeLinecap="round"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <span className="absolute text-[8px] font-mono font-bold text-white">
                    {healthPct}%
                  </span>
                </div>
                <span className="text-[10px] font-semibold text-slate-300 hidden sm:inline">
                  Salud
                </span>
              </div>

              {/* Badge de Estatus */}
              {equipment.status === 'assigned' ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                  Asignado
                </span>
              ) : equipment.status === 'available' ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Disponible
                </span>
              ) : equipment.status === 'maintenance' ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  Mantenimiento
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-700 text-slate-300">
                  {equipment.status}
                </span>
              )}
            </div>
          </div>

          {/* Serial Number táctil + Botón 1-Tap Verificar Presencia */}
          <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                Número de Serie (S/N)
              </p>
              <p className="text-sm font-mono font-bold text-slate-200">
                {equipment.serial_number}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopySerial}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition-colors"
                title="Copiar Serial"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-medium">Copiado</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar</span>
                  </>
                )}
              </button>

              <button
                onClick={handleOneTapVerify}
                disabled={isVerifying}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-colors shadow-lg shadow-emerald-600/20"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Verificar Presencia</span>
              </button>
            </div>
          </div>

          {verifiedBanner && (
            <div className="mt-3 px-3 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Presencia física confirmada hoy a las {verifiedBanner.time}
              </span>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-950/80">
                {verifiedBanner.mode === 'online' ? 'Sincronizado' : 'En Cola Offline'}
              </span>
            </div>
          )}
        </div>

        {/* TARJETA 1: ¿QUIÉN LO TIENE ASIGNADO? (CUSTODIA + FIRMA REAL) */}
        {isAssigned && custody ? (
          <div className="rounded-2xl border border-blue-900/40 bg-gradient-to-br from-blue-950/40 via-slate-900/90 to-slate-900/90 backdrop-blur-xl p-5 shadow-xl">
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">En Custodia de:</h3>
                  <p className="text-xs text-blue-400 font-medium">Trabajador Responsable</p>
                </div>
              </div>

              {custody.act_number && (
                <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-mono font-bold">
                  {custody.act_number}
                </span>
              )}
            </div>

            <div className="space-y-3 bg-slate-950/40 rounded-xl p-3.5 border border-slate-800/60">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Nombre Completo:</span>
                <span className="text-xs font-bold text-white text-right">
                  {custody.recipient_name || custody.assigned_to}
                </span>
              </div>

              {custody.recipient_id_card && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <CreditCard className="w-3.5 h-3.5 text-slate-500" />
                    Cédula de Identidad:
                  </span>
                  <span className="text-xs font-mono font-semibold text-slate-200">
                    {custody.recipient_id_card}
                  </span>
                </div>
              )}

              {custody.recipient_position && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Cargo:</span>
                  <span className="text-xs font-medium text-slate-300">
                    {custody.recipient_position}
                  </span>
                </div>
              )}

              {custody.recipient_department && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Departamento:</span>
                  <span className="text-xs font-medium text-slate-300">
                    {custody.recipient_department}
                  </span>
                </div>
              )}

              {custody.assigned_date && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    Fecha de Asignación:
                  </span>
                  <span className="text-xs text-slate-300">
                    {new Date(custody.assigned_date).toLocaleDateString('es-VE', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric',
                    })}
                  </span>
                </div>
              )}

              {custody.accessories && (
                <div className="pt-2 border-t border-slate-800/60">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 block mb-0.5">
                    Accesorios Entregados con el Equipo:
                  </span>
                  <span className="text-xs text-slate-200 font-medium">
                    {custody.accessories}
                  </span>
                </div>
              )}
            </div>

            {/* Miniatura de la Firma Digital Real del Trabajador si existe */}
            {custody.recipient_signature && (
              <div className="mt-3 p-3 rounded-xl bg-white/95 border border-blue-400/40 flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-800">
                  <FileSignature className="w-4 h-4 text-blue-600" />
                  <div>
                    <p className="text-[11px] font-bold">Firma Digital Registrada</p>
                    <p className="text-[10px] text-slate-500">
                      Conformidad legal en Acta {custody.act_number}
                    </p>
                  </div>
                </div>
                <img
                  src={custody.recipient_signature}
                  alt="Firma del receptor"
                  className="h-10 w-28 object-contain"
                />
              </div>
            )}

            {/* Botón directo a la Hoja Física Escaneada si fue subida */}
            {custody.scanned_document_url && (
              <div className="mt-3">
                <a
                  href={custody.scanned_document_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-lg shadow-emerald-600/20"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Ver Hoja Física Firmada (Escaneada)</span>
                </a>
              </div>
            )}

            {/* Si el usuario está autenticado en la PWA y hay acta, botón para verla */}
            {isAuthenticated && custody.act_id && (
              <div className="mt-2.5">
                <Link
                  to={`/acts?selected=${custody.act_id}`}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs transition-colors shadow-lg shadow-blue-600/20"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Ver Acta de Entrega en Sistema
                </Link>
              </div>
            )}
          </div>
        ) : (
          /* TARJETA DISPONIBLE EN ALMACÉN */
          <div className="rounded-2xl border border-emerald-900/40 bg-gradient-to-br from-emerald-950/30 via-slate-900/90 to-slate-900/90 backdrop-blur-xl p-5 shadow-xl">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Building className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Activo Disponible</h3>
                <p className="text-xs text-emerald-400 font-medium">Listo para Asignación</p>
              </div>
            </div>

            <div className="bg-slate-950/40 rounded-xl p-3.5 border border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Almacén Actual:</span>
                <span className="text-xs font-bold text-white">
                  {equipment.warehouse_name || 'Almacén Principal'}
                </span>
              </div>
              {equipment.warehouse_location && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Ubicación / Sede:</span>
                  <span className="text-xs text-slate-300">
                    {equipment.warehouse_location}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TARJETA 2: FICHA TÉCNICA Y ESPECIFICACIONES */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Especificaciones Técnicas</h3>
              <p className="text-xs text-slate-400">Detalles del Hardware y Vida Útil</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/60">
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Tipo</span>
              <span className="font-semibold text-slate-200 capitalize">
                {equipment.category}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/60">
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Marca</span>
              <span className="font-semibold text-slate-200">
                {equipment.brand || 'No especificada'}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/60">
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Modelo</span>
              <span className="font-semibold text-slate-200">
                {equipment.model || 'No especificado'}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/60">
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Garantía</span>
              <span className="font-semibold text-slate-200">
                {equipment.warranty_expires
                  ? new Date(equipment.warranty_expires).toLocaleDateString('es-VE')
                  : 'Operativo / Vigente'}
              </span>
            </div>
          </div>

          {/* Notas / Specs detalladas */}
          {equipment.notes && (
            <div className="p-3.5 rounded-xl bg-slate-950/50 border border-slate-800/60">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                Configuración y Componentes
              </span>
              <p className="text-xs text-slate-300 leading-relaxed font-mono">
                {equipment.notes}
              </p>
            </div>
          )}
        </div>

        {/* AVISO INSTITUCIONAL / SOPORTE */}
        <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40 text-center">
          <p className="text-[11px] text-slate-400 leading-normal">
            {company.support_message ||
              `Propiedad exclusiva de ${company.name}. En caso de extravío o consultas técnicas, comunicarse con la Gerencia de Tecnología.`}
          </p>
        </div>

        {/* ACCIONES INFERIORES */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => navigate('/scan')}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-primary text-white font-semibold text-sm hover:opacity-90 transition-opacity shadow-lg shadow-primary/20"
          >
            <Camera className="w-4 h-4" />
            Abrir Visor de Cámara AR / HUD
          </button>

          {isAuthenticated ? (
            <Link
              to="/equipment"
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-colors border border-slate-700"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Ver en Panel de Inventario
            </Link>
          ) : (
            <Link
              to="/login"
              className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl text-slate-400 hover:text-white font-medium text-xs transition-colors"
            >
              ¿Eres del equipo de TI? Iniciar sesión aquí
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}
