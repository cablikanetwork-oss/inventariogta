import { useState, useEffect } from 'react'
import {
  X,
  FileSpreadsheet,
  FileText,
  Warehouse as WarehouseIcon,
  Filter,
  CheckCircle2,
  Download,
  Printer,
  Layers
} from 'lucide-react'
import { type Warehouse } from '../../api/warehouses'
import { equipmentApi, DEFAULT_CATEGORY_CATALOG } from '../../api/equipment'

interface Props {
  warehouses: Warehouse[]
  isOpen: boolean
  onClose: () => void
  onOpenPdfReport: (filters: {
    warehouseId?: string
    status?: string
    category?: string
    groupBy: 'category' | 'warehouse' | 'status' | 'none'
  }) => void
}

const CATEGORIES = [
  { value: 'all', label: 'Todos los tipos' },
  { value: 'laptop', label: 'Laptops' },
  { value: 'desktop', label: 'Computadoras de Escritorio (Desktop)' },
  { value: 'monitor', label: 'Monitores' },
  { value: 'keyboard', label: 'Teclados' },
  { value: 'mouse', label: 'Ratones / Mouse' },
  { value: 'switch', label: 'Switches' },
  { value: 'router', label: 'Routers' },
  { value: 'server', label: 'Servidores' },
  { value: 'printer', label: 'Impresoras' },
  { value: 'phone', label: 'Teléfonos / VoIP' },
  { value: 'tablet', label: 'Tablets' },
  { value: 'ups', label: 'UPS / Respaldos Eléctricos' },
  { value: 'other', label: 'Otros' },
]

const STATUSES = [
  { value: 'all', label: 'Todos los estados' },
  { value: 'available', label: 'Disponibles (En Stock para entrega)' },
  { value: 'assigned', label: 'Asignados (En custodia de empleados)' },
  { value: 'maintenance', label: 'En Mantenimiento (En reparación/revisión)' },
  { value: 'retired', label: 'De Baja / Retirados' },
]

export function ExportReportModal({
  warehouses,
  isOpen,
  onClose,
  onOpenPdfReport,
}: Props) {
  const [selectedWarehouse, setSelectedWarehouse] = useState<string>('')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [groupBy, setGroupBy] = useState<'category' | 'warehouse' | 'status' | 'none'>('category')
  const [isExportingExcel, setIsExportingExcel] = useState(false)
  const [exportSuccess, setExportSuccess] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [categoryOptions, setCategoryOptions] = useState([
    { value: 'all', label: 'Todos los tipos' },
    ...DEFAULT_CATEGORY_CATALOG.map((c) => ({ value: c.value, label: c.label })),
  ])

  useEffect(() => {
    if (!isOpen) return
    equipmentApi
      .getCatalogs()
      .then((res) => {
        if (res.categories?.length) {
          setCategoryOptions([
            { value: 'all', label: 'Todos los tipos' },
            ...res.categories.map((c) => ({ value: c.value, label: c.label })),
          ])
        }
      })
      .catch(() => {})
  }, [isOpen])

  if (!isOpen) return null

  const handleDownloadExcel = async () => {
    setIsExportingExcel(true)
    setErrorMessage(null)
    setExportSuccess(false)
    try {
      await equipmentApi.exportExcel({
        warehouse_id: selectedWarehouse || undefined,
        status: selectedStatus === 'all' ? undefined : selectedStatus,
        category: selectedCategory === 'all' ? undefined : selectedCategory,
      })
      setExportSuccess(true)
      setTimeout(() => setExportSuccess(false), 4000)
    } catch (err: any) {
      console.error(err)
      setErrorMessage(
        err?.response?.data?.detail || 'Ocurrió un error al generar el archivo Excel.'
      )
    } finally {
      setIsExportingExcel(false)
    }
  }

  const handleOpenPdf = () => {
    onOpenPdfReport({
      warehouseId: selectedWarehouse || undefined,
      status: selectedStatus,
      category: selectedCategory,
      groupBy,
    })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center text-primary">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Exportar / Reporte de Inventario
              </h2>
              <p className="text-xs text-slate-400">
                Descarga en Excel (.xlsx) o genera un documento PDF oficial listo para imprimir
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Filtros */}
        <div className="p-5 space-y-4 text-xs">
          {errorMessage && (
            <div className="p-3 bg-rose-950/50 border border-rose-900/70 rounded-xl text-rose-300">
              {errorMessage}
            </div>
          )}

          {exportSuccess && (
            <div className="p-3 bg-emerald-950/50 border border-emerald-900/70 rounded-xl text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>¡Archivo Excel descargado exitosamente con múltiples pestañas organizadas!</span>
            </div>
          )}

          <div className="space-y-3">
            <div className="flex items-center gap-2 text-slate-300 font-semibold">
              <Filter className="w-4 h-4 text-primary" />
              <span>Criterios de Organización y Filtro:</span>
            </div>

            {/* 1. Almacén */}
            <div>
              <label className="block text-slate-400 mb-1">
                Almacén / Ubicación:
              </label>
              <div className="relative">
                <WarehouseIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <select
                  value={selectedWarehouse}
                  onChange={(e) => setSelectedWarehouse(e.target.value)}
                  className="input-field pl-9 py-2 text-xs w-full bg-slate-950"
                >
                  <option value="">Todos los almacenes (Inventario Global)</option>
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 2. Estado */}
            <div>
              <label className="block text-slate-400 mb-1">
                Estado del Equipo:
              </label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="input-field py-2 text-xs w-full bg-slate-950"
              >
                {STATUSES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Tipo / Categoría */}
            <div>
              <label className="block text-slate-400 mb-1">
                Tipo / Categoría de Equipo:
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="input-field py-2 text-xs w-full bg-slate-950"
              >
                {categoryOptions.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            {/* 4. Agrupamiento para el PDF */}
            <div>
              <label className="block text-slate-400 mb-1 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-primary" />
                <span>Agrupar reporte PDF por:</span>
              </label>
              <select
                value={groupBy}
                onChange={(e) => setGroupBy(e.target.value as any)}
                className="input-field py-2 text-xs w-full bg-slate-950"
              >
                <option value="category">Por Tipo / Categoría de Equipo</option>
                <option value="warehouse">Por Almacén / Ubicación</option>
                <option value="status">Por Estado (Disponibles, Asignados, Mantenimiento)</option>
                <option value="none">Sin agrupar (Lista Continua)</option>
              </select>
            </div>
          </div>

          {/* Tarjetas de opciones de descarga */}
          <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Tarjeta Opción 1: Excel */}
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/50 hover:border-emerald-500/40 transition-colors flex flex-col justify-between space-y-3">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Libro Excel (.xlsx)</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Genera un libro oficial con hojas organizadas: Resumen Ejecutivo, Inventario Total, Disponibles, Asignados y En Mantenimiento, con auto-filtros y colores institucionales.
                </p>
              </div>

              <button
                type="button"
                onClick={handleDownloadExcel}
                disabled={isExportingExcel}
                className="w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all disabled:opacity-50"
              >
                {isExportingExcel ? (
                  <span>Generando Excel...</span>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar Excel</span>
                  </>
                )}
              </button>
            </div>

            {/* Tarjeta Opción 2: Reporte PDF / Imprimir */}
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/50 hover:border-blue-500/40 transition-colors flex flex-col justify-between space-y-3">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-blue-400 font-bold text-sm">
                  <FileText className="w-4 h-4" />
                  <span>Reporte PDF / Imprimir</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Visualiza el documento formateado en hoja tipo Carta/A4 con el logotipo de la empresa, KPIs, tablas agrupadas y área de firmas, listo para imprimir o guardar en PDF.
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenPdf}
                className="w-full py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Ver Reporte PDF</span>
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-900/60 border-t border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary py-1.5 px-4 text-xs"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  )
}

