import { useState, useRef } from 'react'
import {
  X,
  FileSpreadsheet,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Package,
  Warehouse,
  Check,
  RefreshCw,
} from 'lucide-react'
import {
  equipmentApi,
  type EquipmentImportItem,
  type EquipmentImportPreviewResponse,
} from '../../api/equipment'
import { type Warehouse as WarehouseType } from '../../api/warehouses'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

interface Props {
  warehouses: WarehouseType[]
  onClose: () => void
  onSuccess: (importedCount: number) => void
}

export function ImportExcelModal({ warehouses, onClose, onSuccess }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isPreviewing, setIsPreviewing] = useState(false)
  const [isCommitting, setIsCommitting] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)
  const [previewData, setPreviewData] = useState<EquipmentImportPreviewResponse | null>(null)
  const [defaultWarehouseId, setDefaultWarehouseId] = useState<string>(warehouses[0]?.id || '')
  const [error, setError] = useState<string | null>(null)

  const handleDownloadTemplate = async () => {
    setIsDownloading(true)
    setError(null)
    try {
      await equipmentApi.downloadTemplate()
    } catch (err: any) {
      setError('No fue posible descargar la plantilla. Intenta de nuevo.')
    } finally {
      setIsDownloading(false)
    }
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    processFile(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files?.[0]
    if (!file) return
    processFile(file)
  }

  const processFile = async (file: File) => {
    if (!file.name.match(/\.(xlsx|xls|csv|txt)$/i)) {
      setError('Por favor selecciona un archivo con extensión .xlsx, .xls o .csv')
      return
    }

    setSelectedFile(file)
    setIsPreviewing(true)
    setError(null)
    setPreviewData(null)

    try {
      const data = await equipmentApi.importPreview(file)
      setPreviewData(data)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al procesar el archivo Excel. Verifica el formato.')
      setSelectedFile(null)
    } finally {
      setIsPreviewing(false)
    }
  }

  const handleCommit = async () => {
    if (!previewData || previewData.valid_count === 0) return

    setIsCommitting(true)
    setError(null)
    try {
      const result = await equipmentApi.importCommit(previewData.items, defaultWarehouseId)
      onSuccess(result.imported_count)
      onClose()
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Ocurrió un error al guardar los equipos en la base de datos.')
      setIsCommitting(false)
    }
  }

  const resetSelection = () => {
    setSelectedFile(null)
    setPreviewData(null)
    setError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-slate-900 w-full sm:max-w-4xl sm:rounded-2xl border border-slate-800 max-h-[92vh] flex flex-col shadow-2xl safe-bottom overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Cabecera */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/80 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-white font-bold text-base">Carga Masiva de Equipos (Excel / CSV)</h2>
              <p className="text-xs text-slate-400">Importa activos en bloque directamente desde tu hoja de cálculo</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-5 space-y-4">
          {error && (
            <div className="text-rose-400 text-xs font-semibold bg-rose-950/40 border border-rose-900/60 rounded-xl p-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* PASO 1: Descargar Plantilla y Seleccionar Archivo */}
          {!previewData && !isPreviewing && (
            <div className="space-y-4">
              {/* Tarjeta de descarga de plantilla */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <p className="text-sm font-bold text-white flex items-center gap-2">
                    <Download className="w-4 h-4 text-primary" />
                    <span>¿No tienes la plantilla oficial?</span>
                  </p>
                  <p className="text-xs text-slate-400">
                    Descarga el formato Excel modelo pre-rellenado con las columnas y valores admitidos por el sistema.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadTemplate}
                  disabled={isDownloading}
                  className="btn-secondary py-2 px-3.5 text-xs flex items-center gap-2 whitespace-nowrap self-start sm:self-auto hover:border-primary/50"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <span>{isDownloading ? 'Generando...' : 'Descargar Plantilla Excel (.xlsx)'}</span>
                </button>
              </div>

              {/* Zona de Carga Drag & Drop */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-700 hover:border-primary/60 rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all bg-slate-950/30 hover:bg-slate-950/60 group"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv,.txt"
                  className="hidden"
                  onChange={handleFileChange}
                />
                <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto text-primary mb-3 group-hover:scale-105 transition-transform">
                  <Upload className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-bold text-white mb-1">
                  Arrastra tu archivo Excel aquí o haz clic para seleccionarlo
                </h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Formatos compatibles: <strong className="text-slate-300">.xlsx, .xls, .csv</strong>. El sistema validará automáticamente duplicados y columnas.
                </p>
              </div>
            </div>
          )}

          {/* Spinner de procesamiento */}
          {isPreviewing && (
            <div className="py-20 text-center space-y-3">
              <LoadingSpinner size="lg" />
              <p className="text-sm font-semibold text-white">Analizando y validando archivo...</p>
              <p className="text-xs text-slate-400">Verificando números de serie, almacenes y categorías</p>
            </div>
          )}

          {/* PASO 2: Previsualización de Datos Detectados */}
          {previewData && (
            <div className="space-y-4">
              {/* Tarjetas de Métricas de Validación */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl text-center">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Total Detectados
                  </span>
                  <span className="text-xl font-black text-white">{previewData.total_rows}</span>
                </div>

                <div className="bg-emerald-950/20 border border-emerald-900/40 p-3 rounded-xl text-center">
                  <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Listos para Importar</span>
                  </span>
                  <span className="text-xl font-black text-emerald-400">{previewData.valid_count}</span>
                </div>

                <div className={`p-3 rounded-xl text-center border ${
                  previewData.error_count > 0
                    ? 'bg-rose-950/20 border-rose-900/40'
                    : 'bg-slate-950/40 border-slate-800 text-slate-500'
                }`}>
                  <span className="text-[11px] font-semibold uppercase tracking-wider block flex items-center justify-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>Con Errores / Omitidos</span>
                  </span>
                  <span className={`text-xl font-black ${previewData.error_count > 0 ? 'text-rose-400' : 'text-slate-500'}`}>
                    {previewData.error_count}
                  </span>
                </div>
              </div>

              {/* Selector de almacén por defecto */}
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2">
                  <Warehouse className="w-4 h-4 text-primary" />
                  <span className="text-xs font-semibold text-slate-300">
                    Almacén de destino (para filas sin almacén especificado):
                  </span>
                </div>
                <select
                  value={defaultWarehouseId}
                  onChange={(e) => setDefaultWarehouseId(e.target.value)}
                  className="input-field text-xs py-1.5 w-full sm:w-64"
                >
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.parent_name ? `↳ ${w.parent_name} › ${w.name}` : `🏢 ${w.name}`}
                    </option>
                  ))}
                </select>
              </div>

              {/* Tabla de Registros */}
              <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/50">
                <div className="overflow-x-auto max-h-72">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-800 sticky top-0">
                      <tr>
                        <th className="py-2.5 px-3 text-center">Fila</th>
                        <th className="py-2.5 px-3">Serial</th>
                        <th className="py-2.5 px-3">Equipo</th>
                        <th className="py-2.5 px-3">Marca / Modelo</th>
                        <th className="py-2.5 px-3">Almacén</th>
                        <th className="py-2.5 px-3">Estado</th>
                        <th className="py-2.5 px-3 text-center">Validación</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {previewData.items.map((item) => (
                        <tr
                          key={item.row_index}
                          className={`hover:bg-slate-900/40 transition-colors ${
                            !item.is_valid ? 'bg-rose-950/10' : ''
                          }`}
                        >
                          <td className="py-2 px-3 text-center font-mono text-slate-500">
                            #{item.row_index}
                          </td>
                          <td className="py-2 px-3 font-mono font-bold text-white">
                            {item.serial_number}
                          </td>
                          <td className="py-2 px-3 font-medium text-slate-200">
                            <div>{item.name}</div>
                            {item.notes && (
                              <div className="text-[10px] text-slate-400 italic truncate max-w-xs">
                                {item.notes}
                              </div>
                            )}
                          </td>
                          <td className="py-2 px-3 text-slate-400">
                            {item.brand || item.model ? `${item.brand || ''} ${item.model || ''}` : '—'}
                          </td>
                          <td className="py-2 px-3 text-slate-300">
                            {item.warehouse_name || 'Almacén Central'}
                          </td>
                          <td className="py-2 px-3 capitalize">
                            <span className="text-[10px] font-semibold text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded">
                              {item.status}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-center whitespace-nowrap">
                            {item.is_valid ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-900/50 px-2 py-0.5 rounded-full">
                                <Check className="w-3 h-3" />
                                <span>Válido</span>
                              </span>
                            ) : (
                              <span
                                className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-400 bg-rose-950/40 border border-rose-900/50 px-2 py-0.5 rounded-full"
                                title={item.error_message || ''}
                              >
                                <AlertTriangle className="w-3 h-3" />
                                <span>{item.error_message || 'Error'}</span>
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Botonera de Acción */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between gap-3 bg-slate-950/80 flex-shrink-0">
          <div>
            {previewData && (
              <button
                type="button"
                onClick={resetSelection}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Subir otro archivo</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary py-2 px-4 text-xs"
            >
              Cancelar
            </button>

            {previewData && (
              <button
                type="button"
                onClick={handleCommit}
                disabled={isCommitting || previewData.valid_count === 0}
                className="btn-primary py-2 px-5 text-xs flex items-center gap-2 shadow-lg"
              >
                {isCommitting ? (
                  <>
                    <LoadingSpinner size="sm" />
                    <span>Guardando equipos...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>Confirmar e Importar {previewData.valid_count} Equipos</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

