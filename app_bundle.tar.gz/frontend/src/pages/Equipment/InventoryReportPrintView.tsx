import { useRef } from 'react'
import { Printer, X, ArrowLeft, Download } from 'lucide-react'
import { getCategoryLabel, type Equipment } from '../../api/equipment'
import { type Warehouse } from '../../api/warehouses'
import { useThemeStore } from '../../store/themeStore'
import { useAuthStore } from '../../store/authStore'

interface Props {
  equipment: Equipment[]
  warehouses: Warehouse[]
  filterWarehouseId?: string
  filterStatus?: string
  filterCategory?: string
  groupBy?: 'none' | 'warehouse' | 'status' | 'category'
  onClose: () => void
  onExportExcel?: () => void
}

const statusLabels: Record<string, string> = {
  available: 'Disponible',
  assigned: 'Asignado',
  maintenance: 'En Mantenimiento',
  retired: 'De Baja',
  lost: 'Extraviado',
}

const statusBadges: Record<string, { bg: string; text: string; border: string }> = {
  available: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-300' },
  assigned: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-300' },
  maintenance: { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-300' },
  retired: { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-300' },
  lost: { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-300' },
}

export function InventoryReportPrintView({
  equipment,
  warehouses,
  filterWarehouseId,
  filterStatus,
  filterCategory,
  groupBy = 'category',
  onClose,
  onExportExcel,
}: Props) {
  const { config } = useThemeStore()
  const { user } = useAuthStore()
  const printAreaRef = useRef<HTMLDivElement>(null)
  const modalRootRef = useRef<HTMLDivElement>(null)

  const handlePrint = () => {
    if (modalRootRef.current) {
      modalRootRef.current.scrollTop = 0
    }
    window.scrollTo(0, 0)
    setTimeout(() => {
      window.print()
    }, 50)
  }

  // Filtrado de equipos
  const filteredList = equipment.filter((eq) => {
    if (filterWarehouseId && eq.current_warehouse_id !== filterWarehouseId) return false
    if (filterStatus && filterStatus !== 'all' && eq.status !== filterStatus) return false
    if (filterCategory && filterCategory !== 'all' && eq.category !== filterCategory) return false
    return true
  })

  // Métricas para el resumen ejecutivo
  const totalCount = filteredList.length
  const availableCount = filteredList.filter((e) => e.status === 'available').length
  const assignedCount = filteredList.filter((e) => e.status === 'assigned').length
  const maintenanceCount = filteredList.filter((e) => e.status === 'maintenance').length
  const retiredCount = filteredList.filter((e) => e.status === 'retired').length

  // Obtener nombre del almacén seleccionado
  const selectedWarehouse = warehouses.find((w) => w.id === filterWarehouseId)

  // Texto descriptivo de filtros aplicados
  const filterSummary = [
    selectedWarehouse ? `Almacén: ${selectedWarehouse.name}` : 'Todos los Almacenes',
    filterStatus && filterStatus !== 'all' ? `Estado: ${statusLabels[filterStatus] || filterStatus}` : 'Todos los Estados',
    filterCategory && filterCategory !== 'all' ? `Tipo: ${filterCategory.toUpperCase()}` : 'Todos los Tipos',
  ].join(' • ')

  const now = new Date()
  const dateFormatted = now.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  })
  const timeFormatted = now.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  })

  // Agrupamiento
  const groups: { [key: string]: Equipment[] } = {}
  if (groupBy === 'none') {
    groups['Inventario General'] = filteredList
  } else {
    for (const item of filteredList) {
      let key = 'Sin clasificar'
      if (groupBy === 'warehouse') {
        key = item.current_warehouse?.name || 'Sin Almacén Asignado'
      } else if (groupBy === 'status') {
        key = statusLabels[item.status] || item.status.toUpperCase()
      } else if (groupBy === 'category') {
        key = getCategoryLabel(item.category).toUpperCase()
      }
      if (!groups[key]) groups[key] = []
      groups[key].push(item)
    }
  }

  return (
    <div
      ref={modalRootRef}
      className="print-modal-root fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md overflow-y-auto p-2 sm:p-6 print:static print:overflow-visible print:p-0 print:bg-white print:block"
    >
      {/* Barra de Acciones Superior (Oculta en Impresión) */}
      <div className="w-full max-w-[210mm] mx-auto flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 p-3 rounded-xl mb-4 shadow-xl print:hidden">
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="btn-secondary py-1.5 px-3 text-xs flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Volver</span>
          </button>
          <span className="text-xs text-slate-300 font-medium ml-1">
            Vista Previa de Reporte ({filteredList.length} equipos)
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onExportExcel && (
            <button
              onClick={onExportExcel}
              className="btn-secondary py-1.5 px-3 text-xs flex items-center gap-1.5 text-emerald-400 border-emerald-500/30 hover:bg-emerald-950/30"
              title="Descargar este reporte en archivo Excel"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Descargar Excel</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="btn-primary py-1.5 px-4 text-xs flex items-center gap-2 shadow-md hover:brightness-110 font-bold"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir / Guardar como PDF</span>
          </button>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            title="Cerrar reporte"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* DOCUMENTO HOJA TIPO CARTA / A4 PARA IMPRESIÓN Y PDF */}
      <div
        ref={printAreaRef}
        className="w-full max-w-[210mm] mx-auto h-auto min-h-[279mm] bg-white text-slate-900 shadow-2xl rounded-sm p-8 sm:p-12 mb-10 font-sans print:shadow-none print:p-2 print:w-full print:max-w-none print:m-0 print:min-h-0 flex flex-col justify-between"
        style={{ backgroundColor: '#ffffff', color: '#0f172a' }}
      >
        <div className="space-y-6">
          {/* Encabezado Institucional */}
          <div className="flex items-start justify-between border-b border-slate-300 pb-5">
            <div className="flex items-center gap-4">
              {config?.logo_url ? (
                <img
                  src={config.logo_url}
                  alt={config.name || 'Logotipo Empresa'}
                  className="h-14 max-w-[200px] object-contain"
                />
              ) : (
                <div
                  className="h-12 px-4 rounded flex items-center justify-center font-bold text-white text-lg tracking-wider"
                  style={{ backgroundColor: config?.primary_color || '#1e3a8a' }}
                >
                  {config?.name || 'EMPRESA'}
                </div>
              )}

              <div>
                <h1 className="text-xl font-black text-slate-900 tracking-tight leading-tight">
                  {config?.name || 'SISTEMA DE GESTIÓN DE INVENTARIO'}
                </h1>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Departamento de Tecnología e Información
                </p>
              </div>
            </div>

            <div className="text-right">
              <div className="inline-block bg-slate-900 text-white font-mono font-bold text-xs px-3 py-1 rounded">
                REPORTE DE INVENTARIO
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Fecha: {dateFormatted}
              </p>
              <p className="text-[10px] text-slate-400">
                Hora: {timeFormatted}
              </p>
            </div>
          </div>

          {/* Subtítulo y Filtros Aplicados */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="font-bold text-slate-700">Filtros aplicados: </span>
              <span className="text-slate-600">{filterSummary}</span>
            </div>
            <div className="text-slate-500 text-[11px]">
              Generado por: <span className="font-semibold text-slate-700">{user?.full_name || user?.username || 'Usuario'}</span>
            </div>
          </div>

          {/* Tarjetas de Resumen Ejecutivo (KPIs) */}
          <div className="grid grid-cols-5 gap-2 text-center">
            <div className="border border-slate-300 rounded-lg p-2 bg-slate-100/70">
              <div className="text-[10px] font-bold text-slate-600 uppercase">Total Activos</div>
              <div className="text-lg font-black text-slate-900 mt-0.5">{totalCount}</div>
            </div>
            <div className="border border-emerald-200 rounded-lg p-2 bg-emerald-50/60">
              <div className="text-[10px] font-bold text-emerald-800 uppercase">Disponibles</div>
              <div className="text-lg font-black text-emerald-600 mt-0.5">{availableCount}</div>
            </div>
            <div className="border border-blue-200 rounded-lg p-2 bg-blue-50/60">
              <div className="text-[10px] font-bold text-blue-800 uppercase">Asignados</div>
              <div className="text-lg font-black text-blue-600 mt-0.5">{assignedCount}</div>
            </div>
            <div className="border border-amber-200 rounded-lg p-2 bg-amber-50/60">
              <div className="text-[10px] font-bold text-amber-800 uppercase">En Mantenimiento</div>
              <div className="text-lg font-black text-amber-600 mt-0.5">{maintenanceCount}</div>
            </div>
            <div className="border border-rose-200 rounded-lg p-2 bg-rose-50/60">
              <div className="text-[10px] font-bold text-rose-800 uppercase">De Baja</div>
              <div className="text-lg font-black text-rose-600 mt-0.5">{retiredCount}</div>
            </div>
          </div>

          {/* Listado de Equipos por Grupos */}
          <div className="space-y-6">
            {Object.keys(groups).length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-sm border border-dashed border-slate-300 rounded-lg">
                No se encontraron equipos que coincidan con los criterios seleccionados.
              </div>
            ) : (
              Object.entries(groups).map(([groupName, items]) => (
                <div key={groupName} className="space-y-2">
                  {/* Encabezado del Grupo */}
                  <div className="flex items-center justify-between border-b-2 border-slate-800 pb-1 break-after-avoid">
                    <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-slate-800 inline-block"></span>
                      {groupName}
                    </h2>
                    <span className="text-[11px] font-bold text-slate-500">
                      {items.length} {items.length === 1 ? 'equipo' : 'equipos'}
                    </span>
                  </div>

                  {/* Tabla de Equipos */}
                  <table className="w-full text-left border-collapse text-[10px]">
                    <thead>
                      <tr className="bg-slate-100 text-slate-700 font-bold border-y border-slate-300">
                        <th className="py-1.5 px-2 w-7 text-center">N°</th>
                        <th className="py-1.5 px-2 w-28">Serial / S/N</th>
                        <th className="py-1.5 px-2">Descripción / Modelo</th>
                        <th className="py-1.5 px-2 w-24">Almacén</th>
                        <th className="py-1.5 px-2 w-24 text-center">Estado</th>
                        <th className="py-1.5 px-2 w-32">Custodia / Asignado</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {items.map((eq, idx) => {
                        const badge = statusBadges[eq.status] || {
                          bg: 'bg-slate-100',
                          text: 'text-slate-800',
                          border: 'border-slate-300',
                        }
                        const showBarcodeSub =
                          eq.barcode &&
                          eq.barcode.trim().toLowerCase() !== eq.serial_number.trim().toLowerCase()
                        return (
                          <tr key={eq.id} className="hover:bg-slate-50/50 break-inside-avoid">
                            <td className="py-1.5 px-2 text-center font-mono text-slate-500">
                              {idx + 1}
                            </td>
                            <td className="py-1.5 px-2 font-mono font-bold text-slate-900 select-all">
                              {eq.serial_number}
                              {showBarcodeSub && (
                                <span className="block text-[9px] font-mono text-slate-400">
                                  {eq.barcode}
                                </span>
                              )}
                            </td>
                            <td className="py-1.5 px-2">
                              <div className="font-semibold text-slate-800 leading-tight">
                                {eq.name}
                              </div>
                              <div className="text-[9px] text-slate-500">
                                {[eq.brand, eq.model].filter(Boolean).join(' • ') || '—'}
                              </div>
                            </td>
                            <td className="py-1.5 px-2 text-slate-700">
                              {eq.current_warehouse?.name || '—'}
                            </td>
                            <td className="py-1.5 px-2 text-center">
                              <span
                                className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-bold border ${badge.bg} ${badge.text} ${badge.border}`}
                              >
                                {statusLabels[eq.status] || eq.status}
                              </span>
                            </td>
                            <td className="py-1.5 px-2 text-slate-700 font-medium">
                              {eq.assigned_to || (
                                <span className="text-slate-400 italic">No asignado</span>
                              )}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Firmas de Control Institucional */}
        <div className="pt-10 mt-8 border-t border-slate-300 break-inside-avoid">
          <div className="grid grid-cols-2 gap-12 text-center">
            {/* Firma 1: Responsable de Inventario */}
            <div>
              <div className="border-b border-slate-900 pb-1 mx-6 mb-2">
                <span className="invisible select-none">Firma</span>
              </div>
              <p className="font-bold text-xs text-slate-900">
                {user?.full_name || 'Responsable de Inventario'}
              </p>
              <p className="text-[10px] text-slate-500">Control de Activos y Almacén</p>
              <p className="text-[9px] text-slate-400 mt-0.5">FIRMA Y FECHA</p>
            </div>

            {/* Firma 2: Gerencia / Auditoría */}
            <div>
              <div className="border-b border-slate-900 pb-1 mx-6 mb-2">
                <span className="invisible select-none">Firma</span>
              </div>
              <p className="font-bold text-xs text-slate-900">
                Gerencia de Sistemas / Auditoría
              </p>
              <p className="text-[10px] text-slate-500">Visto Bueno y Conformidad</p>
              <p className="text-[9px] text-slate-400 mt-0.5">FIRMA Y SELLO</p>
            </div>
          </div>

          <div className="text-center text-[9px] text-slate-400 mt-8">
            Documento emitido oficialmente por {config?.name || 'InventoryOS'}. Válido para auditorías y control interno.
          </div>
        </div>
      </div>
    </div>
  )
}

