import { useState, useEffect } from 'react'
import {
  X,
  Wrench,
  Plus,
  Trash2,
  Cpu,
  CheckCircle2,
  Calendar,
  User,
  DollarSign,
  Sparkles,
} from 'lucide-react'
import {
  equipmentApi,
  type Equipment,
  type EquipmentMaintenance,
} from '../../api/equipment'

interface Props {
  equipment: Equipment
  onClose: () => void
  onUpdated: () => void
}

const PRESET_EVENTS = [
  {
    type: 'preventive',
    title: 'Mantenimiento Preventivo + Pasta Térmica',
    desc: 'Limpieza interna de ventiladores, disipador, cambio de pasta térmica y optimización de sistema operativo.',
  },
  {
    type: 'upgrade',
    title: 'Upgrade de Memoria RAM / Disco SSD NVMe',
    desc: 'Ampliación de capacidad de hardware para mayor rendimiento.',
  },
  {
    type: 'corrective',
    title: 'Reemplazo de Batería / Teclado / Cargador',
    desc: 'Sustitución de componente por desgaste operativo.',
  },
  {
    type: 'preventive',
    title: 'Formateo, Respaldo y Reinstalación Corporativa',
    desc: 'Instalación limpia de Windows / Office y políticas de seguridad TI.',
  },
]

export function EquipmentMaintenanceModal({ equipment, onClose, onUpdated }: Props) {
  const [maintenances, setMaintenances] = useState<EquipmentMaintenance[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const defaultTech = localStorage.getItem('deliv_mgr_name') || 'Raimundo Gil'

  const [form, setForm] = useState({
    maintenance_type: 'preventive',
    title: '',
    description: '',
    cost: '',
    performed_by: defaultTech,
    performed_at: new Date().toISOString().slice(0, 10),
    new_specs: equipment.notes || '',
    update_equipment_specs: false,
  })

  const loadMaintenances = async () => {
    setIsLoading(true)
    try {
      const list = await equipmentApi.listMaintenances(equipment.id)
      setMaintenances(list)
    } catch (err) {
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadMaintenances()
  }, [equipment.id])

  const handleApplyPreset = (preset: (typeof PRESET_EVENTS)[0]) => {
    setForm((f) => ({
      ...f,
      maintenance_type: preset.type,
      title: preset.title,
      description: preset.desc,
      update_equipment_specs: preset.type === 'upgrade',
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title.trim()) return

    setIsSubmitting(true)
    try {
      await equipmentApi.createMaintenance(equipment.id, {
        maintenance_type: form.maintenance_type,
        title: form.title.trim(),
        description: form.description.trim() || undefined,
        cost: form.cost ? parseFloat(form.cost) : 0,
        performed_by: form.performed_by.trim() || defaultTech,
        performed_at: form.performed_at,
        new_specs: form.update_equipment_specs ? form.new_specs.trim() : undefined,
        update_equipment_specs: form.update_equipment_specs,
      })

      setForm((f) => ({
        ...f,
        title: '',
        description: '',
        cost: '',
        update_equipment_specs: false,
      }))
      await loadMaintenances()
      onUpdated()
    } catch (err) {
      console.error(err)
      alert('No se pudo registrar el mantenimiento.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async (maintId: string) => {
    if (!window.confirm('¿Eliminar este registro de la Hoja de Vida del equipo?')) return
    try {
      await equipmentApi.deleteMaintenance(equipment.id, maintId)
      await loadMaintenances()
    } catch (err) {
      console.error(err)
    }
  }

  const typeBadge = (type: string) => {
    if (type === 'upgrade') {
      return (
        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1">
          <Cpu className="w-3 h-3" />
          <span>UPGRADE HARDWARE</span>
        </span>
      )
    }
    if (type === 'corrective') {
      return (
        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
          REPARACIÓN / CORRECTIVO
        </span>
      )
    }
    return (
      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
        PREVENTIVO
      </span>
    )
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-slate-900 w-full sm:max-w-2xl sm:rounded-2xl border border-slate-800 max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Cabecera */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-primary/15 text-primary rounded-lg">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-white font-bold text-base">
                Hoja de Vida Técnica y Mantenimientos
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                {equipment.name} • SN: {equipment.serial_number}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido */}
        <div className="overflow-y-auto flex-1 p-4 space-y-5">
          {/* Formulario para agregar nuevo evento */}
          <form
            onSubmit={handleSubmit}
            className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5" />
                <span>Registrar Nuevo Mantenimiento o Upgrade</span>
              </h3>
              <span className="text-[10px] text-slate-400">Plantillas rápidas:</span>
            </div>

            {/* Plantillas rápidas de 1 clic */}
            <div className="flex flex-wrap gap-1.5">
              {PRESET_EVENTS.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700/80 px-2.5 py-1 rounded-lg flex items-center gap-1 transition-colors"
                >
                  <Sparkles className="w-3 h-3 text-primary" />
                  <span>{p.title}</span>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="label">Tipo de Intervención</label>
                <select
                  value={form.maintenance_type}
                  onChange={(e) => {
                    const val = e.target.value
                    setForm((f) => ({
                      ...f,
                      maintenance_type: val,
                      update_equipment_specs: val === 'upgrade' ? true : f.update_equipment_specs,
                    }))
                  }}
                  className="input-field text-xs py-2"
                >
                  <option value="preventive">Mantenimiento Preventivo</option>
                  <option value="upgrade">Upgrade de Hardware / RAM / SSD</option>
                  <option value="corrective">Reparación / Correctivo</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="label">Título / Resumen *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Ampliación de RAM de 8GB a 16GB DDR4 + Limpieza"
                  value={form.title}
                  onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                  className="input-field text-xs py-2"
                />
              </div>
            </div>

            <div>
              <label className="label">Detalle Técnico Realizado</label>
              <textarea
                rows={2}
                placeholder="Descripción de los trabajos, repuestos instalados o diagnóstico..."
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                className="input-field text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="label">Fecha</label>
                <input
                  type="date"
                  value={form.performed_at}
                  onChange={(e) => setForm((f) => ({ ...f, performed_at: e.target.value }))}
                  className="input-field text-xs py-1.5"
                />
              </div>
              <div>
                <label className="label">Realizado / Autorizado por</label>
                <input
                  type="text"
                  value={form.performed_by}
                  onChange={(e) => setForm((f) => ({ ...f, performed_by: e.target.value }))}
                  className="input-field text-xs py-1.5"
                />
              </div>
              <div>
                <label className="label">Costo Inversión USD (Opcional)</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={form.cost}
                  onChange={(e) => setForm((f) => ({ ...f, cost: e.target.value }))}
                  className="input-field text-xs py-1.5 font-mono"
                />
              </div>
            </div>

            {/* Opción de actualizar ficha técnica automáticamente */}
            <div className="p-2.5 bg-slate-900/90 border border-slate-800 rounded-lg space-y-2">
              <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer font-medium">
                <input
                  type="checkbox"
                  checked={form.update_equipment_specs}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, update_equipment_specs: e.target.checked }))
                  }
                  className="rounded border-slate-700 bg-slate-950 text-primary"
                />
                <span>
                  Actualizar automáticamente las Especificaciones Técnicas del equipo (para próximas Actas y QR)
                </span>
              </label>

              {form.update_equipment_specs && (
                <input
                  type="text"
                  value={form.new_specs}
                  onChange={(e) => setForm((f) => ({ ...f, new_specs: e.target.value }))}
                  placeholder="Nuevas especificaciones (ej: Core i7 | 16GB RAM | SSD 1TB NVMe)"
                  className="input-field text-xs font-mono"
                />
              )}
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting || !form.title.trim()}
                className="btn-primary py-2 px-4 text-xs font-bold flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isSubmitting ? 'Guardando...' : 'Agregar a Hoja de Vida'}</span>
              </button>
            </div>
          </form>

          {/* Línea de Tiempo de Mantenimientos */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Historial Clínico del Equipo ({maintenances.length})
            </h3>

            {isLoading ? (
              <p className="text-xs text-slate-400 py-6 text-center">Cargando historial...</p>
            ) : maintenances.length === 0 ? (
              <div className="text-center py-8 bg-slate-950/40 border border-slate-800/80 rounded-xl space-y-1">
                <Wrench className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs font-semibold text-slate-300">
                  Sin mantenimientos ni upgrades registrados aún
                </p>
                <p className="text-[11px] text-slate-500">
                  Usa el formulario superior para registrar limpiezas, reparaciones o mejoras de hardware.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {maintenances.map((m) => (
                  <div
                    key={m.id}
                    className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-start justify-between gap-3"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        {typeBadge(m.maintenance_type)}
                        <span className="text-sm font-bold text-white">{m.title}</span>
                      </div>

                      {m.description && (
                        <p className="text-xs text-slate-300 leading-relaxed">{m.description}</p>
                      )}

                      {m.new_specs && (
                        <p className="text-[11px] font-mono text-purple-300 bg-purple-950/30 border border-purple-800/40 px-2 py-0.5 rounded inline-block">
                          Ficha actualizada: {m.new_specs}
                        </p>
                      )}

                      <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {m.performed_at}
                        </span>
                        {m.performed_by && (
                          <span className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {m.performed_by}
                          </span>
                        )}
                        {m.cost && Number(m.cost) > 0 ? (
                          <span className="flex items-center gap-0.5 text-emerald-400 font-mono">
                            <DollarSign className="w-3 h-3" />
                            {Number(m.cost).toFixed(2)}
                          </span>
                        ) : null}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDelete(m.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-900"
                      title="Eliminar registro"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

