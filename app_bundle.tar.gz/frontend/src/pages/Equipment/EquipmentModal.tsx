import { useState, useEffect, useMemo, useRef } from 'react'
import {
  X,
  Package,
  ArrowLeftRight,
  Pencil,
  Trash2,
  QrCode,
  ScanLine,
  Barcode,
  Plus,
  Check,
  Sparkles,
  Tag,
  Layers,
  Camera,
  Printer,
  CheckCircle2
} from 'lucide-react'
import {
  equipmentApi,
  DEFAULT_BRAND_CATALOG,
  DEFAULT_CATEGORY_CATALOG,
  getCategoryLabel,
  type Equipment,
  type EquipmentCategory,
  type EquipmentStatus,
  type CatalogItem
} from '../../api/equipment'
import { movementsApi, type MovementType } from '../../api/movements'
import { type Warehouse } from '../../api/warehouses'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { MovementTypeBadge } from '../../components/ui/MovementTypeBadge'
import { BarcodeScanner } from '../../components/BarcodeScanner/BarcodeScanner'
import { useAuthStore } from '../../store/authStore'

const STATUS_OPTIONS: { value: EquipmentStatus; label: string }[] = [
  { value: 'available', label: 'Disponible' },
  { value: 'assigned', label: 'Asignado' },
  { value: 'maintenance', label: 'Mantenimiento' },
  { value: 'retired', label: 'Retirado' },
  { value: 'lost', label: 'Extraviado' },
]

const BRAND_GROUPS = [
  { id: 'top', label: '⭐ Más Usadas' },
  { id: 'Computación', label: '💻 Computación' },
  { id: 'Redes', label: '🌐 Redes / Telecom' },
  { id: 'Impresión', label: '🖨️ Impresión / Periféricos' },
  { id: 'Energía', label: '🔋 Energía / Discos' },
  { id: 'all', label: '📋 Todas' },
]

const TOP_BRAND_NAMES = new Set([
  'Lenovo',
  'HP',
  'Dell',
  'ASUS',
  'Acer',
  'MSI',
  'Apple',
  'Samsung',
  'LG',
  'Ubiquiti',
  'Cisco',
  'MikroTik',
  'TP-Link',
  'Epson',
  'Brother',
  'Logitech',
  'APC',
  'Forza',
  'Hikvision',
  'Grandstream',
])

interface Props {
  equipment: Equipment | null
  cloneTemplate?: Equipment | null
  initialBatchMode?: boolean
  warehouses: Warehouse[]
  initialTab?: 'info' | 'movement'
  initialScannedCode?: string
  onClose: () => void
  onSaved: () => void
}

export function EquipmentModal({
  equipment,
  cloneTemplate = null,
  initialBatchMode = false,
  warehouses,
  initialTab = 'movement',
  initialScannedCode,
  onClose,
  onSaved,
}: Props) {
  const { user } = useAuthStore()
  const isAdmin = user?.role === 'admin'
  const isNew = !equipment
  const sourceItem = equipment || cloneTemplate

  const [tab, setTab] = useState<'info' | 'movement'>(isNew ? 'info' : initialTab)
  const [isBatchMode, setIsBatchMode] = useState<boolean>(isNew && (initialBatchMode || !!cloneTemplate))
  const [batchSerials, setBatchSerials] = useState<string[]>(
    initialScannedCode && initialBatchMode ? [initialScannedCode] : []
  )
  const [gunInput, setGunInput] = useState<string>('')
  const [gunFeedback, setGunFeedback] = useState<{ text: string; type: 'ok' | 'dup' } | null>(null)
  const gunInputRef = useRef<HTMLInputElement>(null)

  const [createdBatchResult, setCreatedBatchResult] = useState<{
    createdCount: number
    skippedSerials: string[]
    items: Equipment[]
  } | null>(null)
  const [isDownloadingLabels, setIsDownloadingLabels] = useState(false)

  const [isSaving, setIsSaving] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successBanner, setSuccessBanner] = useState<string | null>(null)
  const [scanTarget, setScanTarget] = useState<'serial_number' | 'barcode' | 'batch_burst' | null>(null)

  // Catálogos dinámicos de Marcas y Categorías
  const [brandCatalog, setBrandCatalog] = useState<CatalogItem[]>(DEFAULT_BRAND_CATALOG)
  const [categoryCatalog, setCategoryCatalog] = useState<CatalogItem[]>(DEFAULT_CATEGORY_CATALOG)
  const [selectedBrandGroup, setSelectedBrandGroup] = useState<string>('top')
  const [categoryInputText, setCategoryInputText] = useState<string>(
    sourceItem?.category ? getCategoryLabel(sourceItem.category) : 'Laptop / Portátil'
  )
  const [isSavingCatalogItem, setIsSavingCatalogItem] = useState(false)
  const [nameManuallyEdited, setNameManuallyEdited] = useState<boolean>(!!sourceItem?.name)

  // Formulario de equipo (Edición / Creación / Plantilla de Lote)
  const [form, setForm] = useState({
    serial_number: equipment?.serial_number ?? (initialScannedCode || ''),
    barcode: equipment?.barcode ?? (initialScannedCode || ''),
    name: sourceItem?.name ?? '',
    brand: sourceItem?.brand ?? '',
    model: sourceItem?.model ?? '',
    category: (sourceItem?.category ?? 'laptop') as EquipmentCategory,
    status: (equipment?.status ?? 'available') as EquipmentStatus,
    current_warehouse_id: sourceItem?.current_warehouse_id ?? (warehouses[0]?.id || ''),
    assigned_to: equipment?.assigned_to ?? '',
    notes: sourceItem?.notes ?? '',
    purchase_date: sourceItem?.purchase_date ?? '',
    purchase_price:
      sourceItem?.purchase_price !== null && sourceItem?.purchase_price !== undefined
        ? String(sourceItem.purchase_price)
        : '',
    expected_lifespan_years: sourceItem?.expected_lifespan_years ?? 3,
    warranty_expires: sourceItem?.warranty_expires ?? '',
  })

  // Cargar catálogos desde el backend
  useEffect(() => {
    let mounted = true
    equipmentApi
      .getCatalogs()
      .then((res) => {
        if (!mounted) return
        if (res.brands?.length) setBrandCatalog(res.brands)
        if (res.categories?.length) {
          setCategoryCatalog(res.categories)
          if (sourceItem?.category) {
            const matched = res.categories.find(
              (c) =>
                c.value.toLowerCase() === sourceItem.category.toLowerCase() ||
                c.label.toLowerCase() === sourceItem.category.toLowerCase()
            )
            if (matched) setCategoryInputText(matched.label)
          }
        }
      })
      .catch(() => {
        // Fallback silencioso al catálogo local
      })
    return () => {
      mounted = false
    }
  }, [sourceItem?.category])

  const buildSuggestedName = (catVal: string, catLabel: string, brandVal: string, modelVal: string) => {
    const shortCat = (catLabel || getCategoryLabel(catVal)).split('/')[0].trim()
    const parts = [shortCat, brandVal.trim(), modelVal.trim()].filter(Boolean)
    return parts.join(' ')
  }

  const handleSelectCategoryChip = (cat: CatalogItem) => {
    setCategoryInputText(cat.label)
    setForm((prev) => {
      const next = { ...prev, category: cat.value }
      if (isNew && !nameManuallyEdited && (prev.brand || prev.model)) {
        next.name = buildSuggestedName(cat.value, cat.label, prev.brand, prev.model)
      }
      return next
    })
  }

  const handleCategoryInputChange = (rawText: string) => {
    setCategoryInputText(rawText)
    const trimmed = rawText.trim()
    if (!trimmed) {
      setForm((prev) => ({ ...prev, category: 'other' }))
      return
    }
    const existing = categoryCatalog.find(
      (c) =>
        c.label.toLowerCase() === trimmed.toLowerCase() ||
        c.value.toLowerCase() === trimmed.toLowerCase()
    )
    const resolvedCategory = existing ? existing.value : trimmed
    setForm((prev) => {
      const next = { ...prev, category: resolvedCategory }
      if (isNew && !nameManuallyEdited && (prev.brand || prev.model)) {
        next.name = buildSuggestedName(
          resolvedCategory,
          existing ? existing.label : trimmed,
          prev.brand,
          prev.model
        )
      }
      return next
    })
  }

  const handleSelectBrandChip = (brandName: string) => {
    setForm((prev) => {
      const nextBrand = prev.brand === brandName ? '' : brandName
      const next = { ...prev, brand: nextBrand }
      if (isNew && !nameManuallyEdited && (nextBrand || prev.model)) {
        next.name = buildSuggestedName(prev.category, categoryInputText, nextBrand, prev.model)
      }
      return next
    })
  }

  const handleBrandInputChange = (val: string) => {
    setForm((prev) => {
      const next = { ...prev, brand: val }
      if (isNew && !nameManuallyEdited && (val.trim() || prev.model)) {
        next.name = buildSuggestedName(prev.category, categoryInputText, val, prev.model)
      }
      return next
    })
  }

  const handleModelInputChange = (val: string) => {
    setForm((prev) => {
      const next = { ...prev, model: val }
      if (isNew && !nameManuallyEdited && (prev.brand || val.trim())) {
        next.name = buildSuggestedName(prev.category, categoryInputText, prev.brand, val)
      }
      return next
    })
  }

  const isCustomNewCategory = useMemo(() => {
    const clean = categoryInputText.trim()
    if (!clean) return false
    return !categoryCatalog.some(
      (c) =>
        c.label.toLowerCase() === clean.toLowerCase() ||
        c.value.toLowerCase() === clean.toLowerCase()
    )
  }, [categoryInputText, categoryCatalog])

  const isCustomNewBrand = useMemo(() => {
    const clean = form.brand.trim()
    if (!clean) return false
    return !brandCatalog.some(
      (b) =>
        b.value.toLowerCase() === clean.toLowerCase() ||
        b.label.toLowerCase() === clean.toLowerCase()
    )
  }, [form.brand, brandCatalog])

  const handleQuickSaveCatalogItem = async (type: 'brand' | 'category') => {
    const rawLabel = type === 'brand' ? form.brand.trim() : categoryInputText.trim()
    if (!rawLabel) return
    setIsSavingCatalogItem(true)
    try {
      const created = await equipmentApi.addCatalogItem({
        item_type: type,
        label: rawLabel,
        value: rawLabel,
        group_name: 'Personalizadas',
      })
      if (type === 'brand') {
        setBrandCatalog((prev) =>
          prev.some((b) => b.value.toLowerCase() === created.value.toLowerCase())
            ? prev
            : [...prev, created]
        )
      } else {
        setCategoryCatalog((prev) =>
          prev.some((c) => c.value.toLowerCase() === created.value.toLowerCase())
            ? prev
            : [...prev, created]
        )
        setForm((f) => ({ ...f, category: created.value }))
      }
    } catch {
      const localItem: CatalogItem = {
        item_type: type,
        value: rawLabel,
        label: rawLabel,
        group_name: 'Personalizadas',
        is_custom: true,
      }
      if (type === 'brand') {
        setBrandCatalog((prev) => [...prev, localItem])
      } else {
        setCategoryCatalog((prev) => [...prev, localItem])
        setForm((f) => ({ ...f, category: rawLabel }))
      }
    } finally {
      setIsSavingCatalogItem(false)
    }
  }

  const visibleBrands = useMemo(() => {
    const query = form.brand.trim().toLowerCase()
    const exactMatch = brandCatalog.some((b) => b.value.toLowerCase() === query)
    if (query && !exactMatch) {
      const matches = brandCatalog.filter(
        (b) =>
          b.label.toLowerCase().includes(query) ||
          (b.group_name && b.group_name.toLowerCase().includes(query))
      )
      if (matches.length > 0) return matches
    }

    if (selectedBrandGroup === 'all') return brandCatalog
    if (selectedBrandGroup === 'top') {
      return brandCatalog.filter((b) => TOP_BRAND_NAMES.has(b.value) || b.is_custom)
    }
    if (selectedBrandGroup === 'Computación') {
      return brandCatalog.filter((b) => b.group_name?.includes('Computación') || b.group_name?.includes('Monitores'))
    }
    if (selectedBrandGroup === 'Redes') {
      return brandCatalog.filter(
        (b) =>
          b.group_name?.includes('Redes') ||
          b.group_name?.includes('Seguridad') ||
          b.group_name?.includes('Telefonía') ||
          b.group_name?.includes('Móvil')
      )
    }
    if (selectedBrandGroup === 'Impresión') {
      return brandCatalog.filter(
        (b) =>
          b.group_name?.includes('Impresión') ||
          b.group_name?.includes('Periféricos') ||
          b.group_name?.includes('Audio') ||
          b.group_name?.includes('Escáneres')
      )
    }
    if (selectedBrandGroup === 'Energía') {
      return brandCatalog.filter(
        (b) => b.group_name?.includes('Energía') || b.group_name?.includes('Almacenamiento')
      )
    }
    return brandCatalog
  }, [brandCatalog, selectedBrandGroup, form.brand])

  // Agregar uno o múltiples seriales (por cámara en ráfaga, pistola lectora USB/Bluetooth o pegado múltiple)
  const addSerialsToBatch = (rawInput: string) => {
    const tokens = rawInput
      .split(/[\r\n,;]+/)
      .map((s) => s.trim())
      .filter(Boolean)

    if (tokens.length === 0) return

    setBatchSerials((prev) => {
      const existingLower = new Set(prev.map((p) => p.toLowerCase()))
      const added: string[] = []
      const dups: string[] = []

      for (const token of tokens) {
        if (existingLower.has(token.toLowerCase())) {
          dups.push(token)
        } else {
          existingLower.add(token.toLowerCase())
          added.push(token)
        }
      }

      if (added.length > 0) {
        setGunFeedback({
          text:
            added.length === 1
              ? `✅ Serial "${added[0]}" agregado (#${prev.length + 1})`
              : `✅ ${added.length} seriales agregados al lote`,
          type: 'ok',
        })
      } else if (dups.length > 0) {
        setGunFeedback({
          text: `⚠️ El serial "${dups[0]}" ya está en la lista del lote`,
          type: 'dup',
        })
      }

      return added.length > 0 ? [...prev, ...added] : prev
    })
  }

  const removeBatchSerial = (serialToRemove: string) => {
    setBatchSerials((prev) => prev.filter((s) => s !== serialToRemove))
  }

  const handleGunKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      if (!gunInput.trim()) return
      addSerialsToBatch(gunInput)
      setGunInput('')
      setTimeout(() => gunInputRef.current?.focus(), 10)
    }
  }

  const handleScanComplete = (scannedCode: string) => {
    if (!scanTarget) return
    if (scanTarget === 'batch_burst') {
      addSerialsToBatch(scannedCode)
      return
    }
    setForm((f) => {
      const updated = { ...f, [scanTarget]: scannedCode }
      if (scanTarget === 'serial_number' && !f.barcode) {
        updated.barcode = scannedCode
      }
      return updated
    })
    setScanTarget(null)
  }

  // Formulario de movimiento rápido (Entrada, Salida, Traslado)
  const [mvForm, setMvForm] = useState({
    type: 'exit' as MovementType,
    to_warehouse_id: warehouses[0]?.id || '',
    assigned_to: '',
    notes: '',
  })

  const saveEquipmentRecord = async (keepOpenForNext: boolean) => {
    if (!form.name.trim()) return

    if (isNew && isBatchMode) {
      // Si el usuario dejó un serial escrito en el campo de pistola sin pulsar Enter, incluirlo
      const pendingGun = gunInput.trim()
      const finalSerials = pendingGun
        ? Array.from(new Set([...batchSerials, pendingGun]))
        : batchSerials

      if (finalSerials.length === 0) {
        setError('Escanea con la cámara o dispara con la pistola lectora al menos un número de serie.')
        return
      }

      setIsSaving(true)
      setError(null)
      setSuccessBanner(null)
      try {
        const finalCategory = (form.category || categoryInputText || 'laptop').trim()
        const response = await equipmentApi.createBatch({
          serial_numbers: finalSerials,
          name: form.name.trim(),
          brand: form.brand?.trim() || undefined,
          model: form.model?.trim() || undefined,
          category: finalCategory,
          status: form.status,
          current_warehouse_id: form.current_warehouse_id || undefined,
          assigned_to: form.assigned_to?.trim() || undefined,
          notes: form.notes?.trim() || undefined,
          purchase_date: form.purchase_date || null,
          purchase_price: form.purchase_price ? Number(form.purchase_price) : null,
          expected_lifespan_years: Number(form.expected_lifespan_years) || 3,
          warranty_expires: form.warranty_expires || null,
        })

        setGunInput('')
        setBatchSerials([])
        setCreatedBatchResult({
          createdCount: response.created_count,
          skippedSerials: response.skipped_serials || [],
          items: response.items || [],
        })
        onSaved()
      } catch (err: any) {
        setError(err?.response?.data?.detail ?? 'Error al registrar el lote de equipos')
      } finally {
        setIsSaving(false)
      }
      return
    }

    if (!form.serial_number.trim()) return

    setIsSaving(true)
    setError(null)
    setSuccessBanner(null)
    try {
      const finalCategory = (form.category || categoryInputText || 'laptop').trim()
      const payload = {
        serial_number: form.serial_number.trim(),
        barcode: form.barcode?.trim() || undefined,
        name: form.name.trim(),
        brand: form.brand?.trim() || undefined,
        model: form.model?.trim() || undefined,
        category: finalCategory,
        status: form.status,
        current_warehouse_id: form.current_warehouse_id || undefined,
        assigned_to: form.assigned_to?.trim() || undefined,
        notes: form.notes?.trim() || undefined,
        purchase_date: form.purchase_date || null,
        purchase_price: form.purchase_price ? Number(form.purchase_price) : null,
        expected_lifespan_years: Number(form.expected_lifespan_years) || 3,
        warranty_expires: form.warranty_expires || null,
      }

      if (isNew) {
        await equipmentApi.create(payload)
      } else {
        await equipmentApi.update(equipment!.id, payload)
      }

      if (isCustomNewBrand && form.brand.trim()) {
        const cleanB = form.brand.trim()
        setBrandCatalog((prev) => [
          ...prev,
          { item_type: 'brand', value: cleanB, label: cleanB, group_name: 'Personalizadas', is_custom: true },
        ])
      }
      if (isCustomNewCategory && categoryInputText.trim()) {
        const cleanC = categoryInputText.trim()
        setCategoryCatalog((prev) => [
          ...prev,
          { item_type: 'category', value: cleanC, label: cleanC, group_name: 'Personalizadas', is_custom: true },
        ])
      }

      onSaved()

      if (keepOpenForNext && isNew) {
        const savedSerial = form.serial_number.trim()
        setForm((prev) => ({
          ...prev,
          serial_number: '',
          barcode: '',
        }))
        setSuccessBanner(
          `✅ Equipo "${form.name.trim()}" (SN: ${savedSerial}) cargado exitosamente. Escanea o escribe el siguiente serial.`
        )
      } else {
        onClose()
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al guardar los datos del equipo')
    } finally {
      setIsSaving(false)
    }
  }

  const handleSaveEquipment = async (e: React.FormEvent) => {
    e.preventDefault()
    await saveEquipmentRecord(false)
  }

  const handleDownloadCreatedBatchLabels = async () => {
    if (!createdBatchResult?.items?.length) return
    setIsDownloadingLabels(true)
    try {
      const ids = createdBatchResult.items.map((i) => i.id)
      await equipmentApi.downloadLabelsPdf(ids, window.location.origin)
    } catch {
      setError('No se pudo descargar el PDF de etiquetas QR del lote.')
    } finally {
      setIsDownloadingLabels(false)
    }
  }

  const handleSaveMovement = async () => {
    if (!equipment) return
    setIsSaving(true)
    setError(null)
    try {
      await movementsApi.create({
        type: mvForm.type,
        equipment_id: equipment.id,
        from_warehouse_id: equipment.current_warehouse_id ?? undefined,
        to_warehouse_id: mvForm.to_warehouse_id || undefined,
        assigned_to: mvForm.assigned_to?.trim() || undefined,
        notes: mvForm.notes?.trim() || undefined,
      })
      onSaved()
      onClose()
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al registrar el movimiento')
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteEquipment = async () => {
    if (!equipment) return
    const confirmed = window.confirm(
      `¿Estás seguro de eliminar el equipo "${equipment.name}" (SN: ${equipment.serial_number})?`
    )
    if (!confirmed) return

    setIsDeleting(true)
    setError(null)
    try {
      await equipmentApi.delete(equipment.id)
      onSaved()
      onClose()
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al eliminar el equipo')
    } finally {
      setIsDeleting(false)
    }
  }

  const canSubmitEquipment = isNew
    ? isBatchMode
      ? Boolean(form.name.trim() && (batchSerials.length > 0 || gunInput.trim().length > 0))
      : Boolean(form.name.trim() && form.serial_number.trim())
    : Boolean(form.name.trim() && form.serial_number.trim())

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-slate-900 w-full sm:max-w-2xl sm:rounded-2xl border border-slate-800 max-h-[94vh] flex flex-col shadow-2xl safe-bottom overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Encabezado */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 flex-shrink-0 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <Package className="w-5 h-5 text-primary" />
            <div>
              <h2 className="text-white font-bold text-base truncate">
                {isNew
                  ? cloneTemplate
                    ? `Cargar Lote de: ${cloneTemplate.name}`
                    : 'Cargar Nuevo Equipo al Inventario'
                  : equipment?.name}
              </h2>
              {isNew && (
                <p className="text-[11px] text-slate-400">
                  Carga un equipo individual o escanea un lote de seriales de equipos iguales
                </p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selector de Modo al crear nuevo equipo: Individual vs Lote de Equipos Iguales */}
        {isNew && !createdBatchResult && (
          <div className="grid grid-cols-2 p-1.5 bg-slate-950 border-b border-slate-800 gap-1.5 flex-shrink-0">
            <button
              type="button"
              onClick={() => setIsBatchMode(false)}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                !isBatchMode
                  ? 'bg-primary text-white shadow-md shadow-primary/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>1 Equipo Individual</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setIsBatchMode(true)
                if (form.serial_number.trim() && batchSerials.length === 0) {
                  setBatchSerials([form.serial_number.trim()])
                }
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                isBatchMode
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>⚡ Lote de Equipos Iguales (Varios Seriales)</span>
            </button>
          </div>
        )}

        {/* Pestañas (si el equipo ya existe) */}
        {!isNew && (
          <div className="flex border-b border-slate-800 flex-shrink-0 bg-slate-950/30">
            <button
              type="button"
              onClick={() => setTab('info')}
              className={`flex-1 py-3 text-xs uppercase font-bold tracking-wider transition-colors flex items-center justify-center gap-1.5 ${
                tab === 'info'
                  ? 'text-primary border-b-2 border-primary bg-primary/5'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Ficha Técnica y Edición</span>
            </button>
            <button
              type="button"
              onClick={() => setTab('movement')}
              className={`flex-1 py-3 text-xs uppercase font-bold tracking-wider transition-colors flex items-center justify-center gap-1.5 ${
                tab === 'movement'
                  ? 'text-primary border-b-2 border-primary bg-primary/5'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Registrar Movimiento</span>
            </button>
          </div>
        )}

        {/* Contenido scrolleable */}
        <div className="overflow-y-auto flex-1 p-4 space-y-4">
          {error && (
            <div className="text-rose-400 text-xs font-semibold bg-rose-950/40 border border-rose-900/60 rounded-xl p-3">
              {error}
            </div>
          )}

          {successBanner && (
            <div className="text-emerald-300 text-xs font-semibold bg-emerald-950/50 border border-emerald-700/60 rounded-xl p-3 flex items-center justify-between gap-2">
              <span>{successBanner}</span>
              <button
                type="button"
                onClick={() => setSuccessBanner(null)}
                className="text-emerald-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {/* PANTALLA DE RESUMEN POST-CREACIÓN DE LOTE */}
          {createdBatchResult ? (
            <div className="py-6 px-4 text-center space-y-5">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-black text-white">
                  ¡Lote de {createdBatchResult.createdCount} Equipos Registrado!
                </h3>
                <p className="text-xs text-slate-400">
                  Ficha aplicada: <strong className="text-white">{form.name}</strong> (
                  {getCategoryLabel(form.category)})
                </p>
              </div>

              {createdBatchResult.skippedSerials.length > 0 && (
                <div className="bg-amber-950/40 border border-amber-800/60 rounded-xl p-3 text-xs text-amber-300 text-left">
                  <p className="font-bold mb-1">
                    ⚠️ Se omitieron {createdBatchResult.skippedSerials.length} seriales que ya estaban registrados:
                  </p>
                  <p className="font-mono">{createdBatchResult.skippedSerials.join(', ')}</p>
                </div>
              )}

              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-left max-h-40 overflow-y-auto">
                <p className="text-[11px] font-bold text-slate-400 uppercase mb-2">
                  Seriales dados de alta en este lote:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {createdBatchResult.items.map((item, i) => (
                    <span
                      key={item.id}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 border border-emerald-800/50 text-emerald-300 font-mono text-xs"
                    >
                      #{i + 1} {item.serial_number}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  disabled={isDownloadingLabels}
                  onClick={handleDownloadCreatedBatchLabels}
                  className="w-full sm:w-auto px-5 py-3 rounded-xl bg-primary hover:brightness-110 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg"
                >
                  <Printer className="w-4 h-4" />
                  <span>
                    {isDownloadingLabels
                      ? 'Generando PDF de Etiquetas...'
                      : `Imprimir / Descargar ${createdBatchResult.createdCount} Etiquetas QR`}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setCreatedBatchResult(null)}
                  className="w-full sm:w-auto px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Escanear más seriales de este modelo</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* TAB 1: Información / Formulario de Creación, Lote y Edición */}
              {(isNew || tab === 'info') && (
                <form id="equipment-form" onSubmit={handleSaveEquipment} className="space-y-4">
                  {/* SECCIÓN DE SERIALES: MODO LOTE (OPCIÓN A + OPCIÓN B) vs MODO INDIVIDUAL */}
                  {isNew && isBatchMode ? (
                    <div className="bg-emerald-950/20 border-2 border-emerald-600/40 rounded-2xl p-3.5 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <span className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-300 uppercase tracking-wide">
                            <Layers className="w-4 h-4" />
                            <span>Cola de Seriales del Lote ({batchSerials.length} listos)</span>
                          </span>
                          <p className="text-[11px] text-slate-300 mt-0.5">
                            Usa <strong>Opción A</strong> (cámara del teléfono sin cerrarse) o{' '}
                            <strong>Opción B</strong> (pistola lectora USB/Bluetooth o teclado)
                          </p>
                        </div>

                        {/* OPCIÓN A: Botón de Cámara en Ráfaga Continua */}
                        <button
                          type="button"
                          onClick={() => setScanTarget('batch_burst')}
                          className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all flex-shrink-0"
                        >
                          <Camera className="w-4 h-4" />
                          <span>Opción A: Escáner Cámara en Ráfaga</span>
                        </button>
                      </div>

                      {/* OPCIÓN B: Campo para Pistola Lectora USB/Bluetooth o Teclado + Enter */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                          <Barcode className="w-3.5 h-3.5 text-emerald-400" />
                          <span>
                            Opción B: Pistola Lectora / Teclado (Dispara o escribe el serial y pulsa Enter)
                          </span>
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            ref={gunInputRef}
                            type="text"
                            value={gunInput}
                            onChange={(e) => setGunInput(e.target.value)}
                            onKeyDown={handleGunKeyDown}
                            placeholder="Dispara con la pistola lectora o escribe el serial y presiona Enter..."
                            className="input-field font-mono text-sm py-2 flex-1 border-emerald-700/50 focus:border-emerald-400"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (!gunInput.trim()) return
                              addSerialsToBatch(gunInput)
                              setGunInput('')
                              gunInputRef.current?.focus()
                            }}
                            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-700/50 font-bold text-xs flex items-center gap-1 flex-shrink-0"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Agregar</span>
                          </button>
                        </div>

                        {gunFeedback && (
                          <p
                            className={`text-[11px] font-semibold ${
                              gunFeedback.type === 'ok' ? 'text-emerald-400' : 'text-amber-400'
                            }`}
                          >
                            {gunFeedback.text}
                          </p>
                        )}
                      </div>

                      {/* Listado de Chips de Seriales Capturados */}
                      <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-2.5">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] font-bold text-slate-400">
                            {batchSerials.length === 0
                              ? 'Ningún serial agregado todavía'
                              : `${batchSerials.length} ${
                                  batchSerials.length === 1
                                    ? 'serial en cola para registrar'
                                    : 'seriales en cola para registrar'
                                }`}
                          </span>
                          {batchSerials.length > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                setBatchSerials([])
                                setGunFeedback(null)
                              }}
                              className="text-[11px] text-rose-400 hover:underline font-semibold"
                            >
                              Vaciar lista
                            </button>
                          )}
                        </div>

                        {batchSerials.length === 0 ? (
                          <p className="text-xs text-slate-500 text-center py-2">
                            Pulsa <strong>"Opción A: Escáner Cámara en Ráfaga"</strong> para escanear con el teléfono o dispara con la pistola lectora arriba.
                          </p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
                            {batchSerials.map((sn, idx) => (
                              <span
                                key={sn}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-emerald-600/40 text-white font-mono text-xs"
                              >
                                <span className="text-[10px] font-bold text-emerald-400">
                                  #{idx + 1}
                                </span>
                                <span>{sn}</span>
                                <button
                                  type="button"
                                  onClick={() => removeBatchSerial(sn)}
                                  className="text-slate-500 hover:text-rose-400 ml-0.5"
                                  title="Quitar este serial del lote"
                                >
                                  ✕
                                </button>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* MODO INDIVIDUAL: Escaneo Rápido con Cámara */}
                      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 bg-primary/10 text-primary rounded-lg flex-shrink-0">
                            <QrCode className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">Escanear con Cámara</p>
                            <p className="text-[11px] text-slate-400">
                              Captura código de barras o QR para autocompletar
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setScanTarget('serial_number')}
                            className="flex-1 sm:flex-none px-3 py-1.5 rounded-lg bg-primary hover:brightness-110 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                          >
                            <ScanLine className="w-3.5 h-3.5" />
                            <span>Escanear Serie</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setScanTarget('barcode')}
                            className="flex-1 sm:flex-none px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
                          >
                            <Barcode className="w-3.5 h-3.5" />
                            <span>Escanear Código</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="label">Número de Serie (S/N) *</label>
                          <div className="relative">
                            <input
                              className="input-field font-mono text-sm pr-9"
                              value={form.serial_number}
                              onChange={(e) =>
                                setForm((f) => ({ ...f, serial_number: e.target.value }))
                              }
                              placeholder="PF-3X99AB / V2509N0002754"
                              required={!isBatchMode}
                            />
                            <button
                              type="button"
                              title="Escanear Número de Serie con cámara"
                              onClick={() => setScanTarget('serial_number')}
                              className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-slate-400 hover:text-primary hover:bg-slate-800 transition-colors"
                            >
                              <ScanLine className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        <div>
                          <label className="label">Código de Barras / Activo (Opcional)</label>
                          <div className="relative">
                            <input
                              className="input-field font-mono text-sm pr-9"
                              value={form.barcode}
                              onChange={(e) => setForm((f) => ({ ...f, barcode: e.target.value }))}
                              placeholder="750123456789"
                            />
                            <button
                              type="button"
                              title="Escanear Código de Barras con cámara"
                              onClick={() => setScanTarget('barcode')}
                              className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-slate-400 hover:text-primary hover:bg-slate-800 transition-colors"
                            >
                              <Barcode className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {/* 1. CATEGORÍA DEL EQUIPO (Selección rápida + Escritura libre y guardado) */}
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <label className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-primary" />
                        <span>Categoría / Tipo de Equipo *</span>
                      </label>
                      <span className="text-[11px] text-slate-400">
                        Pulsa una categoría o escríbela si es nueva (se guardará automáticamente)
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <input
                          type="text"
                          className="input-field text-sm py-2 pr-24"
                          value={categoryInputText}
                          onChange={(e) => handleCategoryInputChange(e.target.value)}
                          placeholder="Escribe o selecciona (ej. Laptop, Monitor, Proyector, Dron, Cámara IP...)"
                        />
                        {isCustomNewCategory ? (
                          <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                            ✨ Nueva
                          </span>
                        ) : (
                          <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-semibold text-slate-500">
                            En catálogo
                          </span>
                        )}
                      </div>

                      {isCustomNewCategory && (
                        <button
                          type="button"
                          disabled={isSavingCatalogItem}
                          onClick={() => handleQuickSaveCatalogItem('category')}
                          className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 flex-shrink-0 shadow-sm transition-all"
                          title="Guardar esta categoría en el catálogo para próximos equipos"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Guardar Categoría</span>
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-0.5 max-h-32 overflow-y-auto">
                      {categoryCatalog.map((cat) => {
                        const isSelected =
                          form.category.toLowerCase() === cat.value.toLowerCase() ||
                          categoryInputText.trim().toLowerCase() === cat.label.toLowerCase()
                        return (
                          <button
                            key={cat.value}
                            type="button"
                            onClick={() => handleSelectCategoryChip(cat)}
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 border ${
                              isSelected
                                ? 'bg-primary text-white border-primary shadow-md shadow-primary/20'
                                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3" />}
                            <span>{cat.label}</span>
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* 2. CATÁLOGO DE MARCAS MÁS CONOCIDAS (Pulsar en 1 clic o escribir nueva) */}
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <label className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-primary" />
                        <span>Marca y Modelo del Equipo (Catálogo Rápido 1-Clic)</span>
                      </label>
                      <span className="text-[11px] text-slate-400">
                        Toca la marca para seleccionarla al instante o escribe otra
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div className="flex items-center gap-1.5">
                        <div className="relative flex-1">
                          <input
                            type="text"
                            className="input-field text-sm py-2 pr-16"
                            value={form.brand}
                            onChange={(e) => handleBrandInputChange(e.target.value)}
                            placeholder="Marca (ej. Lenovo, HP, Ubiquiti...)"
                          />
                          {form.brand && (
                            <button
                              type="button"
                              onClick={() => handleBrandInputChange('')}
                              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-white px-1"
                              title="Limpiar marca"
                            >
                              ✕
                            </button>
                          )}
                        </div>
                        {isCustomNewBrand && (
                          <button
                            type="button"
                            disabled={isSavingCatalogItem}
                            onClick={() => handleQuickSaveCatalogItem('brand')}
                            className="px-2.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 flex-shrink-0"
                            title="Guardar nueva marca en el catálogo"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Guardar</span>
                          </button>
                        )}
                      </div>

                      <div>
                        <input
                          type="text"
                          className="input-field text-sm py-2"
                          value={form.model}
                          onChange={(e) => handleModelInputChange(e.target.value)}
                          placeholder="Modelo (ej. ThinkPad E14 / A18 HX / LiteBeam)"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
                      {BRAND_GROUPS.map((grp) => (
                        <button
                          key={grp.id}
                          type="button"
                          onClick={() => setSelectedBrandGroup(grp.id)}
                          className={`px-2.5 py-1 rounded-md text-[11px] font-bold whitespace-nowrap transition-colors ${
                            selectedBrandGroup === grp.id
                              ? 'bg-slate-800 text-primary border border-primary/40'
                              : 'text-slate-400 hover:text-white hover:bg-slate-900'
                          }`}
                        >
                          {grp.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto pt-0.5">
                      {visibleBrands.map((b) => {
                        const isSelected = form.brand.trim().toLowerCase() === b.value.toLowerCase()
                        return (
                          <button
                            key={b.value}
                            type="button"
                            onClick={() => handleSelectBrandChip(b.value)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 border ${
                              isSelected
                                ? 'bg-primary text-white border-primary shadow-md shadow-primary/20 scale-[1.02]'
                                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3" />}
                            <span>{b.label}</span>
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Nombre del Equipo */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="label mb-0">Nombre / Descripción Corta del Equipo *</label>
                      {(form.brand || form.model || categoryInputText) && (
                        <button
                          type="button"
                          onClick={() => {
                            const suggested = buildSuggestedName(
                              form.category,
                              categoryInputText,
                              form.brand,
                              form.model
                            )
                            if (suggested) {
                              setForm((f) => ({ ...f, name: suggested }))
                              setNameManuallyEdited(false)
                            }
                          }}
                          className="text-[11px] text-primary hover:underline flex items-center gap-1 font-semibold"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Autocompletar con Categoría + Marca + Modelo</span>
                        </button>
                      )}
                    </div>
                    <input
                      className="input-field text-sm"
                      value={form.name}
                      onChange={(e) => {
                        setNameManuallyEdited(true)
                        setForm((f) => ({ ...f, name: e.target.value }))
                      }}
                      placeholder="Ej. Laptop Lenovo ThinkPad E14"
                      required
                    />
                  </div>

                  {/* Ubicación y Estado */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="label">Almacén o Sub-almacén de Ubicación</label>
                      <select
                        className="input-field text-sm"
                        value={form.current_warehouse_id}
                        onChange={(e) =>
                          setForm((f) => ({ ...f, current_warehouse_id: e.target.value }))
                        }
                      >
                        <option value="">Sin almacén asignado</option>
                        {warehouses.map((w) => (
                          <option key={w.id} value={w.id}>
                            {w.parent_name ? `↳ ${w.parent_name} › ${w.name}` : `🏢 ${w.name}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="label">Estado Actual</label>
                      <select
                        className="input-field text-sm"
                        value={form.status}
                        onChange={(e) =>
                          setForm((f) => ({ ...f, status: e.target.value as EquipmentStatus }))
                        }
                      >
                        {STATUS_OPTIONS.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {form.status === 'assigned' && (
                    <div>
                      <label className="label">Asignado a (Empleado / Proyecto)</label>
                      <input
                        className="input-field text-sm"
                        value={form.assigned_to}
                        onChange={(e) => setForm((f) => ({ ...f, assigned_to: e.target.value }))}
                        placeholder="Ej. Juan Pérez (Área Finanzas)"
                      />
                    </div>
                  )}

                  {/* Sección: Datos de Adquisición y Garantía */}
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-3">
                    <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span>📅 Datos de Adquisición y Garantía (Opcional)</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="label">Fecha de Compra</label>
                        <input
                          type="date"
                          className="input-field text-xs"
                          value={form.purchase_date}
                          onChange={(e) =>
                            setForm((f) => ({ ...f, purchase_date: e.target.value }))
                          }
                        />
                      </div>
                      <div>
                        <label className="label">Costo Unitario ($ USD)</label>
                        <input
                          type="number"
                          step="0.01"
                          className="input-field text-xs"
                          value={form.purchase_price}
                          onChange={(e) =>
                            setForm((f) => ({ ...f, purchase_price: e.target.value }))
                          }
                          placeholder="0.00"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="label">Vida Útil Estimada</label>
                        <select
                          className="input-field text-xs"
                          value={form.expected_lifespan_years}
                          onChange={(e) =>
                            setForm((f) => ({
                              ...f,
                              expected_lifespan_years: Number(e.target.value),
                            }))
                          }
                        >
                          <option value={2}>2 Años</option>
                          <option value={3}>3 Años (Estándar)</option>
                          <option value={4}>4 Años</option>
                          <option value={5}>5 Años</option>
                          <option value={7}>7 Años</option>
                          <option value={10}>10 Años</option>
                        </select>
                      </div>
                      <div>
                        <label className="label">Vencimiento de Garantía</label>
                        <input
                          type="date"
                          className="input-field text-xs"
                          value={form.warranty_expires}
                          onChange={(e) =>
                            setForm((f) => ({ ...f, warranty_expires: e.target.value }))
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="label">
                      Observaciones / Especificaciones Técnicas (Color, RAM, Disco, Procesador)
                    </label>
                    <textarea
                      className="input-field resize-none text-xs"
                      rows={2}
                      value={form.notes}
                      onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                      placeholder="Ej. Color Negro, 16GB RAM DDR5, 512GB SSD NVMe, Core i7..."
                    />
                  </div>
                </form>
              )}

              {/* TAB 2: Movimiento rápido */}
              {!isNew && tab === 'movement' && equipment && (
                <div className="space-y-4">
                  <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono text-slate-400">
                        SN: {equipment.serial_number}
                      </span>
                      <StatusBadge status={equipment.status} />
                    </div>
                    <p className="text-sm font-bold text-white">{equipment.name}</p>
                    <p className="text-xs text-slate-400">
                      Ubicación actual:{' '}
                      <span className="text-white font-medium">
                        {equipment.current_warehouse?.name ||
                          (equipment.assigned_to ? `Asignado a ${equipment.assigned_to}` : 'Sin asignar')}
                      </span>
                    </p>
                  </div>

                  <div>
                    <label className="label">Tipo de Movimiento</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['exit', 'transfer', 'return'] as MovementType[]).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setMvForm((f) => ({ ...f, type: t }))}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center ${
                            mvForm.type === t
                              ? 'border-primary bg-primary/10 text-white'
                              : 'border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <MovementTypeBadge type={t} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {mvForm.type === 'exit' && (
                    <div>
                      <label className="label">Empleado o Proyecto Destino *</label>
                      <input
                        className="input-field text-sm"
                        value={mvForm.assigned_to}
                        onChange={(e) => setMvForm((f) => ({ ...f, assigned_to: e.target.value }))}
                        placeholder="Ej. Roberto Martínez (Área Finanzas)"
                        autoFocus
                      />
                    </div>
                  )}

                  {(mvForm.type === 'transfer' || mvForm.type === 'return') && (
                    <div>
                      <label className="label">
                        {mvForm.type === 'transfer'
                          ? 'Almacén de Destino *'
                          : 'Retornar a Almacén *'}
                      </label>
                      <select
                        className="input-field text-sm"
                        value={mvForm.to_warehouse_id}
                        onChange={(e) =>
                          setMvForm((f) => ({ ...f, to_warehouse_id: e.target.value }))
                        }
                      >
                        <option value="">Selecciona almacén o contenedor...</option>
                        {warehouses.map((w) => (
                          <option key={w.id} value={w.id}>
                            {w.parent_name ? `↳ ${w.parent_name} › ${w.name}` : `🏢 ${w.name}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="label">Notas / Justificación</label>
                    <textarea
                      className="input-field resize-none text-xs"
                      rows={2}
                      value={mvForm.notes}
                      onChange={(e) => setMvForm((f) => ({ ...f, notes: e.target.value }))}
                      placeholder="Detalles sobre el motivo del movimiento..."
                    />
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Botonera de Acción */}
        <div className="p-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 flex-shrink-0 bg-slate-950/60">
          <div>
            {!isNew && (
              <button
                type="button"
                onClick={handleDeleteEquipment}
                disabled={isDeleting || isSaving}
                className="py-2.5 px-3 rounded-xl text-xs font-semibold text-rose-400 bg-rose-950/30 hover:bg-rose-900/40 border border-rose-900/60 transition-colors flex items-center gap-1.5"
                title="Eliminar este equipo del inventario"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeleting ? 'Eliminando...' : 'Eliminar'}</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button type="button" onClick={onClose} className="btn-secondary py-2.5 px-4 text-xs">
              Cerrar
            </button>

            {!createdBatchResult && !isNew && tab === 'movement' && (
              <button
                type="button"
                onClick={handleSaveMovement}
                disabled={isSaving || (mvForm.type === 'exit' && !mvForm.assigned_to.trim())}
                className="btn-primary py-2.5 px-4 text-xs"
              >
                <ArrowLeftRight className="w-4 h-4" />
                <span>{isSaving ? 'Registrando...' : 'Confirmar Movimiento'}</span>
              </button>
            )}

            {!createdBatchResult && isNew && !isBatchMode && (
              <button
                type="button"
                onClick={() => saveEquipmentRecord(true)}
                disabled={isSaving || !canSubmitEquipment}
                className="py-2.5 px-3.5 rounded-xl text-xs font-bold text-emerald-300 bg-emerald-950/50 hover:bg-emerald-900/60 border border-emerald-700/60 transition-all flex items-center gap-1.5"
                title="Guarda este equipo y mantiene la ventana lista con la misma marca y categoría para escanear el siguiente"
              >
                <Plus className="w-4 h-4" />
                <span>Guardar y Cargar Otro</span>
              </button>
            )}

            {!createdBatchResult && (isNew || tab === 'info') && (
              <button
                type="submit"
                form="equipment-form"
                disabled={isSaving || !canSubmitEquipment}
                className={`py-2.5 px-4 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all ${
                  isNew && isBatchMode
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20 disabled:opacity-50'
                    : 'btn-primary'
                }`}
              >
                {isSaving
                  ? 'Guardando...'
                  : isNew
                  ? isBatchMode
                    ? `Guardar Lote (${
                        batchSerials.length + (gunInput.trim() ? 1 : 0)
                      } Equipos)`
                    : 'Guardar Equipo'
                  : 'Guardar Cambios'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Visor de Escaneo con Cámara sobre el modal (Individual o Ráfaga Continua) */}
      {scanTarget && (
        <BarcodeScanner
          continuousMode={scanTarget === 'batch_burst'}
          scannedList={batchSerials}
          onRemoveFromList={removeBatchSerial}
          batchTitle={form.name || 'Lote de Equipos Iguales'}
          onResult={handleScanComplete}
          onClose={() => setScanTarget(null)}
        />
      )}
    </div>
  )
}
