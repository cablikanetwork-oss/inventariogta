import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Plus,
  Search,
  QrCode,
  Package,
  Pencil,
  Trash2,
  ArrowLeftRight,
  User,
  Barcode,
  Warehouse,
  AlertCircle,
  FileText,
  FileSpreadsheet,
  Download,
  Wrench,
  Layers
} from 'lucide-react'
import {
  equipmentApi,
  DEFAULT_CATEGORY_CATALOG,
  getCategoryLabel,
  type Equipment,
  type CatalogItem
} from '../../api/equipment'
import { warehousesApi, type Warehouse as WarehouseType } from '../../api/warehouses'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'
import { BarcodeScanner } from '../../components/BarcodeScanner/BarcodeScanner'
import { useAuthStore } from '../../store/authStore'
import { EquipmentModal } from './EquipmentModal'
import { EquipmentMaintenanceModal } from './EquipmentMaintenanceModal'
import { ImportExcelModal } from './ImportExcelModal'
import { ExportReportModal } from './ExportReportModal'
import { InventoryReportPrintView } from './InventoryReportPrintView'
import { NewActModal } from '../Acts/NewActModal'
import { ActDocumentView } from '../Acts/ActDocumentView'
import { type DeliveryAct } from '../../api/deliveryActs'

export function EquipmentPage() {
  const { user } = useAuthStore()
  const navigate = useNavigate()
  const isAdmin = user?.role === 'admin'

  const [equipment, setEquipment] = useState<Equipment[]>([])
  const [warehouses, setWarehouses] = useState<WarehouseType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterWarehouse, setFilterWarehouse] = useState('')
  const [filterCategory, setFilterCategory] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [categoriesList, setCategoriesList] = useState<CatalogItem[]>(DEFAULT_CATEGORY_CATALOG)
  
  const [showScanner, setShowScanner] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null)
  const [cloneTemplate, setCloneTemplate] = useState<Equipment | null>(null)
  const [initialBatchMode, setInitialBatchMode] = useState(false)
  const [modalTab, setModalTab] = useState<'info' | 'movement'>('movement')
  const [scannedInitialCode, setScannedInitialCode] = useState<string | undefined>(undefined)
  const [actEquipment, setActEquipment] = useState<Equipment | null>(null)
  const [showActModal, setShowActModal] = useState(false)
  const [maintEquipment, setMaintEquipment] = useState<Equipment | null>(null)
  const [showImportModal, setShowImportModal] = useState(false)
  const [showExportModal, setShowExportModal] = useState(false)
  const [showPdfView, setShowPdfView] = useState(false)
  const [pdfFilters, setPdfFilters] = useState<{
    warehouseId?: string
    status?: string
    category?: string
    groupBy: 'category' | 'warehouse' | 'status' | 'none'
  }>({ groupBy: 'category' })
  const [createdAct, setCreatedAct] = useState<DeliveryAct | null>(null)
  const [actionError, setActionError] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    try {
      const [items, wh, cats] = await Promise.all([
        equipmentApi.list({
          search: search || undefined,
          warehouse_id: filterWarehouse || undefined,
          category: filterCategory || undefined,
          status: filterStatus || undefined,
        }),
        warehousesApi.list(),
        equipmentApi.getCatalogs().catch(() => null),
      ])
      setEquipment(items)
      setWarehouses(wh)
      if (cats?.categories?.length) {
        setCategoriesList(cats.categories)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }, [search, filterWarehouse, filterCategory, filterStatus])

  useEffect(() => {
    loadData()
    const handleInventoryUpdated = () => loadData()
    window.addEventListener('inventory-updated', handleInventoryUpdated)
    return () => window.removeEventListener('inventory-updated', handleInventoryUpdated)
  }, [loadData])

  // Abrir para crear nuevo equipo
  const handleOpenCreate = (batch = false) => {
    setSelectedEquipment(null)
    setCloneTemplate(null)
    setInitialBatchMode(batch)
    setScannedInitialCode(undefined)
    setModalTab('info')
    setShowModal(true)
  }

  // Abrir para clonar la ficha de un equipo existente y escanear un lote de seriales iguales
  const handleOpenCloneBatch = (item: Equipment, e?: React.MouseEvent) => {
    e?.stopPropagation()
    setSelectedEquipment(null)
    setCloneTemplate(item)
    setInitialBatchMode(true)
    setScannedInitialCode(undefined)
    setModalTab('info')
    setShowModal(true)
  }

  // Abrir para editar datos técnicos
  const handleOpenEdit = (item: Equipment, e?: React.MouseEvent) => {
    e?.stopPropagation()
    setSelectedEquipment(item)
    setCloneTemplate(null)
    setInitialBatchMode(false)
    setScannedInitialCode(undefined)
    setModalTab('info')
    setShowModal(true)
  }

  // Abrir para registrar movimiento (traslado / asignación)
  const handleOpenMove = (item: Equipment, e?: React.MouseEvent) => {
    e?.stopPropagation()
    setSelectedEquipment(item)
    setCloneTemplate(null)
    setInitialBatchMode(false)
    setScannedInitialCode(undefined)
    setModalTab('movement')
    setShowModal(true)
  }

  // Abrir para generar acta de entrega para este equipo
  const handleOpenAct = (item: Equipment, e?: React.MouseEvent) => {
    e?.stopPropagation()
    setActEquipment(item)
    setShowActModal(true)
  }

  // Eliminar equipo
  const handleDelete = async (item: Equipment, e?: React.MouseEvent) => {
    e?.stopPropagation()
    const confirmed = window.confirm(
      `¿Deseas eliminar definitivamente el equipo "${item.name}" (SN: ${item.serial_number})?`
    )
    if (!confirmed) return

    setActionError(null)
    try {
      await equipmentApi.delete(item.id)
      loadData()
    } catch (err: any) {
      setActionError(err?.response?.data?.detail ?? 'No fue posible eliminar el equipo')
    }
  }

  // Escaneo por cámara
  const handleScanResult = async (scannedCode: string) => {
    setShowScanner(false)
    const clean = scannedCode.trim()
    if (
      clean.toUpperCase().startsWith('ACT-') ||
      clean.toUpperCase().startsWith('SOLV-')
    ) {
      navigate(`/verify-act/${encodeURIComponent(clean)}`)
      return
    }
    try {
      const found = await equipmentApi.getByBarcode(scannedCode)
      setSelectedEquipment(found)
      setModalTab('movement')
      setScannedInitialCode(undefined)
      setShowModal(true)
    } catch {
      if (isAdmin) {
        const createNew = window.confirm(
          `No se encontró ningún equipo con código o serie "${scannedCode}".\n\n¿Deseas dar de alta un NUEVO equipo con este código ahora?`
        )
        if (createNew) {
          setSelectedEquipment(null)
          setScannedInitialCode(scannedCode)
          setModalTab('info')
          setShowModal(true)
        }
      } else {
        alert(`No se encontró ningún equipo con código o serie: "${scannedCode}"`)
      }
    }
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-[1440px] mx-auto print:p-0 print:m-0 print:max-w-none">
      <div className={createdAct || showPdfView ? 'print:hidden space-y-4' : 'space-y-4'}>
      {/* Encabezado Principal */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Package className="w-6 h-6 text-primary" />
            <span>Inventario de Equipos</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm">
            {equipment.length} equipos tecnológicos registrados en el sistema
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {/* Botón Escáner destacado para móviles */}
          <button
            onClick={() => setShowScanner(true)}
            className="btn-primary py-2.5 px-3.5 text-xs sm:text-sm shadow-none"
          >
            <QrCode className="w-4 h-4" />
            <span>Escanear</span>
          </button>

          {/* Botón Exportar / Reporte Excel & PDF */}
          <button
            onClick={() => setShowExportModal(true)}
            className="btn-secondary py-2.5 px-3.5 text-xs sm:text-sm flex items-center gap-1.5 hover:border-blue-500/50 hover:text-blue-400"
            title="Exportar inventario a Excel o generar Reporte PDF para imprimir"
          >
            <Download className="w-4 h-4 text-blue-400" />
            <span className="hidden sm:inline">Exportar / Reporte</span>
            <span className="sm:hidden">Reporte</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => setShowImportModal(true)}
              className="btn-secondary py-2.5 px-3.5 text-xs sm:text-sm flex items-center gap-1.5 hover:border-emerald-500/50 hover:text-emerald-400"
              title="Carga Masiva de Equipos desde Excel o CSV"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">Importar Excel</span>
              <span className="sm:hidden">Excel</span>
            </button>
          )}

          <button
            onClick={() => handleOpenCreate(false)}
            className="btn-primary py-2.5 px-3.5 text-xs sm:text-sm"
          >
            <Plus className="w-4 h-4" />
            <span>+ Cargar Equipo</span>
          </button>
        </div>
      </div>

      {/* Alerta de Error de Acción */}
      {actionError && (
        <div className="p-3 bg-rose-950/40 border border-rose-900/60 rounded-xl text-rose-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{actionError}</span>
          </div>
          <button onClick={() => setActionError(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Barra de Filtros y Búsqueda */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
        <div className="sm:col-span-5 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por serie, modelo, marca, código o empleado asignado..."
            className="input-field pl-9 text-sm py-2.5"
          />
        </div>

        <div className="sm:col-span-3">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="input-field text-sm py-2.5"
          >
            <option value="">Todas las categorías</option>
            {categoriesList.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-2">
          <select
            value={filterWarehouse}
            onChange={(e) => setFilterWarehouse(e.target.value)}
            className="input-field text-sm py-2.5"
          >
            <option value="">Todos los almacenes</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.parent_name ? `↳ ${w.parent_name} › ${w.name}` : `🏢 ${w.name}`}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="input-field text-sm py-2.5"
          >
            <option value="">Todos los estados</option>
            <option value="available">Disponible</option>
            <option value="assigned">Asignado</option>
            <option value="maintenance">Mantenimiento</option>
            <option value="retired">Retirado</option>
            <option value="lost">Extraviado</option>
          </select>
        </div>
      </div>

      {/* Listado de Equipos */}
      {isLoading ? (
        <div className="flex justify-center py-20">
          <LoadingSpinner size="lg" />
        </div>
      ) : equipment.length === 0 ? (
        <div className="card p-12 text-center text-slate-500 space-y-3">
          <Package className="w-12 h-12 mx-auto opacity-30 text-slate-400" />
          <p className="font-bold text-white text-base">No se encontraron equipos</p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Prueba ajustando los filtros de búsqueda o agrega un nuevo activo con el botón superior.
          </p>
          {isAdmin && (
            <button onClick={() => handleOpenCreate(false)} className="btn-primary py-2 px-4 text-xs mx-auto">
              <Plus className="w-4 h-4" />
              <span>Registrar Primer Equipo</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {equipment.map((item) => (
            <div
              key={item.id}
              onClick={() => handleOpenEdit(item)}
              className="card p-4 hover:border-slate-700 transition-all cursor-pointer select-none flex flex-col justify-between group shadow-lg"
            >
              <div>
                {/* Cabecera de la Tarjeta */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-slate-400 px-2 py-0.5 rounded-md">
                      {getCategoryLabel(item.category)}
                    </span>
                    <h3 className="font-bold text-white text-sm truncate mt-1 group-hover:text-primary transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {item.brand ? `${item.brand} ` : ''}{item.model || ''}
                    </p>
                  </div>
                  <StatusBadge status={item.status} />
                </div>

                {/* Número de Serie y Código */}
                <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800/90 text-xs font-mono space-y-1 mt-2">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-500 text-[11px]">SN:</span>
                    <span className="font-bold tracking-wider">{item.serial_number}</span>
                  </div>
                  {item.barcode && (
                    <div className="flex items-center justify-between text-slate-400 text-[11px] pt-1 border-t border-slate-900">
                      <span className="text-slate-600 flex items-center gap-1">
                        <Barcode className="w-3 h-3" /> Barcode:
                      </span>
                      <span>{item.barcode}</span>
                    </div>
                  )}
                </div>

                {/* Ubicación o Asignación */}
                <div className="mt-2.5 text-xs">
                  {item.status === 'assigned' && item.assigned_to ? (
                    <div className="flex items-center gap-1.5 text-sky-400 bg-sky-950/30 border border-sky-900/50 p-1.5 rounded-lg font-medium">
                      <User className="w-3.5 h-3.5 flex-shrink-0 text-sky-400" />
                      <span className="truncate">Asignado a: {item.assigned_to}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 text-slate-400 truncate">
                      <Warehouse className="w-3.5 h-3.5 flex-shrink-0 text-slate-500" />
                      <span className="truncate">
                        {item.current_warehouse?.name || 'Sin almacén asignado'}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* BARRA DE ACCIONES CRUD EN LA TARJETA (Cuadrícula simétrica 3x2 sin desbordamiento) */}
              <div className="mt-3 pt-2.5 border-t border-slate-800/80 grid grid-cols-3 gap-1.5">
                {/* 1. Mover / Trasladar */}
                <button
                  type="button"
                  onClick={(e) => handleOpenMove(item, e)}
                  className="py-1.5 px-2 rounded-lg text-xs font-semibold text-primary bg-primary/10 hover:bg-primary/20 border border-primary/30 transition-colors flex items-center justify-center gap-1.5"
                  title="Registrar traslado, salida o devolución"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Mover</span>
                </button>

                {/* 2. Lote Igual */}
                <button
                  type="button"
                  onClick={(e) => handleOpenCloneBatch(item, e)}
                  className="py-1.5 px-2 rounded-lg text-sky-400 hover:text-white bg-sky-950/40 hover:bg-sky-900/60 border border-sky-900/40 transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
                  title="Cargar Lote Igual: Copia esta ficha técnica y abre el escáner en ráfaga para cargar varios seriales del mismo modelo"
                >
                  <Layers className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Lote</span>
                </button>

                {/* 3. Hoja de Vida */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation()
                    setMaintEquipment(item)
                  }}
                  className="py-1.5 px-2 rounded-lg text-amber-400 hover:text-white bg-amber-950/40 hover:bg-amber-900/60 border border-amber-900/40 transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
                  title="Hoja de Vida: Mantenimientos y Upgrades"
                >
                  <Wrench className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Vida</span>
                </button>

                {/* 4. Generar Acta */}
                <button
                  type="button"
                  onClick={(e) => handleOpenAct(item, e)}
                  className="py-1.5 px-2 rounded-lg text-emerald-400 hover:text-white bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-900/40 transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
                  title="Generar Acta de Entrega / Custodia para este equipo"
                >
                  <FileText className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Acta</span>
                </button>

                {/* 5. Editar Ficha */}
                <button
                  type="button"
                  onClick={(e) => handleOpenEdit(item, e)}
                  className="py-1.5 px-2 rounded-lg text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
                  title="Editar ficha técnica del equipo"
                >
                  <Pencil className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Editar</span>
                </button>

                {/* 6. Eliminar Equipo */}
                <button
                  type="button"
                  onClick={(e) => handleDelete(item, e)}
                  className="py-1.5 px-2 rounded-lg text-rose-400 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 border border-rose-900/40 transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
                  title="Eliminar equipo"
                >
                  <Trash2 className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Eliminar</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal del Escáner de Cámara */}
      {showScanner && (
        <BarcodeScanner
          onResult={handleScanResult}
          onClose={() => setShowScanner(false)}
        />
      )}

      {/* Modal de Detalle / Edición / Movimiento / Lote */}
      {showModal && (
        <EquipmentModal
          equipment={selectedEquipment}
          cloneTemplate={cloneTemplate}
          initialBatchMode={initialBatchMode}
          warehouses={warehouses}
          initialTab={modalTab}
          initialScannedCode={scannedInitialCode}
          onClose={() => {
            setShowModal(false)
            setCloneTemplate(null)
            setInitialBatchMode(false)
          }}
          onSaved={loadData}
        />
      )}

      {/* Modal para Crear Acta desde este equipo */}
      {showActModal && (
        <NewActModal
          initialEquipment={actEquipment}
          onClose={() => setShowActModal(false)}
          onCreated={(act) => {
            setShowActModal(false)
            loadData()
            setCreatedAct(act)
          }}
        />
      )}
      </div>

      {/* Visor e Impresión de Acta en Hoja Membretada */}
      {createdAct && (
        <ActDocumentView
          act={createdAct}
          onClose={() => setCreatedAct(null)}
        />
      )}

      {/* Modal de Hoja de Vida de Mantenimientos y Upgrades */}
      {maintEquipment && (
        <EquipmentMaintenanceModal
          equipment={maintEquipment}
          onClose={() => setMaintEquipment(null)}
          onUpdated={loadData}
        />
      )}

      {/* Modal de Carga Masiva desde Excel / CSV */}
      {showImportModal && (
        <ImportExcelModal
          warehouses={warehouses}
          onClose={() => setShowImportModal(false)}
          onSuccess={(count) => {
            loadData()
            alert(`¡Importación exitosa! Se han agregado ${count} equipos al inventario.`)
          }}
        />
      )}

      {/* Modal de Exportación y Filtro de Reporte */}
      <ExportReportModal
        warehouses={warehouses}
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        onOpenPdfReport={(filters) => {
          setPdfFilters(filters)
          setShowPdfView(true)
        }}
      />

      {/* Vista de Impresión y PDF Oficial de Inventario */}
      {showPdfView && (
        <InventoryReportPrintView
          equipment={equipment}
          warehouses={warehouses}
          filterWarehouseId={pdfFilters.warehouseId}
          filterStatus={pdfFilters.status}
          filterCategory={pdfFilters.category}
          groupBy={pdfFilters.groupBy}
          onClose={() => setShowPdfView(false)}
          onExportExcel={() => {
            equipmentApi.exportExcel({
              warehouse_id: pdfFilters.warehouseId,
              status: pdfFilters.status === 'all' ? undefined : pdfFilters.status,
              category: pdfFilters.category === 'all' ? undefined : pdfFilters.category,
            })
          }}
        />
      )}
    </div>
  )
}
