import { useState, useCallback } from 'react'
import {
  BarChart3,
  Search,
  Clock,
  AlertTriangle,
  User,
  CheckCircle2,
  Printer,
  Download,
  Info,
  RefreshCw,
  ArrowRightLeft,
} from 'lucide-react'
import { equipmentApi, type Equipment } from '../../api/equipment'
import { reportsApi, type EquipmentLifecycle, type ObsolescenceItem } from '../../api/reports'
import { warehousesApi, type Warehouse } from '../../api/warehouses'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'
import { StatusBadge } from '../../components/ui/StatusBadge'

type Tab = 'lifecycle' | 'obsolescence' | 'clearance'

// ─── Semáforo de obsolescencia ────────────────────────────────────────────────
function ObsolescenceLight({ pct, isObsolete }: { pct: number | null; isObsolete: boolean }) {
  if (pct === null) return <span className="text-slate-500 text-xs">—</span>
  if (isObsolete || pct >= 100)
    return <span title="Obsoleto" className="text-lg">🔴</span>
  if (pct >= 80)
    return <span title="Próximo a obsoleto" className="text-lg">🟡</span>
  return <span title="En buen estado" className="text-lg">🟢</span>
}

// ─── Formato de fecha ─────────────────────────────────────────────────────────
function fmtDate(iso: string | null | undefined): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('es-CO', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

// ─── Tab 1: Hoja de Vida ──────────────────────────────────────────────────────
function LifecycleTab() {
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<Equipment[]>([])
  const [selected, setSelected] = useState<Equipment | null>(null)
  const [lifecycle, setLifecycle] = useState<EquipmentLifecycle | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showSugg, setShowSugg] = useState(false)

  const handleSearch = useCallback(async (val: string) => {
    setQuery(val)
    if (val.length < 2) { setSuggestions([]); return }
    const results = await equipmentApi.list({ search: val })
    setSuggestions(results.slice(0, 8))
    setShowSugg(true)
  }, [])

  const handleSelect = async (eq: Equipment) => {
    setSelected(eq)
    setSuggestions([])
    setShowSugg(false)
    setQuery(`${eq.name} (SN: ${eq.serial_number})`)
    setIsLoading(true)
    setError(null)
    try {
      const data = await reportsApi.getEquipmentLifecycle(eq.id)
      setLifecycle(data)
    } catch {
      // TODO: Backend endpoint /reports/equipment/{id}/lifecycle pendiente de implementar
      setError('El endpoint de hoja de vida aún no está disponible en el backend. Se muestra información básica.')
      setLifecycle(null)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-5">
      {/* Búsqueda */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          onFocus={() => suggestions.length > 0 && setShowSugg(true)}
          placeholder="Buscar equipo por nombre, serial o marca..."
          className="input-field pl-9 text-sm"
        />
        {showSugg && suggestions.length > 0 && (
          <div className="absolute z-20 w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl shadow-xl overflow-hidden">
            {suggestions.map((eq) => (
              <button
                key={eq.id}
                onClick={() => handleSelect(eq)}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-slate-800 text-left text-sm transition-colors"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-white font-semibold truncate">{eq.name}</p>
                  <p className="text-slate-400 text-xs font-mono">SN: {eq.serial_number}</p>
                </div>
                <StatusBadge status={eq.status} />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Resultado */}
      {isLoading && <div className="flex justify-center py-10"><LoadingSpinner size="lg" /></div>}

      {error && (
        <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl text-amber-300 text-xs flex items-start gap-2">
          <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {selected && !isLoading && (
        <div className="space-y-4">
          {/* Info básica del equipo */}
          <div className="card p-4 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="text-white font-bold text-base">{selected.name}</h3>
                <p className="text-slate-400 text-xs font-mono">SN: {selected.serial_number}</p>
                <p className="text-slate-400 text-xs mt-1">
                  {selected.brand} {selected.model} · Categoría: {selected.category}
                </p>
              </div>
              <StatusBadge status={selected.status} />
            </div>
            <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
              <div className="bg-slate-950/80 p-2 rounded-lg">
                <p className="text-slate-500">Ubicación</p>
                <p className="text-white font-medium">{selected.current_warehouse?.name ?? '—'}</p>
              </div>
              <div className="bg-slate-950/80 p-2 rounded-lg">
                <p className="text-slate-500">Asignado a</p>
                <p className="text-white font-medium">{selected.assigned_to ?? '—'}</p>
              </div>
              <div className="bg-slate-950/80 p-2 rounded-lg">
                <p className="text-slate-500">Fecha compra</p>
                <p className="text-white font-medium">{fmtDate(selected.purchase_date)}</p>
              </div>
              <div className="bg-slate-950/80 p-2 rounded-lg">
                <p className="text-slate-500">Garantía hasta</p>
                <p className="text-white font-medium">{fmtDate(selected.warranty_expires)}</p>
              </div>
            </div>
          </div>

          {/* Línea de tiempo de movimientos */}
          {lifecycle ? (
            <div className="card p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-white font-bold text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4 text-primary" />
                  Historial de Movimientos ({lifecycle.movements.length})
                </h4>
                <span className="text-xs text-slate-400">Edad: {lifecycle.age_days} días</span>
              </div>
              {lifecycle.movements.length === 0 ? (
                <p className="text-slate-500 text-sm text-center py-4">Sin movimientos registrados</p>
              ) : (
                <div className="relative ml-3">
                  <div className="absolute left-0 top-0 bottom-0 w-px bg-slate-800" />
                  <div className="space-y-4">
                    {lifecycle.movements.map((mv, i) => (
                      <div key={mv.id} className="relative pl-6">
                        <div className="absolute left-[-5px] top-1 w-2.5 h-2.5 rounded-full bg-primary border-2 border-slate-900" />
                        <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-xs font-bold text-primary uppercase tracking-wide flex items-center gap-1">
                              <ArrowRightLeft className="w-3 h-3" />
                              {mv.type}
                            </span>
                            <span className="text-[11px] text-slate-500">{fmtDate(mv.created_at)}</span>
                          </div>
                          <p className="text-xs text-slate-300">
                            {mv.from_warehouse ? `De: ${mv.from_warehouse.name}` : ''}
                            {mv.to_warehouse ? ` → ${mv.to_warehouse.name}` : ''}
                            {mv.assigned_to ? ` → ${mv.assigned_to}` : ''}
                          </p>
                          {mv.notes && <p className="text-[11px] text-slate-500 mt-1">{mv.notes}</p>}
                          {mv.performed_by && (
                            <p className="text-[11px] text-slate-600 mt-1">Por: {mv.performed_by}</p>
                          )}
                        </div>
                        {i === lifecycle.movements.length - 1 && (
                          <div className="text-[10px] text-slate-600 pl-0 mt-1">← más reciente</div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            !error && (
              <div className="card p-4 text-center text-slate-500 text-sm py-8">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p>Selecciona un equipo para ver su hoja de vida</p>
              </div>
            )
          )}

          <div className="flex justify-end">
            <button
              onClick={() => window.print()}
              className="btn-secondary py-2 px-4 text-xs flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimir / PDF
            </button>
          </div>
        </div>
      )}

      {!selected && !isLoading && (
        <div className="card p-12 text-center text-slate-500 space-y-2">
          <Clock className="w-10 h-10 mx-auto opacity-20" />
          <p className="text-sm">Busca un equipo para ver su hoja de vida completa</p>
        </div>
      )}
    </div>
  )
}

// ─── Tab 2: Obsolescencia ─────────────────────────────────────────────────────
function ObsolescenceTab() {
  const [threshold, setThreshold] = useState(3)
  const [warehouseId, setWarehouseId] = useState('')
  const [category, setCategory] = useState('')
  const [items, setItems] = useState<ObsolescenceItem[]>([])
  const [warehouses, setWarehouses] = useState<Warehouse[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const loadWarehouses = useCallback(async () => {
    if (warehouses.length > 0) return
    const wh = await warehousesApi.list()
    setWarehouses(wh)
  }, [warehouses.length])

  const handleSearch = async () => {
    setIsLoading(true)
    setError(null)
    setLoaded(false)
    try {
      const data = await reportsApi.getObsolescence({
        threshold_years: threshold,
        warehouse_id: warehouseId || undefined,
        category: category || undefined,
      })
      setItems(data)
      setLoaded(true)
    } catch {
      // TODO: Backend /reports/obsolescence pendiente de implementar
      setError('El endpoint de obsolescencia aún no está disponible en el backend.')
      setItems([])
    } finally {
      setIsLoading(false)
    }
  }

  const noPurchaseDate = loaded && items.length > 0 && items.every((i) => i.equipment.purchase_date === null)

  return (
    <div className="space-y-5">
      {/* Filtros */}
      <div className="card p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="label">Umbral de obsolescencia</label>
          <select
            className="input-field text-sm"
            value={threshold}
            onChange={(e) => setThreshold(Number(e.target.value))}
            onClick={loadWarehouses}
          >
            {[2, 3, 4, 5, 7, 10].map((y) => (
              <option key={y} value={y}>{y} años</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Almacén</label>
          <select
            className="input-field text-sm"
            value={warehouseId}
            onChange={(e) => setWarehouseId(e.target.value)}
            onClick={loadWarehouses}
          >
            <option value="">Todos los almacenes</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>
                {w.parent_name ? `↳ ${w.parent_name} › ${w.name}` : `🏢 ${w.name}`}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Categoría</label>
          <select
            className="input-field text-sm"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">Todas</option>
            {['laptop','desktop','monitor','server','switch','router','phone','tablet','printer','ups','other'].map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-3 flex justify-end gap-2">
          <button onClick={handleSearch} className="btn-primary py-2 px-4 text-xs flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" />
            Generar Reporte
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl text-amber-300 text-xs flex items-start gap-2">
          <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {isLoading && <div className="flex justify-center py-10"><LoadingSpinner size="lg" /></div>}

      {noPurchaseDate && (
        <div className="p-4 bg-blue-950/40 border border-blue-800/60 rounded-xl text-blue-300 text-sm flex items-start gap-2.5">
          <Info className="w-5 h-5 flex-shrink-0 mt-0.5 text-blue-400" />
          <div>
            <p className="font-semibold">Sin fechas de compra registradas</p>
            <p className="text-xs mt-1 text-blue-400">
              Para ver el semáforo de obsolescencia, registra la <strong>Fecha de Compra</strong> en la
              ficha de cada equipo (botón Editar → sección "Datos de Adquisición y Garantía").
            </p>
          </div>
        </div>
      )}

      {loaded && items.length > 0 && (
        <>
          <div className="flex items-center justify-between gap-2">
            <p className="text-slate-400 text-xs">{items.length} equipos analizados</p>
            <button
              onClick={() => equipmentApi.exportExcel({ warehouse_id: warehouseId || undefined, category: category || undefined })}
              className="btn-secondary py-1.5 px-3 text-xs flex items-center gap-1.5 hover:border-emerald-500/50 hover:text-emerald-400"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              Exportar Excel
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="text-slate-500 border-b border-slate-800">
                  <th className="py-2 pr-3">Estado</th>
                  <th className="py-2 pr-3">Equipo</th>
                  <th className="py-2 pr-3">Serial</th>
                  <th className="py-2 pr-3">Categoría</th>
                  <th className="py-2 pr-3">Almacén</th>
                  <th className="py-2 pr-3">F. Compra</th>
                  <th className="py-2 pr-3">Edad</th>
                  <th className="py-2 pr-3">% Usado</th>
                  <th className="py-2 pr-3">Garantía</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {items.map((item) => (
                  <tr key={item.equipment.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2 pr-3 text-center">
                      <ObsolescenceLight pct={item.depreciation_pct} isObsolete={item.is_obsolete} />
                    </td>
                    <td className="py-2 pr-3 text-white font-medium">{item.equipment.name}</td>
                    <td className="py-2 pr-3 font-mono text-slate-400">{item.equipment.serial_number}</td>
                    <td className="py-2 pr-3 text-slate-400">{item.equipment.category}</td>
                    <td className="py-2 pr-3 text-slate-400">{item.equipment.current_warehouse?.name ?? '—'}</td>
                    <td className="py-2 pr-3 text-slate-400">{fmtDate(item.equipment.purchase_date)}</td>
                    <td className="py-2 pr-3 text-slate-300">
                      {item.age_years !== null ? `${item.age_years.toFixed(1)} años` : '—'}
                    </td>
                    <td className="py-2 pr-3">
                      {item.depreciation_pct !== null ? (
                        <div className="flex items-center gap-1.5">
                          <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${item.depreciation_pct >= 100 ? 'bg-rose-500' : item.depreciation_pct >= 80 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                              style={{ width: `${Math.min(item.depreciation_pct, 100)}%` }}
                            />
                          </div>
                          <span className="text-slate-300">{item.depreciation_pct.toFixed(0)}%</span>
                        </div>
                      ) : '—'}
                    </td>
                    <td className="py-2 pr-3">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        item.warranty_status === 'Vigente' ? 'bg-emerald-950/60 text-emerald-400' :
                        item.warranty_status === 'Vencida' ? 'bg-rose-950/60 text-rose-400' :
                        'bg-slate-800 text-slate-500'
                      }`}>
                        {item.warranty_status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {loaded && items.length === 0 && !error && (
        <div className="card p-10 text-center text-slate-500">
          <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-emerald-500 opacity-60" />
          <p>No se encontraron equipos con los filtros seleccionados.</p>
        </div>
      )}
    </div>
  )
}

// ─── Tab 3: Paz y Salvo ───────────────────────────────────────────────────────
function ClearanceTab() {
  const [name, setName] = useState('')
  const [inputName, setInputName] = useState('')
  const [assigned, setAssigned] = useState<Equipment[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [searched, setSearched] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSearch = async () => {
    if (!inputName.trim()) return
    setName(inputName.trim())
    setIsLoading(true)
    setError(null)
    setSearched(false)
    try {
      const result = await reportsApi.getEmployeeClearance(inputName.trim())
      setAssigned(result.assigned_equipment ?? [])
      setSearched(true)
    } catch {
      // TODO: Backend /reports/employee-clearance pendiente de implementar
      // Fallback: buscar equipos asignados por nombre
      try {
        const list = await equipmentApi.list({ search: inputName.trim(), status: 'assigned' })
        const filtered = list.filter(
          (eq) => eq.assigned_to?.toLowerCase().includes(inputName.trim().toLowerCase())
        )
        setAssigned(filtered)
        setSearched(true)
      } catch {
        setError('No se pudo consultar la información de equipos asignados.')
      }
    } finally {
      setIsLoading(false)
    }
  }

  const handlePrint = () => window.print()

  return (
    <div className="space-y-5">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={inputName}
            onChange={(e) => setInputName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Nombre del empleado..."
            className="input-field pl-9 text-sm"
          />
        </div>
        <button onClick={handleSearch} disabled={isLoading || !inputName.trim()} className="btn-primary py-2 px-4 text-xs">
          <Search className="w-4 h-4" />
          Buscar
        </button>
      </div>

      {error && (
        <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-xl text-rose-300 text-xs">{error}</div>
      )}

      {isLoading && <div className="flex justify-center py-10"><LoadingSpinner size="lg" /></div>}

      {searched && !isLoading && (
        <>
          {assigned.length === 0 ? (
            <div className="card p-10 text-center space-y-2">
              <CheckCircle2 className="w-12 h-12 mx-auto text-emerald-500 opacity-80" />
              <p className="text-white font-semibold text-base">✅ {name} no tiene equipos asignados actualmente</p>
              <p className="text-slate-400 text-sm">Puede proceder con la baja o el paz y salvo.</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-slate-400 text-xs">
                  <span className="text-amber-400 font-bold">{name}</span> tiene {assigned.length} equipo(s) asignado(s)
                </p>
                <button onClick={handlePrint} className="btn-secondary py-1.5 px-3 text-xs flex items-center gap-1.5">
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir lista
                </button>
              </div>
              <div className="space-y-2">
                {assigned.map((eq) => (
                  <div key={eq.id} className="card p-3 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-white font-semibold text-sm">{eq.name}</p>
                      <p className="text-xs text-slate-400 font-mono">
                        SN: {eq.serial_number} · {eq.category}
                      </p>
                      {eq.current_warehouse && (
                        <p className="text-xs text-slate-500">📍 {eq.current_warehouse.name}</p>
                      )}
                    </div>
                    <StatusBadge status={eq.status} />
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

// ─── Página principal ─────────────────────────────────────────────────────────
export function ReportsPage() {
  const [tab, setTab] = useState<Tab>('lifecycle')

  const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'lifecycle', label: 'Hoja de Vida', icon: <Clock className="w-4 h-4" /> },
    { id: 'obsolescence', label: 'Obsolescencia', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'clearance', label: 'Paz y Salvo', icon: <User className="w-4 h-4" /> },
  ]

  return (
    <div className="p-4 lg:p-6 space-y-5 max-w-5xl mx-auto">
      {/* Encabezado */}
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
          <BarChart3 className="w-6 h-6 text-primary" />
          <span>Reportes</span>
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
          Hoja de vida de equipos, análisis de obsolescencia y paz y salvo por empleado
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold uppercase tracking-wider transition-colors ${
              tab === t.id
                ? 'text-primary border-b-2 border-primary bg-primary/5'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.icon}
            <span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {/* Contenido del tab activo */}
      <div>
        {tab === 'lifecycle' && <LifecycleTab />}
        {tab === 'obsolescence' && <ObsolescenceTab />}
        {tab === 'clearance' && <ClearanceTab />}
      </div>
    </div>
  )
}
