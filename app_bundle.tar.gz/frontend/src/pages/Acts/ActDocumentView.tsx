import { useState, useRef, useEffect } from 'react'
import {
  Printer,
  X,
  ArrowLeft,
  Upload,
  Camera,
  CheckCircle2,
  Clock,
  ExternalLink,
  Trash2,
  Sparkles,
  Image as ImageIcon,
  FileCheck,
  RotateCcw,
  ShieldCheck,
  Pencil,
  Eye,
  EyeOff,
} from 'lucide-react'
import { Link } from 'react-router-dom'
import { deliveryActsApi, type DeliveryAct } from '../../api/deliveryActs'
import { useThemeStore } from '../../store/themeStore'

interface Props {
  act: DeliveryAct
  onClose: () => void
  onUpdated?: (updated: DeliveryAct) => void
  onEdit?: (act: DeliveryAct) => void
  onDelete?: (act: DeliveryAct) => void
}

export function ActDocumentView({ act: initialAct, onClose, onUpdated, onEdit, onDelete }: Props) {
  const { config } = useThemeStore()
  const modalScrollRef = useRef<HTMLDivElement>(null)
  const printAreaRef = useRef<HTMLDivElement>(null)

  const [act, setAct] = useState<DeliveryAct>(initialAct)
  const [isUploadingScan, setIsUploadingScan] = useState(false)
  const [isUploadingEvidence, setIsUploadingEvidence] = useState(false)
  const [uploadMessage, setUploadMessage] = useState<string | null>(null)

  // Modal de Escáner de Documento con Filtro B/N tipo CamScanner
  const [rawScanImage, setRawScanImage] = useState<string | null>(null)
  const [processedScanImage, setProcessedScanImage] = useState<string | null>(null)
  const [useBwFilter, setUseBwFilter] = useState(true)
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null)

  // Alternar visualización del detalle técnico/especificaciones en la tabla (para ahorrar espacio en hoja)
  const hasAnySpecs = act.items.some((it) => it.specs && it.specs.trim())
  const [showSpecs, setShowSpecs] = useState(act.items.length <= 2)
  const [includeTiSignature, setIncludeTiSignature] = useState(true)

  useEffect(() => {
    if (initialAct) {
      if (!initialAct.items || initialAct.items.length === 0) {
        deliveryActsApi
          .get(initialAct.id)
          .then((fresh) => {
            setAct(fresh)
            if (onUpdated) onUpdated(fresh)
          })
          .catch(() => setAct(initialAct))
      } else {
        setAct(initialAct)
      }
    }
  }, [initialAct])

  const [isCreatingReturn, setIsCreatingReturn] = useState(false)

  // Generar en 1 clic el Acta de Devolución / Solvencia TI cuando el trabajador regresa el equipo
  const handleQuickReturnAct = async () => {
    const ok = window.confirm(
      `¿Registrar la devolución de los equipos de "${act.recipient_name}" y generar su Acta de Devolución / Solvencia con TI?`
    )
    if (!ok) return
    setIsCreatingReturn(true)
    try {
      const returnAct = await deliveryActsApi.create({
        city: act.city || 'Caracas',
        act_type: 'return',
        recipient_name: act.recipient_name,
        recipient_id_card: act.recipient_id_card,
        recipient_position: act.recipient_position || undefined,
        recipient_department: act.recipient_department || undefined,
        delivered_by_name: act.delivered_by_name || 'Raimundo Gil',
        delivered_by_position: act.delivered_by_position || 'Gerente de Tecnología',
        delivered_by_id_card: act.delivered_by_id_card || '14.287.629',
        accessories: act.accessories || undefined,
        notes: `Devolución conforme correspondiente al Acta ${act.act_number}`,
        items: act.items.map((it) => ({
          equipment_id: it.equipment_id || undefined,
          equipment_name: it.equipment_name,
          equipment_type: it.equipment_type,
          brand: it.brand || undefined,
          model: it.model || undefined,
          serial_number: it.serial_number,
          specs: it.specs || undefined,
        })),
        auto_assign_equipment: true,
      })
      notifyUpdate(
        returnAct,
        '🛡️ Acta de Devolución / Solvencia TI generada. El equipo quedó Disponible en inventario.'
      )
    } catch (err) {
      console.error(err)
      alert('No se pudo generar el acta de devolución.')
    } finally {
      setIsCreatingReturn(false)
    }
  }

  const handlePrint = () => {
    if (modalScrollRef.current) {
      modalScrollRef.current.scrollTop = 0
    }
    window.scrollTo(0, 0)
    setTimeout(() => {
      window.print()
    }, 50)
  }

  const notifyUpdate = (updated: DeliveryAct, msg?: string) => {
    setAct(updated)
    if (onUpdated) onUpdated(updated)
    if (msg) {
      setUploadMessage(msg)
      setTimeout(() => setUploadMessage(null), 4000)
    }
  }

  // Subida directa de PDF o Imagen Escaneada
  const handleDirectScanFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setIsUploadingScan(true)
    try {
      const updated = await deliveryActsApi.uploadScanFile(act.id, file)
      notifyUpdate(updated, '✅ Acta física firmada respaldada exitosamente.')
    } catch (err) {
      console.error(err)
      alert('No se pudo subir el archivo escaneado.')
    } finally {
      setIsUploadingScan(false)
      e.target.value = ''
    }
  }

  // Captura con Cámara + Filtro Escáner de Documento B/N (CamScanner)
  const handleCameraScannerFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = reader.result as string
      setRawScanImage(dataUrl)
      applyDocumentScannerFilter(dataUrl)
    }
    reader.readAsDataURL(file)
    e.target.value = ''
  }

  const applyDocumentScannerFilter = (srcDataUrl: string) => {
    const img = new Image()
    img.onload = () => {
      const canvas = document.createElement('canvas')
      const maxDim = 1600
      let w = img.width
      let h = img.height
      if (w > maxDim || h > maxDim) {
        if (w > h) {
          h = Math.round((h * maxDim) / w)
          w = maxDim
        } else {
          w = Math.round((w * maxDim) / h)
          h = maxDim
        }
      }
      canvas.width = w
      canvas.height = h
      const ctx = canvas.getContext('2d')
      if (!ctx) return

      ctx.drawImage(img, 0, 0, w, h)
      const imgData = ctx.getImageData(0, 0, w, h)
      const data = imgData.data

      // Filtro adaptativo de alto contraste para hojas blancas y firmas nítidas
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i]
        const g = data[i + 1]
        const b = data[i + 2]
        // Luminancia estándar
        const lum = 0.299 * r + 0.587 * g + 0.114 * b
        // Curva de contraste de documento (blanquea el fondo > 165, oscurece tinta < 120)
        let val: number
        if (lum > 170) {
          val = 255
        } else if (lum < 95) {
          val = Math.max(0, (lum - 30) * 0.5)
        } else {
          val = ((lum - 95) / (170 - 95)) * 255
        }
        data[i] = val
        data[i + 1] = val
        data[i + 2] = val
      }

      ctx.putImageData(imgData, 0, 0)
      setProcessedScanImage(canvas.toDataURL('image/jpeg', 0.88))
    }
    img.src = srcDataUrl
  }

  const handleConfirmScannerUpload = async () => {
    const targetDataUrl = useBwFilter ? processedScanImage : rawScanImage
    if (!targetDataUrl) return
    setIsUploadingScan(true)
    try {
      const updated = await deliveryActsApi.uploadScanBase64(act.id, targetDataUrl)
      setRawScanImage(null)
      setProcessedScanImage(null)
      notifyUpdate(updated, '✅ Hoja física digitalizada con filtro escáner y guardada.')
    } catch (err) {
      console.error(err)
      alert('Error al guardar la captura digitalizada.')
    } finally {
      setIsUploadingScan(false)
    }
  }

  // Subir fotos de evidencia del estado físico ("Antes y Después")
  const handleUploadEvidence = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return
    setIsUploadingEvidence(true)
    try {
      let latest = act
      for (const file of Array.from(files)) {
        latest = await deliveryActsApi.uploadEvidencePhoto(act.id, file)
      }
      notifyUpdate(latest, '📸 Evidencia fotográfica añadida al expediente del acta.')
    } catch (err) {
      console.error(err)
      alert('No se pudo subir la foto de evidencia.')
    } finally {
      setIsUploadingEvidence(false)
      e.target.value = ''
    }
  }

  const handleDeleteEvidence = async (idx: number) => {
    if (!window.confirm('¿Eliminar esta foto de evidencia del acta?')) return
    try {
      const updated = await deliveryActsApi.deleteEvidencePhoto(act.id, idx)
      notifyUpdate(updated)
    } catch (err) {
      console.error(err)
    }
  }

  const formatDateSpanish = (dateStr: string, city: string) => {
    try {
      const d = new Date(dateStr)
      const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' }
      const formatted = new Intl.DateTimeFormat('es-ES', options).format(d)
      return `${city || 'Caracas'}, ${formatted}`
    } catch {
      return `${city || 'Caracas'}, ${dateStr}`
    }
  }

  const evidencePhotos = act.evidence_photos_list || []

  return (
    <div
      ref={modalScrollRef}
      className="print-modal-root fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-start overflow-y-auto p-2 sm:p-6 print:static print:overflow-visible print:p-0 print:bg-white print:block"
    >
      {/* Barra de Controles Superior (Oculta en Impresión) */}
      <div className="w-full max-w-3xl flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 p-3 rounded-xl mb-3 shadow-xl print:hidden flex-shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="btn-secondary py-1.5 px-3 text-xs flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Volver</span>
          </button>
          <span className="text-xs font-mono text-primary font-bold ml-1">
            {act.act_number}
          </span>
          {act.scanned_document_url ? (
            <span className="text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>Acta Física Respaldada</span>
            </span>
          ) : (
            <span className="text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>Pendiente Escaneo Físico</span>
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onEdit && (
            <button
              type="button"
              onClick={() => onEdit(act)}
              className="px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors"
              title="Editar datos de la persona, equipos o accesorios de esta acta"
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Editar Acta</span>
            </button>
          )}

          {onDelete && (
            <button
              type="button"
              onClick={() => onDelete(act)}
              className="px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors"
              title="Eliminar esta acta y liberar sus equipos al inventario"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Eliminar Acta</span>
            </button>
          )}

          <Link
            to={`/verify-act/${encodeURIComponent(act.act_number)}`}
            className="px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors"
            title="Ver pantalla pública de Verificación de Autenticidad (Seguridad / RRHH)"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Verificar Autenticidad</span>
          </Link>

          {act.act_type === 'assignment' && (
            <button
              type="button"
              disabled={isCreatingReturn}
              onClick={handleQuickReturnAct}
              className="px-3 py-1.5 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 text-sky-300 border border-sky-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors"
              title="Recibir equipo de vuelta y generar Acta de Devolución / Solvencia con TI"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isCreatingReturn ? 'Procesando...' : 'Recibir Devolución / Solvencia'}</span>
            </button>
          )}

          {hasAnySpecs && (
            <button
              type="button"
              onClick={() => setShowSpecs((prev) => !prev)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 border transition-all ${
                showSpecs
                  ? 'bg-primary/20 text-primary border-primary/40 hover:bg-primary/30'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white hover:bg-slate-700'
              }`}
              title={
                showSpecs
                  ? 'Ocultar detalles técnicos para ahorrar espacio y que quepa en 1 hoja'
                  : 'Mostrar detalles técnicos en la tabla'
              }
            >
              {showSpecs ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{showSpecs ? 'Detalle Técnico: Visible' : 'Detalle Técnico: Oculto'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIncludeTiSignature((prev) => !prev)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 border transition-all ${
              includeTiSignature
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white hover:bg-slate-700'
            }`}
            title={
              includeTiSignature
                ? 'Firma de Raimundo Gil incluida. Clic para ocultar si se requiere firma física manuscrita en papel'
                : 'Firma de Raimundo Gil oculta. Clic para incluir la firma digital'
            }
          >
            <span>{includeTiSignature ? 'Firma TI: Con Firma' : 'Firma TI: Sin Firma'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="btn-primary py-1.5 px-4 text-xs flex items-center gap-2 shadow-md hover:brightness-110"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir / Guardar PDF</span>
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            title="Cerrar vista"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* PANEL DE EXPEDIENTE DIGITAL: ESCANEO DE HOJA FIRMADA Y EVIDENCIAS (Oculto en Impresión) */}
      <div className="w-full max-w-3xl bg-slate-900/95 border border-slate-800 rounded-xl p-4 mb-4 space-y-4 print:hidden shadow-xl flex-shrink-0">
        {uploadMessage && (
          <div className="bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 text-xs font-semibold px-3 py-2 rounded-lg">
            {uploadMessage}
          </div>
        )}

        {/* Sección A: Respaldo de Hoja Física Firmada (Trabajador + Gerente) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="space-y-1">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-primary" />
              <span>Respaldo Digital de Hoja Física Firmada</span>
            </h3>
            <p className="text-xs text-slate-400">
              {act.scanned_document_url
                ? `Documento físico firmado cargado el ${new Date(
                    act.scanned_at || act.updated_at
                  ).toLocaleString('es-ES')}`
                : 'Una vez impresa y firmada en bolígrafo por el trabajador y el Gerente, digitalízala aquí:'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {act.scanned_document_url && (
              <a
                href={act.scanned_document_url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Ver Acta Firmada</span>
              </a>
            )}

            {/* Botón Escáner Cámara con Filtro Documento B/N */}
            <label className="px-3 py-1.5 rounded-lg bg-primary/20 hover:bg-primary/30 text-primary border border-primary/40 text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-colors">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isUploadingScan ? 'Procesando...' : '📷 Escáner Cámara (Filtro B/N)'}</span>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                disabled={isUploadingScan}
                onChange={handleCameraScannerFile}
              />
            </label>

            {/* Botón Subir PDF o Imagen */}
            <label className="btn-secondary py-1.5 px-3 text-xs cursor-pointer flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5" />
              <span>Subir PDF / Imagen</span>
              <input
                type="file"
                accept=".pdf,image/*"
                className="hidden"
                disabled={isUploadingScan}
                onChange={handleDirectScanFile}
              />
            </label>
          </div>
        </div>

        {/* Previsualizador Interactivo del Filtro Escáner B/N */}
        {rawScanImage && (
          <div className="p-3 bg-slate-950 border border-primary/40 rounded-xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-primary" />
                <span>Previsualización de Escáner de Documento</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setUseBwFilter(true)}
                  className={`px-2.5 py-1 rounded text-xs font-bold ${
                    useBwFilter
                      ? 'bg-primary text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Filtro Escáner B/N Nitidez
                </button>
                <button
                  type="button"
                  onClick={() => setUseBwFilter(false)}
                  className={`px-2.5 py-1 rounded text-xs font-bold ${
                    !useBwFilter
                      ? 'bg-primary text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Color Original
                </button>
              </div>
            </div>

            <div className="max-h-72 overflow-y-auto flex justify-center bg-slate-900 p-2 rounded-lg border border-slate-800">
              <img
                src={(useBwFilter ? processedScanImage : rawScanImage) || rawScanImage}
                alt="Previsualización Escáner"
                className="max-h-64 object-contain rounded shadow"
              />
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setRawScanImage(null)
                  setProcessedScanImage(null)
                }}
                className="btn-secondary py-1.5 px-3 text-xs"
              >
                Descartar
              </button>
              <button
                type="button"
                disabled={isUploadingScan}
                onClick={handleConfirmScannerUpload}
                className="btn-primary py-1.5 px-4 text-xs font-bold flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isUploadingScan ? 'Guardando...' : 'Guardar Respaldo Oficial'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Sección B: Fotos de Evidencia del Estado Físico ("Antes y Después") */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <ImageIcon className="w-3.5 h-3.5 text-primary" />
              <span>
                Evidencias Fotográficas del Estado Físico ({evidencePhotos.length})
              </span>
            </h4>
            <label className="text-xs text-primary hover:underline cursor-pointer font-semibold flex items-center gap-1">
              <Camera className="w-3.5 h-3.5" />
              <span>{isUploadingEvidence ? 'Subiendo...' : '+ Añadir Foto del Equipo'}</span>
              <input
                type="file"
                accept="image/*"
                multiple
                capture="environment"
                className="hidden"
                disabled={isUploadingEvidence}
                onChange={handleUploadEvidence}
              />
            </label>
          </div>

          {evidencePhotos.length === 0 ? (
            <p className="text-[11px] text-slate-500">
              Sin fotos de evidencia adjuntas. Puedes tomar fotos del estado de la pantalla, teclado o carcasa como respaldo.
            </p>
          ) : (
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {evidencePhotos.map((url, idx) => (
                <div
                  key={idx}
                  className="relative group w-20 h-20 rounded-lg overflow-hidden border border-slate-700 bg-slate-950 flex-shrink-0"
                >
                  <img
                    src={url}
                    alt={`Evidencia ${idx + 1}`}
                    onClick={() => setPreviewPhotoUrl(url)}
                    className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                  />
                  <button
                    type="button"
                    onClick={() => handleDeleteEvidence(idx)}
                    className="absolute top-1 right-1 p-1 rounded bg-black/70 text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Eliminar foto"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Modal Lightbox de Foto de Evidencia */}
      {previewPhotoUrl && (
        <div
          onClick={() => setPreviewPhotoUrl(null)}
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 print:hidden"
        >
          <img
            src={previewPhotoUrl}
            alt="Evidencia ampliada"
            className="max-w-full max-h-[88vh] object-contain rounded-xl shadow-2xl"
          />
        </div>
      )}

      {/* DOCUMENTO HOJA TIPO CARTA / A4 (Diseño idéntico al acta institucional) */}
      {(() => {
        const isMultiItem = act.items.length >= 3 || (showSpecs && hasAnySpecs)
        return (
          <div
            ref={printAreaRef}
            className={`print-sheet-page flex-shrink-0 h-auto w-full max-w-[215mm] min-h-[265mm] print:min-h-0 print:h-auto bg-white text-slate-900 shadow-2xl ${
              isMultiItem ? 'p-6 sm:p-8' : 'p-8 sm:p-12'
            } font-sans print:shadow-none print:p-0 print:w-full print:max-w-none print:m-0 flex flex-col justify-between`}
            style={{ backgroundColor: '#ffffff', color: '#0f172a' }}
          >
            {/* Encabezado y Cuerpo Principal */}
            <div className={isMultiItem ? 'space-y-3 print:space-y-2' : 'space-y-4 print:space-y-3'}>
              <div className="flex items-center justify-between">
                {/* Logo de la Empresa White-Label (+50% de tamaño) */}
                <div className="flex flex-col items-start max-w-[320px]">
                  {config?.logo_url ? (
                    <img
                      src={config.logo_url}
                      alt={config.name || 'Logotipo Empresa'}
                      className="h-[75px] sm:h-[84px] print:h-[70px] max-w-[300px] object-contain"
                    />
                  ) : (
                    <div className="border-2 border-slate-800 rounded p-2 text-center">
                      <span className="font-black text-sm tracking-widest uppercase">
                        {config?.name || 'GRUPO TUANDAMIO'}
                      </span>
                    </div>
                  )}
                </div>

                {/* Ciudad y Fecha de Emisión */}
                <div className="text-right text-[10pt] sm:text-[10.5pt] text-slate-700 font-medium self-start pt-2">
                  <p>{formatDateSpanish(act.created_at, act.city)}</p>
                </div>
              </div>

              {/* Título Central con respiro vertical adecuado */}
              <div className="text-center pt-6 pb-2 print:pt-6 print:pb-2">
                <h1 className="text-base sm:text-lg print:text-[13pt] font-black tracking-wide uppercase underline underline-offset-4 text-black">
                  {act.act_type === 'return'
                    ? 'ACTA DE DEVOLUCIÓN DE EQUIPOS'
                    : 'ACTA DE ASIGNACIÓN DE EQUIPOS'}
                </h1>
              </div>

              {/* Introducción y Receptor */}
              <div className="text-justify text-[10pt] sm:text-[10.5pt] leading-snug print:leading-normal text-slate-800">
                <p>
                  {act.act_type === 'return'
                    ? 'Por medio de la presente se deja constancia de la devolución y recepción conforme por parte de '
                    : 'Por medio de la presente hacemos entrega a '}
                  <strong className="text-black font-bold underline decoration-slate-400">
                    {act.recipient_name}
                  </strong>
                  , cédula de identidad:{' '}
                  <strong className="text-black font-mono font-bold">
                    {act.recipient_id_card}
                  </strong>
                  {act.recipient_position && (
                    <>
                      , cargo:{' '}
                      <strong className="text-black font-semibold">
                        {act.recipient_position}
                      </strong>
                    </>
                  )}
                  {act.recipient_department && (
                    <>
                      {' '}de la gerencia/área de{' '}
                      <strong className="text-black font-semibold">
                        {act.recipient_department}
                      </strong>
                    </>
                  )}
                  , de los siguientes equipos tecnológicos:
                </p>
              </div>

              {/* Resumen de cantidad y Tipo */}
              <div className="pt-0.5">
                <p className="text-[10pt] sm:text-[10.5pt] font-bold text-black">
                  {act.items.length === 1
                    ? 'Un (1) equipo detallado a continuación:'
                    : `${act.items.length} equipos detallados a continuación:`}
                </p>
              </div>

              {/* Tabla de Equipos Tabulada para Máximo Espacio y Legibilidad */}
              <div className="overflow-x-auto my-1">
                <table className="w-full border-collapse border border-black text-[10pt] text-left">
                  <thead>
                    <tr className="bg-slate-100 font-bold text-black border-b border-black">
                      <th
                        className={`border border-black ${
                          isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                        } text-center uppercase tracking-wider w-1/3`}
                      >
                        Tipo de equipo
                      </th>
                      <th
                        className={`border border-black ${
                          isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                        } text-center uppercase tracking-wider w-1/5`}
                      >
                        Marca
                      </th>
                      <th
                        className={`border border-black ${
                          isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                        } text-center uppercase tracking-wider w-1/4`}
                      >
                        Modelo
                      </th>
                      <th
                        className={`border border-black ${
                          isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                        } text-center uppercase tracking-wider font-mono`}
                      >
                        Serial
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {act.items.map((item, index) => (
                      <tr key={item.id || index} className="border-b border-black hover:bg-slate-50/50">
                        <td
                          className={`border border-black ${
                            isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                          } font-medium text-black`}
                        >
                          <div className="font-semibold leading-tight">
                            {item.equipment_type || item.equipment_name}
                          </div>
                          {showSpecs && item.specs && (
                            <div className="text-[10pt] text-slate-700 font-normal italic mt-0.5 leading-tight">
                              {item.specs}
                            </div>
                          )}
                        </td>
                        <td
                          className={`border border-black ${
                            isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                          } text-slate-900 text-center`}
                        >
                          {item.brand || '—'}
                        </td>
                        <td
                          className={`border border-black ${
                            isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                          } text-slate-900`}
                        >
                          {item.model || '—'}
                        </td>
                        <td
                          className={`border border-black ${
                            isMultiItem ? 'px-2 py-1' : 'px-3 py-1.5'
                          } font-mono font-bold text-black text-center whitespace-nowrap`}
                        >
                          {item.serial_number}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Accesorios Incluidos */}
              {act.accessories && (
                <div className="border border-black bg-slate-50/70 px-2.5 py-1.5 text-[10pt] text-slate-900">
                  <strong className="font-bold text-black uppercase tracking-wide">
                    Accesorios Incluidos:{' '}
                  </strong>
                  <span>{act.accessories}</span>
                </div>
              )}

              {/* Cláusula Legal de Custodia y Responsabilidad */}
              <div className="text-justify text-[10pt] leading-snug print:leading-normal text-slate-800 pt-1.5 space-y-1 border-t border-slate-200">
                <p>{act.terms_clause}</p>
              </div>
            </div>

            {/* Bloque de Firmas al Pie (Empujado al límite inferior de la página) */}
            <div className="pt-6 print:pt-4 break-inside-avoid print:break-inside-avoid mt-auto pb-0 mb-0">
              <div className="grid grid-cols-2 gap-8 sm:gap-14 text-[10pt] items-start">
                {/* Columna Emisor (Entrega / Recibe TI) */}
                <div className="flex flex-col">
                  <p className="font-bold text-black text-[10.5pt] mb-1">
                    {act.act_type === 'return' ? 'Recibe por TI:' : 'Entrega:'}
                  </p>
                  <div className="h-16 flex items-end justify-center relative">
                    {includeTiSignature && (act.delivered_by_name?.toLowerCase().includes('raimundo') || !act.delivered_by_name) && (
                      <img
                        src="/signature-raimundo.png"
                        alt="Firma de Raimundo Gil"
                        className="h-24 w-auto max-w-none object-contain -mb-3 relative z-10 pointer-events-none mix-blend-multiply"
                      />
                    )}
                  </div>
                  <div className="border-t-2 border-slate-900 pt-1.5 space-y-0.5">
                    <p className="font-bold text-black text-[10.5pt] leading-tight">
                      {act.delivered_by_name || 'Raimundo Gil'}
                    </p>
                    <p className="text-[10pt] text-slate-700 font-medium leading-tight">
                      {act.delivered_by_position || 'Gerente de Tecnología'}
                    </p>
                    <p className="text-[10pt] font-mono text-slate-600 leading-tight">
                      C.I: {act.delivered_by_id_card || '14.287.629'}
                    </p>
                    <span className="text-[10pt] text-slate-500 uppercase tracking-wider block pt-0.5">
                      {act.act_type === 'return' ? 'RECIBE CONFORME (TI)' : 'ENTREGA CONFORME'}
                    </span>
                  </div>
                </div>

                {/* Columna Receptor (Trabajador) */}
                <div className="flex flex-col">
                  <p className="font-bold text-black text-[10.5pt] mb-1">
                    {act.act_type === 'return' ? 'Devuelve:' : 'Recibe:'}
                  </p>
                  <div className="h-16 flex items-end justify-center">
                    {act.recipient_signature && (
                      <img
                        src={act.recipient_signature}
                        alt="Firma del receptor"
                        className="max-h-16 max-w-full object-contain mb-1"
                      />
                    )}
                  </div>
                  <div className="border-t-2 border-slate-900 pt-1.5 space-y-0.5">
                    <p className="font-bold text-black text-[10.5pt] leading-tight">
                      {act.recipient_name}
                    </p>
                    <p className="text-[10pt] text-slate-700 font-medium leading-tight">
                      {act.recipient_position || 'Trabajador'}{' '}
                      {act.recipient_department ? `- ${act.recipient_department}` : ''}
                    </p>
                    <p className="text-[10pt] font-mono text-slate-600 leading-tight">
                      C.I: {act.recipient_id_card}
                    </p>
                    <span className="text-[10pt] text-slate-500 uppercase tracking-wider block pt-0.5">
                      {act.act_type === 'return' ? 'ENTREGA CONFORME' : 'RECIBE CONFORME'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
      })()}
    </div>
  )
}
