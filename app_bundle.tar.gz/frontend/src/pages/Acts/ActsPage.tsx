import { useState, useEffect, useCallback } from 'react'
import {
  FileText,
  Plus,
  Search,
  Printer,
  Trash2,
  Calendar,
  User,
  Package,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ExternalLink,
  Camera,
  Sparkles,
  RotateCcw,
  Pencil,
} from 'lucide-react'
import {
  deliveryActsApi,
  type DeliveryAct,
  type EmployeeSolvencyItem,
} from '../../api/deliveryActs'
import { useAuthStore } from '../../store/authStore'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'
import { ActDocumentView } from './ActDocumentView'
import { NewActModal } from './NewActModal'
import { SolvencyCertificateView } from './SolvencyCertificateView'

export function ActsPage() {
  const { user } = useAuthStore()
  const isAdmin = user?.role === 'admin'

  const [activeTab, setActiveTab] = useState<'acts' | 'solvency'>('acts')
  const [scanFilter, setScanFilter] = useState<'all' | 'scanned' | 'pending'>('all')

  const [acts, setActs] = useState<DeliveryAct[]>([])
  const [solvencyList, setSolvencyList] = useState<EmployeeSolvencyItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedAct, setSelectedAct] = useState<DeliveryAct | null>(null)
  const [editingAct, setEditingAct] = useState<DeliveryAct | null>(null)
  const [selectedSolvencyEmp, setSelectedSolvencyEmp] = useState<EmployeeSolvencyItem | null>(null)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    setIsLoading(true)
    try {
      const [actsData, solvencyData] = await Promise.all([
        deliveryActsApi.list({ search: search || undefined }),
        deliveryActsApi.getEmployeesSolvency(search || undefined),
      ])
      setActs(actsData)
      setSolvencyList(solvencyData)
    } catch (err) {
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }, [search])

  useEffect(() => {
    loadData()
  }, [loadData])

  const handleDelete = async (act: DeliveryAct, e: React.MouseEvent) => {
    e.stopPropagation()
    const ok = window.confirm(
      `¿Deseas eliminar el acta ${act.act_number} emitida a nombre de "${act.recipient_name}"?`
    )
    if (!ok) return

    try {
      await deliveryActsApi.delete(act.id)
      loadData()
    } catch (err: any) {
      setActionError(err?.response?.data?.detail ?? 'No fue posible eliminar el acta.')
    }
  }

  const handleCreated = async (newAct: DeliveryAct) => {
    setShowCreateModal(false)
    setEditingAct(null)
    await loadData()
    if (!newAct.items || newAct.items.length === 0) {
      try {
        const fresh = await deliveryActsApi.get(newAct.id)
        setSelectedAct(fresh)
        return
      } catch (e) {
        console.error(e)
      }
    }
    setSelectedAct(newAct)
  }

  const handleActUpdated = async (updated: DeliveryAct) => {
    let actToSet = updated
    if (!updated.items || updated.items.length === 0) {
      try {
        actToSet = await deliveryActsApi.get(updated.id)
      } catch (e) {
        console.error(e)
      }
    }
    setActs((prev) => prev.map((a) => (a.id === actToSet.id ? actToSet : a)))
    setSelectedAct(actToSet)
    loadData()
  }

  const filteredActs = acts.filter((act) => {
    if (scanFilter === 'scanned') return Boolean(act.scanned_document_url)
    if (scanFilter === 'pending') return !act.scanned_document_url
    return true
  })

  const scannedCount = acts.filter((a) => Boolean(a.scanned_document_url)).length
  const pendingScanCount = acts.length - scannedCount

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto print:p-0 print:m-0 print:max-w-none">
      <div className={selectedAct || selectedSolvencyEmp ? 'print:hidden space-y-4' : 'space-y-4'}>
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-primary" />
            <span>Actas de Entrega, Respaldo Físico y Paz y Salvo</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm">
            Control documental, digitalización de hojas firmadas, evidencias fotográficas y solvencia RRHH
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="btn-primary py-2.5 px-4 text-xs sm:text-sm flex items-center gap-2 self-start sm:self-auto shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>+ Nueva Acta (Entrega / Devolución)</span>
        </button>
      </div>

      {actionError && (
        <div className="bg-rose-950/40 border border-rose-900/60 rounded-xl p-3 text-rose-400 text-xs font-semibold">
          {actionError}
        </div>
      )}

      {/* Pestañas: Actas vs Solvencia / Paz y Salvo RRHH */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 p-2 rounded-xl border border-slate-800">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('acts')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'acts'
                ? 'bg-primary text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Actas Emitidas ({acts.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('solvency')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'solvency'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Solvencia y Paz y Salvo RRHH ({solvencyList.length})</span>
          </button>
        </div>

        {activeTab === 'acts' && (
          <div className="flex items-center gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setScanFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-semibold ${
                scanFilter === 'all'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Todas ({acts.length})
            </button>
            <button
              type="button"
              onClick={() => setScanFilter('scanned')}
              className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 ${
                scanFilter === 'scanned'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-emerald-300'
              }`}
            >
              <CheckCircle2 className="w-3 h-3" />
              <span>Respaldadas ({scannedCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setScanFilter('pending')}
              className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 ${
                scanFilter === 'pending'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-slate-400 hover:text-amber-300'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Pendientes de Escaneo ({pendingScanCount})</span>
            </button>
          </div>
        )}
      </div>

      {/* Barra de Búsqueda */}
      <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder={
              activeTab === 'acts'
                ? 'Buscar por número de acta (ej. ACT-2026-0001), nombre del trabajador o cédula...'
                : 'Buscar trabajador por nombre, cédula o cargo para verificar Paz y Salvo...'
            }
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field pl-9 text-xs sm:text-sm"
          />
        </div>
      </div>

      {/* CONTENIDO PESTAÑA 1: LISTA DE ACTAS */}
      {isLoading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" />
        </div>
      ) : activeTab === 'acts' ? (
        filteredActs.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800 space-y-3">
            <FileText className="w-12 h-12 text-slate-600 mx-auto" />
            <p className="text-white font-bold text-base">No hay actas que coincidan con el filtro</p>
            <p className="text-slate-400 text-xs max-w-sm mx-auto">
              Genera una nueva acta de asignación o devolución para respaldar la custodia de equipos.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredActs.map((act) => {
              const dateStr = new Date(act.created_at).toLocaleDateString('es-ES', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
              })
              const photosCount = act.evidence_photos_list?.length || 0

              return (
                <div
                  key={act.id}
                  onClick={() => setSelectedAct(act)}
                  className="card p-4 hover:border-primary/50 transition-all cursor-pointer group flex flex-col justify-between space-y-3 bg-slate-900/90"
                >
                  <div className="space-y-2.5">
                    {/* Fila superior: Código, Tipo y Fecha */}
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-lg">
                          {act.act_number}
                        </span>
                        {act.act_type === 'return' && (
                          <span className="text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            <RotateCcw className="w-2.5 h-2.5" />
                            <span>Devolución</span>
                          </span>
                        )}
                      </div>
                      <span className="text-slate-400 text-[11px] flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {dateStr}
                      </span>
                    </div>

                    {/* Estado de Respaldo de Hoja Física Firmada */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      {act.scanned_document_url ? (
                        <span className="text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Hoja Física Escaneada</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>Pendiente Escaneo Físico</span>
                        </span>
                      )}

                      {photosCount > 0 && (
                        <span className="text-[10px] font-semibold bg-sky-500/15 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Camera className="w-3 h-3" />
                          <span>{photosCount} {photosCount === 1 ? 'foto' : 'fotos'}</span>
                        </span>
                      )}
                    </div>

                    {/* Datos del Trabajador Receptor */}
                    <div>
                      <h3 className="text-white font-bold text-sm group-hover:text-primary transition-colors flex items-center gap-1.5">
                        <User className="w-4 h-4 text-slate-400" />
                        <span>{act.recipient_name}</span>
                      </h3>
                      <p className="text-xs text-slate-400 font-mono pl-5">
                        C.I: {act.recipient_id_card}
                        {act.recipient_position ? ` • ${act.recipient_position}` : ''}
                      </p>
                    </div>

                    {/* Resumen de Equipos y Accesorios */}
                    <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
                      <div className="flex items-center justify-between text-xs text-slate-300 font-medium">
                        <span className="flex items-center gap-1.5">
                          <Package className="w-3.5 h-3.5 text-primary" />
                          <span>
                            {act.items.length} {act.items.length === 1 ? 'equipo' : 'equipos'}
                          </span>
                        </span>
                        {act.recipient_signature && (
                          <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Firma Digital</span>
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">
                        {act.items.map((i) => i.equipment_name).join(', ')}
                      </p>
                      {act.accessories && (
                        <p className="text-[10px] text-emerald-400/90 truncate flex items-center gap-1 pt-0.5">
                          <Sparkles className="w-2.5 h-2.5 flex-shrink-0" />
                          <span>Accesorios: {act.accessories}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Acciones */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                    <span className="text-[11px] text-slate-500 truncate">
                      Por: {act.delivered_by_name}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {act.scanned_document_url && (
                        <a
                          href={act.scanned_document_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/30 transition-colors"
                          title="Abrir Acta Física Firmada Escaneada"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          setEditingAct(act)
                        }}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-600/30 text-slate-300 hover:text-amber-300 border border-transparent hover:border-amber-500/30 transition-colors"
                        title="Editar Acta (Persona, Equipos o Accesorios)"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          setSelectedAct(act)
                        }}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-primary text-slate-300 hover:text-white transition-colors"
                        title="Imprimir o Escanear Hoja Firmada"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => handleDelete(act, e)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-300 border border-transparent hover:border-rose-500/30 transition-colors"
                        title="Eliminar Acta"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )
      ) : (
        /* CONTENIDO PESTAÑA 2: SOLVENCIA Y PAZ Y SALVO TECNOLÓGICO (RRHH) */
        <div className="space-y-3">
          {solvencyList.length === 0 ? (
            <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800 space-y-2">
              <ShieldCheck className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-white font-bold text-base">
                No hay registros de custodia de empleados aún
              </p>
              <p className="text-slate-400 text-xs">
                Al emitir actas de entrega o devolución, el historial de solvencia aparecerá aquí automáticamente.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {solvencyList.map((emp, idx) => (
                <div
                  key={idx}
                  className="card p-4 bg-slate-900/90 border border-slate-800 flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-white font-bold text-base flex items-center gap-1.5">
                          <User className="w-4 h-4 text-primary" />
                          <span>{emp.recipient_name}</span>
                        </h3>
                        <p className="text-xs text-slate-400 font-mono">
                          C.I: {emp.recipient_id_card}
                          {emp.recipient_position ? ` • ${emp.recipient_position}` : ''}
                          {emp.recipient_department ? ` (${emp.recipient_department})` : ''}
                        </p>
                      </div>

                      {emp.is_solvent ? (
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1 flex-shrink-0">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>PAZ Y SALVO (SOLVENTE)</span>
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex-shrink-0">
                          {emp.active_count} {emp.active_count === 1 ? 'Equipo Activo' : 'Equipos Activos'}
                        </span>
                      )}
                    </div>

                    {/* Equipos bajo custodia actual */}
                    {emp.active_equipment.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                        <p className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                          Equipos actualmente bajo su responsabilidad:
                        </p>
                        {emp.active_equipment.map((eq, i) => (
                          <div
                            key={i}
                            className="flex items-center justify-between text-xs text-slate-300"
                          >
                            <span className="font-semibold truncate">{eq.equipment_name}</span>
                            <span className="font-mono text-[11px] text-slate-400">
                              SN: {eq.serial_number} ({eq.act_number})
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Equipos devueltos */}
                    {emp.returned_equipment.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-900/40 space-y-1">
                        <p className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                          Equipos devueltos / reintegrados ({emp.returned_count}):
                        </p>
                        {emp.returned_equipment.slice(0, 3).map((eq, i) => (
                          <div
                            key={i}
                            className="flex items-center justify-between text-xs text-slate-400"
                          >
                            <span className="truncate">{eq.equipment_name}</span>
                            <span className="font-mono text-[11px]">SN: {eq.serial_number}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">
                      {emp.acts.length} {emp.acts.length === 1 ? 'acta registrada' : 'actas registradas'}
                    </span>

                    <button
                      type="button"
                      onClick={() => setSelectedSolvencyEmp(emp)}
                      className="btn-primary py-1.5 px-3 text-xs font-bold flex items-center gap-1.5"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Emitir Paz y Salvo TI</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal para Crear o Editar Acta */}
      {(showCreateModal || editingAct) && (
        <NewActModal
          actToEdit={editingAct}
          onClose={() => {
            setShowCreateModal(false)
            setEditingAct(null)
          }}
          onCreated={handleCreated}
        />
      )}
      </div>

      {/* Visor, Escáner de Hoja Firmada e Impresión del Acta */}
      {selectedAct && (
        <ActDocumentView
          act={selectedAct}
          onClose={() => setSelectedAct(null)}
          onUpdated={handleActUpdated}
          onEdit={(actToMod) => setEditingAct(actToMod)}
          onDelete={async (actToDelete) => {
            const ok = window.confirm(
              `¿Deseas eliminar el acta ${actToDelete.act_number} emitida a nombre de "${actToDelete.recipient_name}"?`
            )
            if (!ok) return
            try {
              await deliveryActsApi.delete(actToDelete.id)
              setSelectedAct(null)
              loadData()
            } catch (err: any) {
              alert(err?.response?.data?.detail ?? 'No fue posible eliminar el acta.')
            }
          }}
        />
      )}

      {/* Visor de Certificado de Solvencia / Paz y Salvo RRHH */}
      {selectedSolvencyEmp && (
        <SolvencyCertificateView
          employee={selectedSolvencyEmp}
          onClose={() => setSelectedSolvencyEmp(null)}
        />
      )}
    </div>
  )
}
