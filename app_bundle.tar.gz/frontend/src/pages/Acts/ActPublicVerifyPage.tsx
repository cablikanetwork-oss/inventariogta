import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  User,
  Package,
  Calendar,
  CheckCircle2,
  Camera,
  ArrowLeft,
  FileSignature,
  Lock,
  Sparkles,
  RotateCcw,
  ExternalLink,
  FileText,
} from 'lucide-react'
import {
  deliveryActsApi,
  type PublicActVerificationResponse,
} from '../../api/deliveryActs'
import { useAuthStore } from '../../store/authStore'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

export function ActPublicVerifyPage() {
  const { identifier } = useParams<{ identifier: string }>()
  const navigate = useNavigate()
  const { isAuthenticated } = useAuthStore()

  const [data, setData] = useState<PublicActVerificationResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isReturning, setIsReturning] = useState(false)

  const loadVerification = () => {
    if (!identifier) {
      setError('No se especificó un código de documento para verificar.')
      setLoading(false)
      return
    }
    setLoading(true)
    setError(null)
    deliveryActsApi
      .publicVerifyAct(identifier)
      .then((res) => {
        setData(res)
        setLoading(false)
      })
      .catch((err: any) => {
        setError(
          err?.response?.data?.detail ||
            'ALERTA: Este código no corresponde a ningún documento oficial emitido por la Gerencia de Tecnología.'
        )
        setLoading(false)
      })
  }

  useEffect(() => {
    loadVerification()
  }, [identifier])

  const handleQuickReturn = async () => {
    if (!data || isReturning) return
    const ok = window.confirm(
      `¿Confirmas que "${data.act.recipient_name}" está devolviendo el(los) equipo(s) y deseas emitir su Acta de Devolución / Solvencia con TI?`
    )
    if (!ok) return
    setIsReturning(true)
    try {
      const returnAct = await deliveryActsApi.create({
        city: data.act.city || 'Caracas',
        act_type: 'return',
        recipient_name: data.act.recipient_name,
        recipient_id_card: data.act.recipient_id_card,
        recipient_position: data.act.recipient_position || undefined,
        recipient_department: data.act.recipient_department || undefined,
        delivered_by_name: data.act.delivered_by_name || 'Raimundo Gil',
        delivered_by_position: data.act.delivered_by_position || 'Gerente de Tecnología',
        delivered_by_id_card: data.act.delivered_by_id_card || '14.287.629',
        accessories: data.act.accessories || undefined,
        notes: `Devolución y Solvencia TI generada desde verificación de ${data.act.act_number}`,
        items: data.act.items.map((it) => ({
          equipment_id: it.equipment_id || undefined,
          equipment_name: it.equipment_name,
          equipment_type: it.equipment_type || 'Equipo Tecnológico',
          brand: it.brand || undefined,
          model: it.model || undefined,
          serial_number: it.serial_number,
          specs: it.specs || undefined,
        })),
        auto_assign_equipment: true,
      })
      navigate(`/verify-act/${encodeURIComponent(returnAct.act_number)}`)
    } catch (err) {
      console.error(err)
      alert('No se pudo registrar la devolución.')
    } finally {
      setIsReturning(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center text-white">
        <LoadingSpinner size="lg" />
        <p className="mt-4 text-slate-400 text-sm animate-pulse">
          Verificando autenticidad criptográfica del documento en el servidor de TI...
        </p>
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center text-white">
        <div className="w-20 h-20 rounded-3xl bg-rose-500/15 border-2 border-rose-500/40 flex items-center justify-center text-rose-400 mb-4 shadow-[0_0_40px_rgba(244,63,94,0.3)]">
          <ShieldAlert className="w-10 h-10" />
        </div>
        <span className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-black uppercase tracking-wider mb-2">
          ALERTA DE SEGURIDAD — DOCUMENTO NO VERIFICADO
        </span>
        <h2 className="text-xl font-black mb-2 text-white">Posible Documento No Oficial o Alterado</h2>
        <p className="text-slate-300 text-sm max-w-md mb-6 leading-relaxed">{error}</p>
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => navigate('/scan')}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-white font-bold text-sm"
          >
            <Camera className="w-4 h-4" />
            <span>Abrir Escáner AR / HUD</span>
          </button>
          <button
            onClick={() => navigate('/')}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Ir al Inicio</span>
          </button>
        </div>
      </div>
    )
  }

  const { act, company, validity_status, security_verdict, verification_hash, allow_exit } = data
  const isAssignmentActive = validity_status === 'VALID_ACTIVE_ASSIGNMENT'
  const isReturnSolvency = validity_status === 'VALID_RETURN_SOLVENCY'

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col items-center justify-start p-4 sm:p-6 pb-24">
      {/* Cabecera Institucional */}
      <div className="w-full max-w-2xl flex items-center justify-between py-3 border-b border-slate-800 mb-5">
        <div className="flex items-center gap-3">
          {company.logo_url ? (
            <img
              src={company.logo_url}
              alt={company.name}
              className="h-10 w-auto max-w-[150px] object-contain rounded bg-white/5 p-1"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center font-black text-white">
              {company.name.charAt(0)}
            </div>
          )}
          <div>
            <h1 className="text-sm font-black tracking-wide text-white uppercase">
              {company.name}
            </h1>
            <p className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
              <Lock className="w-3 h-3" />
              <span>Verificación Oficial de Seguridad y Auditoría TI</span>
            </p>
          </div>
        </div>

        <button
          onClick={() => navigate('/scan')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700"
        >
          <Camera className="w-3.5 h-3.5 text-cyan-400" />
          <span>Escanear Otro</span>
        </button>
      </div>

      <div className="w-full max-w-2xl space-y-4">
        {/* BANNER PRINCIPAL DE AUTENTICIDAD PARA SEGURIDAD / GARITA / RRHH */}
        <div
          className={`rounded-3xl p-5 border-2 shadow-2xl ${
            isAssignmentActive
              ? 'bg-emerald-950/40 border-emerald-500/60 shadow-[0_0_35px_rgba(16,185,129,0.2)]'
              : isReturnSolvency
              ? 'bg-sky-950/40 border-sky-500/60 shadow-[0_0_35px_rgba(14,165,233,0.2)]'
              : 'bg-amber-950/40 border-amber-500/60 shadow-[0_0_35px_rgba(245,158,11,0.2)]'
          }`}
        >
          <div className="flex items-start gap-3.5">
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                isAssignmentActive
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : isReturnSolvency
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              }`}
            >
              {isAssignmentActive || isReturnSolvency ? (
                <ShieldCheck className="w-7 h-7" />
              ) : (
                <AlertTriangle className="w-7 h-7" />
              )}
            </div>

            <div className="space-y-1.5 flex-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span
                  className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full border ${
                    isAssignmentActive
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : isReturnSolvency
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  }`}
                >
                  {isAssignmentActive
                    ? '✓ DOCUMENTO OFICIAL AUTÉNTICO (NO MONTADO)'
                    : isReturnSolvency
                    ? '🛡️ PAZ Y SALVO / DEVOLUCIÓN TI VERIFICADA'
                    : '⚠ ACTA HISTÓRICA / EQUIPO YA REINTEGRADO'}
                </span>

                <span className="text-[10px] font-mono text-slate-400">
                  SELLO SHA: {verification_hash}
                </span>
              </div>

              <h2 className="text-base sm:text-lg font-black text-white leading-snug">
                {security_verdict}
              </h2>

              <p className="text-xs text-slate-300 leading-relaxed">
                {allow_exit
                  ? 'Personal de Seguridad: Verifique que la Cédula de Identidad del portador y el Serial (S/N) físico del equipo coincidan exactamente con los datos oficiales mostrados abajo.'
                  : isReturnSolvency
                  ? 'Recursos Humanos / Seguridad: Este documento certifica que el trabajador reintegró satisfactoriamente los equipos listados a la Gerencia de Tecnología.'
                  : 'Personal de Seguridad: Esta hoja corresponde a una asignación pasada cuyo equipo ya fue devuelto o reasignado en el sistema. NO autoriza salida actual del equipo.'}
              </p>
            </div>
          </div>
        </div>

        {/* DATOS DEL TRABAJADOR VERIFICADOS EN SERVIDOR */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-primary/20 text-primary flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  {isReturnSolvency
                    ? 'Trabajador Solvente / Que Devuelve'
                    : 'Trabajador Autorizado en el Acta'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  Datos originales registrados en la Base de Datos de TI
                </p>
              </div>
            </div>

            <span className="text-xs font-mono font-bold text-primary bg-primary/10 border border-primary/30 px-2.5 py-1 rounded-lg">
              {act.act_number}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Nombre y Apellido Oficial
              </span>
              <span className="text-sm font-black text-white mt-0.5 block">
                {act.recipient_name}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Cédula de Identidad / DNI
              </span>
              <span className="text-sm font-mono font-black text-emerald-400 mt-0.5 block">
                {act.recipient_id_card}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Cargo / Área
              </span>
              <span className="text-xs font-semibold text-slate-200 mt-0.5 block">
                {[act.recipient_position || 'Trabajador', act.recipient_department]
                  .filter(Boolean)
                  .join(' • ')}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Fecha de Emisión Oficial
              </span>
              <span className="text-xs font-semibold text-slate-200 mt-0.5 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {act.created_at
                  ? new Date(act.created_at).toLocaleString('es-ES', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'Registrado'}
              </span>
            </div>
          </div>

          {/* Firma Digital o Respaldo de Hoja Física Escaneada */}
          {act.recipient_signature && (
            <div className="p-3 rounded-xl bg-white text-slate-900 flex items-center justify-between border border-slate-300">
              <div className="flex items-center gap-2">
                <FileSignature className="w-4 h-4 text-blue-600" />
                <div>
                  <p className="text-xs font-bold">Firma Digital del Trabajador</p>
                  <p className="text-[10px] text-slate-500">Capturada en el dispositivo de TI</p>
                </div>
              </div>
              <img
                src={act.recipient_signature}
                alt="Firma"
                className="h-10 w-28 object-contain"
              />
            </div>
          )}

          {act.scanned_document_url && (
            <a
              href={act.scanned_document_url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Ver Hoja Física Escaneada con Firmas en Bolígrafo</span>
            </a>
          )}
        </div>

        {/* EQUIPOS TECNOLÓGICOS INCLUIDOS EN EL DOCUMENTO */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 space-y-3">
          <div className="flex items-center gap-2.5 border-b border-slate-800 pb-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Equipos Verificados en este Documento ({act.items.length})
              </h3>
              <p className="text-[11px] text-slate-400">
                Compara el Serial físico del equipo contra esta lista oficial
              </p>
            </div>
          </div>

          <div className="space-y-2.5">
            {act.items.map((item, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">{item.equipment_name}</span>
                    <span className="text-xs text-slate-400">
                      {[item.brand, item.model].filter(Boolean).join(' • ')}
                    </span>
                  </div>
                  {item.specs && (
                    <p className="text-[11px] text-slate-400 font-mono">{item.specs}</p>
                  )}
                </div>

                <div className="flex flex-col sm:items-end gap-1 shrink-0">
                  <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs font-black text-cyan-300">
                    S/N: {item.serial_number}
                  </span>
                  {item.currently_assigned_to_recipient ? (
                    <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Custodia Activa Confirmada</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold text-sky-400">
                      Reintegrado a TI ({item.live_status.toUpperCase()})
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {act.accessories && (
            <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-800/40 text-xs">
              <span className="font-bold text-emerald-400 flex items-center gap-1 mb-0.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Accesorios Incluidos / Autorizados:</span>
              </span>
              <span className="text-slate-200">{act.accessories}</span>
            </div>
          )}
        </div>

        {/* AUTORIDAD EMISORA DE TI */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">
              Autorizado y Emitido por Gerencia de Tecnología:
            </span>
            <p className="text-sm font-bold text-white mt-0.5">{act.delivered_by_name}</p>
            <p className="text-slate-400">
              {act.delivered_by_position} • C.I: {act.delivered_by_id_card}
            </p>
          </div>
          <div className="flex items-center gap-3 self-end sm:self-auto">
            {(act.delivered_by_name?.toLowerCase().includes('raimundo') || !act.delivered_by_name) && (
              <img
                src="/signature-raimundo.png"
                alt="Firma Raimundo Gil"
                className="h-12 w-auto object-contain bg-white/10 rounded-lg p-1 border border-slate-700/60"
              />
            )}
            <div className="text-right">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold text-[11px]">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Firma TI Válida</span>
              </span>
            </div>
          </div>
        </div>

        {/* ACCIONES EXCLUSIVAS SI EL GERENTE DE TI TIENE SESIÓN INICIADA */}
        {isAuthenticated && (
          <div className="rounded-2xl border border-primary/40 bg-primary/10 p-4 space-y-2.5">
            <p className="text-xs font-bold text-white uppercase tracking-wider">
              Acciones Rápidas de Gerencia de Tecnología:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {isAssignmentActive && (
                <button
                  type="button"
                  disabled={isReturning}
                  onClick={handleQuickReturn}
                  className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>
                    {isReturning
                      ? 'Generando Devolución...'
                      : 'Recibir Equipo y Emitir Solvencia TI'}
                  </span>
                </button>
              )}

              <Link
                to="/acts"
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-slate-700"
              >
                <FileText className="w-4 h-4 text-primary" />
                <span>Ir al Panel de Actas y Solvencias</span>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

