import { useEffect, useRef } from 'react'
import { Printer, X, ArrowLeft, ShieldCheck } from 'lucide-react'
import { BrowserQRCodeSvgWriter } from '@zxing/browser'
import { type EmployeeSolvencyItem } from '../../api/deliveryActs'
import { useThemeStore } from '../../store/themeStore'

interface Props {
  employee: EmployeeSolvencyItem
  onClose: () => void
}

export function SolvencyCertificateView({ employee, onClose }: Props) {
  const { config } = useThemeStore()
  const modalScrollRef = useRef<HTMLDivElement>(null)
  const qrContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!qrContainerRef.current) return
    qrContainerRef.current.innerHTML = ''
    try {
      let origin = typeof window !== 'undefined' ? window.location.origin : ''
      if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
        origin = origin.replace('localhost', '10.101.159').replace('127.0.0.1', '10.101.159')
      }
      const verifyUrl = `${origin}/verify-act/SOLV-${encodeURIComponent(employee.recipient_id_card)}`
      const writer = new BrowserQRCodeSvgWriter()
      const svg = writer.write(verifyUrl, 68, 68)
      svg.setAttribute('style', 'width: 64px; height: 64px; display: block;')
      qrContainerRef.current.appendChild(svg)
    } catch (err) {
      console.error('Error generando QR de solvencia:', err)
    }
  }, [employee.recipient_id_card])

  const handlePrint = () => {
    if (modalScrollRef.current) {
      modalScrollRef.current.scrollTop = 0
    }
    window.scrollTo(0, 0)
    setTimeout(() => {
      window.print()
    }, 50)
  }

  const todayFormatted = new Intl.DateTimeFormat('es-ES', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date())

  const mgrName = localStorage.getItem('deliv_mgr_name') || 'Raimundo Gil'
  const mgrPos = localStorage.getItem('deliv_mgr_pos') || 'Gerente de Tecnología'
  const mgrCi = localStorage.getItem('deliv_mgr_ci') || '14.287.629'

  return (
    <div
      ref={modalScrollRef}
      className="print-modal-root fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-start overflow-y-auto p-2 sm:p-6 print:static print:overflow-visible print:p-0 print:bg-white print:block"
    >
      {/* Barra Superior (Oculta al imprimir) */}
      <div className="w-full max-w-3xl flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-xl mb-4 shadow-xl print:hidden flex-shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="btn-secondary py-1.5 px-3 text-xs flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Volver</span>
          </button>
          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 ml-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Certificado de Solvencia / Paz y Salvo de TI</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="btn-primary py-1.5 px-4 text-xs flex items-center gap-2 shadow-md"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir Certificado</span>
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* HOJA CARTA / A4 IMPRIMIBLE */}
      <div
        className="print-sheet-page flex-shrink-0 h-auto w-full max-w-[210mm] min-h-[275mm] print:min-h-[235mm] bg-white text-slate-900 shadow-2xl p-8 sm:p-14 font-sans print:shadow-none print:p-6 print:w-full print:max-w-none print:m-0 flex flex-col justify-between"
        style={{ backgroundColor: '#ffffff', color: '#0f172a' }}
      >
        <div className="space-y-6">
          {/* Encabezado */}
          <div className="flex items-start justify-between">
            <div className="flex flex-col items-start max-w-[260px]">
              {config?.logo_url ? (
                <img
                  src={config.logo_url}
                  alt={config.name || 'Logotipo Empresa'}
                  className="h-[75px] max-w-[240px] object-contain"
                />
              ) : (
                <div className="border-2 border-slate-800 rounded p-2.5 text-center">
                  <span className="font-black text-base tracking-widest uppercase">
                    {config?.name || 'GRUPO TUANDAMIO'}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right text-sm text-slate-700 font-medium">
                <p>Caracas, {todayFormatted}</p>
              </div>
              <div
                ref={qrContainerRef}
                className="border border-slate-300 rounded p-0.5 bg-white flex-shrink-0"
                title="Código QR Oficial de Verificación de Solvencia TI"
              />
            </div>
          </div>

          {/* Título Central */}
          <div className="text-center pt-4">
            <h1 className="text-base sm:text-lg font-black tracking-wide uppercase underline underline-offset-4 text-black">
              CERTIFICADO DE SOLVENCIA Y PAZ Y SALVO TECNOLÓGICO
            </h1>
          </div>

          {/* Cuerpo del Certificado */}
          <div className="text-justify text-sm leading-relaxed text-slate-800 space-y-3 pt-2">
            <p>
              Quien suscribe, <strong className="text-black font-bold">{mgrName}</strong>, en mi
              carácter de <strong className="text-black font-semibold">{mgrPos}</strong>, hago
              constar por medio de la presente que el(la) trabajador(a){' '}
              <strong className="text-black font-bold underline decoration-slate-400">
                {employee.recipient_name}
              </strong>
              , titular de la Cédula de Identidad N°{' '}
              <strong className="text-black font-mono font-bold">
                {employee.recipient_id_card}
              </strong>
              {employee.recipient_position ? (
                <>
                  , desempeñando el cargo de{' '}
                  <strong className="text-black font-semibold">
                    {employee.recipient_position}
                  </strong>
                </>
              ) : null}
              {employee.recipient_department ? (
                <>
                  {' '}adscrito(a) a{' '}
                  <strong className="text-black font-semibold">
                    {employee.recipient_department}
                  </strong>
                </>
              ) : null}
              , presenta a la fecha el siguiente estado de custodia sobre los activos tecnológicos
              propiedad de la organización:
            </p>
          </div>

          {/* Caja de Dictamen de Solvencia */}
          <div className="border-2 border-black p-4 bg-slate-50 text-center space-y-1">
            <p className="text-xs uppercase tracking-widest font-bold text-slate-600">
              DICTAMEN OFICIAL DE AUDITORÍA DE ACTIVOS TI
            </p>
            {employee.is_solvent ? (
              <p className="text-base font-black text-black uppercase tracking-wide">
                ✓ SOLVENTE (PAZ Y SALVO TECNOLÓGICO OTORGADO — 0 EQUIPOS PENDIENTES)
              </p>
            ) : (
              <p className="text-base font-black text-black uppercase tracking-wide">
                ⚠ CON CUSTODIA ACTIVA ({employee.active_count}{' '}
                {employee.active_count === 1 ? 'EQUIPO ASIGNADO' : 'EQUIPOS ASIGNADOS'})
              </p>
            )}
          </div>

          {/* Tabla de Equipos Reintegrados / Devueltos */}
          {employee.returned_equipment.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs font-bold uppercase tracking-wider text-black">
                Equipos Reintegrados Satisfactoriamente a la Gerencia de Tecnología:
              </p>
              <table className="w-full border-collapse border border-black text-xs text-left">
                <thead>
                  <tr className="bg-slate-100 font-bold text-black">
                    <th className="border border-black px-3 py-1.5">Equipo</th>
                    <th className="border border-black px-3 py-1.5">Marca / Modelo</th>
                    <th className="border border-black px-3 py-1.5 text-center font-mono">Serial</th>
                    <th className="border border-black px-3 py-1.5 text-center">Ref. Acta</th>
                  </tr>
                </thead>
                <tbody>
                  {employee.returned_equipment.map((eq, idx) => (
                    <tr key={idx}>
                      <td className="border border-black px-3 py-1.5 font-semibold text-black">
                        {eq.equipment_name}
                      </td>
                      <td className="border border-black px-3 py-1.5 text-slate-800">
                        {[eq.brand, eq.model].filter(Boolean).join(' ') || '—'}
                      </td>
                      <td className="border border-black px-3 py-1.5 font-mono font-bold text-center text-black">
                        {eq.serial_number}
                      </td>
                      <td className="border border-black px-3 py-1.5 font-mono text-center text-slate-700">
                        {eq.act_number}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Tabla de Equipos Aún Bajo Custodia (si aplica) */}
          {employee.active_equipment.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs font-bold uppercase tracking-wider text-black">
                Equipos Actualmente Bajo Custodia del Trabajador:
              </p>
              <table className="w-full border-collapse border border-black text-xs text-left">
                <thead>
                  <tr className="bg-slate-100 font-bold text-black">
                    <th className="border border-black px-3 py-1.5">Equipo</th>
                    <th className="border border-black px-3 py-1.5">Marca / Modelo</th>
                    <th className="border border-black px-3 py-1.5 text-center font-mono">Serial</th>
                    <th className="border border-black px-3 py-1.5 text-center">Acta Asignación</th>
                  </tr>
                </thead>
                <tbody>
                  {employee.active_equipment.map((eq, idx) => (
                    <tr key={idx}>
                      <td className="border border-black px-3 py-1.5 font-semibold text-black">
                        {eq.equipment_name}
                      </td>
                      <td className="border border-black px-3 py-1.5 text-slate-800">
                        {[eq.brand, eq.model].filter(Boolean).join(' ') || '—'}
                      </td>
                      <td className="border border-black px-3 py-1.5 font-mono font-bold text-center text-black">
                        {eq.serial_number}
                      </td>
                      <td className="border border-black px-3 py-1.5 font-mono text-center text-slate-700">
                        {eq.act_number}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="text-justify text-xs sm:text-sm leading-relaxed text-slate-800 pt-2">
            <p>
              Constancia que se expide a solicitud de la Gerencia de Recursos Humanos (RRHH) para
              fines administrativos, auditoría de activos y control de solvencia laboral.
            </p>
          </div>
        </div>

        {/* Bloque de Firmas al Pie (Alineación Horizontal Estricta) */}
        <div className="pt-8 break-inside-avoid">
          <div className="grid grid-cols-2 gap-8 sm:gap-14 text-sm items-start">
            {/* Emisor: Gerente de Tecnología */}
            <div className="flex flex-col">
              <p className="font-bold text-black text-sm mb-2">Por Gerencia de Tecnología:</p>
              <div className="h-20 flex items-end" />
              <div className="border-t-2 border-slate-900 pt-2 space-y-0.5">
                <p className="font-bold text-black text-sm leading-tight">{mgrName}</p>
                <p className="text-xs text-slate-700 font-medium leading-tight">{mgrPos}</p>
                <p className="text-xs font-mono text-slate-600 leading-tight">C.I: {mgrCi}</p>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block pt-1">
                  AUTORIZADO CONFORME
                </span>
              </div>
            </div>

            {/* Receptor: Trabajador / RRHH */}
            <div className="flex flex-col">
              <p className="font-bold text-black text-sm mb-2">Trabajador / Recursos Humanos:</p>
              <div className="h-20 flex items-end" />
              <div className="border-t-2 border-slate-900 pt-2 space-y-0.5">
                <p className="font-bold text-black text-sm leading-tight">
                  {employee.recipient_name}
                </p>
                <p className="text-xs text-slate-700 font-medium leading-tight">
                  {employee.recipient_position || 'Trabajador'}{' '}
                  {employee.recipient_department ? `- ${employee.recipient_department}` : ''}
                </p>
                <p className="text-xs font-mono text-slate-600 leading-tight">
                  C.I: {employee.recipient_id_card}
                </p>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block pt-1">
                  RECIBIDO CONFORME
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

