import { useState, useEffect, useRef } from 'react'
import { X, FileText, Check, Trash2, Search, Package, Sparkles, Camera, RotateCcw, Pencil } from 'lucide-react'
import { deliveryActsApi, type DeliveryAct, type DeliveryActItemCreate } from '../../api/deliveryActs'
import { equipmentApi, type Equipment } from '../../api/equipment'
import { SignaturePad, type SignaturePadRef } from '../../components/SignaturePad/SignaturePad'

interface Props {
  initialEquipment?: Equipment | null
  actToEdit?: DeliveryAct | null
  onClose: () => void
  onCreated: (act: DeliveryAct) => void
}

const PRESET_ACCESSORIES = [
  'Cargador Original',
  'Mouse',
  'Maletín / Funda',
  'Guaya de Seguridad',
  'Adaptador HDMI / USB-C',
  'Base Refrigerante',
  'Teclado Externo',
  'Auriculares / Headset',
]

export function NewActModal({ initialEquipment, actToEdit, onClose, onCreated }: Props) {
  const isEditing = Boolean(actToEdit)
  const sigPadRef = useRef<SignaturePadRef>(null)

  const [availableEquipment, setAvailableEquipment] = useState<Equipment[]>([])
  const [eqSearch, setEqSearch] = useState('')
  const [onlyAvailable, setOnlyAvailable] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [replaceSignature, setReplaceSignature] = useState(false)
  const [clearExistingSignature, setClearExistingSignature] = useState(false)

  // Datos persistentes del gerente / emisor de la entrega
  const defaultMgrName = localStorage.getItem('deliv_mgr_name') || 'Raimundo Gil'
  const defaultMgrPos = localStorage.getItem('deliv_mgr_pos') || 'Gerente de Tecnología'
  const defaultMgrCi = localStorage.getItem('deliv_mgr_ci') || '14.287.629'

  const [form, setForm] = useState({
    city: actToEdit?.city || 'Caracas',
    act_type: actToEdit?.act_type || 'assignment',
    recipient_name: actToEdit?.recipient_name || initialEquipment?.assigned_to || '',
    recipient_id_card: actToEdit?.recipient_id_card || '',
    recipient_position: actToEdit?.recipient_position || '',
    recipient_department: actToEdit?.recipient_department || '',
    delivered_by_name: actToEdit?.delivered_by_name || defaultMgrName,
    delivered_by_position: actToEdit?.delivered_by_position || defaultMgrPos,
    delivered_by_id_card: actToEdit?.delivered_by_id_card || defaultMgrCi,
    notes: actToEdit?.notes || '',
  })

  // Inicializar accesorios (separando los predefinidos de los personalizados si se está editando)
  const parseInitialAccessories = () => {
    if (!actToEdit) {
      return { presets: ['Cargador Original'], custom: '' }
    }
    if (!actToEdit.accessories) {
      return { presets: [], custom: '' }
    }
    const parts = actToEdit.accessories
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
    const presets = parts.filter((p) => PRESET_ACCESSORIES.includes(p))
    const customList = parts.filter((p) => !PRESET_ACCESSORIES.includes(p))
    return { presets, custom: customList.join(', ') }
  }

  const initialAcc = parseInitialAccessories()

  // Checklist Rápido de Accesorios
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>(initialAcc.presets)
  const [customAccessory, setCustomAccessory] = useState(initialAcc.custom)

  // Fotos de Evidencia Iniciales ("Antes y Después")
  const [initialEvidenceFiles, setInitialEvidenceFiles] = useState<File[]>([])

  // Items de equipos incluidos en el acta
  const [selectedItems, setSelectedItems] = useState<DeliveryActItemCreate[]>([])

  useEffect(() => {
    if (actToEdit) {
      setSelectedItems(
        actToEdit.items.map((it) => ({
          equipment_id: it.equipment_id || undefined,
          equipment_name: it.equipment_name,
          equipment_type: it.equipment_type || 'Equipo Tecnológico',
          brand: it.brand || '',
          model: it.model || '',
          serial_number: it.serial_number,
          specs: it.specs || '',
        }))
      )
    } else if (initialEquipment) {
      setSelectedItems([
        {
          equipment_id: initialEquipment.id,
          equipment_name: initialEquipment.name,
          equipment_type: initialEquipment.category ? initialEquipment.category.toUpperCase() : 'Equipo Tecnológico',
          brand: initialEquipment.brand || '',
          model: initialEquipment.model || '',
          serial_number: initialEquipment.serial_number,
          specs: initialEquipment.notes || '',
        },
      ])
    }

    equipmentApi.list()
      .then((items) => setAvailableEquipment(items))
      .catch(console.error)
  }, [initialEquipment, actToEdit])

  // Si cambia a devolución, desactivar filtro "Solo disponibles" para ver los asignados
  useEffect(() => {
    if (form.act_type === 'return') {
      setOnlyAvailable(false)
    } else {
      setOnlyAvailable(true)
    }
  }, [form.act_type])

  const toggleAccessoryChip = (acc: string) => {
    setSelectedAccessories((prev) =>
      prev.includes(acc) ? prev.filter((item) => item !== acc) : [...prev, acc]
    )
  }

  // Agregar o quitar equipo desde el inventario existente
  const handleToggleEquipment = (eq: Equipment) => {
    const exists = selectedItems.some((i) => i.equipment_id === eq.id)
    if (exists) {
      setSelectedItems((prev) => prev.filter((i) => i.equipment_id !== eq.id))
      return
    }

    const wasAlreadyInThisAct = Boolean(
      actToEdit?.items.some((i) => i.equipment_id === eq.id)
    )

    if (form.act_type === 'assignment' && eq.status !== 'available' && !wasAlreadyInThisAct) {
      alert(
        `El equipo "${eq.name}" (SN: ${eq.serial_number}) no está disponible. Estado actual: ${eq.status.toUpperCase()}${
          eq.assigned_to ? ` (Asignado a: ${eq.assigned_to})` : ''
        }. Debe registrarse una devolución antes de reasignarlo.`
      )
      return
    }

    // Si es devolución y aún no se ha puesto nombre del trabajador, autocompletar con assigned_to
    if (form.act_type === 'return' && eq.assigned_to && !form.recipient_name.trim()) {
      setForm((f) => ({ ...f, recipient_name: eq.assigned_to || '' }))
    }

    setSelectedItems((prev) => [
      ...prev,
      {
        equipment_id: eq.id,
        equipment_name: eq.name,
        equipment_type: eq.category ? eq.category.toUpperCase() : 'Equipo Tecnológico',
        brand: eq.brand || '',
        model: eq.model || '',
        serial_number: eq.serial_number,
        specs: eq.notes || '',
      },
    ])
  }

  const handleUpdateItemField = (
    index: number,
    field: keyof DeliveryActItemCreate,
    value: string
  ) => {
    setSelectedItems((prev) => {
      const copy = [...prev]
      copy[index] = { ...copy[index], [field]: value }
      return copy
    })
  }

  const handleRemoveItem = (index: number) => {
    setSelectedItems((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.recipient_name.trim() || !form.recipient_id_card.trim()) {
      setError('Por favor ingresa el nombre y la cédula del trabajador.')
      return
    }

    if (selectedItems.length === 0) {
      setError('Debes incluir al menos un equipo en el acta.')
      return
    }

    setIsSubmitting(true)
    setError(null)

    try {
      const newDrawnSignature = sigPadRef.current?.getSignatureDataUrl() || undefined

      localStorage.setItem('deliv_mgr_name', form.delivered_by_name)
      localStorage.setItem('deliv_mgr_pos', form.delivered_by_position)
      localStorage.setItem('deliv_mgr_ci', form.delivered_by_id_card)

      const allAccessories = [
        ...selectedAccessories,
        ...(customAccessory.trim() ? [customAccessory.trim()] : []),
      ]
      const accessoriesStr = allAccessories.length > 0 ? allAccessories.join(', ') : ''

      let act: DeliveryAct

      if (isEditing && actToEdit) {
        let finalSignature: string | undefined = undefined
        if (clearExistingSignature) {
          finalSignature = ''
        } else if (replaceSignature && newDrawnSignature) {
          finalSignature = newDrawnSignature
        } else if (!actToEdit.recipient_signature && newDrawnSignature) {
          finalSignature = newDrawnSignature
        }

        act = await deliveryActsApi.update(actToEdit.id, {
          city: form.city,
          act_type: form.act_type,
          recipient_name: form.recipient_name.trim(),
          recipient_id_card: form.recipient_id_card.trim(),
          recipient_position: form.recipient_position.trim(),
          recipient_department: form.recipient_department.trim(),
          ...(finalSignature !== undefined ? { recipient_signature: finalSignature } : {}),
          delivered_by_name: form.delivered_by_name.trim(),
          delivered_by_position: form.delivered_by_position.trim(),
          delivered_by_id_card: form.delivered_by_id_card.trim(),
          notes: form.notes.trim(),
          accessories: accessoriesStr,
          items: selectedItems,
          auto_assign_equipment: true,
        })

        // Asegurar que siempre recuperamos el acta completa con todos sus renglones de equipos
        try {
          const freshAct = await deliveryActsApi.get(actToEdit.id)
          if (freshAct && freshAct.items && freshAct.items.length > 0) {
            act = freshAct
          }
        } catch (getErr) {
          console.error('Error refrescando acta editada:', getErr)
        }
      } else {
        act = await deliveryActsApi.create({
          city: form.city,
          act_type: form.act_type,
          recipient_name: form.recipient_name.trim(),
          recipient_id_card: form.recipient_id_card.trim(),
          recipient_position: form.recipient_position.trim() || undefined,
          recipient_department: form.recipient_department.trim() || undefined,
          recipient_signature: newDrawnSignature,
          delivered_by_name: form.delivered_by_name.trim() || undefined,
          delivered_by_position: form.delivered_by_position.trim() || undefined,
          delivered_by_id_card: form.delivered_by_id_card.trim() || undefined,
          notes: form.notes.trim() || undefined,
          accessories: accessoriesStr || undefined,
          items: selectedItems,
          auto_assign_equipment: true,
        })
      }

      // Si adjuntó fotos de evidencia del estado físico, subirlas en secuencia
      for (const file of initialEvidenceFiles) {
        try {
          act = await deliveryActsApi.uploadEvidencePhoto(act.id, file)
        } catch (uploadErr) {
          console.error('Error subiendo foto de evidencia inicial:', uploadErr)
        }
      }

      onCreated(act)
    } catch (err: any) {
      setError(
        err?.response?.data?.detail ??
          (isEditing ? 'Ocurrió un error al actualizar el acta.' : 'Ocurrió un error al generar el acta.')
      )
      setIsSubmitting(false)
    }
  }

  const filteredInventory = availableEquipment.filter((eq) => {
    const wasInEditedAct = Boolean(actToEdit?.items.some((i) => i.equipment_id === eq.id))
    if (
      form.act_type === 'assignment' &&
      onlyAvailable &&
      eq.status !== 'available' &&
      !selectedItems.some((i) => i.equipment_id === eq.id) &&
      !wasInEditedAct
    ) {
      return false
    }
    if (!eqSearch) return true
    const s = eqSearch.toLowerCase()
    return (
      eq.name.toLowerCase().includes(s) ||
      eq.serial_number.toLowerCase().includes(s) ||
      (eq.brand && eq.brand.toLowerCase().includes(s)) ||
      (eq.assigned_to && eq.assigned_to.toLowerCase().includes(s))
    )
  })

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-slate-900 w-full sm:max-w-2xl sm:rounded-2xl border border-slate-800 max-h-[94vh] flex flex-col shadow-2xl safe-bottom overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Cabecera */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/70 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-primary/10 text-primary rounded-lg">
              {isEditing ? <Pencil className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-white font-bold text-base">
                {isEditing
                  ? `Editar Acta ${actToEdit?.act_number}`
                  : form.act_type === 'return'
                  ? 'Generar Acta de Devolución / Reintegro'
                  : 'Generar Acta de Entrega / Asignación'}
              </h2>
              <p className="text-xs text-slate-400">
                {isEditing
                  ? 'Corrige datos del trabajador, equipos asignados, seriales, marcas o accesorios'
                  : 'Documento institucional de custodia, accesorios y estado físico'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulario Scrolleable */}
        <form id="new-act-form" onSubmit={handleSubmit} className="overflow-y-auto flex-1 p-4 space-y-5">
          {error && (
            <div className="text-rose-400 text-xs font-semibold bg-rose-950/40 border border-rose-900/60 rounded-xl p-3">
              {error}
            </div>
          )}

          {/* Selector de Tipo de Acta: Asignación vs Devolución */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 border border-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, act_type: 'assignment' }))}
              className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                form.act_type === 'assignment'
                  ? 'bg-primary text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Acta de Asignación (Entrega)</span>
            </button>
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, act_type: 'return' }))}
              className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                form.act_type === 'return'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Acta de Devolución (Paz y Salvo)</span>
            </button>
          </div>

          {/* Bloque 1: Datos del Receptor / Trabajador */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-1.5">
              <span>
                1. Datos del Trabajador {form.act_type === 'return' ? 'que Devuelve' : 'que Recibe'}
              </span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="label">Nombre y Apellido *</label>
                <input
                  className="input-field text-sm"
                  placeholder="Ej. Marbelys Ochoa"
                  value={form.recipient_name}
                  onChange={(e) => setForm((f) => ({ ...f, recipient_name: e.target.value }))}
                  required
                />
              </div>

              <div>
                <label className="label">Cédula de Identidad / DNI *</label>
                <input
                  className="input-field text-sm font-mono"
                  placeholder="Ej. 19.274.188"
                  value={form.recipient_id_card}
                  onChange={(e) => setForm((f) => ({ ...f, recipient_id_card: e.target.value }))}
                  required
                />
              </div>

              <div>
                <label className="label">Cargo</label>
                <input
                  className="input-field text-sm"
                  placeholder="Ej. Gte. RRHH la Yaguara"
                  value={form.recipient_position}
                  onChange={(e) => setForm((f) => ({ ...f, recipient_position: e.target.value }))}
                />
              </div>

              <div>
                <label className="label">Departamento / Gerencia</label>
                <input
                  className="input-field text-sm"
                  placeholder="Ej. Recursos Humanos"
                  value={form.recipient_department}
                  onChange={(e) => setForm((f) => ({ ...f, recipient_department: e.target.value }))}
                />
              </div>
            </div>
          </div>

          {/* Bloque 2: Selección de Equipos */}
          <div className="space-y-3 border-t border-slate-800 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-primary uppercase tracking-wider">
                2. Equipos Tecnológicos ({selectedItems.length})
              </h3>
            </div>

            {selectedItems.length > 0 && (
              <div className="space-y-2.5">
                {selectedItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Package className="w-4 h-4 text-primary flex-shrink-0" />
                        <span className="text-sm font-bold text-white truncate">
                          {item.equipment_name}
                        </span>
                        <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded flex-shrink-0">
                          SN: {item.serial_number}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="text-slate-500 hover:text-rose-400 p-1 flex-shrink-0"
                        title="Quitar equipo del acta"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Campos editables del renglón en el acta (Tipo, Marca, Modelo, Serial) */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">
                          Tipo de Equipo
                        </label>
                        <input
                          className="input-field text-xs py-1 px-2"
                          placeholder="Ej: LAPTOP"
                          value={item.equipment_type || ''}
                          onChange={(e) =>
                            handleUpdateItemField(idx, 'equipment_type', e.target.value)
                          }
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">
                          Marca
                        </label>
                        <input
                          className="input-field text-xs py-1 px-2"
                          placeholder="Ej: Lenovo"
                          value={item.brand || ''}
                          onChange={(e) => handleUpdateItemField(idx, 'brand', e.target.value)}
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">
                          Modelo
                        </label>
                        <input
                          className="input-field text-xs py-1 px-2"
                          placeholder="Ej: IdeaPad Slim 3"
                          value={item.model || ''}
                          onChange={(e) => handleUpdateItemField(idx, 'model', e.target.value)}
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">
                          Serial / S/N
                        </label>
                        <input
                          className="input-field text-xs font-mono py-1 px-2"
                          placeholder="Serial"
                          value={item.serial_number || ''}
                          onChange={(e) =>
                            handleUpdateItemField(idx, 'serial_number', e.target.value)
                          }
                        />
                      </div>
                    </div>

                    <div>
                      <input
                        className="input-field text-xs py-1.5"
                        placeholder="Especificaciones adicionales (Ej: Procesador: AMD RYZEN 7 | RAM: 16 GB | SSD 1TB)"
                        value={item.specs || ''}
                        onChange={(e) => handleUpdateItemField(idx, 'specs', e.target.value)}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="p-3 bg-slate-950/40 border border-slate-800/80 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-slate-300">
                  Selecciona equipos del inventario para adjuntar al acta:
                </p>
                {form.act_type === 'assignment' && (
                  <label className="flex items-center gap-1.5 text-[11px] text-slate-400 cursor-pointer hover:text-slate-200">
                    <input
                      type="checkbox"
                      checked={onlyAvailable}
                      onChange={(e) => setOnlyAvailable(e.target.checked)}
                      className="rounded border-slate-700 bg-slate-900 text-primary focus:ring-0"
                    />
                    <span>Solo disponibles</span>
                  </label>
                )}
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar por serie, modelo, marca o responsable..."
                  value={eqSearch}
                  onChange={(e) => setEqSearch(e.target.value)}
                  className="input-field text-xs pl-8 py-1.5"
                />
              </div>

              <div className="max-h-40 overflow-y-auto space-y-1 pr-1">
                {filteredInventory.slice(0, 15).map((eq) => {
                  const isSelected = selectedItems.some((i) => i.equipment_id === eq.id)
                  const isSelectable =
                    form.act_type === 'return' || eq.status === 'available' || isSelected

                  return (
                    <button
                      type="button"
                      key={eq.id}
                      onClick={() => handleToggleEquipment(eq)}
                      disabled={!isSelectable}
                      className={`w-full flex items-center justify-between p-2 rounded-lg text-xs transition-colors text-left ${
                        isSelected
                          ? 'bg-primary/20 border border-primary/40 text-white'
                          : isSelectable
                          ? 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-transparent'
                          : 'bg-slate-950/60 text-slate-500 border border-slate-900 cursor-not-allowed opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <span
                          className={`w-3.5 h-3.5 rounded flex items-center justify-center border ${
                            isSelected ? 'bg-primary border-primary text-white' : 'border-slate-600'
                          }`}
                        >
                          {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </span>
                        <span className="font-semibold">{eq.name}</span>
                        <span className="text-[11px] font-mono text-slate-400">
                          ({eq.serial_number})
                        </span>
                      </div>

                      <div className="text-right flex items-center gap-1.5 flex-shrink-0">
                        {eq.status === 'available' ? (
                          <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/50 px-1.5 py-0.5 rounded">
                            Disponible
                          </span>
                        ) : eq.status === 'assigned' ? (
                          <span className="text-[10px] text-sky-400 bg-sky-950/40 border border-sky-900/50 px-1.5 py-0.5 rounded truncate max-w-[150px]">
                            Asignado a: {eq.assigned_to || 'Empleado'}
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-400 bg-amber-950/40 border border-amber-900/50 px-1.5 py-0.5 rounded capitalize">
                            {eq.status}
                          </span>
                        )}
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>

          {/* Bloque 3: Checklist Rápido de Accesorios Incluidos (Feature C) */}
          <div className="space-y-2.5 border-t border-slate-800 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>3. Checklist Rápido de Accesorios Incluidos</span>
              </h3>
              <span className="text-[10px] text-slate-400">
                {selectedAccessories.length} seleccionados (1 clic)
              </span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {PRESET_ACCESSORIES.map((acc) => {
                const active = selectedAccessories.includes(acc)
                return (
                  <button
                    key={acc}
                    type="button"
                    onClick={() => toggleAccessoryChip(acc)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center gap-1.5 ${
                      active
                        ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300 shadow-sm'
                        : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <span
                      className={`w-3.5 h-3.5 rounded flex items-center justify-center ${
                        active ? 'bg-emerald-500 text-slate-950' : 'border border-slate-600'
                      }`}
                    >
                      {active && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                    </span>
                    <span>{acc}</span>
                  </button>
                )
              })}
            </div>

            <div>
              <input
                type="text"
                className="input-field text-xs"
                placeholder="Otros accesorios adicionales (ej: Cable de red Cat6, Hub USB, Forro protector)..."
                value={customAccessory}
                onChange={(e) => setCustomAccessory(e.target.value)}
              />
            </div>
          </div>

          {/* Bloque 4: Fotos de Evidencia del Estado Físico "Antes y Después" (Feature B) */}
          <div className="space-y-2 border-t border-slate-800 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5" />
                <span>4. Evidencia Fotográfica del Estado Físico (Opcional)</span>
              </h3>
              <span className="text-[10px] text-slate-400">
                Respaldo visual contra daños o golpes
              </span>
            </div>

            <div className="p-3 bg-slate-950/50 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <p className="text-xs text-slate-400">
                Puedes adjuntar fotos de la pantalla, carcasa o serial ahora, o subirlas después desde el visor del acta.
              </p>
              <label className="btn-secondary py-1.5 px-3 text-xs cursor-pointer inline-flex items-center gap-1.5 flex-shrink-0">
                <Camera className="w-3.5 h-3.5 text-primary" />
                <span>Adjuntar Fotos ({initialEvidenceFiles.length})</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  capture="environment"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files) {
                      setInitialEvidenceFiles(Array.from(e.target.files))
                    }
                  }}
                />
              </label>
            </div>
            {initialEvidenceFiles.length > 0 && (
              <div className="flex flex-wrap gap-1.5 text-[11px] text-emerald-400">
                {initialEvidenceFiles.map((f, i) => (
                  <span
                    key={i}
                    className="bg-emerald-950/40 border border-emerald-800/50 px-2 py-0.5 rounded-lg"
                  >
                    📸 {f.name}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Bloque 5: Datos de quien entrega */}
          <div className="space-y-3 border-t border-slate-800 pt-4">
            <h3 className="text-xs font-bold text-primary uppercase tracking-wider flex items-center justify-between">
              <span>5. Responsable de TI / Sistemas</span>
              <span className="text-[10px] text-emerald-400 font-normal">Auto-guardado permanente</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="label">Nombre de quien Entrega/Recibe TI</label>
                <input
                  className="input-field text-sm"
                  value={form.delivered_by_name}
                  onChange={(e) => setForm((f) => ({ ...f, delivered_by_name: e.target.value }))}
                />
              </div>
              <div>
                <label className="label">Cargo</label>
                <input
                  className="input-field text-sm"
                  value={form.delivered_by_position}
                  onChange={(e) => setForm((f) => ({ ...f, delivered_by_position: e.target.value }))}
                />
              </div>
              <div>
                <label className="label">Cédula</label>
                <input
                  className="input-field text-sm font-mono"
                  value={form.delivered_by_id_card}
                  onChange={(e) => setForm((f) => ({ ...f, delivered_by_id_card: e.target.value }))}
                  placeholder="Ej. 14.287.629"
                />
              </div>
            </div>
          </div>

          {/* Bloque 6: Firma Digital Táctil en Móvil / PC */}
          <div className="space-y-2 border-t border-slate-800 pt-4">
            <h3 className="text-xs font-bold text-primary uppercase tracking-wider">
              6. Firma Táctil en Pantalla (Opcional si se firmará en físico)
            </h3>
            {isEditing && actToEdit?.recipient_signature && !replaceSignature && !clearExistingSignature ? (
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="bg-white p-1.5 rounded-lg border border-slate-300">
                    <img
                      src={actToEdit.recipient_signature}
                      alt="Firma actual"
                      className="h-12 object-contain"
                    />
                  </div>
                  <div className="text-xs">
                    <p className="text-emerald-400 font-bold">Firma digital registrada en el acta</p>
                    <p className="text-slate-400">Se conservará al guardar los cambios.</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setReplaceSignature(true)}
                    className="btn-secondary py-1.5 px-3 text-xs"
                  >
                    Volver a Firmar
                  </button>
                  <button
                    type="button"
                    onClick={() => setClearExistingSignature(true)}
                    className="px-2.5 py-1.5 rounded-lg bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 text-xs font-semibold"
                  >
                    Quitar Firma
                  </button>
                </div>
              </div>
            ) : (
              <>
                <p className="text-xs text-slate-400">
                  El trabajador puede firmar aquí en pantalla o firmar la hoja impresa y luego escanearla al sistema:
                </p>
                <SignaturePad ref={sigPadRef} />
                {isEditing && actToEdit?.recipient_signature && (
                  <button
                    type="button"
                    onClick={() => {
                      setReplaceSignature(false)
                      setClearExistingSignature(false)
                    }}
                    className="text-xs text-primary hover:underline"
                  >
                    Restaurar firma digital anterior
                  </button>
                )}
              </>
            )}
          </div>
        </form>

        {/* Botonera de Acción */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between gap-3 bg-slate-950/80 flex-shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary py-2 px-4 text-xs"
          >
            Cancelar
          </button>

          <button
            type="submit"
            form="new-act-form"
            disabled={isSubmitting || selectedItems.length === 0 || !form.recipient_name.trim()}
            className="btn-primary py-2 px-5 text-xs flex items-center gap-1.5"
          >
            {isEditing ? <Check className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
            <span>
              {isSubmitting
                ? isEditing
                  ? 'Guardando cambios...'
                  : 'Generando...'
                : isEditing
                ? 'Guardar Cambios del Acta'
                : 'Crear y Ver Acta'}
            </span>
          </button>
        </div>
      </div>
    </div>
  )
}
