import { useState, useEffect, useCallback, useRef } from 'react'
import {
  ClipboardCheck,
  QrCode,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Warehouse as WarehouseIcon,
  Plus,
  Printer,
  ChevronRight,
  RotateCcw,
  Search,
  Check,
  X
} from 'lucide-react'
import { auditApi, type AuditSession, type AuditScanResult, type AuditReport } from '../../api/audit'
import { warehousesApi, type Warehouse } from '../../api/warehouses'
import { BarcodeScanner } from '../../components/BarcodeScanner/BarcodeScanner'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'
import { useAuthStore } from '../../store/authStore'
import { useThemeStore } from '../../store/themeStore'

export function AuditPage() {
  const { user } = useAuthStore()
  const { config } = useThemeStore()

  const [warehouses, setWarehouses] = useState<Warehouse[]>([])
  const [sessions, setSessions] = useState<AuditSession[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Sesión activa
  const [activeSession, setActiveSession] = useState<AuditSession | null>(null)
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('')
  const [sessionNotes, setSessionNotes] = useState<string>('')
  const [isStartingSession, setIsStartingSession] = useState(false)

  // Escaneo en sesión
  const [serialInput, setSerialInput] = useState('')
  const [showScanner, setShowScanner] = useState(false)
  const [lastScanResult, setLastScanResult] = useState<AuditScanResult | null>(null)
  const [recentScans, setRecentScans] = useState<AuditScanResult[]>([])
  const [isSubmittingScan, setIsSubmittingScan] = useState(false)

  // Reporte de cierre
  const [reportSession, setReportSession] = useState<AuditSession | null>(null)
  const [reportData, setReportData] = useState<AuditReport | null>(null)
  const [isLoadingReport, setIsLoadingReport] = useState(false)
  const [isClosingSession, setIsClosingSession] = useState(false)

  const printAreaRef = useRef<HTMLDivElement>(null)

  // Cargar almacenes y sesiones
  const loadInitialData = useCallback(async () => {
    setIsLoading(true)
    try {
      const [whs, sessList] = await Promise.all([
        warehousesApi.list(),
        auditApi.listSessions()
      ])
      setWarehouses(whs)
      setSessions(sessList)
      if (whs.length > 0 && !selectedWarehouseId) {
        setSelectedWarehouseId(whs[0].id)
      }
      // Si hay una sesión activa, seleccionarla
      const currentActive = sessList.find((s) => s.status === 'open' || (s.status as any) === 'active')
      if (currentActive && !activeSession) {
        setActiveSession(currentActive)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }, [activeSession, selectedWarehouseId])

  useEffect(() => {
    loadInitialData()
  }, [])

  // Iniciar nueva sesión
  const handleStartSession = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedWarehouseId) return
    setIsStartingSession(true)
    try {
      const newSession = await auditApi.createSession(selectedWarehouseId, sessionNotes)
      setActiveSession(newSession)
      setRecentScans([])
      setLastScanResult(null)
      loadInitialData()
    } catch (err: any) {
      alert(err?.response?.data?.detail || 'Error al iniciar sesión de auditoría')
    } finally {
      setIsStartingSession(false)
    }
  }

  // Reproducir sonido beep al escanear
  const playBeep = (type: 'success' | 'warning' | 'error') => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)

      if (type === 'success') {
        osc.frequency.setValueAtTime(800, ctx.currentTime)
        gain.gain.setValueAtTime(0.15, ctx.currentTime)
        osc.start()
        osc.stop(ctx.currentTime + 0.12)
      } else if (type === 'warning') {
        osc.frequency.setValueAtTime(450, ctx.currentTime)
        gain.gain.setValueAtTime(0.2, ctx.currentTime)
        osc.start()
        osc.stop(ctx.currentTime + 0.25)
      } else {
        osc.frequency.setValueAtTime(250, ctx.currentTime)
        gain.gain.setValueAtTime(0.25, ctx.currentTime)
        osc.start()
        osc.stop(ctx.currentTime + 0.35)
      }
    } catch {}
  }

  // Procesar escaneo
  const handleScanSerial = async (serial: string) => {
    if (!activeSession || !serial.trim()) return
    const clean = serial.trim()
    setIsSubmittingScan(true)
    try {
      const res = await auditApi.scanEquipment(activeSession.id, clean)
      setLastScanResult(res)
      setRecentScans((prev) => [res, ...prev.slice(0, 19)])

      if (res.is_duplicate) {
        playBeep('warning')
      } else if (res.found && res.is_expected) {
        playBeep('success')
      } else {
        playBeep('error')
      }
      setSerialInput('')
    } catch (err: any) {
      alert(err?.response?.data?.detail || 'Error procesando escaneo')
      playBeep('error')
    } finally {
      setIsSubmittingScan(false)
    }
  }

  // Cerrar sesión activa
  const handleCloseSession = async () => {
    if (!activeSession) return
    const confirmClose = window.confirm(
      '¿Deseas finalizar y sellar formalmente esta toma física de inventario?\nUna vez cerrada no podrás registrar más escaneos.'
    )
    if (!confirmClose) return

    setIsClosingSession(true)
    try {
      await auditApi.closeSession(activeSession.id)
      const report = await auditApi.getReport(activeSession.id)
      setReportSession(activeSession)
      setReportData(report)
      setActiveSession(null)
      loadInitialData()
    } catch (err: any) {
      alert(err?.response?.data?.detail || 'Error al cerrar sesión')
    } finally {
      setIsClosingSession(false)
    }
  }

  // Ver reporte de una sesión pasada
  const handleViewReport = async (session: AuditSession) => {
    setReportSession(session)
    setIsLoadingReport(true)
    try {
      const report = await auditApi.getReport(session.id)
      setReportData(report)
    } catch (err: any) {
      alert(err?.response?.data?.detail || 'Error al cargar reporte')
    } finally {
      setIsLoadingReport(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center p-8">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  // ─── VISTA 1: REPORTE DE DISCREPANCIAS / RESULTADOS (IMPRIMIBLE) ──────────────
  if (reportData && reportSession) {
    const missing = reportData.missing_items || reportData.missing || []
    const extra = reportData.extra_items || reportData.extra || []
    const matched = reportData.matched_items || []

    return (
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between print:hidden">
          <button
            onClick={() => {
              setReportData(null)
              setReportSession(null)
            }}
            className="btn-secondary py-2 px-3 text-xs flex items-center gap-1.5"
          >
            ← Volver a Auditoría
          </button>
          <button
            onClick={() => window.print()}
            className="btn-primary py-2 px-4 text-xs flex items-center gap-2 font-bold"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir Reporte Oficial / Guardar PDF</span>
          </button>
        </div>

        {/* Hoja imprimible */}
        <div
          ref={printAreaRef}
          className="bg-white text-slate-900 rounded-2xl p-6 sm:p-10 shadow-2xl print:shadow-none print:p-0 print:m-0"
        >
          {/* Header */}
          <div className="border-b border-slate-300 pb-5 flex items-start justify-between">
            <div>
              <div className="text-xs uppercase font-bold tracking-wider text-slate-500">
                {config?.name || 'InventoryOS'}
              </div>
              <h1 className="text-xl font-black text-slate-900">
                REPORTE OFICIAL DE TOMA FÍSICA DE INVENTARIO
              </h1>
              <p className="text-xs text-slate-600 mt-1">
                Almacén Auditado: <span className="font-bold text-slate-900">{reportSession.warehouse_name}</span>
              </p>
            </div>
            <div className="text-right text-xs text-slate-500">
              <div>Fecha: {new Date(reportSession.created_at).toLocaleDateString('es-ES')}</div>
              <div className="font-mono text-[10px] text-slate-400">ID: {reportSession.id.slice(0, 8)}</div>
            </div>
          </div>

          {/* Tarjetas KPI */}
          <div className="grid grid-cols-4 gap-3 my-6 text-center text-xs">
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50">
              <div className="text-[10px] font-bold text-slate-500 uppercase">Total Esperados</div>
              <div className="text-2xl font-black text-slate-900 mt-1">{reportData.expected_total}</div>
            </div>
            <div className="border border-emerald-200 rounded-xl p-3 bg-emerald-50/70">
              <div className="text-[10px] font-bold text-emerald-800 uppercase">Verificados (OK)</div>
              <div className="text-2xl font-black text-emerald-600 mt-1">{reportData.found_count}</div>
            </div>
            <div className="border border-rose-200 rounded-xl p-3 bg-rose-50/70">
              <div className="text-[10px] font-bold text-rose-800 uppercase">Faltantes</div>
              <div className="text-2xl font-black text-rose-600 mt-1">{reportData.missing_count}</div>
            </div>
            <div className="border border-amber-200 rounded-xl p-3 bg-amber-50/70">
              <div className="text-[10px] font-bold text-amber-800 uppercase">Sobrantes / Extras</div>
              <div className="text-2xl font-black text-amber-600 mt-1">{reportData.extra_count}</div>
            </div>
          </div>

          {/* Faltantes */}
          {missing.length > 0 && (
            <div className="mb-6">
              <h2 className="text-sm font-bold text-rose-700 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <XCircle className="w-4 h-4" />
                <span>Equipos Faltantes (No encontrados físicamente en almacén) - {missing.length}</span>
              </h2>
              <table className="w-full text-left text-[11px] border-collapse border border-slate-200">
                <thead className="bg-rose-50/80 text-rose-900 border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Serial</th>
                    <th className="py-2 px-3">Nombre</th>
                    <th className="py-2 px-3">Marca / Modelo</th>
                    <th className="py-2 px-3">Categoría</th>
                    <th className="py-2 px-3">Estado Sistema</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {missing.map((eq: any) => (
                    <tr key={eq.id}>
                      <td className="py-1.5 px-3 font-mono font-bold text-slate-900">{eq.serial_number}</td>
                      <td className="py-1.5 px-3">{eq.name}</td>
                      <td className="py-1.5 px-3">{[eq.brand, eq.model].filter(Boolean).join(' ') || '—'}</td>
                      <td className="py-1.5 px-3 uppercase text-[10px]">{eq.category}</td>
                      <td className="py-1.5 px-3">{eq.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Extras / Sobrantes */}
          {extra.length > 0 && (
            <div className="mb-6">
              <h2 className="text-sm font-bold text-amber-700 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Equipos Sobrantes / Discrepancias (Físicos en almacén pero no asignados a esta sede) - {extra.length}</span>
              </h2>
              <table className="w-full text-left text-[11px] border-collapse border border-slate-200">
                <thead className="bg-amber-50/80 text-amber-900 border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Serial Escaneado</th>
                    <th className="py-2 px-3">Diagnóstico</th>
                    <th className="py-2 px-3">Hora Escaneo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {extra.map((s: any, idx: number) => (
                    <tr key={idx}>
                      <td className="py-1.5 px-3 font-mono font-bold text-slate-900">{s.scanned_serial || s.serial_number}</td>
                      <td className="py-1.5 px-3 text-amber-800">
                        {s.equipment ? `Registrado en otra sede (${s.equipment.current_warehouse?.name || 'Sin almacén'})` : 'Serial NO registrado en el sistema'}
                      </td>
                      <td className="py-1.5 px-3 text-slate-500">{new Date(s.scanned_at).toLocaleTimeString('es-ES')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Firmas de conformidad */}
          <div className="pt-12 mt-8 border-t border-slate-300 grid grid-cols-2 gap-12 text-center text-xs break-inside-avoid">
            <div>
              <div className="border-b border-slate-900 pb-1 mx-8 mb-2"></div>
              <p className="font-bold text-slate-900">{user?.full_name || 'Auditor de Inventario'}</p>
              <p className="text-[10px] text-slate-500">Auditor Responsable / Toma Física</p>
            </div>
            <div>
              <div className="border-b border-slate-900 pb-1 mx-8 mb-2"></div>
              <p className="font-bold text-slate-900">Gerencia / Control de Activos</p>
              <p className="text-[10px] text-slate-500">Visto Bueno y Cierre</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // ─── VISTA 2: SESIÓN ACTIVA DE AUDITORÍA (ESCÁNER EN TIEMPO REAL) ──────────────
  if (activeSession) {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-4">
        {/* Header de la sesión activa */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Auditoría Física en Progreso
              </span>
            </div>
            <h1 className="text-xl font-black text-white mt-0.5 flex items-center gap-2">
              <WarehouseIcon className="w-5 h-5 text-primary" />
              <span>{activeSession.warehouse_name}</span>
            </h1>
            <p className="text-xs text-slate-400">
              Iniciado: {new Date(activeSession.created_at).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} • Esperados en catálogo: <strong className="text-white">{activeSession.expected_total}</strong>
            </p>
          </div>

          <button
            onClick={handleCloseSession}
            disabled={isClosingSession}
            className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isClosingSession ? 'Cerrando...' : 'Finalizar y Generar Reporte'}</span>
          </button>
        </div>

        {/* Panel de Escaneo Activo */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <QrCode className="w-4 h-4 text-primary" />
              <span>Escaneo Rápido de Activos</span>
            </h2>
            <button
              onClick={() => setShowScanner(true)}
              className="btn-primary py-2 px-3 text-xs flex items-center gap-1.5"
            >
              <QrCode className="w-4 h-4" />
              <span>Cámara Escáner</span>
            </button>
          </div>

          {/* Formulario de ingreso manual / pistola lectora */}
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleScanSerial(serialInput)
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={serialInput}
                onChange={(e) => setSerialInput(e.target.value)}
                placeholder="Escanea con lector de código de barras o escribe el serial..."
                autoFocus
                className="input-field pl-9 text-sm py-2.5 font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={isSubmittingScan || !serialInput.trim()}
              className="btn-primary py-2.5 px-5 text-xs font-bold shadow-md disabled:opacity-50"
            >
              {isSubmittingScan ? 'Verificando...' : 'Verificar'}
            </button>
          </form>

          {/* Feedback del último escaneo */}
          {lastScanResult && (
            <div
              className={`p-4 rounded-xl border text-xs flex items-start gap-3 transition-all ${
                lastScanResult.is_duplicate
                  ? 'bg-amber-950/40 border-amber-800/80 text-amber-200'
                  : lastScanResult.found && lastScanResult.is_expected
                  ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-200'
                  : 'bg-rose-950/40 border-rose-800/80 text-rose-200'
              }`}
            >
              {lastScanResult.is_duplicate ? (
                <AlertTriangle className="w-5 h-5 flex-shrink-0 text-amber-400 mt-0.5" />
              ) : lastScanResult.found && lastScanResult.is_expected ? (
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-400 mt-0.5" />
              ) : (
                <XCircle className="w-5 h-5 flex-shrink-0 text-rose-400 mt-0.5" />
              )}
              <div className="space-y-1 min-w-0 flex-1">
                <div className="font-bold text-sm">
                  {lastScanResult.scanned_serial}
                </div>
                <div>{lastScanResult.message}</div>
                {lastScanResult.equipment && (
                  <div className="text-[11px] opacity-80">
                    {lastScanResult.equipment.name} • {lastScanResult.equipment.category.toUpperCase()}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Historial reciente de escaneos en esta sesión */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold uppercase tracking-wider">
            <span>Últimos equipos escaneados en esta sesión ({recentScans.length})</span>
          </div>

          {recentScans.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
              Aún no has escaneado ningún equipo en esta sesión. Comienza escaneando con la cámara o pistola lectora.
            </div>
          ) : (
            <div className="divide-y divide-slate-800 max-h-72 overflow-y-auto">
              {recentScans.map((scan, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    {scan.found && scan.is_expected ? (
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    ) : scan.is_duplicate ? (
                      <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                    )}
                    <div>
                      <span className="font-mono font-bold text-white">{scan.scanned_serial}</span>
                      {scan.equipment && (
                        <span className="text-slate-400 ml-2">({scan.equipment.name})</span>
                      )}
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500">
                    {scan.found && scan.is_expected ? 'Correcto' : scan.is_duplicate ? 'Duplicado' : 'Discrepancia'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal de escáner con cámara */}
        {showScanner && (
          <BarcodeScanner
            onResult={(code) => {
              setShowScanner(false)
              handleScanSerial(code)
            }}
            onClose={() => setShowScanner(false)}
          />
        )}
      </div>
    )
  }

  // ─── VISTA 3: PANTALLA PRINCIPAL (INICIAR NUEVA SESIÓN / HISTORIAL) ───────────
  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <ClipboardCheck className="w-6 h-6 text-primary" />
            <span>Toma Física / Auditoría de Inventario</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm">
            Audita las existencias físicas reales de tus almacenes y detecta discrepancias al instante
          </p>
        </div>
      </div>

      {/* Tarjeta para iniciar nueva sesión */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Plus className="w-4 h-4 text-primary" />
          <span>Iniciar Nueva Toma Física</span>
        </h2>

        <form onSubmit={handleStartSession} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
          <div className="sm:col-span-5">
            <label className="block text-xs text-slate-400 mb-1">Selecciona el almacén a auditar:</label>
            <div className="relative">
              <WarehouseIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <select
                value={selectedWarehouseId}
                onChange={(e) => setSelectedWarehouseId(e.target.value)}
                className="input-field pl-9 py-2.5 text-xs w-full bg-slate-950 font-semibold"
                required
              >
                {warehouses.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name} ({w.location || 'Sede principal'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="sm:col-span-5">
            <label className="block text-xs text-slate-400 mb-1">Notas u observaciones (opcional):</label>
            <input
              type="text"
              value={sessionNotes}
              onChange={(e) => setSessionNotes(e.target.value)}
              placeholder="Ej. Auditoría de fin de mes, revisión anual..."
              className="input-field py-2.5 text-xs w-full bg-slate-950"
            />
          </div>

          <div className="sm:col-span-2">
            <button
              type="submit"
              disabled={isStartingSession || !selectedWarehouseId}
              className="btn-primary w-full py-2.5 text-xs font-bold flex items-center justify-center gap-1.5 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{isStartingSession ? 'Iniciando...' : 'Comenzar'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Historial de sesiones de auditoría */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-slate-400" />
          <span>Historial de Tomas Físicas Realizadas</span>
        </h2>

        {sessions.length === 0 ? (
          <div className="text-center py-10 text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
            Aún no se ha realizado ninguna auditoría de inventario. Inicia la primera arriba.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 px-3">Fecha</th>
                  <th className="py-2.5 px-3">Almacén</th>
                  <th className="py-2.5 px-3">Auditor</th>
                  <th className="py-2.5 px-3 text-center">Estado</th>
                  <th className="py-2.5 px-3 text-center">Escaneados</th>
                  <th className="py-2.5 px-3 text-right">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {sessions.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-medium text-white">
                      {new Date(s.created_at).toLocaleDateString('es-ES', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-200">{s.warehouse_name}</td>
                    <td className="py-3 px-3 text-slate-400">{(s as any).creator_name || 'Usuario'}</td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          s.status === 'closed'
                            ? 'bg-slate-800 text-slate-400'
                            : 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                        }`}
                      >
                        {s.status === 'closed' ? 'Cerrada' : 'En Progreso'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center font-mono">
                      {(s as any).scanned_count ?? 0}
                    </td>
                    <td className="py-3 px-3 text-right">
                      {s.status === 'closed' ? (
                        <button
                          onClick={() => handleViewReport(s)}
                          className="btn-secondary py-1 px-2.5 text-[11px] inline-flex items-center gap-1"
                        >
                          <span>Ver Reporte</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <button
                          onClick={() => setActiveSession(s)}
                          className="btn-primary py-1 px-3 text-[11px] inline-flex items-center gap-1 font-bold"
                        >
                          <span>Continuar</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
