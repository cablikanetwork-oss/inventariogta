import { useState, useEffect, useCallback, useMemo } from 'react'
import {
  Plus,
  Warehouse,
  MapPin,
  Package,
  Pencil,
  Trash2,
  FolderTree,
  Boxes,
  CornerDownRight,
  ChevronDown,
  ChevronRight,
  AlertCircle
} from 'lucide-react'
import { warehousesApi, type Warehouse as WarehouseType, type WarehouseCreate } from '../../api/warehouses'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'
import { useAuthStore } from '../../store/authStore'

export function WarehousesPage() {
  const { user } = useAuthStore()
  const isAdmin = user?.role === 'admin'

  const [warehouses, setWarehouses] = useState<WarehouseType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingWarehouse, setEditingWarehouse] = useState<WarehouseType | null>(null)
  
  // Estado del formulario
  const [form, setForm] = useState<WarehouseCreate>({
    name: '',
    location: '',
    description: '',
    parent_id: null,
  })
  
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)

  // Acordeón para expandir/colapsar sub-almacenes por localidad
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({})

  const loadData = useCallback(async () => {
    try {
      const data = await warehousesApi.list()
      setWarehouses(data)
    } catch (err) {
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  // Separar primarios y sub-almacenes
  const primaryWarehouses = useMemo(() => {
    return warehouses.filter((w) => !w.parent_id)
  }, [warehouses])

  const subWarehousesByParent = useMemo(() => {
    const map: Record<string, WarehouseType[]> = {}
    for (const w of warehouses) {
      if (w.parent_id) {
        if (!map[w.parent_id]) map[w.parent_id] = []
        map[w.parent_id].push(w)
      }
    }
    return map
  }, [warehouses])

  // Abrir modal para crear Almacén Primario
  const openCreatePrimary = () => {
    setEditingWarehouse(null)
    setForm({ name: '', location: '', description: '', parent_id: null })
    setError(null)
    setDeleteError(null)
    setShowModal(true)
  }

  // Abrir modal para crear Sub-almacén directamente en un padre
  const openCreateSub = (parentId: string, parentLocation?: string | null) => {
    setEditingWarehouse(null)
    setForm({
      name: '',
      location: parentLocation || '',
      description: '',
      parent_id: parentId,
    })
    setError(null)
    setDeleteError(null)
    setShowModal(true)
  }

  // Abrir modal para Editar
  const openEdit = (w: WarehouseType) => {
    setEditingWarehouse(w)
    setForm({
      name: w.name,
      location: w.location || '',
      description: w.description || '',
      parent_id: w.parent_id || null,
    })
    setError(null)
    setDeleteError(null)
    setShowModal(true)
  }

  // Guardar (Crear o Actualizar)
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim()) return

    setIsSaving(true)
    setError(null)

    try {
      const payload: WarehouseCreate = {
        name: form.name.trim(),
        location: form.location?.trim() || undefined,
        description: form.description?.trim() || undefined,
        parent_id: form.parent_id || null,
      }

      if (editingWarehouse) {
        await warehousesApi.update(editingWarehouse.id, payload)
      } else {
        await warehousesApi.create(payload)
      }

      setShowModal(false)
      loadData()
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al guardar los datos del almacén')
    } finally {
      setIsSaving(false)
    }
  }

  // Eliminar almacén o sub-almacén
  const handleDelete = async (w: WarehouseType) => {
    const isSub = Boolean(w.parent_id)
    const promptMsg = isSub
      ? `¿Estás seguro de eliminar el sub-almacén "${w.name}"?`
      : `¿Estás seguro de eliminar el almacén principal "${w.name}"?`

    if (!window.confirm(promptMsg)) return

    setDeleteError(null)
    try {
      await warehousesApi.delete(w.id)
      loadData()
    } catch (err: any) {
      const msg = err?.response?.data?.detail ?? 'No fue posible eliminar el almacén'
      setDeleteError(msg)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  const toggleCollapse = (id: string) => {
    setCollapsed((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  return (
    <div className="p-4 lg:p-6 space-y-5 max-w-6xl mx-auto">
      {/* Encabezado Principal */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Warehouse className="w-6 h-6 text-primary" />
            <span>Almacenes y Sucursales</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Estructura jerárquica: administra localidades principales y sus respectivos sub-almacenes o contenedores
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={openCreatePrimary}
            className="btn-primary py-2.5 px-4 text-xs sm:text-sm self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>+ Nueva Localidad / Almacén</span>
          </button>
        )}
      </div>

      {/* Alerta de error global (ej: al intentar borrar con equipos) */}
      {deleteError && (
        <div className="p-4 bg-rose-950/40 border border-rose-900/80 rounded-2xl text-rose-300 text-xs sm:text-sm flex items-start gap-3 shadow-lg">
          <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <strong className="font-bold text-white block mb-0.5">Operación no permitida</strong>
            <span>{deleteError}</span>
          </div>
          <button
            onClick={() => setDeleteError(null)}
            className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1 rounded-lg"
          >
            Entendido
          </button>
        </div>
      )}

      {/* Estado de Carga */}
      {isLoading ? (
        <div className="flex justify-center py-24">
          <LoadingSpinner size="lg" />
        </div>
      ) : primaryWarehouses.length === 0 ? (
        <div className="card p-12 text-center text-slate-500 space-y-3">
          <Warehouse className="w-12 h-12 mx-auto opacity-30 text-slate-400" />
          <p className="font-bold text-white text-base">No hay almacenes configurados</p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Comienza registrando tu primera localidad principal o bodega central para comenzar a gestionar equipos tecnológicos.
          </p>
          {isAdmin && (
            <button onClick={openCreatePrimary} className="btn-primary py-2 px-4 text-xs mx-auto">
              <Plus className="w-4 h-4" />
              <span>Crear Almacén Principal</span>
            </button>
          )}
        </div>
      ) : (
        /* Listado Jerárquico de Almacenes */
        <div className="space-y-4">
          {primaryWarehouses.map((primary) => {
            const subs = subWarehousesByParent[primary.id] || []
            const isClosed = Boolean(collapsed[primary.id])

            return (
              <div
                key={primary.id}
                className="card border border-slate-800 bg-slate-900/95 overflow-hidden shadow-xl"
              >
                {/* Cabecera del Almacén Primario */}
                <div className="p-5 border-b border-slate-800/80 flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-950/40">
                  <div className="flex items-start gap-3 min-w-0">
                    <button
                      onClick={() => toggleCollapse(primary.id)}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors mt-0.5"
                      title={isClosed ? 'Expandir sub-almacenes' : 'Colapsar sub-almacenes'}
                    >
                      {isClosed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    <div className="w-11 h-11 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center text-primary flex-shrink-0">
                      <Warehouse className="w-6 h-6" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="font-black text-white text-base truncate">{primary.name}</h2>
                        <span className="text-[10px] font-bold text-primary bg-primary/10 border border-primary/30 px-2.5 py-0.5 rounded-full">
                          Localidad Principal
                        </span>
                        {subs.length > 0 && (
                          <span className="text-[10px] font-semibold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                            {subs.length} sub-almacén{subs.length > 1 ? 'es' : ''}
                          </span>
                        )}
                      </div>

                      {primary.location && (
                        <p className="text-slate-400 text-xs flex items-center gap-1.5 mt-1 truncate">
                          <MapPin className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                          <span>{primary.location}</span>
                        </p>
                      )}

                      {primary.description && (
                        <p className="text-slate-500 text-xs mt-1.5 line-clamp-1 italic">
                          {primary.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Métricas y Botones de Acción */}
                  <div className="flex items-center justify-between lg:justify-end gap-3 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-800">
                    {/* Tarjeta de Stock Consolidado */}
                    <div className="bg-slate-950/80 px-3.5 py-2 rounded-xl border border-slate-800 text-right">
                      <div className="flex items-center gap-1.5 text-slate-400 text-[11px] justify-end">
                        <Package className="w-3.5 h-3.5 text-primary" />
                        <span>Stock Total</span>
                      </div>
                      <p className="text-xl font-black text-white leading-none mt-1">
                        {primary.total_equipment_count}
                        {primary.equipment_count > 0 && subs.length > 0 && (
                          <span className="text-[10px] text-slate-500 font-normal ml-1">
                            ({primary.equipment_count} en bodega + {primary.total_equipment_count - primary.equipment_count} en subs)
                          </span>
                        )}
                      </p>
                    </div>

                    {/* Acciones de administración */}
                    {isAdmin && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openCreateSub(primary.id, primary.location)}
                          className="btn-primary py-2 px-3 text-xs shadow-none"
                          title="Crear un contenedor o sub-almacén dentro de esta localidad"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">+ Sub-almacén</span>
                        </button>

                        <button
                          onClick={() => openEdit(primary)}
                          className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 transition-colors"
                          title="Editar localidad"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleDelete(primary)}
                          className="p-2 rounded-xl text-slate-400 hover:text-rose-400 bg-slate-800/80 hover:bg-rose-950/40 transition-colors"
                          title="Eliminar localidad"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sub-almacenes anidados (Contenedores, Bodegas secundarias, Racks) */}
                {!isClosed && (
                  <div className="p-4 bg-slate-950/60">
                    {subs.length === 0 ? (
                      <div className="p-4 rounded-xl border border-dashed border-slate-800 text-center">
                        <p className="text-slate-500 text-xs">
                          No hay sub-almacenes en esta localidad.
                        </p>
                        {isAdmin && (
                          <button
                            onClick={() => openCreateSub(primary.id, primary.location)}
                            className="text-primary hover:underline text-xs font-semibold mt-1 inline-flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" />
                            <span>Crear contenedor o sub-almacén interno</span>
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 mb-2 px-1">
                          <FolderTree className="w-3.5 h-3.5 text-primary" />
                          <span>Sub-almacenes y Contenedores ({subs.length})</span>
                        </span>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                          {subs.map((sub) => (
                            <div
                              key={sub.id}
                              className="p-3.5 rounded-xl bg-slate-900 border border-slate-800/90 hover:border-slate-700 transition-colors flex flex-col justify-between"
                            >
                              <div className="space-y-1">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <CornerDownRight className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                                    <h3 className="font-bold text-white text-sm truncate">
                                      {sub.name}
                                    </h3>
                                  </div>

                                  {isAdmin && (
                                    <div className="flex items-center gap-1 flex-shrink-0">
                                      <button
                                        onClick={() => openEdit(sub)}
                                        className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-slate-800"
                                        title="Editar sub-almacén"
                                      >
                                        <Pencil className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleDelete(sub)}
                                        className="p-1 text-slate-400 hover:text-rose-400 rounded-md hover:bg-slate-800"
                                        title="Eliminar sub-almacén"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  )}
                                </div>

                                {sub.description && (
                                  <p className="text-[11px] text-slate-400 line-clamp-1 pl-5">
                                    {sub.description}
                                  </p>
                                )}
                              </div>

                              <div className="mt-3 pt-2 border-t border-slate-800/70 flex items-center justify-between text-xs pl-5">
                                <span className="text-slate-500 text-[11px]">Stock en contenedor:</span>
                                <span className="font-black text-white font-mono bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
                                  {sub.equipment_count} equipos
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* MODAL CREAR / EDITAR ALMACÉN O SUB-ALMACÉN */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 w-full max-w-lg rounded-2xl border border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Cabecera del modal */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-2.5">
                <Boxes className="w-5 h-5 text-primary" />
                <h2 className="text-white font-bold text-base">
                  {editingWarehouse
                    ? `Editar: ${editingWarehouse.name}`
                    : form.parent_id
                    ? 'Crear Sub-almacén / Contenedor'
                    : 'Crear Almacén Principal'}
                </h2>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            {/* Formulario */}
            <form onSubmit={handleSave} className="p-5 space-y-4">
              {error && (
                <div className="p-3 bg-rose-950/40 border border-rose-900/60 rounded-xl text-rose-300 text-xs font-semibold">
                  {error}
                </div>
              )}

              {/* Selector de Nivel Jerárquico */}
              <div>
                <label className="label">Tipo de Almacén</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, parent_id: null }))}
                    className={`p-3 rounded-xl border text-xs font-bold text-left transition-all ${
                      !form.parent_id
                        ? 'border-primary bg-primary/10 text-white'
                        : 'border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Warehouse className="w-4 h-4 mb-1 text-primary" />
                    <span>Localidad Principal</span>
                    <p className="text-[10px] text-slate-500 font-normal mt-0.5">Sede, Edificio o Centro</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!form.parent_id && primaryWarehouses.length > 0) {
                        const defaultParent = primaryWarehouses.find((p) => p.id !== editingWarehouse?.id)
                        setForm((f) => ({ ...f, parent_id: defaultParent?.id || null }))
                      }
                    }}
                    className={`p-3 rounded-xl border text-xs font-bold text-left transition-all ${
                      form.parent_id
                        ? 'border-primary bg-primary/10 text-white'
                        : 'border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <CornerDownRight className="w-4 h-4 mb-1 text-primary" />
                    <span>Sub-almacén / Contenedor</span>
                    <p className="text-[10px] text-slate-500 font-normal mt-0.5">Ubicado dentro de otra localidad</p>
                  </button>
                </div>
              </div>

              {/* Si es sub-almacén, seleccionar almacén padre */}
              {form.parent_id && (
                <div>
                  <label className="label">Almacén Principal Padre *</label>
                  <select
                    className="input-field text-sm"
                    value={form.parent_id}
                    onChange={(e) => setForm((f) => ({ ...f, parent_id: e.target.value || null }))}
                    required
                  >
                    <option value="">Selecciona el almacén padre...</option>
                    {primaryWarehouses
                      .filter((p) => p.id !== editingWarehouse?.id)
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} {p.location ? `(${p.location})` : ''}
                        </option>
                      ))}
                  </select>
                </div>
              )}

              {/* Nombre */}
              <div>
                <label className="label">
                  {form.parent_id ? 'Nombre del Sub-almacén o Contenedor *' : 'Nombre del Almacén *'}
                </label>
                <input
                  className="input-field text-sm"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder={form.parent_id ? 'Ej. Contenedor 1, Jaula Servidores, Estante B' : 'Ej. Centro de Convenciones La Carlota'}
                  autoFocus
                  required
                />
              </div>

              {/* Ubicación */}
              <div>
                <label className="label">Ubicación / Dirección Específica</label>
                <input
                  className="input-field text-sm"
                  value={form.location || ''}
                  onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
                  placeholder="Ej. Nave A, Pasillo 3, o Dirección física"
                />
              </div>

              {/* Descripción */}
              <div>
                <label className="label">Descripción u Observaciones</label>
                <textarea
                  className="input-field resize-none text-xs"
                  rows={2}
                  value={form.description || ''}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder="Detalles sobre tipos de equipos almacenados o accesos..."
                />
              </div>

              {/* Botones de acción */}
              <div className="flex gap-2 justify-end pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn-secondary py-2 px-4 text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!form.name.trim() || isSaving}
                  className="btn-primary py-2 px-4 text-xs"
                >
                  {isSaving ? 'Guardando...' : editingWarehouse ? 'Guardar Cambios' : 'Crear Almacén'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
