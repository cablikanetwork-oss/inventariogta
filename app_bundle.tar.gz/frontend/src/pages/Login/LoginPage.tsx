import { useState } from 'react'
import { useThemeStore } from '../../store/themeStore'
import { useAuthStore } from '../../store/authStore'
import { authApi } from '../../api/auth'
import { useNavigate } from 'react-router-dom'
import { PinKeypad } from '../../components/PinKeypad/PinKeypad'
import {
  Cpu,
  ArrowLeft,
  UserCircle2,
  KeyRound,
  CreditCard,
  ShieldCheck,
  LockKeyhole,
  CheckCircle2
} from 'lucide-react'

export function LoginPage() {
  const { config } = useThemeStore()
  const { setAuth } = useAuthStore()
  const navigate = useNavigate()

  const [username, setUsername] = useState('')
  const [step, setStep] = useState<'username' | 'pin' | 'recover'>('username')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Estado para recuperación de PIN
  const [recIdCard, setRecIdCard] = useState('')
  const [recKey, setRecKey] = useState('')
  const [recNewPin, setRecNewPin] = useState('')
  const [recConfirmPin, setRecConfirmPin] = useState('')
  const [recSuccess, setRecSuccess] = useState<string | null>(null)

  const handleUsernameSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (username.trim().length >= 3) {
      setStep('pin')
      setError(null)
    }
  }

  const handlePinSubmit = async (pin: string) => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await authApi.login({
        username: username.trim().toLowerCase(),
        pin,
      })
      setAuth(response.user, response.access_token)
      navigate('/dashboard')
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Usuario o PIN incorrecto')
    } finally {
      setIsLoading(false)
    }
  }

  const openRecoverStep = () => {
    setError(null)
    setRecSuccess(null)
    setRecIdCard('')
    setRecKey('')
    setRecNewPin('')
    setRecConfirmPin('')
    setStep('recover')
  }

  const handleRecoverSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setRecSuccess(null)

    if (recNewPin.length < 4 || recNewPin.length > 6) {
      setError('El nuevo PIN debe tener entre 4 y 6 dígitos numéricos.')
      return
    }
    if (recNewPin !== recConfirmPin) {
      setError('La confirmación del PIN no coincide.')
      return
    }

    setIsLoading(true)
    try {
      const response = await authApi.recoverPin({
        username: username.trim().toLowerCase(),
        id_card: recIdCard.trim(),
        recovery_key: recKey.trim(),
        new_pin: recNewPin.trim(),
      })
      setRecSuccess('¡PIN restablecido exitosamente! Ingresando al sistema...')
      setTimeout(() => {
        setAuth(response.user, response.access_token)
        navigate('/dashboard')
      }, 900)
    } catch (err: any) {
      setError(
        err?.response?.data?.detail ||
          'No se pudo verificar la identidad para restablecer el PIN.'
      )
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 p-4 safe-top safe-bottom">
      <div className="w-full max-w-sm">
        {/* Identidad de Marca Blanca */}
        <div className="text-center mb-6">
          {config?.logo_url ? (
            <img
              src={config.logo_url}
              alt="Logo Empresa"
              className="w-20 h-20 object-contain mx-auto mb-3 rounded-2xl bg-slate-900 border border-slate-800 p-2 shadow-xl"
            />
          ) : (
            <div
              className="w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center shadow-lg"
              style={{ background: 'var(--color-primary)' }}
            >
              <Cpu className="w-9 h-9 text-white stroke-[2]" />
            </div>
          )}
          <h1 className="text-2xl font-black text-white tracking-tight">
            {config?.name ?? 'InventoryOS'}
          </h1>
          <p className="text-slate-400 text-xs mt-1 font-medium">
            Control de Inventario y Activos Tecnológicos
          </p>
        </div>

        {/* Tarjeta de Autenticación */}
        <div className="card p-6 shadow-2xl">
          {step === 'username' && (
            <form onSubmit={handleUsernameSubmit} className="space-y-4">
              <div>
                <label className="label">Usuario del Sistema</label>
                <div className="relative">
                  <UserCircle2 className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Ingresa tu usuario"
                    className="input-field pl-10 text-base"
                    autoFocus
                    autoCapitalize="none"
                    autoCorrect="off"
                    autoComplete="username"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={username.trim().length < 3}
                className="btn-primary w-full disabled:opacity-40"
              >
                Siguiente
              </button>

              <div className="pt-2 border-t border-slate-800/80 text-center">
                <button
                  type="button"
                  onClick={openRecoverStep}
                  className="text-xs font-medium text-slate-400 hover:text-primary transition-colors inline-flex items-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>¿Olvidaste tu PIN de acceso?</span>
                </button>
              </div>
            </form>
          )}

          {step === 'pin' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <button
                  type="button"
                  onClick={() => {
                    setStep('username')
                    setError(null)
                  }}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                  title="Cambiar usuario"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                    Usuario
                  </span>
                  <p className="text-white font-bold text-sm leading-none">{username}</p>
                </div>
              </div>

              <div className="pt-2">
                <p className="text-center text-slate-400 text-xs font-medium mb-3">
                  Digita tu PIN de acceso (4-6 dígitos)
                </p>
                <PinKeypad
                  onSubmit={handlePinSubmit}
                  isLoading={isLoading}
                  error={error}
                  maxLength={6}
                />
              </div>

              <div className="pt-2 border-t border-slate-800/80 text-center">
                <button
                  type="button"
                  onClick={openRecoverStep}
                  className="text-xs font-medium text-slate-400 hover:text-primary transition-colors inline-flex items-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>¿Olvidaste tu PIN? Restablecer aquí</span>
                </button>
              </div>
            </div>
          )}

          {step === 'recover' && (
            <form onSubmit={handleRecoverSubmit} className="space-y-3.5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <button
                  type="button"
                  onClick={() => {
                    setStep('username')
                    setError(null)
                  }}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                  title="Volver al login"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-primary tracking-wider flex items-center justify-end gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Seguridad
                  </span>
                  <p className="text-white font-bold text-sm leading-none">
                    Recuperación de PIN
                  </p>
                </div>
              </div>

              {error && (
                <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs font-medium">
                  {error}
                </div>
              )}

              {recSuccess && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{recSuccess}</span>
                </div>
              )}

              <div>
                <label className="label text-xs">Usuario a Recuperar *</label>
                <div className="relative">
                  <UserCircle2 className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Nombre de usuario"
                    className="input-field pl-9 text-sm"
                    autoCapitalize="none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="label text-xs">
                  Cédula de Identidad (Titular o Gerencia TI) *
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={recIdCard}
                    onChange={(e) => setRecIdCard(e.target.value)}
                    placeholder="Ej. 14.287.629"
                    className="input-field pl-9 text-sm font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="label text-xs">Llave de Seguridad / Recuperación *</label>
                <div className="relative">
                  <LockKeyhole className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="password"
                    value={recKey}
                    onChange={(e) => setRecKey(e.target.value)}
                    placeholder="Palabra secreta o Llave Maestra"
                    className="input-field pl-9 text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5 pt-1">
                <div>
                  <label className="label text-xs">Nuevo PIN *</label>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={6}
                    value={recNewPin}
                    onChange={(e) => setRecNewPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="4-6 dígitos"
                    className="input-field text-sm font-mono tracking-widest text-center"
                    required
                  />
                </div>
                <div>
                  <label className="label text-xs">Confirmar PIN *</label>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={6}
                    value={recConfirmPin}
                    onChange={(e) => setRecConfirmPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="Repetir PIN"
                    className="input-field text-sm font-mono tracking-widest text-center"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={
                  isLoading ||
                  username.trim().length < 3 ||
                  !recIdCard.trim() ||
                  !recKey.trim() ||
                  recNewPin.length < 4
                }
                className="btn-primary w-full py-2.5 text-xs font-bold disabled:opacity-40"
              >
                {isLoading ? 'Verificando...' : 'Restablecer PIN e Ingresar'}
              </button>
            </form>
          )}
        </div>

        <p className="text-center text-slate-600 text-xs mt-6 font-mono">
          PWA Multi-Almacén v1.0 • Acceso Seguro por PIN
        </p>
      </div>
    </div>
  )
}
