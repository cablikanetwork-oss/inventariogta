import { useState, useRef, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { BrowserMultiFormatReader, NotFoundException } from '@zxing/library'
import {
  X,
  Flashlight,
  FlashlightOff,
  RefreshCw,
  Sparkles,
  User,
  Building,
  CheckCircle2,
  ExternalLink,
  ShieldAlert,
  Layers,
  ArrowRight,
  Zap,
  Wifi,
  WifiOff,
  ZoomIn,
  FileSignature,
  Activity,
  Radar,
  ShieldCheck
} from 'lucide-react'
import { type PublicEquipmentLookupResponse } from '../../api/equipment'
import {
  getEquipmentSync0ms,
  lookupEquipmentOfflineFirst,
  parseQrCodeIdentifier,
  syncArCatalogOfflineFirst,
  verifyPresenceOfflineFirst,
  getArCacheStatus
} from '../../services/arOfflineStore'

interface Point2D {
  x: number
  y: number
}

interface TrackedArTarget {
  code: string
  corners: Point2D[]
  displayCorners: Point2D[]
  center: Point2D
  displayCenter: Point2D
  lastSeen: number
  data: PublicEquipmentLookupResponse | null
  isSimulated?: boolean
}

const ZOOM_LEVELS = [1, 1.5, 2, 3]

export function QuickScanHUDPage() {
  const navigate = useNavigate()
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const readerRef = useRef<BrowserMultiFormatReader | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const trackedTargetsRef = useRef<Map<string, TrackedArTarget>>(new Map())
  const animFrameRef = useRef<number | null>(null)

  const [isScanning, setIsScanning] = useState(false)
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment')
  const [torchEnabled, setTorchEnabled] = useState(false)
  const [hasTorch, setHasTorch] = useState(false)
  const [zoomLevel, setZoomLevel] = useState<number>(1)
  const [supportsHardwareZoom, setSupportsHardwareZoom] = useState(false)

  // Modos avanzados: Rayos-X Multi-Equipo y Demo AR
  const [xrayMultiMode, setXrayMultiMode] = useState(false)
  const [demoArActive, setDemoArActive] = useState(false)
  const [detectedList, setDetectedList] = useState<PublicEquipmentLookupResponse[]>([])

  // Estado Offline / Pre-Caché 0ms
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  )
  const [cachedCount, setCachedCount] = useState<number>(0)
  const [lookupLatencyMs, setLookupLatencyMs] = useState<number>(0)
  const [lookupSource, setLookupSource] = useState<'0ms-ram' | 'offline-cache' | 'live-api'>('0ms-ram')

  // Estado del Activo Principal Seleccionado en el Holograma Inferior
  const [activeEquipment, setActiveEquipment] = useState<PublicEquipmentLookupResponse | null>(null)
  const [isLookingUp, setIsLookingUp] = useState(false)
  const [scanError, setScanError] = useState<string | null>(null)
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null)
  const lastScannedCodeRef = useRef<string | null>(null)
  const isOnlineRef = useRef<boolean>(isOnline)

  useEffect(() => {
    isOnlineRef.current = isOnline
  }, [isOnline])

  // Estado de Verificación Rápida 1-Tap
  const [isVerifying, setIsVerifying] = useState(false)
  const [verifiedFeedback, setVerifiedFeedback] = useState<{
    serial: string
    mode: 'online' | 'offline-outbox'
    time: string
  } | null>(null)

  // Sincronizar Pre-Caché AR al abrir el visor
  useEffect(() => {
    const initial = getArCacheStatus()
    setCachedCount(initial.cachedCount)

    syncArCatalogOfflineFirst().then((res) => {
      setCachedCount(res.count)
    })

    const onOnline = () => {
      setIsOnline(true)
      syncArCatalogOfflineFirst().then((r) => setCachedCount(r.count))
    }
    const onOffline = () => setIsOnline(false)

    window.addEventListener('online', onOnline)
    window.addEventListener('offline', onOffline)
    return () => {
      window.removeEventListener('online', onOnline)
      window.removeEventListener('offline', onOffline)
    }
  }, [])

  // Sonido sintetizado de bloqueo de objetivo AR
  const playScanChirp = useCallback(() => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext
      if (!AudioCtx) return
      const ctx = new AudioCtx()
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()

      osc.type = 'sine'
      osc.frequency.setValueAtTime(920, ctx.currentTime)
      osc.frequency.exponentialRampToValueAtTime(1480, ctx.currentTime + 0.07)

      gain.gain.setValueAtTime(0.16, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.09)

      osc.connect(gain)
      gain.connect(ctx.destination)

      osc.start()
      osc.stop(ctx.currentTime + 0.09)
    } catch {
      // Ignorar restricciones de audio
    }
  }, [])

  const triggerHaptic = useCallback(() => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate([35, 25, 70])
    }
  }, [])

  // Convierte coordenadas del frame de video a coordenadas reales de pantalla en el <canvas>
  const mapVideoPointToCanvas = useCallback((vx: number, vy: number): Point2D => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas || !video.videoWidth || !video.videoHeight) {
      return { x: vx, y: vy }
    }
    const cw = canvas.width
    const ch = canvas.height
    const vw = video.videoWidth
    const vh = video.videoHeight

    const scale = Math.max(cw / vw, ch / vh)
    const offsetX = (cw - vw * scale) / 2
    const offsetY = (ch - vh * scale) / 2

    return {
      x: vx * scale + offsetX,
      y: vy * scale + offsetY,
    }
  }, [])

  // Registra o actualiza un objetivo espacial AR en el diccionario de seguimiento a 60 FPS
  const upsertSpatialTarget = useCallback(
    (rawCode: string, screenCorners: Point2D[], isSimulated = false) => {
      const cleanCode = parseQrCodeIdentifier(rawCode)
      if (!cleanCode) return

      const key = cleanCode.toUpperCase()
      const now = performance.now()

      const cx =
        screenCorners.reduce((acc, p) => acc + p.x, 0) / Math.max(screenCorners.length, 1)
      const cy =
        screenCorners.reduce((acc, p) => acc + p.y, 0) / Math.max(screenCorners.length, 1)

      const existing = trackedTargetsRef.current.get(key)
      const syncData = existing?.data || getEquipmentSync0ms(cleanCode)

      if (existing) {
        existing.corners = screenCorners
        existing.center = { x: cx, y: cy }
        existing.lastSeen = now
        if (syncData) existing.data = syncData
      } else {
        trackedTargetsRef.current.set(key, {
          code: cleanCode,
          corners: screenCorners,
          displayCorners: screenCorners.map((p) => ({ ...p })),
          center: { x: cx, y: cy },
          displayCenter: { x: cx, y: cy },
          lastSeen: now,
          data: syncData,
          isSimulated,
        })
      }

      // Disparar lectura completa (0ms RAM -> IDB -> API) si es nuevo o no es el activo actual
      if (lastScannedCodeRef.current !== cleanCode) {
        lastScannedCodeRef.current = cleanCode
        playScanChirp()
        triggerHaptic()
        setLastScannedCode(cleanCode)
        setVerifiedFeedback(null)

        if (syncData) {
          setActiveEquipment(syncData)
          setLookupLatencyMs(0.1)
          setLookupSource(isOnlineRef.current ? '0ms-ram' : 'offline-cache')
          setScanError(null)
          setDetectedList((prev) =>
            prev.some((x) => x.equipment.id === syncData.equipment.id)
              ? prev
              : [syncData, ...prev]
          )
        } else {
          setIsLookingUp(true)
          lookupEquipmentOfflineFirst(cleanCode)
            .then((res) => {
              const target = trackedTargetsRef.current.get(key)
              if (target) target.data = res.data
              setActiveEquipment(res.data)
              setLookupLatencyMs(res.latencyMs)
              setLookupSource(res.source)
              setScanError(null)
              setDetectedList((prev) =>
                prev.some((x) => x.equipment.id === res.data.equipment.id)
                  ? prev
                  : [res.data, ...prev]
              )
            })
            .catch((err: any) => {
              setScanError(
                err?.response?.data?.detail ||
                  `Código detectado (${cleanCode}) no registrado en el catálogo`
              )
            })
            .finally(() => setIsLookingUp(false))
        }
      }
    },
    [playScanChirp, triggerHaptic]
  )

  // Motor Nativo Hardware Multi-QR (BarcodeDetector API) para Modo Rayos-X Simultáneo
  useEffect(() => {
    const BarcodeDetectorClass = (window as any).BarcodeDetector
    if (!BarcodeDetectorClass || !isScanning) return

    let detector: any = null
    try {
      detector = new BarcodeDetectorClass({
        formats: ['qr_code', 'code_128', 'code_39', 'ean_13'],
      })
    } catch {
      return
    }

    const interval = setInterval(async () => {
      const video = videoRef.current
      if (!video || video.readyState < 2 || !detector) return
      try {
        const barcodes = await detector.detect(video)
        if (Array.isArray(barcodes) && barcodes.length > 0) {
          for (const bc of barcodes) {
            if (!bc.rawValue) continue
            let pts: Point2D[] = []
            if (Array.isArray(bc.cornerPoints) && bc.cornerPoints.length >= 4) {
              pts = bc.cornerPoints.map((p: any) => mapVideoPointToCanvas(p.x, p.y))
            } else if (bc.boundingBox) {
              const b = bc.boundingBox
              pts = [
                mapVideoPointToCanvas(b.x, b.y),
                mapVideoPointToCanvas(b.x + b.width, b.y),
                mapVideoPointToCanvas(b.x + b.width, b.y + b.height),
                mapVideoPointToCanvas(b.x, b.y + b.height),
              ]
            }
            if (pts.length > 0) {
              upsertSpatialTarget(bc.rawValue, pts)
            }
          }
        }
      } catch {
        // Ignorar frames intermedios
      }
    }, 70)

    return () => clearInterval(interval)
  }, [isScanning, mapVideoPointToCanvas, upsertSpatialTarget])

  // Simulador / Demo AR en vivo (para probar el seguimiento espacial multi-equipo en cualquier momento)
  useEffect(() => {
    if (!demoArActive) {
      trackedTargetsRef.current.forEach((val, key) => {
        if (val.isSimulated) trackedTargetsRef.current.delete(key)
      })
      return
    }

    const demoCodes = ['V2509N0002754', '3497BMMHBG0683']
    let tick = 0
    const timer = setInterval(() => {
      const canvas = canvasRef.current
      if (!canvas) return
      tick += 0.06

      const cw = canvas.width
      const ch = canvas.height

      demoCodes.forEach((code, idx) => {
        const baseX = idx === 0 ? cw * 0.28 : cw * 0.58
        const baseY = idx === 0 ? ch * 0.34 : ch * 0.48
        const floatX = baseX + Math.sin(tick + idx * 2) * 18
        const floatY = baseY + Math.cos(tick * 1.2 + idx) * 14
        const size = 68

        const corners: Point2D[] = [
          { x: floatX - size / 2, y: floatY - size / 2 },
          { x: floatX + size / 2, y: floatY - size / 2 },
          { x: floatX + size / 2, y: floatY + size / 2 },
          { x: floatX - size / 2, y: floatY + size / 2 },
        ]
        upsertSpatialTarget(code, corners, true)
      })
    }, 50)

    return () => clearInterval(timer)
  }, [demoArActive, upsertSpatialTarget])

  // Bucle de Renderizado Holográfico a 60 FPS sobre el <canvas>
  useEffect(() => {
    const renderArOverlay = () => {
      const canvas = canvasRef.current
      if (canvas) {
        const rect = canvas.getBoundingClientRect()
        if (canvas.width !== rect.width || canvas.height !== rect.height) {
          canvas.width = rect.width
          canvas.height = rect.height
        }

        const ctx = canvas.getContext('2d')
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height)
          const now = performance.now()
          const lerp = 0.28

          trackedTargetsRef.current.forEach((target, key) => {
            const age = now - target.lastSeen
            const maxAge = target.isSimulated ? 2000 : 1100
            if (age > maxAge) {
              trackedTargetsRef.current.delete(key)
              return
            }

            const alpha = age > maxAge - 300 ? Math.max(0, (maxAge - age) / 300) : 1

            // Interpolación suave (60 FPS) de esquinas y centro
            for (let i = 0; i < target.corners.length; i++) {
              if (!target.displayCorners[i]) {
                target.displayCorners[i] = { ...target.corners[i] }
              } else {
                target.displayCorners[i].x +=
                  (target.corners[i].x - target.displayCorners[i].x) * lerp
                target.displayCorners[i].y +=
                  (target.corners[i].y - target.displayCorners[i].y) * lerp
              }
            }
            target.displayCenter.x += (target.center.x - target.displayCenter.x) * lerp
            target.displayCenter.y += (target.center.y - target.displayCenter.y) * lerp

            const eq = target.data?.equipment
            const custody = target.data?.custody
            const isAssigned = eq?.status === 'assigned' || !!custody
            const isAvailable = eq?.status === 'available'

            const mainColor = !eq
              ? '#f43f5e' // Rojo alerta si no registrado
              : isAssigned
              ? '#38bdf8' // Azul cian holográfico si asignado
              : isAvailable
              ? '#10b981' // Verde esmeralda si disponible
              : '#f59e0b' // Ámbar si mantenimiento

            const fillRgba = !eq
              ? `rgba(244, 63, 94, ${0.18 * alpha})`
              : isAssigned
              ? `rgba(56, 189, 248, ${0.16 * alpha})`
              : isAvailable
              ? `rgba(16, 185, 129, ${0.16 * alpha})`
              : `rgba(245, 158, 11, ${0.16 * alpha})`

            ctx.save()
            ctx.globalAlpha = alpha

            // 1. Polígono de Anclaje Espacial sobre el QR
            const pts = target.displayCorners
            if (pts.length >= 4) {
              ctx.beginPath()
              ctx.moveTo(pts[0].x, pts[0].y)
              for (let i = 1; i < pts.length; i++) {
                ctx.lineTo(pts[i].x, pts[i].y)
              }
              ctx.closePath()
              ctx.fillStyle = fillRgba
              ctx.fill()

              ctx.lineWidth = 2.5
              ctx.strokeStyle = mainColor
              ctx.shadowColor = mainColor
              ctx.shadowBlur = 12
              ctx.stroke()

              // Puntos de vértice iluminados
              pts.forEach((p) => {
                ctx.beginPath()
                ctx.arc(p.x, p.y, 4, 0, Math.PI * 2)
                ctx.fillStyle = '#ffffff'
                ctx.fill()
              })
            }

            // 2. Anillo Central de Bloqueo Táctico
            const cx = target.displayCenter.x
            const cy = target.displayCenter.y
            ctx.beginPath()
            ctx.arc(cx, cy, 8 + Math.sin(now * 0.008) * 2.5, 0, Math.PI * 2)
            ctx.strokeStyle = mainColor
            ctx.lineWidth = 2
            ctx.stroke()

            // 3. Línea Conectora Táctica (Callout Leader Line) + Etiqueta Holográfica Flotante
            const cardW = 225
            const cardH = 74
            const dirX = cx > canvas.width * 0.58 ? -1 : 1
            const elbowX = cx + dirX * 32
            const elbowY = cy - 36
            const cardX =
              dirX > 0
                ? Math.min(canvas.width - cardW - 12, elbowX + 14)
                : Math.max(12, elbowX - cardW - 14)
            const cardY = Math.max(70, Math.min(canvas.height - cardH - 160, elbowY - cardH / 2))

            ctx.beginPath()
            ctx.moveTo(cx, cy)
            ctx.lineTo(elbowX, elbowY)
            ctx.lineTo(dirX > 0 ? cardX : cardX + cardW, cardY + cardH / 2)
            ctx.strokeStyle = mainColor
            ctx.lineWidth = 2
            ctx.stroke()

            // Fondo de la etiqueta flotante sobre el video
            ctx.shadowBlur = 18
            ctx.shadowColor = 'rgba(0, 0, 0, 0.75)'
            ctx.fillStyle = 'rgba(9, 14, 28, 0.92)'
            ctx.beginPath()
            ctx.roundRect(cardX, cardY, cardW, cardH, 12)
            ctx.fill()

            ctx.shadowBlur = 0
            ctx.lineWidth = 1.5
            ctx.strokeStyle = mainColor
            ctx.stroke()

            // Textos dentro de la tarjeta AR en vivo
            ctx.fillStyle = mainColor
            ctx.font = 'bold 9px monospace'
            const isActScan =
              target.code.toUpperCase().startsWith('ACT-') ||
              target.code.toUpperCase().startsWith('SOLV-')
            const statusText = !eq
              ? '● NO REGISTRADO'
              : isActScan
              ? '✓ ACTA OFICIAL AUTÉNTICA'
              : isAssigned
              ? '● ASIGNADO EN CUSTODIA'
              : isAvailable
              ? '● DISPONIBLE EN SEDE'
              : `● ${eq.status.toUpperCase()}`
            ctx.fillText(statusText, cardX + 10, cardY + 16)

            // salud % a la derecha
            if (eq && typeof eq.health_pct === 'number') {
              ctx.fillStyle = '#94a3b8'
              ctx.font = 'bold 9px monospace'
              ctx.fillText(`SALUD ${eq.health_pct}%`, cardX + cardW - 64, cardY + 16)
            }

            ctx.fillStyle = '#ffffff'
            ctx.font = 'bold 12px sans-serif'
            const titleText = eq
              ? `${eq.name} ${eq.brand ? `(${eq.brand})` : ''}`.slice(0, 26)
              : `Código: ${target.code.slice(0, 18)}`
            ctx.fillText(titleText, cardX + 10, cardY + 34)

            ctx.fillStyle = '#cbd5e1'
            ctx.font = '11px sans-serif'
            const subText = custody
              ? `Custodio: ${custody.recipient_name || custody.assigned_to}`.slice(0, 30)
              : eq
              ? `Almacén: ${eq.warehouse_name || 'Principal'}`.slice(0, 30)
              : 'Sin ficha en base de datos'
            ctx.fillText(subText, cardX + 10, cardY + 51)

            ctx.fillStyle = '#64748b'
            ctx.font = '10px monospace'
            ctx.fillText(`S/N: ${target.code.slice(0, 22)}`, cardX + 10, cardY + 65)

            ctx.restore()
          })
        }
      }
      animFrameRef.current = requestAnimationFrame(renderArOverlay)
    }

    animFrameRef.current = requestAnimationFrame(renderArOverlay)
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current)
    }
  }, [])

  // Iniciar Cámara y Lector Universal ZXing (con extracción de coordenadas ResultPoints)
  const startCamera = useCallback(async () => {
    if (!videoRef.current) return
    setIsScanning(true)
    setScanError(null)

    try {
      if (readerRef.current) {
        readerRef.current.reset()
      }

      const reader = new BrowserMultiFormatReader()
      readerRef.current = reader

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: cameraFacing,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      }

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop())
        streamRef.current = null
      }

      let stream: MediaStream
      try {
        stream = await navigator.mediaDevices.getUserMedia(constraints)
      } catch {
        // Fallback si la resolución ideal o facingMode falla tras cambiar de app en Android
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false })
      }
      streamRef.current = stream

      const track = stream.getVideoTracks()[0]
      const capabilities = (track && track.getCapabilities && track.getCapabilities()) || {}
      setHasTorch(Boolean((capabilities as any).torch))
      setSupportsHardwareZoom(Boolean((capabilities as any).zoom))

      reader.decodeFromStream(stream, videoRef.current, (result, err) => {
        if (result) {
          const rawText = result.getText()
          const resultPts = result.getResultPoints()
          let corners: Point2D[] = []

          if (resultPts && resultPts.length >= 2) {
            const mapped = resultPts.map((rp) =>
              mapVideoPointToCanvas(rp.getX(), rp.getY())
            )
            if (mapped.length >= 3) {
              // Calcular el 4to vértice del paralelogramo QR a partir de los 3 patrones de posición
              const [p0, p1, p2] = mapped
              const p3 = {
                x: p0.x + (p2.x - p1.x),
                y: p0.y + (p2.y - p1.y),
              }
              corners = [p0, p1, p2, p3]
            } else {
              const [a, b] = mapped
              const pad = 35
              corners = [
                { x: Math.min(a.x, b.x) - pad, y: Math.min(a.y, b.y) - pad },
                { x: Math.max(a.x, b.x) + pad, y: Math.min(a.y, b.y) - pad },
                { x: Math.max(a.x, b.x) + pad, y: Math.max(a.y, b.y) + pad },
                { x: Math.min(a.x, b.x) - pad, y: Math.max(a.y, b.y) + pad },
              ]
            }
          } else if (canvasRef.current) {
            const cw = canvasRef.current.width
            const ch = canvasRef.current.height
            corners = [
              { x: cw / 2 - 60, y: ch / 2 - 60 },
              { x: cw / 2 + 60, y: ch / 2 - 60 },
              { x: cw / 2 + 60, y: ch / 2 + 60 },
              { x: cw / 2 - 60, y: ch / 2 + 60 },
            ]
          }

          upsertSpatialTarget(rawText, corners)
        }
        if (err && !(err instanceof NotFoundException)) {
          // Ignorar frames sin código
        }
      })

      setTimeout(() => {
        if (videoRef.current && videoRef.current.paused) {
          videoRef.current.play().catch(() => {})
        }
      }, 250)
    } catch (err) {
      console.error(err)
      setScanError(
        'Sin acceso directo a cámara física. Puedes usar el botón "Demo AR" arriba para probar el seguimiento holográfico en vivo.'
      )
      setIsScanning(false)
    }
  }, [cameraFacing, mapVideoPointToCanvas, upsertSpatialTarget])

  const stopCamera = useCallback(() => {
    if (readerRef.current) {
      readerRef.current.reset()
      readerRef.current = null
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    setIsScanning(false)
  }, [])

  useEffect(() => {
    startCamera()

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        setTimeout(() => {
          const currentStream = streamRef.current
          const trackEnded =
            !currentStream ||
            currentStream.getVideoTracks().length === 0 ||
            currentStream.getVideoTracks().some((t) => t.readyState === 'ended')
          if (trackEnded) {
            startCamera()
          } else if (videoRef.current && videoRef.current.paused) {
            videoRef.current.play().catch(() => startCamera())
          }
        }, 350)
      }
    }

    document.addEventListener('visibilitychange', handleVisibilityOrFocus)
    window.addEventListener('focus', handleVisibilityOrFocus)

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus)
      window.removeEventListener('focus', handleVisibilityOrFocus)
      stopCamera()
    }
  }, [startCamera, stopCamera])

  // Control de Linterna (Torch)
  const toggleTorch = async () => {
    if (!streamRef.current) return
    const track = streamRef.current.getVideoTracks()[0]
    if (!track) return
    try {
      const nextTorch = !torchEnabled
      await track.applyConstraints({
        advanced: [{ torch: nextTorch } as any],
      })
      setTorchEnabled(nextTorch)
    } catch (err) {
      console.warn('Error al activar linterna', err)
    }
  }

  // Control de Zoom Óptico / Digital Táctico
  const handleSelectZoom = async (targetZoom: number) => {
    setZoomLevel(targetZoom)
    if (supportsHardwareZoom && streamRef.current) {
      const track = streamRef.current.getVideoTracks()[0]
      if (track) {
        try {
          await track.applyConstraints({
            advanced: [{ zoom: targetZoom } as any],
          })
        } catch {
          // Fallback a CSS scale automático
        }
      }
    }
  }

  const toggleCameraFacing = () => {
    stopCamera()
    setCameraFacing((prev) => (prev === 'environment' ? 'user' : 'environment'))
  }

  const handleScanNext = () => {
    setActiveEquipment(null)
    setScanError(null)
    setLastScannedCode(null)
    lastScannedCodeRef.current = null
    setVerifiedFeedback(null)
  }

  // Acción 1-Tap: Verificar Presencia Física (Online + Offline Outbox)
  const handleOneTapVerify = async () => {
    if (!activeEquipment || isVerifying) return
    setIsVerifying(true)
    try {
      const res = await verifyPresenceOfflineFirst(
        activeEquipment.equipment.id,
        activeEquipment.equipment.serial_number
      )
      triggerHaptic()
      setVerifiedFeedback({
        serial: activeEquipment.equipment.serial_number,
        mode: res.mode,
        time: new Date(res.verifiedAt).toLocaleTimeString('es-VE', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      })
    } finally {
      setIsVerifying(false)
    }
  }

  const healthPct = activeEquipment?.equipment.health_pct ?? 100
  const healthColor =
    healthPct >= 60 ? '#10b981' : healthPct >= 30 ? '#f59e0b' : '#f43f5e'

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between overflow-hidden select-none">
      {/* BARRA SUPERIOR HUD TÁCTICA */}
      <div className="relative z-30 flex flex-wrap items-center justify-between gap-2 p-3 sm:p-4 bg-slate-950/85 backdrop-blur-xl border-b border-white/10 safe-top">
        <div className="flex items-center gap-2.5 text-white">
          <div className="w-9 h-9 rounded-xl bg-primary/20 border border-primary/40 flex items-center justify-center text-primary shadow-[0_0_15px_rgba(37,99,235,0.3)]">
            <Radar className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-xs sm:text-sm tracking-wide text-white">
                VISOR AR / HUD TÁCTICO
              </span>
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                  isOnline
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                }`}
              >
                {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                {isOnline ? 'ONLINE' : 'MODO OFFLINE'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
              <span className="text-cyan-400 font-semibold">
                ⚡ {cachedCount} ACTIVOS EN RAM (0ms)
              </span>
              {lookupLatencyMs > 0 && (
                <span>• LECTURA: {lookupLatencyMs}ms ({lookupSource})</span>
              )}
            </div>
          </div>
        </div>

        {/* Controles Superiores */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Botón Simulador Demo AR */}
          <button
            onClick={() => setDemoArActive((prev) => !prev)}
            className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl border text-xs font-semibold transition-all ${
              demoArActive
                ? 'bg-cyan-500/25 text-cyan-300 border-cyan-400/60 shadow-[0_0_15px_rgba(34,211,238,0.35)]'
                : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:text-white'
            }`}
            title="Simular Etiquetas AR en Vivo"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{demoArActive ? 'Demo AR: ON' : 'Demo AR'}</span>
          </button>

          {hasTorch && (
            <button
              onClick={toggleTorch}
              className={`p-2 rounded-xl border transition-colors ${
                torchEnabled
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:text-white'
              }`}
              title="Linterna"
            >
              {torchEnabled ? (
                <Flashlight className="w-4 h-4" />
              ) : (
                <FlashlightOff className="w-4 h-4" />
              )}
            </button>
          )}

          <button
            onClick={toggleCameraFacing}
            className="p-2 rounded-xl bg-slate-800/80 text-slate-300 border border-slate-700 hover:text-white transition-colors"
            title="Cambiar Cámara"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              stopCamera()
              navigate('/equipment')
            }}
            className="p-2 rounded-xl bg-slate-800/80 text-slate-300 border border-slate-700 hover:text-white hover:bg-rose-500/20 hover:border-rose-500/40 transition-colors"
            title="Cerrar Escáner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* VISOR DE CÁMARA + CAPA CANVAS DE SEGUIMIENTO ESPACIAL AR A 60 FPS */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-slate-950">
        <div
          className="relative w-full h-full transition-transform duration-200 ease-out"
          style={{
            transform: !supportsHardwareZoom && zoomLevel > 1 ? `scale(${zoomLevel})` : undefined,
          }}
        >
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            playsInline
            muted
            autoPlay
          />
          {/* Lienzo de Realidad Aumentada 60 FPS */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none z-20"
          />
        </div>

        {/* RETÍCULA CENTRAL CUANDO NO HAY OBJETIVO BLOQUEADO */}
        {!activeEquipment && (
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-6 z-10">
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 border border-cyan-500/25 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.12)]">
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-cyan-400 rounded-tl-2xl" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-cyan-400 rounded-tr-2xl" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-cyan-400 rounded-bl-2xl" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-cyan-400 rounded-br-2xl" />

              {isScanning && (
                <div
                  className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#22d3ee] animate-pulse"
                  style={{ top: '50%' }}
                />
              )}

              {isLookingUp && (
                <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm flex flex-col items-center justify-center text-center p-4">
                  <Sparkles className="w-8 h-8 text-cyan-400 animate-spin mb-2" />
                  <span className="text-xs font-mono font-bold text-white tracking-widest uppercase">
                    IDENTIFICANDO...
                  </span>
                </div>
              )}
            </div>

            <div className="mt-4 flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-950/85 border border-slate-800 text-slate-300 text-xs font-mono backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>ENFOCA UNA O VARIAS ETIQUETAS QR (O PULSA "DEMO AR")</span>
            </div>
          </div>
        )}

        {/* SELECTOR TÁCTICO DE ZOOM ÓPTICO / DIGITAL (1x, 1.5x, 2x, 3x) */}
        <div className="absolute right-3 top-1/2 -translate-y-1/2 z-30 flex flex-col gap-1.5 bg-slate-950/80 border border-slate-800 p-1.5 rounded-2xl backdrop-blur-md">
          <div className="text-[9px] font-mono text-slate-400 text-center flex items-center justify-center py-0.5">
            <ZoomIn className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          {ZOOM_LEVELS.map((z) => (
            <button
              key={z}
              onClick={() => handleSelectZoom(z)}
              className={`w-9 h-8 rounded-xl text-[11px] font-mono font-bold transition-all ${
                zoomLevel === z
                  ? 'bg-primary text-white shadow-lg shadow-primary/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {z}x
            </button>
          ))}
        </div>

        {/* PANEL LATERAL MODO RAYOS-X (MULTI-EQUIPO EN ESCENA) */}
        {xrayMultiMode && detectedList.length > 0 && (
          <div className="absolute left-3 top-4 z-30 w-64 max-h-60 overflow-y-auto bg-slate-950/90 border border-cyan-500/40 rounded-2xl p-3 backdrop-blur-xl shadow-2xl space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
              <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase flex items-center gap-1">
                <Layers className="w-3.5 h-3.5" />
                RADAR MULTI-ACTIVO ({detectedList.length})
              </span>
              <button
                onClick={() => setDetectedList([])}
                className="text-[10px] text-slate-400 hover:text-white"
              >
                Limpiar
              </button>
            </div>
            {detectedList.map((item) => {
              const isAssg = item.equipment.status === 'assigned' || !!item.custody
              return (
                <button
                  key={item.equipment.id}
                  onClick={() => setActiveEquipment(item)}
                  className="w-full text-left p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 transition-colors flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">
                      {item.equipment.name}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">
                      {item.custody
                        ? `👤 ${item.custody.recipient_name || item.custody.assigned_to}`
                        : `🏢 ${item.equipment.warehouse_name || 'Disponible'}`}
                    </p>
                  </div>
                  <span
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      isAssg ? 'bg-cyan-400' : 'bg-emerald-400'
                    }`}
                  />
                </button>
              )
            })}
          </div>
        )}

        {/* HOLOGRAMA TÁCTICO INFERIOR CON TELEMETRÍA, FIRMA Y ACCIONES 1-TAP */}
        {activeEquipment && (
          <div className="absolute inset-x-3 bottom-20 z-30 max-w-lg mx-auto bg-slate-950/92 border border-cyan-500/50 shadow-[0_0_40px_rgba(6,182,212,0.28)] rounded-3xl backdrop-blur-2xl p-4 sm:p-5 text-white animate-in fade-in slide-in-from-bottom-6 duration-200">
            {/* Cabecera con Anillo de Salud SVG */}
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    {lastScannedCode &&
                    (lastScannedCode.toUpperCase().startsWith('ACT-') ||
                      lastScannedCode.toUpperCase().startsWith('SOLV-'))
                      ? 'ACTA OFICIAL AUTÉNTICA (VERIFICADA)'
                      : 'ANCLAJE AR ACTIVO'}
                  </span>
                  {activeEquipment.custody?.verification_hash && (
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      SHA: {activeEquipment.custody.verification_hash.slice(0, 8)}
                    </span>
                  )}
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                    {lookupLatencyMs}ms
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white truncate mt-0.5">
                  {activeEquipment.equipment.name}{' '}
                  {activeEquipment.equipment.brand ? `• ${activeEquipment.equipment.brand}` : ''}
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  S/N: {activeEquipment.equipment.serial_number} •{' '}
                  {activeEquipment.equipment.model || activeEquipment.equipment.category}
                </p>
              </div>

              {/* Medidor Circular SVG de Vida Útil / Salud */}
              <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-2.5 py-1.5 rounded-2xl shrink-0">
                <div className="relative w-9 h-9 flex items-center justify-center">
                  <svg className="w-9 h-9 -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-slate-800"
                      strokeWidth="3.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <path
                      stroke={healthColor}
                      strokeWidth="3.5"
                      strokeDasharray={`${healthPct}, 100`}
                      strokeLinecap="round"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <span className="absolute text-[9px] font-mono font-bold text-white">
                    {healthPct}%
                  </span>
                </div>
                <div className="text-[10px] leading-tight">
                  <span className="text-slate-400 block font-semibold">SALUD</span>
                  <span className="text-emerald-400 font-mono font-bold">ÓPTIMA</span>
                </div>
              </div>
            </div>

            {/* SELLO DE AUTENTICIDAD ANTI-FORJADO CUANDO TIENE ACTA O SE ESCANEÓ UN ACTA */}
            {activeEquipment.custody && (
              <div className="mb-2.5 px-3 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[11px] font-black text-emerald-300 uppercase tracking-wide truncate">
                      {activeEquipment.custody.act_type === 'return'
                        ? '✓ SOLVENCIA / DEVOLUCIÓN TI AUTÉNTICA (NO MONTADA)'
                        : '✓ ACTA DE ASIGNACIÓN AUTÉNTICA Y VÁLIDA (NO MONTADA)'}
                    </p>
                    <p className="text-[10px] text-slate-300 truncate">
                      Autorizado por: {activeEquipment.custody.delivered_by_name || 'Raimundo Gil'} (Gerencia TI)
                    </p>
                  </div>
                </div>
                <span className="text-[9px] font-mono font-bold bg-emerald-950/80 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 shrink-0">
                  VERIFICADO
                </span>
              </div>
            )}

            {/* CUSTODIO + MINIATURA DE FIRMA REAL EN EL HOLOGRAMA */}
            <div className="p-3 rounded-2xl bg-slate-900/95 border border-slate-800/90 mb-3">
              {activeEquipment.custody ? (
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
                      <User className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 text-xs">
                      <p className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
                        En Custodia de:
                      </p>
                      <p className="text-sm font-bold text-white truncate">
                        {activeEquipment.custody.recipient_name ||
                          activeEquipment.custody.assigned_to}
                      </p>
                      <p className="text-slate-400 text-[11px] truncate">
                        {[
                          activeEquipment.custody.recipient_id_card
                            ? `C.I: ${activeEquipment.custody.recipient_id_card}`
                            : null,
                          activeEquipment.custody.recipient_position,
                          activeEquipment.custody.act_number,
                        ]
                          .filter(Boolean)
                          .join(' • ')}
                      </p>
                    </div>
                  </div>

                  {/* Sello de Firma Manuscrita Real o Acta Física Escaneada */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {activeEquipment.custody.scanned_document_url && (
                      <a
                        href={activeEquipment.custody.scanned_document_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold flex items-center gap-1"
                        title="Abrir Hoja Física Firmada Escaneada"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Acta Física</span>
                      </a>
                    )}
                    {activeEquipment.custody.recipient_signature ? (
                      <div className="shrink-0 bg-white rounded-xl p-1.5 border border-blue-400/40 shadow-sm text-center">
                        <img
                          src={activeEquipment.custody.recipient_signature}
                          alt="Firma"
                          className="h-8 w-20 object-contain"
                        />
                        <span className="block text-[8px] font-bold text-slate-700 uppercase">
                          Firma Verificada
                        </span>
                      </div>
                    ) : (
                      <div className="shrink-0 px-2.5 py-1.5 rounded-xl bg-blue-500/10 border border-blue-500/25 text-blue-300 text-[10px] font-mono flex items-center gap-1">
                        <FileSignature className="w-3.5 h-3.5" />
                        <span>{activeEquipment.custody.act_number || 'Asignado'}</span>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                      <Building className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 text-xs">
                      <p className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                        Disponible en Almacén:
                      </p>
                      <p className="text-sm font-bold text-white truncate">
                        {activeEquipment.equipment.warehouse_name || 'Almacén Principal'}
                      </p>
                      <p className="text-slate-400 text-[11px] truncate">
                        {activeEquipment.equipment.warehouse_location ||
                          'Listo para entrega inmediata'}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Disponible
                  </span>
                </div>
              )}
            </div>

            {/* FEEDBACK DE VERIFICACIÓN 1-TAP */}
            {verifiedFeedback &&
              verifiedFeedback.serial === activeEquipment.equipment.serial_number && (
                <div className="mb-3 px-3 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center justify-between">
                  <span className="font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Presencia verificada ({verifiedFeedback.time})
                  </span>
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-950/80">
                    {verifiedFeedback.mode === 'online'
                      ? 'Sincronizado'
                      : 'Guardado en Cola Offline'}
                  </span>
                </div>
              )}

            {/* BOTONES DE ACCIÓN RÁPIDA EN VIVO (1-TAP AR ACTIONS) */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleOneTapVerify}
                disabled={isVerifying}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-emerald-600/20"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Verificar 1-Tap</span>
              </button>

              <button
                onClick={() => {
                  if (
                    lastScannedCode &&
                    (lastScannedCode.toUpperCase().startsWith('ACT-') ||
                      lastScannedCode.toUpperCase().startsWith('SOLV-'))
                  ) {
                    navigate(`/verify-act/${encodeURIComponent(lastScannedCode)}`)
                  } else if (activeEquipment.custody?.act_number) {
                    navigate(
                      `/verify-act/${encodeURIComponent(activeEquipment.custody.act_number)}`
                    )
                  } else {
                    navigate(`/eq/${activeEquipment.equipment.serial_number}`)
                  }
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-primary hover:opacity-90 text-white font-semibold text-xs transition-opacity shadow-lg shadow-primary/20"
              >
                {activeEquipment.custody?.act_number ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Autenticidad Acta</span>
                  </>
                ) : (
                  <>
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Ficha Completa</span>
                  </>
                )}
              </button>

              <button
                onClick={handleScanNext}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors border border-slate-700"
              >
                <span>Siguiente</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* ALERTA DE CÓDIGO NO REGISTRADO */}
        {scanError && !activeEquipment && (
          <div className="absolute inset-x-6 bottom-24 z-40 max-w-sm mx-auto bg-rose-950/90 border border-rose-500/50 rounded-2xl p-4 text-white text-center backdrop-blur-md">
            <ShieldAlert className="w-6 h-6 text-rose-400 mx-auto mb-1.5" />
            <p className="text-xs font-semibold text-rose-200">{scanError}</p>
            <button
              onClick={handleScanNext}
              className="mt-3 px-4 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-medium border border-rose-500/30 transition-colors"
            >
              Continuar Escaneando
            </button>
          </div>
        )}
      </div>

      {/* BARRA INFERIOR DE MODOS TÁCTICOS */}
      <div className="relative z-30 p-3 sm:p-4 bg-slate-950/90 backdrop-blur-xl border-t border-white/10 safe-bottom flex items-center justify-between gap-2">
        <button
          onClick={() => setXrayMultiMode((prev) => !prev)}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
            xrayMultiMode
              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>{xrayMultiMode ? 'Modo Rayos-X: ACTIVO' : 'Activar Modo Rayos-X'}</span>
        </button>

        <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span>60 FPS CANVAS AR • OFFLINE-FIRST</span>
        </div>

        <button
          onClick={() => navigate('/equipment')}
          className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium transition-colors"
        >
          Panel de Equipos
        </button>
      </div>
    </div>
  )
}
