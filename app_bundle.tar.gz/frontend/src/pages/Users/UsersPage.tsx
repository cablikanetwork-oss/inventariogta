import { useState, useEffect, useCallback } from 'react'
import {
  Plus,
  Shield,
  User as UserIcon,
  KeyRound,
  CreditCard,
  LockKeyhole,
  CheckCircle2
} from 'lucide-react'
import { usersApi, type UserCreate, type UserUpdate } from '../../api/users'
import type { User } from '../../api/auth'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

export function UsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [form, setForm] = useState<UserCreate>({
    username: '',
    full_name: '',
    pin: '',
    role: 'user',
    id_card: '',
    recovery_key: '',
  })
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const data = await usersApi.list()
      setUsers(data)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const openCreate = () => {
    setEditingUser(null)
    setForm({
      username: '',
      full_name: '',
      pin: '',
      role: 'user',
      id_card: '',
      recovery_key: '',
    })
    setError(null)
    setShowForm(true)
  }

  const openEdit = (u: User) => {
    setEditingUser(u)
    setForm({
      username: u.username,
      full_name: u.full_name,
      pin: '',
      role: u.role,
      id_card: u.id_card ?? '',
      recovery_key: '',
    })
    setError(null)
    setShowForm(true)
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)
    setError(null)
    try {
      if (editingUser) {
        const update: UserUpdate = {
          full_name: form.full_name,
          role: form.role,
          id_card: form.id_card?.trim() || '',
        }
        if (form.pin.trim()) update.pin = form.pin.trim()
        if (form.recovery_key?.trim()) update.recovery_key = form.recovery_key.trim()
        await usersApi.update(editingUser.id, update)
      } else {
        await usersApi.create({
          ...form,
          username: form.username.trim().toLowerCase(),
          pin: form.pin.trim(),
          id_card: form.id_card?.trim() || undefined,
          recovery_key: form.recovery_key?.trim() || undefined,
        })
      }
      setShowForm(false)
      load()
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al guardar usuario')
    } finally {
      setIsSaving(false)
    }
  }

  const handleToggleActive = async (u: User) => {
    await usersApi.update(u.id, { is_active: !u.is_active })
    load()
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Gestión de Usuarios</h1>
          <p className="text-slate-400 text-xs sm:text-sm">
            Control de accesos, PIN táctil y credenciales de recuperación
          </p>
        </div>
        <button onClick={openCreate} className="btn-primary py-2 px-3.5 text-xs sm:text-sm">
          <Plus className="w-4 h-4" />
          <span>Nuevo Usuario</span>
        </button>
      </div>

      {/* Formulario */}
      {showForm && (
        <form onSubmit={handleSave} className="card p-5 space-y-3.5">
          <h3 className="text-white font-bold text-sm">
            {editingUser ? `Editar Usuario: @${editingUser.username}` : 'Registrar Nuevo Usuario'}
          </h3>
          {error && <p className="text-rose-400 text-xs font-semibold">{error}</p>}

          {!editingUser && (
            <div>
              <label className="label">Nombre de Usuario (Login) *</label>
              <input
                className="input-field text-sm"
                value={form.username}
                onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
                placeholder="Ej. carlos.almacen"
                autoCapitalize="none"
                required
              />
            </div>
          )}

          <div>
            <label className="label">Nombre Completo *</label>
            <input
              className="input-field text-sm"
              value={form.full_name}
              onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))}
              placeholder="Ej. Carlos Albarrán"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="label">
                PIN Numérico {editingUser ? '(dejar vacío para mantener)' : '*'}
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  className="input-field pl-9 text-sm font-mono tracking-widest"
                  value={form.pin}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, pin: e.target.value.replace(/\D/g, '') }))
                  }
                  placeholder="4 a 6 dígitos"
                  required={!editingUser}
                />
              </div>
            </div>

            <div>
              <label className="label">Rol del Sistema</label>
              <select
                className="input-field text-sm"
                value={form.role}
                onChange={(e) =>
                  setForm((f) => ({ ...f, role: e.target.value as 'admin' | 'user' }))
                }
              >
                <option value="user">Usuario (Operador de Almacén)</option>
                <option value="admin">Administrador (Total Acceso)</option>
              </select>
            </div>
          </div>

          {/* Datos de Recuperación de PIN */}
          <div className="pt-2 border-t border-slate-800/80">
            <p className="text-xs font-bold text-slate-300 mb-2">
              Seguridad para Recuperación de PIN ("¿Olvidaste tu PIN?")
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="label">Cédula de Identidad del Titular</label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    className="input-field pl-9 text-sm font-mono"
                    value={form.id_card ?? ''}
                    onChange={(e) => setForm((f) => ({ ...f, id_card: e.target.value }))}
                    placeholder="Ej. 14.287.629"
                  />
                </div>
              </div>

              <div>
                <label className="label">
                  Llave / Palabra Secreta {editingUser?.has_recovery_key ? '(ya configurada)' : ''}
                </label>
                <div className="relative">
                  <LockKeyhole className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="password"
                    className="input-field pl-9 text-sm"
                    value={form.recovery_key ?? ''}
                    onChange={(e) => setForm((f) => ({ ...f, recovery_key: e.target.value }))}
                    placeholder={
                      editingUser?.has_recovery_key
                        ? 'Dejar vacío para conservar actual'
                        : 'Clave secreta personal'
                    }
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="btn-secondary py-2 px-4 text-xs"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving || !form.full_name || (!editingUser && !form.pin)}
              className="btn-primary py-2 px-4 text-xs"
            >
              {isSaving ? 'Guardando...' : editingUser ? 'Actualizar' : 'Crear Usuario'}
            </button>
          </div>
        </form>
      )}

      {/* Listado */}
      {isLoading ? (
        <div className="flex justify-center py-20">
          <LoadingSpinner size="lg" />
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="divide-y divide-slate-800">
            {users.map((u) => (
              <div key={u.id} className="p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-xs uppercase flex-shrink-0 ${
                      u.role === 'admin' ? 'bg-primary' : 'bg-slate-800'
                    }`}
                  >
                    {u.full_name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-bold text-white text-sm truncate">{u.full_name}</p>
                      {u.role === 'admin' ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 border border-primary/30 px-2 py-0.5 rounded-full">
                          <Shield className="w-2.5 h-2.5" /> Admin
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                          <UserIcon className="w-2.5 h-2.5" /> Operador
                        </span>
                      )}
                      {u.id_card && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-mono text-slate-300 bg-slate-800/80 border border-slate-700 px-2 py-0.5 rounded-full">
                          C.I: {u.id_card}
                        </span>
                      )}
                      {u.has_recovery_key && (
                        <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/50 px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-2.5 h-2.5" /> Llave activa
                        </span>
                      )}
                      {!u.is_active && (
                        <span className="text-[10px] text-rose-400 bg-rose-950/40 border border-rose-900/60 px-1.5 py-0.5 rounded-md">
                          Inactivo
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">@{u.username}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEdit(u)}
                    className="btn-secondary py-1.5 px-3 text-xs"
                  >
                    Editar
                  </button>
                  <button
                    onClick={() => handleToggleActive(u)}
                    className={`py-1.5 px-3 text-xs font-semibold rounded-xl transition-colors ${
                      u.is_active
                        ? 'bg-rose-950/40 text-rose-400 border border-rose-900/50 hover:bg-rose-900/40'
                        : 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/50 hover:bg-emerald-900/40'
                    }`}
                  >
                    {u.is_active ? 'Desactivar' : 'Activar'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
