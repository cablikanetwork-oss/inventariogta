import { useState, useRef } from 'react'
import { Save, Palette, Building2, CheckCircle2, Upload, Trash2, Link as LinkIcon, Sun, Moon } from 'lucide-react'
import { companyApi } from '../../api/company'
import { useThemeStore } from '../../store/themeStore'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

const PALETTE_PRESETS = [
  { label: 'Azul Tu Andamio', primary: '#0F70B7', secondary: '#0A4D80', accent: '#F59E0B' },
  { label: 'Azul Corporativo', primary: '#2563EB', secondary: '#1E40AF', accent: '#F59E0B' },
  { label: 'Verde Esmeralda', primary: '#059669', secondary: '#065F46', accent: '#F97316' },
  { label: 'Púrpura DeepTech', primary: '#7C3AED', secondary: '#5B21B6', accent: '#EC4899' },
  { label: 'Rojo Industrial', primary: '#DC2626', secondary: '#991B1B', accent: '#FBBF24' },
  { label: 'Gris Grafito', primary: '#475569', secondary: '#1E293B', accent: '#38BDF8' },
]

export function SettingsPage() {
  const { config, applyTheme, visualMode, setVisualMode } = useThemeStore()
  const [form, setForm] = useState({
    name: config?.name ?? 'InventoryOS Tech',
    logo_url: config?.logo_url ?? '',
    primary_color: config?.primary_color ?? '#2563EB',
    secondary_color: config?.secondary_color ?? '#1E40AF',
    accent_color: config?.accent_color ?? '#F59E0B',
  })
  
  const [isSaving, setIsSaving] = useState(false)
  const [isUploadingLogo, setIsUploadingLogo] = useState(false)
  const [savedSuccess, setSavedSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showUrlInput, setShowUrlInput] = useState(false)
  
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  const handleApplyPreset = (p: typeof PALETTE_PRESETS[0]) => {
    setForm((f) => ({
      ...f,
      primary_color: p.primary,
      secondary_color: p.secondary,
      accent_color: p.accent,
    }))
    // Inyección reactiva inmediata en variables CSS
    document.documentElement.style.setProperty('--color-primary', p.primary)
    document.documentElement.style.setProperty('--color-secondary', p.secondary)
    document.documentElement.style.setProperty('--color-accent', p.accent)
  }

  const handleColorInput = (key: 'primary_color' | 'secondary_color' | 'accent_color', val: string) => {
    setForm((f) => ({ ...f, [key]: val }))
    const cssVar = key.replace('_color', '')
    document.documentElement.style.setProperty(`--color-${cssVar}`, val)
  }

  // Subida directa de archivo PNG / JPG / SVG
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploadingLogo(true)
    setError(null)
    setSavedSuccess(null)

    try {
      const updatedConfig = await companyApi.uploadLogo(file)
      applyTheme(updatedConfig)
      setForm((f) => ({ ...f, logo_url: updatedConfig.logo_url ?? '' }))
      setSavedSuccess('Logotipo subido y guardado permanentemente')
      setTimeout(() => setSavedSuccess(null), 3500)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al subir la imagen del logotipo')
    } finally {
      setIsUploadingLogo(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  // Eliminar logotipo actual
  const handleDeleteLogo = async () => {
    if (!window.confirm('¿Deseas eliminar el logotipo y volver al isotipo predeterminado?')) return

    setIsUploadingLogo(true)
    setError(null)
    setSavedSuccess(null)

    try {
      const updatedConfig = await companyApi.deleteLogo()
      applyTheme(updatedConfig)
      setForm((f) => ({ ...f, logo_url: '' }))
      setSavedSuccess('Logotipo eliminado. Usando isotipo institucional')
      setTimeout(() => setSavedSuccess(null), 3500)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al eliminar el logotipo')
    } finally {
      setIsUploadingLogo(false)
    }
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)
    setError(null)
    setSavedSuccess(null)
    try {
      const updated = await companyApi.updateConfig({
        name: form.name.trim(),
        logo_url: form.logo_url?.trim() || undefined,
        primary_color: form.primary_color,
        secondary_color: form.secondary_color,
        accent_color: form.accent_color,
      })
      applyTheme(updated)
      setSavedSuccess('Configuración institucional guardada correctamente')
      setTimeout(() => setSavedSuccess(null), 3500)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al guardar configuración de marca')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Marca Blanca (White-Label)</h1>
        <p className="text-slate-400 text-xs sm:text-sm">
          Personaliza la identidad institucional, logotipo y colores del sistema en tiempo real
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-5">
        {/* Identidad Institucional */}
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Building2 className="w-4 h-4 text-primary" />
            <span>Identidad Institucional</span>
          </h2>

          <div>
            <label className="label">Nombre de la Empresa / Cliente *</label>
            <input
              className="input-field text-sm"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="Ej. Grupo Tu Andamio"
              required
            />
          </div>

          {/* Subida de Logotipo PNG/JPG/SVG */}
          <div className="space-y-2">
            <label className="label">Logotipo de la Empresa (PNG, JPG, SVG, WEBP)</label>

            {/* Input de archivo oculto */}
            <input
              ref={fileInputRef}
              type="file"
              accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml"
              className="hidden"
              onChange={handleFileChange}
            />

            {/* Visualización y botones de acción del logo */}
            <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex flex-col sm:flex-row items-center gap-4">
                {/* Caja de previsualización */}
                <div className="w-24 h-24 rounded-2xl bg-slate-900 border border-slate-700/80 p-2 flex items-center justify-center flex-shrink-0 shadow-inner overflow-hidden">
                  {form.logo_url ? (
                    <img
                      src={form.logo_url}
                      alt="Logo Empresa"
                      className="max-w-full max-h-full object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none'
                      }}
                    />
                  ) : (
                    <div
                      className="w-16 h-16 rounded-xl flex items-center justify-center text-white font-black text-2xl shadow-md"
                      style={{ background: 'var(--color-primary)' }}
                    >
                      {form.name ? form.name.charAt(0).toUpperCase() : 'E'}
                    </div>
                  )}
                </div>

                {/* Acciones para subir o borrar */}
                <div className="flex-1 text-center sm:text-left space-y-2">
                  <p className="text-white text-xs font-semibold">
                    {form.logo_url ? 'Logotipo activo para esta empresa' : 'Sin imagen personalizada (usando isotipo dinámico)'}
                  </p>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Sube tu imagen PNG con fondo transparente para un acabado profesional en la barra lateral y pantalla de login.
                  </p>

                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                    <button
                      type="button"
                      disabled={isUploadingLogo}
                      onClick={() => fileInputRef.current?.click()}
                      className="btn-primary py-2 px-3.5 text-xs shadow-none"
                    >
                      {isUploadingLogo ? (
                        <>
                          <LoadingSpinner size="sm" />
                          <span>Subiendo...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Subir Imagen PNG / JPG</span>
                        </>
                      )}
                    </button>

                    {form.logo_url && (
                      <button
                        type="button"
                        disabled={isUploadingLogo}
                        onClick={handleDeleteLogo}
                        className="py-2 px-3 text-xs font-semibold rounded-xl text-rose-400 bg-rose-950/30 hover:bg-rose-950/60 border border-rose-900/50 transition-colors flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Quitar imagen</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Opción alternativa: ingresar URL manualmente */}
              <div className="pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => setShowUrlInput(!showUrlInput)}
                  className="text-[11px] text-slate-400 hover:text-primary transition-colors flex items-center gap-1 font-medium"
                >
                  <LinkIcon className="w-3 h-3" />
                  <span>{showUrlInput ? 'Ocultar opción de URL externa' : 'O vincular mediante URL externa...'}</span>
                </button>

                {showUrlInput && (
                  <div className="mt-2 space-y-1">
                    <input
                      className="input-field text-xs py-2"
                      value={form.logo_url}
                      onChange={(e) => setForm((f) => ({ ...f, logo_url: e.target.value }))}
                      placeholder="https://ejemplo.com/logotipo.png"
                    />
                    <p className="text-[10px] text-slate-500">
                      Ruta actual guardada en base de datos: <code className="text-slate-400 font-mono">{form.logo_url || '(ninguna)'}</code>
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Selector de Modo Visual (Tema Claro Azul/Blanco vs. Modo Oscuro) */}
        <div className="card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              {visualMode === 'light' ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-primary" />
              )}
              <span>Modo Visual de la Interfaz (Fondo y Contraste)</span>
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-primary/15 text-primary border border-primary/30">
              {visualMode === 'light' ? 'Modo Claro Activo' : 'Modo Oscuro Activo'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Opción 1: Tema Claro Corporativo (Azul y Blanco) */}
            <button
              type="button"
              onClick={() => {
                setVisualMode('light')
                handleApplyPreset(PALETTE_PRESETS[0])
              }}
              className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-start gap-3 ${
                visualMode === 'light'
                  ? 'border-primary bg-primary/10 shadow-md'
                  : 'border-slate-800 hover:border-slate-600 bg-slate-950/60'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-white border border-blue-200 flex items-center justify-center flex-shrink-0 shadow-xs">
                <Sun className="w-5 h-5 text-[#0F70B7]" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-white flex items-center gap-1.5">
                  <span>Corporativo Claro (Azul y Blanco)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  Fondo blanco y azul hielo con textos en azul marino y negro. Ideal para proyectores y expo.
                </p>
              </div>
            </button>

            {/* Opción 2: Tema Oscuro Técnico */}
            <button
              type="button"
              onClick={() => setVisualMode('dark')}
              className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-start gap-3 ${
                visualMode === 'dark'
                  ? 'border-primary bg-primary/10 shadow-md'
                  : 'border-slate-800 hover:border-slate-600 bg-slate-950/60'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center flex-shrink-0 shadow-xs">
                <Moon className="w-5 h-5 text-sky-400" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-white flex items-center gap-1.5">
                  <span>Modo Oscuro Técnico (Dark Mode)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  Fondo oscuro pizarra con contraste alto para operaciones nocturnas o de almacén.
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Paleta de Colores */}
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Palette className="w-4 h-4 text-primary" />
            <span>Paleta de Colores Dinámica</span>
          </h2>

          {/* Presets rápidos */}
          <div>
            <span className="label mb-2">Temas Rápidos Predeterminados</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PALETTE_PRESETS.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-800 hover:border-slate-600 bg-slate-950/60 transition-colors text-left"
                >
                  <div className="flex -space-x-1">
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-900" style={{ background: p.primary }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-900" style={{ background: p.secondary }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-900" style={{ background: p.accent }} />
                  </div>
                  <span className="text-xs text-slate-300 font-medium truncate">{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Selectores de color individuales */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div>
              <label className="label">Color Primario</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.primary_color}
                  onChange={(e) => handleColorInput('primary_color', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-800 bg-transparent cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={form.primary_color}
                  onChange={(e) => handleColorInput('primary_color', e.target.value)}
                  className="input-field font-mono text-xs py-2"
                  maxLength={7}
                />
              </div>
            </div>

            <div>
              <label className="label">Color Secundario</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.secondary_color}
                  onChange={(e) => handleColorInput('secondary_color', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-800 bg-transparent cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={form.secondary_color}
                  onChange={(e) => handleColorInput('secondary_color', e.target.value)}
                  className="input-field font-mono text-xs py-2"
                  maxLength={7}
                />
              </div>
            </div>

            <div>
              <label className="label">Color de Acento</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.accent_color}
                  onChange={(e) => handleColorInput('accent_color', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-800 bg-transparent cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={form.accent_color}
                  onChange={(e) => handleColorInput('accent_color', e.target.value)}
                  className="input-field font-mono text-xs py-2"
                  maxLength={7}
                />
              </div>
            </div>
          </div>

          {/* Previsualizador en Vivo */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/80 space-y-2 mt-2">
            <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
              Previsualización de Componentes
            </span>
            <div className="flex flex-wrap items-center gap-3">
              <button type="button" className="btn-primary text-xs py-2 px-4 shadow-none">
                Botón Principal
              </button>
              <span className="badge-available">Etiqueta Disponible</span>
              <span className="text-sm font-bold" style={{ color: form.primary_color }}>
                {form.name}
              </span>
            </div>
          </div>
        </div>

        {error && <p className="text-rose-400 text-xs font-semibold">{error}</p>}
        {savedSuccess && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-900/60 rounded-xl text-emerald-400 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{savedSuccess}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={isSaving}
          className="btn-primary w-full py-3 text-sm"
        >
          {isSaving ? (
            <LoadingSpinner size="sm" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          <span>{isSaving ? 'Guardando cambios...' : 'Guardar Configuración Institucional'}</span>
        </button>
      </form>
    </div>
  )
}
