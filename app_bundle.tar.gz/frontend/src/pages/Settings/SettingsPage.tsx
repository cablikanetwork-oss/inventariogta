import { useState, useRef, useEffect } from 'react'
import {
  Save,
  Palette,
  Building2,
  CheckCircle2,
  Upload,
  Trash2,
  Link as LinkIcon,
  Sun,
  Moon,
  Cloud,
  FileSpreadsheet,
  Download,
  Copy,
  Check,
  Send,
  RefreshCw,
} from 'lucide-react'
import { companyApi } from '../../api/company'
import { backupApi, BackupStatusResponse } from '../../api/backup'
import { useThemeStore } from '../../store/themeStore'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

const PALETTE_PRESETS = [
  { label: 'Azul Tu Andamio', primary: '#0F70B7', secondary: '#0A4D80', accent: '#F59E0B' },
  { label: 'Azul Corporativo', primary: '#2563EB', secondary: '#1E40AF', accent: '#F59E0B' },
  { label: 'Verde Esmeralda', primary: '#059669', secondary: '#065F46', accent: '#F97316' },
  { label: 'Púrpura DeepTech', primary: '#7C3AED', secondary: '#5B21B6', accent: '#EC4899' },
  { label: 'Rojo Industrial', primary: '#DC2626', secondary: '#991B1B', accent: '#FBBF24' },
  { label: 'Gris Grafito', primary: '#475569', secondary: '#1E293B', accent: '#38BDF8' },
]

function buildGoogleAppsScriptCode(baseUrl: string, syncKey: string): string {
  const cleanUrl = baseUrl.replace(/\/+$/, '')
  return `/**
 * ============================================================================
 * CONECTOR AUTOMÁTICO: INVENTARIO GRUPO TU ANDAMIO -> GOOGLE SHEETS & DRIVE
 * ============================================================================
 * 1. Sincroniza en vivo las 4 pestañas de Google Sheets (Equipos, Almacenes,
 *    Movimientos y Actas de Entrega) con diseño corporativo Azul Tu Andamio.
 * 2. Guarda automáticamente copias completas de la base de datos (.JSON) en
 *    la carpeta "Respaldos_Inventario_GTA" de tu Google Drive.
 * 3. Mantiene despierto el servidor de Render (https://inventariogta.onrender.com).
 */

const GTA_API_URL = "${cleanUrl}/api/v1/backup/cloud?key=${syncKey}";
const DRIVE_FOLDER_NAME = "Respaldos_Inventario_GTA";
const MAX_BACKUPS_TO_KEEP = 30; // Conserva los últimos 30 respaldos en Drive

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("🏢 Inventario GTA")
    .addItem("🔄 Sincronizar Inventario Ahora", "sincronizarInventarioGTA")
    .addItem("💾 Guardar Respaldo en Google Drive Ahora", "sincronizarYGuardarEnDrive")
    .addSeparator()
    .addItem("⏰ Activar Respaldo Automático Diario + Keep-Alive", "instalarTriggersAutomaticos")
    .addToUi();
}

function sincronizarInventarioGTA() {
  ejecutarSincronizacionCompleta(false);
}

function sincronizarYGuardarEnDrive() {
  ejecutarSincronizacionCompleta(true);
}

function ejecutarSincronizacionCompleta(guardarArchivoEnDrive) {
  const response = UrlFetchApp.fetch(GTA_API_URL, {
    method: "get",
    muteHttpExceptions: true,
    headers: { "Accept": "application/json" }
  });

  if (response.getResponseCode() !== 200) {
    throw new Error("Error conectando con Inventario GTA (HTTP " + response.getResponseCode() + "): " + response.getContentText());
  }

  const payload = JSON.parse(response.getContentText());
  aplicarDatosASheets(payload);

  if (guardarArchivoEnDrive) {
    guardarSnapshotEnDrive(payload);
  }
}

// Permite recibir actualizaciones instantáneas (Push) desde el botón del sistema web
function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    aplicarDatosASheets(payload);
    const fileUrl = guardarSnapshotEnDrive(payload);
    return ContentService.createTextOutput(JSON.stringify({ status: "ok", drive_file: fileUrl }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function aplicarDatosASheets(payload) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheetsConfig = [
    { key: "equipos", tabName: "📦 Equipos (" + payload.summary.total_active_equipment + ")", color: "#0F70B7" },
    { key: "almacenes", tabName: "🏢 Almacenes", color: "#0A4D82" },
    { key: "movimientos", tabName: "🔄 Movimientos", color: "#0284C7" },
    { key: "actas", tabName: "📄 Actas de Entrega", color: "#059669" }
  ];

  sheetsConfig.forEach(function(cfg) {
    const dataObj = payload.sheets[cfg.key];
    if (!dataObj) return;

    // Buscar pestaña existente por prefijo o crearla
    let sheet = ss.getSheets().find(function(s) {
      return s.getName().indexOf(cfg.tabName.split(" (")[0]) === 0;
    });
    if (!sheet) {
      sheet = ss.insertSheet(cfg.tabName);
    } else {
      sheet.setName(cfg.tabName);
    }

    sheet.clear();
    sheet.setTabColor(cfg.color);

    // Fila 1: Banner Corporativo
    const totalCols = dataObj.headers.length;
    sheet.getRange(1, 1, 1, totalCols).merge()
      .setValue("GRUPO TU ANDAMIO — " + dataObj.title.toUpperCase() + "  |  Última Sincronización: " + new Date().toLocaleString())
      .setBackground("#0A4D82")
      .setFontColor("#FFFFFF")
      .setFontWeight("bold")
      .setFontSize(11)
      .setVerticalAlignment("middle");
    sheet.setRowHeight(1, 32);

    // Fila 2: Encabezados de tabla
    sheet.getRange(2, 1, 1, totalCols)
      .setValues([dataObj.headers])
      .setBackground(cfg.color)
      .setFontColor("#FFFFFF")
      .setFontWeight("bold")
      .setFontSize(10)
      .setVerticalAlignment("middle");
    sheet.setRowHeight(2, 26);

    // Filas de datos
    if (dataObj.rows && dataObj.rows.length > 0) {
      sheet.getRange(3, 1, dataObj.rows.length, totalCols)
        .setValues(dataObj.rows)
        .setFontSize(9.5)
        .setVerticalAlignment("middle");
    }

    sheet.setFrozenRows(2);
    for (let c = 1; c <= totalCols; c++) {
      sheet.autoResizeColumn(c);
    }
  });
}

function guardarSnapshotEnDrive(payload) {
  let folders = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
  let folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(DRIVE_FOLDER_NAME);

  const stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd_HH-mm");
  const fileName = "Backup_InventarioGTA_" + stamp + ".json";
  const jsonContent = JSON.stringify(payload.raw_database_snapshot, null, 2);
  const file = folder.createFile(fileName, jsonContent, MimeType.PLAIN_TEXT);

  // También actualiza siempre un archivo maestro 'ULTIMO_RESPALDO_ACTUAL.json'
  const latestFiles = folder.getFilesByName("ULTIMO_RESPALDO_ACTUAL.json");
  while (latestFiles.hasNext()) {
    latestFiles.next().setTrashed(true);
  }
  folder.createFile("ULTIMO_RESPALDO_ACTUAL.json", jsonContent, MimeType.PLAIN_TEXT);

  // Limpiar respaldos antiguos si superan MAX_BACKUPS_TO_KEEP
  const allFiles = [];
  const it = folder.getFiles();
  while (it.hasNext()) {
    const f = it.next();
    if (f.getName().indexOf("Backup_InventarioGTA_") === 0) {
      allFiles.push(f);
    }
  }
  allFiles.sort(function(a, b) { return b.getDateCreated() - a.getDateCreated(); });
  for (let i = MAX_BACKUPS_TO_KEEP; i < allFiles.length; i++) {
    allFiles[i].setTrashed(true);
  }

  return file.getUrl();
}

function instalarTriggersAutomaticos() {
  // Limpiar triggers previos para no duplicar
  ScriptApp.getProjectTriggers().forEach(function(t) {
    ScriptApp.deleteTrigger(t);
  });

  // 1. Actualizar Google Sheets cada 1 hora (y mantener despierto Render)
  ScriptApp.newTrigger("sincronizarInventarioGTA")
    .timeBased()
    .everyHours(1)
    .create();

  // 2. Guardar respaldo completo JSON en Google Drive todos los días
  ScriptApp.newTrigger("sincronizarYGuardarEnDrive")
    .timeBased()
    .everyDays(1)
    .atHour(18)
    .create();

  // Ejecutar primera sincronización y respaldo de inmediato
  sincronizarYGuardarEnDrive();

  SpreadsheetApp.getUi().alert(
    "✅ ¡Automatización Activada!\\n\\n" +
    "1. Tu Google Sheet se actualizará automáticamente cada hora.\\n" +
    "2. Se ha creado la carpeta '" + DRIVE_FOLDER_NAME + "' en tu Google Drive con el respaldo completo de la base de datos."
  );
}
`
}

export function SettingsPage() {
  const { config, applyTheme, visualMode, setVisualMode } = useThemeStore()
  const [form, setForm] = useState({
    name: config?.name ?? 'Grupo Tu Andamio',
    logo_url: config?.logo_url ?? '',
    primary_color: config?.primary_color ?? '#0F70B7',
    secondary_color: config?.secondary_color ?? '#0A4D80',
    accent_color: config?.accent_color ?? '#F59E0B',
  })

  const [isSaving, setIsSaving] = useState(false)
  const [isUploadingLogo, setIsUploadingLogo] = useState(false)
  const [savedSuccess, setSavedSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showUrlInput, setShowUrlInput] = useState(false)

  // Estado para Respaldo Cloud (Google Drive & Google Sheets)
  const [backupStatus, setBackupStatus] = useState<BackupStatusResponse | null>(null)
  const [webhookUrl, setWebhookUrl] = useState('')
  const [copiedCode, setCopiedCode] = useState(false)
  const [copiedUrl, setCopiedUrl] = useState(false)
  const [isDownloadingJson, setIsDownloadingJson] = useState(false)
  const [isPushingGoogle, setIsPushingGoogle] = useState(false)
  const [showScriptCode, setShowScriptCode] = useState(false)
  const [backupMsg, setBackupMsg] = useState<string | null>(null)

  const fileInputRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    backupApi
      .getStatus()
      .then((st) => {
        setBackupStatus(st)
        setWebhookUrl(st.webhook_url || '')
      })
      .catch(() => {})
  }, [])

  const publicOrigin =
    window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
      ? 'https://inventariogta.onrender.com'
      : window.location.origin

  const syncKey = backupStatus?.sync_key ?? 'GTA-CLOUD-SYNC-2026'
  const fullCloudFeedUrl = `${publicOrigin}/api/v1/backup/cloud?key=${syncKey}`
  const appsScriptCode = buildGoogleAppsScriptCode(publicOrigin, syncKey)

  const handleCopyScript = async () => {
    await navigator.clipboard.writeText(appsScriptCode)
    setCopiedCode(true)
    setTimeout(() => setCopiedCode(false), 3500)
  }

  const handleCopyFeedUrl = async () => {
    await navigator.clipboard.writeText(fullCloudFeedUrl)
    setCopiedUrl(true)
    setTimeout(() => setCopiedUrl(false), 3000)
  }

  const handleDownloadBackup = async () => {
    setIsDownloadingJson(true)
    try {
      await backupApi.downloadJsonBackup()
      setBackupMsg('Respaldo completo JSON descargado en tu equipo.')
      setTimeout(() => setBackupMsg(null), 4000)
    } catch {
      setError('No se pudo descargar el respaldo JSON.')
    } finally {
      setIsDownloadingJson(false)
    }
  }

  const handleSaveAndPushGoogle = async () => {
    setIsPushingGoogle(true)
    setBackupMsg(null)
    setError(null)
    try {
      await backupApi.saveWebhookConfig(webhookUrl.trim())
      if (webhookUrl.trim()) {
        const res = await backupApi.pushToGoogleNow()
        setBackupMsg(res.message)
      } else {
        setBackupMsg('Configuración de Webhook guardada.')
      }
      setTimeout(() => setBackupMsg(null), 5000)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al sincronizar con Google Apps Script')
    } finally {
      setIsPushingGoogle(false)
    }
  }

  const handleApplyPreset = (p: (typeof PALETTE_PRESETS)[0]) => {
    setForm((f) => ({
      ...f,
      primary_color: p.primary,
      secondary_color: p.secondary,
      accent_color: p.accent,
    }))
    document.documentElement.style.setProperty('--color-primary', p.primary)
    document.documentElement.style.setProperty('--color-secondary', p.secondary)
    document.documentElement.style.setProperty('--color-accent', p.accent)
  }

  const handleColorInput = (key: 'primary_color' | 'secondary_color' | 'accent_color', val: string) => {
    setForm((f) => ({ ...f, [key]: val }))
    const cssVar = key.replace('_color', '')
    document.documentElement.style.setProperty(`--color-${cssVar}`, val)
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploadingLogo(true)
    setError(null)
    setSavedSuccess(null)

    try {
      const updatedConfig = await companyApi.uploadLogo(file)
      applyTheme(updatedConfig)
      setForm((f) => ({ ...f, logo_url: updatedConfig.logo_url ?? '' }))
      setSavedSuccess('Logotipo subido y guardado permanentemente')
      setTimeout(() => setSavedSuccess(null), 3500)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al subir la imagen del logotipo')
    } finally {
      setIsUploadingLogo(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  const handleDeleteLogo = async () => {
    if (!window.confirm('¿Deseas eliminar el logotipo y volver al isotipo predeterminado?')) return

    setIsUploadingLogo(true)
    setError(null)
    setSavedSuccess(null)

    try {
      const updatedConfig = await companyApi.deleteLogo()
      applyTheme(updatedConfig)
      setForm((f) => ({ ...f, logo_url: '' }))
      setSavedSuccess('Logotipo eliminado. Usando isotipo institucional')
      setTimeout(() => setSavedSuccess(null), 3500)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al eliminar el logotipo')
    } finally {
      setIsUploadingLogo(false)
    }
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)
    setError(null)
    setSavedSuccess(null)
    try {
      const updated = await companyApi.updateConfig({
        name: form.name.trim(),
        logo_url: form.logo_url?.trim() || undefined,
        primary_color: form.primary_color,
        secondary_color: form.secondary_color,
        accent_color: form.accent_color,
      })
      applyTheme(updated)
      setSavedSuccess('Configuración institucional guardada correctamente')
      setTimeout(() => setSavedSuccess(null), 3500)
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? 'Error al guardar configuración de marca')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-3xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Configuración y Respaldo en la Nube</h1>
        <p className="text-slate-400 text-xs sm:text-sm">
          Personaliza la identidad de Grupo Tu Andamio y sincroniza tu base de datos en vivo con Google Sheets y Google Drive
        </p>
      </div>

      {/* ────────────────────────────────────────────────────────────────────────
          MÓDULO DE RESPALDO AUTOMÁTICO EN GOOGLE DRIVE & GOOGLE SHEETS EN VIVO
         ──────────────────────────────────────────────────────────────────────── */}
      <div className="card p-5 space-y-4 border-2 border-primary/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
              <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Respaldo Automático en Google Drive y Google Sheets en Vivo</span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Visualiza tus {backupStatus?.summary.total_active_equipment ?? 137} equipos, almacenes, movimientos y actas en Google Sheets y guarda copias diarias en Drive
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDownloadBackup}
            disabled={isDownloadingJson}
            className="py-2 px-3.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 flex items-center gap-2 self-start sm:self-auto transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>{isDownloadingJson ? 'Descargando...' : 'Descargar Respaldo JSON'}</span>
          </button>
        </div>

        {/* Pasos rápidos 1-2-3 para Google Sheets & Drive */}
        <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
              <Cloud className="w-4 h-4" />
              <span>Conectar con tu cuenta de Google en 3 pasos (100% Gratis):</span>
            </span>
            <button
              type="button"
              onClick={() => setShowScriptCode(!showScriptCode)}
              className="text-[11px] font-semibold text-primary hover:underline"
            >
              {showScriptCode ? 'Ocultar código del conector' : 'Ver código del conector'}
            </button>
          </div>

          <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside leading-relaxed">
            <li>
              Abre una hoja nueva en Google Sheets escribiendo{' '}
              <a
                href="https://sheets.new"
                target="_blank"
                rel="noreferrer"
                className="text-sky-400 font-bold underline hover:text-sky-300"
              >
                sheets.new
              </a>{' '}
              en tu navegador y ponle de título <strong>Inventario Grupo Tu Andamio</strong>.
            </li>
            <li>
              En el menú superior de Google Sheets entra en <strong>Extensiones ➔ Apps Script</strong>, borra el texto que sale,
              haz clic en el botón de abajo <strong>"Copiar Código Conector Google"</strong>, pégalo ahí y presiona el ícono de{' '}
              <strong>Guardar (💾)</strong>.
            </li>
            <li>
              Selecciona arriba la función <code>instalarTriggersAutomaticos</code> y dale al botón <strong>▷ Ejecutar</strong>{' '}
              (acepta el permiso de tu cuenta). ¡Listo! Se crearán las 4 pestañas con todos tus equipos en vivo y la carpeta{' '}
              <strong>Respaldos_Inventario_GTA</strong> en tu Google Drive.
            </li>
          </ol>

          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            <button
              type="button"
              onClick={handleCopyScript}
              className="btn-primary py-2.5 px-4 text-xs shadow-none flex items-center gap-2"
            >
              {copiedCode ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>
                {copiedCode
                  ? '¡Código Copiado! Pégalo en Extensiones -> Apps Script'
                  : 'Copiar Código Conector Google Sheets + Drive'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleCopyFeedUrl}
              className="py-2.5 px-3.5 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <LinkIcon className="w-3.5 h-3.5 text-sky-400" />}
              <span>{copiedUrl ? 'Enlace API Copiado' : 'Copiar URL del Feed Cloud'}</span>
            </button>
          </div>

          {showScriptCode && (
            <div className="mt-2">
              <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 font-mono overflow-x-auto max-h-64">
                {appsScriptCode}
              </pre>
            </div>
          )}
        </div>

        {/* Opción Push Instantáneo hacia Google Web App */}
        <div className="pt-2 border-t border-slate-800/80 space-y-2">
          <label className="label text-[11px]">
            URL de Web App de Google Apps Script (Opcional — para empujar cambios al instante desde aquí):
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="url"
              className="input-field text-xs py-2 flex-1"
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              placeholder="https://script.google.com/macros/s/.../exec"
            />
            <button
              type="button"
              disabled={isPushingGoogle}
              onClick={handleSaveAndPushGoogle}
              className="py-2 px-4 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center gap-1.5 transition-colors flex-shrink-0"
            >
              {isPushingGoogle ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>{webhookUrl.trim() ? 'Guardar y Sincronizar con Google Ahora' : 'Guardar Webhook'}</span>
            </button>
          </div>
        </div>

        {backupMsg && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-900/60 rounded-xl text-emerald-400 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{backupMsg}</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-5">
        {/* Identidad Institucional */}
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Building2 className="w-4 h-4 text-primary" />
            <span>Identidad Institucional</span>
          </h2>

          <div>
            <label className="label">Nombre de la Empresa / Cliente *</label>
            <input
              className="input-field text-sm"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="Ej. Grupo Tu Andamio"
              required
            />
          </div>

          {/* Subida de Logotipo PNG/JPG/SVG */}
          <div className="space-y-2">
            <label className="label">Logotipo de la Empresa (PNG, JPG, SVG, WEBP)</label>

            <input
              ref={fileInputRef}
              type="file"
              accept=".png,.jpg,.jpeg,.webp,.svg,image/png,image/jpeg,image/webp,image/svg+xml"
              className="hidden"
              onChange={handleFileChange}
            />

            <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-24 h-24 rounded-2xl bg-slate-900 border border-slate-700/80 p-2 flex items-center justify-center flex-shrink-0 shadow-inner overflow-hidden">
                  {form.logo_url ? (
                    <img
                      src={form.logo_url}
                      alt="Logo Empresa"
                      className="max-w-full max-h-full object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none'
                      }}
                    />
                  ) : (
                    <div
                      className="w-16 h-16 rounded-xl flex items-center justify-center text-white font-black text-2xl shadow-md"
                      style={{ background: 'var(--color-primary)' }}
                    >
                      {form.name ? form.name.charAt(0).toUpperCase() : 'E'}
                    </div>
                  )}
                </div>

                <div className="flex-1 text-center sm:text-left space-y-2">
                  <p className="text-white text-xs font-semibold">
                    {form.logo_url ? 'Logotipo activo para esta empresa' : 'Sin imagen personalizada (usando isotipo dinámico)'}
                  </p>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Sube tu imagen PNG con fondo transparente para un acabado profesional en la barra lateral y pantalla de login.
                  </p>

                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                    <button
                      type="button"
                      disabled={isUploadingLogo}
                      onClick={() => fileInputRef.current?.click()}
                      className="btn-primary py-2 px-3.5 text-xs shadow-none"
                    >
                      {isUploadingLogo ? (
                        <>
                          <LoadingSpinner size="sm" />
                          <span>Subiendo...</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-3.5 h-3.5" />
                          <span>Subir Imagen PNG / JPG</span>
                        </>
                      )}
                    </button>

                    {form.logo_url && (
                      <button
                        type="button"
                        disabled={isUploadingLogo}
                        onClick={handleDeleteLogo}
                        className="py-2 px-3 text-xs font-semibold rounded-xl text-rose-400 bg-rose-950/30 hover:bg-rose-950/60 border border-rose-900/50 transition-colors flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Quitar imagen</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => setShowUrlInput(!showUrlInput)}
                  className="text-[11px] text-slate-400 hover:text-primary transition-colors flex items-center gap-1 font-medium"
                >
                  <LinkIcon className="w-3 h-3" />
                  <span>{showUrlInput ? 'Ocultar opción de URL externa' : 'O vincular mediante URL externa...'}</span>
                </button>

                {showUrlInput && (
                  <div className="mt-2 space-y-1">
                    <input
                      className="input-field text-xs py-2"
                      value={form.logo_url}
                      onChange={(e) => setForm((f) => ({ ...f, logo_url: e.target.value }))}
                      placeholder="https://ejemplo.com/logotipo.png"
                    />
                    <p className="text-[10px] text-slate-500">
                      Ruta actual guardada en base de datos: <code className="text-slate-400 font-mono">{form.logo_url || '(ninguna)'}</code>
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Selector de Modo Visual (Tema Claro Azul/Blanco vs. Modo Oscuro) */}
        <div className="card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              {visualMode === 'light' ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-primary" />
              )}
              <span>Modo Visual de la Interfaz (Fondo y Contraste)</span>
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-primary/15 text-primary border border-primary/30">
              {visualMode === 'light' ? 'Modo Claro Activo' : 'Modo Oscuro Activo'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                setVisualMode('light')
                handleApplyPreset(PALETTE_PRESETS[0])
              }}
              className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-start gap-3 ${
                visualMode === 'light'
                  ? 'border-primary bg-primary/10 shadow-md'
                  : 'border-slate-800 hover:border-slate-600 bg-slate-950/60'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-white border border-blue-200 flex items-center justify-center flex-shrink-0 shadow-xs">
                <Sun className="w-5 h-5 text-[#0F70B7]" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-white flex items-center gap-1.5">
                  <span>Corporativo Claro (Azul y Blanco)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  Fondo blanco y azul hielo con textos en azul marino y negro. Ideal para proyectores y expo.
                </p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setVisualMode('dark')}
              className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-start gap-3 ${
                visualMode === 'dark'
                  ? 'border-primary bg-primary/10 shadow-md'
                  : 'border-slate-800 hover:border-slate-600 bg-slate-950/60'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center flex-shrink-0 shadow-xs">
                <Moon className="w-5 h-5 text-sky-400" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-xs text-white flex items-center gap-1.5">
                  <span>Modo Oscuro Técnico (Dark Mode)</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  Fondo oscuro pizarra con contraste alto para operaciones nocturnas o de almacén.
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Paleta de Colores */}
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Palette className="w-4 h-4 text-primary" />
            <span>Paleta de Colores Dinámica</span>
          </h2>

          <div>
            <span className="label mb-2">Temas Rápidos Predeterminados</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PALETTE_PRESETS.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-800 hover:border-slate-600 bg-slate-950/60 transition-colors text-left"
                >
                  <div className="flex -space-x-1">
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-900" style={{ background: p.primary }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-900" style={{ background: p.secondary }} />
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-900" style={{ background: p.accent }} />
                  </div>
                  <span className="text-xs text-slate-300 font-medium truncate">{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div>
              <label className="label">Color Primario</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.primary_color}
                  onChange={(e) => handleColorInput('primary_color', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-800 bg-transparent cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={form.primary_color}
                  onChange={(e) => handleColorInput('primary_color', e.target.value)}
                  className="input-field font-mono text-xs py-2"
                  maxLength={7}
                />
              </div>
            </div>

            <div>
              <label className="label">Color Secundario</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.secondary_color}
                  onChange={(e) => handleColorInput('secondary_color', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-800 bg-transparent cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={form.secondary_color}
                  onChange={(e) => handleColorInput('secondary_color', e.target.value)}
                  className="input-field font-mono text-xs py-2"
                  maxLength={7}
                />
              </div>
            </div>

            <div>
              <label className="label">Color de Acento</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.accent_color}
                  onChange={(e) => handleColorInput('accent_color', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-slate-800 bg-transparent cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={form.accent_color}
                  onChange={(e) => handleColorInput('accent_color', e.target.value)}
                  className="input-field font-mono text-xs py-2"
                  maxLength={7}
                />
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/80 space-y-2 mt-2">
            <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
              Previsualización de Componentes
            </span>
            <div className="flex flex-wrap items-center gap-3">
              <button type="button" className="btn-primary text-xs py-2 px-4 shadow-none">
                Botón Principal
              </button>
              <span className="badge-available">Etiqueta Disponible</span>
              <span className="text-sm font-bold" style={{ color: form.primary_color }}>
                {form.name}
              </span>
            </div>
          </div>
        </div>

        {error && <p className="text-rose-400 text-xs font-semibold">{error}</p>}
        {savedSuccess && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-900/60 rounded-xl text-emerald-400 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{savedSuccess}</span>
          </div>
        )}

        <button type="submit" disabled={isSaving} className="btn-primary w-full py-3 text-sm">
          {isSaving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
          <span>{isSaving ? 'Guardando cambios...' : 'Guardar Configuración Institucional'}</span>
        </button>
      </form>
    </div>
  )
}
