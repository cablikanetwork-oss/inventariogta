import { useState, useEffect } from 'react'
import { Package, Warehouse, ArrowLeftRight, CheckCircle2, AlertCircle, Laptop, QrCode } from 'lucide-react'
import { equipmentApi } from '../../api/equipment'
import { warehousesApi, type Warehouse as WarehouseType } from '../../api/warehouses'
import { movementsApi, type Movement } from '../../api/movements'
import { MovementTypeBadge } from '../../components/ui/MovementTypeBadge'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'
import { Link } from 'react-router-dom'

interface Stats {
  total: number
  available: number
  assigned: number
  maintenance: number
}

export function DashboardPage() {
  const [stats, setStats] = useState<Stats>({ total: 0, available: 0, assigned: 0, maintenance: 0 })
  const [warehouses, setWarehouses] = useState<WarehouseType[]>([])
  const [recentMovements, setRecentMovements] = useState<Movement[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [allEq, availableEq, assignedEq, maintEq, whs, mvts] = await Promise.all([
          equipmentApi.list(),
          equipmentApi.list({ status: 'available' }),
          equipmentApi.list({ status: 'assigned' }),
          equipmentApi.list({ status: 'maintenance' }),
          warehousesApi.list(),
          movementsApi.list({ limit: 8 }),
        ])
        setStats({
          total: allEq.length,
          available: availableEq.length,
          assigned: assignedEq.length,
          maintenance: maintEq.length,
        })
        setWarehouses(whs)
        setRecentMovements(mvts)
      } catch (err) {
        console.error('Error cargando métricas:', err)
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-3">
        <LoadingSpinner size="lg" />
        <p className="text-slate-400 text-sm">Cargando inventario general...</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Saludo y Acción Rápida */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Panel de Control</h1>
          <p className="text-slate-400 text-sm">Estado consolidado de equipos y almacenes</p>
        </div>
        <Link
          to="/equipment"
          className="btn-primary self-start sm:self-auto py-2.5 px-4 text-sm"
        >
          <QrCode className="w-4 h-4" />
          <span>Escanear Equipo</span>
        </Link>
      </div>

      {/* Tarjetas de Métricas Clave */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <div className="card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Equipos</span>
            <Laptop className="w-4 h-4 text-primary" />
          </div>
          <p className="text-3xl font-black text-white">{stats.total}</p>
          <span className="text-[11px] text-slate-500 mt-1">Activos registrados</span>
        </div>

        <div className="card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Disponibles</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-black text-emerald-400">{stats.available}</p>
          <span className="text-[11px] text-slate-500 mt-1">Listos en almacén</span>
        </div>

        <div className="card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-blue-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Asignados</span>
            <ArrowLeftRight className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-3xl font-black text-blue-400">{stats.assigned}</p>
          <span className="text-[11px] text-slate-500 mt-1">En personal o proyectos</span>
        </div>

        <div className="card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">En Mantenimiento</span>
            <AlertCircle className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-3xl font-black text-amber-400">{stats.maintenance}</p>
          <span className="text-[11px] text-slate-500 mt-1">En soporte técnico</span>
        </div>
      </div>

      {/* Distribución por Almacenes */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Warehouse className="w-4 h-4 text-primary" />
            <span>Almacenes Activos</span>
          </h2>
          <Link to="/warehouses" className="text-xs text-primary hover:underline font-semibold">
            Ver todos ({warehouses.length})
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {warehouses.map((wh) => (
            <div key={wh.id} className="card p-4 hover:border-slate-700 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  {wh.parent_name && (
                    <span className="text-[10px] font-bold text-primary block truncate">↳ {wh.parent_name}</span>
                  )}
                  <h3 className="font-bold text-white text-sm truncate">{wh.name}</h3>
                  <p className="text-slate-400 text-xs mt-0.5">{wh.location || 'Sin ubicación específica'}</p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-white">{wh.total_equipment_count ?? wh.equipment_count}</span>
                  <p className="text-[10px] text-slate-500 uppercase font-semibold">
                    {wh.sub_warehouses_count ? 'Total' : 'Equipos'}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Auditoría de Movimientos Recientes */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-primary" />
            <span>Últimos Movimientos de Almacén</span>
          </h2>
          <Link to="/movements" className="text-xs text-primary hover:underline font-semibold">
            Historial completo
          </Link>
        </div>

        <div className="card overflow-hidden">
          {recentMovements.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-sm">
              <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p>Aún no se han registrado movimientos de entrada o salida.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              {recentMovements.map((m) => (
                <div key={m.id} className="p-3.5 flex items-center justify-between gap-3 text-sm">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-white truncate">
                        {m.equipment?.name || 'Equipo'}
                      </span>
                      <span className="text-xs text-slate-500 font-mono">
                        [{m.equipment?.serial_number}]
                      </span>
                      <MovementTypeBadge type={m.type} />
                    </div>
                    <div className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                      {m.from_warehouse && <span>Origen: {m.from_warehouse.name}</span>}
                      {m.to_warehouse && <span>Destino: {m.to_warehouse.name}</span>}
                      {m.assigned_to && <span>Asignado a: {m.assigned_to}</span>}
                      <span>• Por: {m.performed_by_user?.full_name || 'Usuario'}</span>
                    </div>
                  </div>
                  <span className="text-xs text-slate-500 flex-shrink-0">
                    {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

