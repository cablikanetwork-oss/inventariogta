import { useState, useEffect } from 'react'
import { ArrowLeftRight, Clock, User, Warehouse } from 'lucide-react'
import { movementsApi, type Movement } from '../../api/movements'
import { MovementTypeBadge } from '../../components/ui/MovementTypeBadge'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

export function MovementsPage() {
  const [movements, setMovements] = useState<Movement[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    movementsApi
      .list({ limit: 100 })
      .then(setMovements)
      .finally(() => setIsLoading(false))
  }, [])

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Registro de Movimientos</h1>
        <p className="text-slate-400 text-xs sm:text-sm">
          Trazabilidad y auditoría de entradas, salidas y transferencias entre almacenes
        </p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20">
          <LoadingSpinner size="lg" />
        </div>
      ) : movements.length === 0 ? (
        <div className="card p-12 text-center text-slate-500">
          <ArrowLeftRight className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="font-semibold text-white">No se han registrado movimientos</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="divide-y divide-slate-800">
            {movements.map((m) => (
              <div key={m.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-white text-sm truncate">
                      {m.equipment?.name || 'Equipo'}
                    </span>
                    <span className="font-mono text-xs text-slate-400">
                      [{m.equipment?.serial_number}]
                    </span>
                    <MovementTypeBadge type={m.type} />
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-400 flex-wrap">
                    {m.from_warehouse && (
                      <span className="flex items-center gap-1">
                        <Warehouse className="w-3 h-3 text-slate-500" />
                        De: <span className="text-slate-300 font-medium">{m.from_warehouse.name}</span>
                      </span>
                    )}
                    {m.to_warehouse && (
                      <span className="flex items-center gap-1">
                        → A: <span className="text-slate-300 font-medium">{m.to_warehouse.name}</span>
                      </span>
                    )}
                    {m.assigned_to && (
                      <span>Asignado a: <strong className="text-white">{m.assigned_to}</strong></span>
                    )}
                  </div>

                  {m.notes && (
                    <p className="text-xs text-slate-500 italic bg-slate-950/40 p-2 rounded-lg border border-slate-800/80">
                      “{m.notes}”
                    </p>
                  )}
                </div>

                <div className="flex sm:flex-col items-center sm:items-end justify-between text-xs text-slate-500 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800/60">
                  <span className="flex items-center gap-1 font-medium text-slate-300">
                    <User className="w-3.5 h-3.5 text-primary" />
                    {m.performed_by_user?.full_name || 'Operador'}
                  </span>
                  <span className="flex items-center gap-1 mt-0.5 font-mono text-[11px]">
                    <Clock className="w-3 h-3 text-slate-600" />
                    {new Date(m.created_at).toLocaleString('es', {
                      dateStyle: 'short',
                      timeStyle: 'short',
                    })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

