import { useState, useEffect, useCallback } from 'react'
import {
  Tag,
  Download,
  Search,
  CheckSquare,
  Square,
  Printer,
  QrCode,
  Warehouse as WarehouseIcon,
  Filter,
  Eye,
  FileDown,
  Info,
  Sparkles
} from 'lucide-react'
import { equipmentApi, type Equipment } from '../../api/equipment'
import { warehousesApi, type Warehouse } from '../../api/warehouses'
import { LoadingSpinner } from '../../components/ui/LoadingSpinner'

export function LabelsPage() {
  const [equipmentList, setEquipmentList] = useState<Equipment[]>([])
  const [warehouses, setWarehouses] = useState<Warehouse[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Filtros
  const [search, setSearch] = useState('')
  const [selectedWarehouse, setSelectedWarehouse] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')

  // Selección
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [previewEquipment, setPreviewEquipment] = useState<Equipment | null>(null)
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)
  const [encodeDirectUrl, setEncodeDirectUrl] = useState(true)
  const activeBaseUrl = encodeDirectUrl ? window.location.origin : undefined

  const loadData = useCallback(async () => {
    setIsLoading(true)
    try {
      const [items, whs] = await Promise.all([
        equipmentApi.list({
          search: search || undefined,
          warehouse_id: selectedWarehouse || undefined,
          category: selectedCategory === 'all' ? undefined : selectedCategory || undefined,
        }),
        warehousesApi.list(),
      ])
      setEquipmentList(items)
      setWarehouses(whs)
      if (items.length > 0 && !previewEquipment) {
        setPreviewEquipment(items[0])
      }
    } catch (err) {
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }, [search, selectedWarehouse, selectedCategory, previewEquipment])

  useEffect(() => {
    loadData()
  }, [loadData])

  // Manejo de Selección
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const selectAll = () => {
    if (selectedIds.size === equipmentList.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(equipmentList.map((e) => e.id)))
    }
  }

  // Descargar plancha PDF de seleccionados
  const handleDownloadSheet = async () => {
    if (selectedIds.size === 0) return
    setIsGeneratingPdf(true)
    try {
      await equipmentApi.downloadLabelsPdf(Array.from(selectedIds), activeBaseUrl)
    } catch (err: any) {
      alert(err?.response?.data?.detail || 'Error al generar plancha de etiquetas en PDF')
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Descargar imagen individual
  const handleDownloadIndividualLabel = async (eq: Equipment) => {
    try {
      const blob = await equipmentApi.generateQrLabel(eq.id, activeBaseUrl)
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `etiqueta_${eq.serial_number}.png`
      document.body.appendChild(a)
      a.click()
      a.remove()
      window.URL.revokeObjectURL(url)
    } catch {
      alert('Error al descargar la etiqueta individual')
    }
  }

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <Tag className="w-6 h-6 text-primary" />
            <span>Etiquetado Físico y Código QR</span>
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm">
            Genera e imprime etiquetas autoadhesivas oficiales con código QR escaneable para tus activos físicos
          </p>
        </div>

        {/* Acciones principales */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadSheet}
            disabled={selectedIds.size === 0 || isGeneratingPdf}
            className="btn-primary py-2.5 px-4 text-xs font-bold flex items-center gap-2 shadow-lg disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>
              {isGeneratingPdf
                ? 'Generando PDF...'
                : `Descargar Plancha PDF (${selectedIds.size} seleccionados)`}
            </span>
          </button>
        </div>
      </div>

      {/* Grid: Filtros + Lista a la izquierda / Preview a la derecha */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Columna Izquierda: Filtros y Tabla (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Barra de Filtros */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
              <div className="sm:col-span-6 relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Buscar por serial, modelo o nombre..."
                  className="input-field pl-9 text-xs py-2"
                />
              </div>

              <div className="sm:col-span-3">
                <select
                  value={selectedWarehouse}
                  onChange={(e) => setSelectedWarehouse(e.target.value)}
                  className="input-field py-2 text-xs w-full bg-slate-950"
                >
                  <option value="">Todos los almacenes</option>
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-3">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="input-field py-2 text-xs w-full bg-slate-950"
                >
                  <option value="">Todas las categorías</option>
                  <option value="laptop">Laptops</option>
                  <option value="desktop">Desktop</option>
                  <option value="monitor">Monitores</option>
                  <option value="switch">Switches</option>
                  <option value="router">Routers</option>
                  <option value="server">Servidores</option>
                  <option value="other">Otros</option>
                </select>
              </div>
            </div>

            {/* Barra de selección rápida */}
            <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
              <button
                onClick={selectAll}
                className="hover:text-white flex items-center gap-1.5 font-medium transition-colors"
              >
                {selectedIds.size === equipmentList.length && equipmentList.length > 0 ? (
                  <>
                    <CheckSquare className="w-4 h-4 text-primary" />
                    <span>Deseleccionar todos</span>
                  </>
                ) : (
                  <>
                    <Square className="w-4 h-4" />
                    <span>Seleccionar todos ({equipmentList.length})</span>
                  </>
                )}
              </button>

              <span className="font-semibold text-primary">
                {selectedIds.size} de {equipmentList.length} seleccionados para imprimir
              </span>
            </div>
          </div>

          {/* Tabla de Equipos */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
            {isLoading ? (
              <div className="p-8 flex justify-center">
                <LoadingSpinner size="md" />
              </div>
            ) : equipmentList.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No se encontraron equipos que coincidan con la búsqueda.
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[520px]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-950/80 sticky top-0 border-b border-slate-800 text-slate-400">
                    <tr>
                      <th className="py-2.5 px-3 w-10 text-center">Sel.</th>
                      <th className="py-2.5 px-3">Serial</th>
                      <th className="py-2.5 px-3">Equipo</th>
                      <th className="py-2.5 px-3">Categoría</th>
                      <th className="py-2.5 px-3">Almacén</th>
                      <th className="py-2.5 px-3 text-right">Ver</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {equipmentList.map((eq) => {
                      const isSelected = selectedIds.has(eq.id)
                      const isPreview = previewEquipment?.id === eq.id
                      return (
                        <tr
                          key={eq.id}
                          onClick={() => setPreviewEquipment(eq)}
                          className={`cursor-pointer transition-colors ${isPreview
                              ? 'bg-primary/10'
                              : isSelected
                                ? 'bg-slate-800/40'
                                : 'hover:bg-slate-800/20'
                            }`}
                        >
                          <td
                            className="py-2.5 px-3 text-center"
                            onClick={(e) => {
                              e.stopPropagation()
                              toggleSelect(eq.id)
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSelect(eq.id)}
                              className="rounded border-slate-700 bg-slate-900 text-primary cursor-pointer w-4 h-4"
                            />
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-white select-all">
                            {eq.serial_number}
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="font-semibold text-slate-200 leading-tight">{eq.name}</div>
                            <div className="text-[10px] text-slate-400">
                              {[eq.brand, eq.model].filter(Boolean).join(' ') || '—'}
                            </div>
                          </td>
                          <td className="py-2.5 px-3 uppercase text-[10px] text-slate-400">
                            {eq.category}
                          </td>
                          <td className="py-2.5 px-3 text-slate-300">
                            {eq.current_warehouse?.name || '—'}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                setPreviewEquipment(eq)
                              }}
                              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                              title="Previsualizar etiqueta individual"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Columna Derecha: Previsualización Individual e Instrucciones (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {previewEquipment ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-primary" />
                  <span>Vista Previa de Etiqueta</span>
                </h3>
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                  300 DPI
                </span>
              </div>

              {/* Selector de Modo de Codificación QR (URL Directa Universal vs Serial Puro) */}
              <label className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 cursor-pointer">
                <div className="text-[11px]">
                  <span className="font-bold text-slate-200 block">
                    QR Inteligente con URL Directa
                  </span>
                  <span className="text-slate-400 text-[10px]">
                    Abre la Ficha HUD al escanear con cualquier celular
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={encodeDirectUrl}
                  onChange={(e) => setEncodeDirectUrl(e.target.checked)}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
              </label>

              {/* Imagen generada dinámicamente por el endpoint /qr-label */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex justify-center">
                <img
                  src={`/api/v1/equipment/${previewEquipment.id}/qr-label${
                    activeBaseUrl ? `?base_url=${encodeURIComponent(activeBaseUrl)}` : ''
                  }`}
                  alt={`Etiqueta QR ${previewEquipment.serial_number}`}
                  className="w-56 h-auto object-contain rounded shadow-lg bg-white"
                />
              </div>

              <div className="space-y-1 text-xs">
                <div className="font-bold text-white text-sm">{previewEquipment.name}</div>
                <div className="text-slate-400 font-mono text-[11px]">S/N: {previewEquipment.serial_number}</div>
                <div className="text-slate-400 text-[11px]">
                  Ubicación: <strong className="text-slate-200">{previewEquipment.current_warehouse?.name || 'Sin asignar'}</strong>
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => handleDownloadIndividualLabel(previewEquipment)}
                  className="btn-secondary flex-1 py-2 text-xs flex items-center justify-center gap-1.5"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Guardar PNG</span>
                </button>
                <button
                  onClick={() => {
                    const url = `/api/v1/equipment/${previewEquipment.id}/qr-label${
                      activeBaseUrl ? `?base_url=${encodeURIComponent(activeBaseUrl)}` : ''
                    }`
                    const win = window.open(url, '_blank')
                    win?.focus()
                  }}
                  className="btn-primary flex-1 py-2 text-xs flex items-center justify-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Abrir / Imprimir</span>
                </button>
              </div>

              <button
                onClick={() => window.open(`/eq/${previewEquipment.serial_number}`, '_blank')}
                className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700 transition-colors shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5 text-primary" />
                <span>Simular Escaneo / Ver Ficha HUD</span>
              </button>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-500 text-xs shadow-xl">
              Selecciona un equipo de la tabla para ver su etiqueta QR en alta resolución.
            </div>
          )}

          {/* Caja Informativa de Especificaciones de Impresión */}
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 text-xs space-y-2 text-slate-400 shadow-lg">
            <div className="flex items-center gap-2 text-slate-300 font-semibold">
              <Info className="w-4 h-4 text-primary" />
              <span>Instrucciones de Impresión</span>
            </div>
            <ul className="list-disc pl-4 space-y-1 text-[11px] leading-relaxed">
              <li>
                <strong>Formato de la plancha:</strong> Tamaño Carta (Letter) con 10 etiquetas por hoja (2 columnas x 5 filas).
              </li>
              <li>
                <strong>Papel recomendado:</strong> Papel autoadhesivo troquelado estándar (tipo Avery o similar para láser o inyección).
              </li>
              <li>
                <strong>Escaneo:</strong> Compatible con la cámara de cualquier teléfono celular y lectores ópticos 2D/QR.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

