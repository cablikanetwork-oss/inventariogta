import { create } from 'zustand'
import type { CompanyConfig } from '../api/company'

export type VisualMode = 'dark' | 'light'

interface ThemeState {
  config: CompanyConfig | null
  isLoaded: boolean
  visualMode: VisualMode
  setConfig: (config: CompanyConfig) => void
  applyTheme: (config: CompanyConfig) => void
  setVisualMode: (mode: VisualMode) => void
  toggleVisualMode: () => void
}

function applyVisualModeToDom(mode: VisualMode) {
  const root = document.documentElement
  if (mode === 'light') {
    root.classList.add('theme-light')
  } else {
    root.classList.remove('theme-light')
  }
}

const initialVisualMode: VisualMode =
  (typeof window !== 'undefined' &&
    (localStorage.getItem('inventory_visual_mode') as VisualMode)) ||
  'dark'

if (typeof window !== 'undefined') {
  applyVisualModeToDom(initialVisualMode)
}

export const useThemeStore = create<ThemeState>()((set, get) => ({
  config: null,
  isLoaded: false,
  visualMode: initialVisualMode,
  setConfig: (config) => {
    set({ config, isLoaded: true })
  },
  setVisualMode: (mode) => {
    localStorage.setItem('inventory_visual_mode', mode)
    applyVisualModeToDom(mode)
    set({ visualMode: mode })
  },
  toggleVisualMode: () => {
    const next: VisualMode = get().visualMode === 'dark' ? 'light' : 'dark'
    localStorage.setItem('inventory_visual_mode', next)
    applyVisualModeToDom(next)
    set({ visualMode: next })
  },
  applyTheme: (config) => {
    const root = document.documentElement
    if (config.primary_color) {
      root.style.setProperty('--color-primary', config.primary_color)
    }
    if (config.secondary_color) {
      root.style.setProperty('--color-secondary', config.secondary_color)
    }
    if (config.accent_color) {
      root.style.setProperty('--color-accent', config.accent_color)
    }
    // Actualizar meta theme-color para Android/PWA
    const metaTheme = document.querySelector('meta[name="theme-color"]')
    if (metaTheme && config.primary_color) {
      metaTheme.setAttribute('content', config.primary_color)
    }
    // Actualizar título de la pestaña/PWA
    if (config.name) {
      document.title = `${config.name} — Inventario`
    }
    // Asegurar que el favicon siempre utilice el archivo favicon.png actualizado
    const iconLinks = document.querySelectorAll<HTMLLinkElement>('link[rel*="icon"]')
    iconLinks.forEach((link) => {
      link.href = '/favicon.png?v=4'
    })
    set({ config, isLoaded: true })
  },
}))
