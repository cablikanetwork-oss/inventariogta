import { useRef, useState, useCallback } from 'react'
import { BrowserMultiFormatReader, NotFoundException } from '@zxing/library'

interface UseBarcodeScanner {
  isScanning: boolean
  error: string | null
  startScanning: (
    videoRef: React.RefObject<HTMLVideoElement>,
    onResult: (result: string) => void,
    continuous?: boolean
  ) => void
  stopScanning: () => void
}

export function useBarcodeScanner(): UseBarcodeScanner {
  const [isScanning, setIsScanning] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const readerRef = useRef<BrowserMultiFormatReader | null>(null)

  const stopScanning = useCallback(() => {
    if (readerRef.current) {
      readerRef.current.reset()
      readerRef.current = null
    }
    setIsScanning(false)
    setError(null)
  }, [])

  const startScanning = useCallback(
    (
      videoRef: React.RefObject<HTMLVideoElement>,
      onResult: (result: string) => void,
      continuous: boolean = false
    ) => {
      if (!videoRef.current) return

      setError(null)
      const reader = new BrowserMultiFormatReader()
      readerRef.current = reader
      setIsScanning(true)

      reader
        .decodeFromVideoDevice(null, videoRef.current, (result, err) => {
          if (result) {
            onResult(result.getText())
            if (!continuous) {
              stopScanning()
            }
          }
          if (err && !(err instanceof NotFoundException)) {
            // Se ignoran los frames donde aún no se detecta código
          }
        })
        .catch((err) => {
          setError('No se pudo acceder a la cámara. Asegúrate de otorgar permisos.')
          setIsScanning(false)
          console.error(err)
        })
    },
    [stopScanning]
  )

  return { isScanning, error, startScanning, stopScanning }
}
