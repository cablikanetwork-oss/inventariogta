import { useEffect } from 'react'
import { companyApi } from '../api/company'
import { useThemeStore } from '../store/themeStore'

export function useCompanyConfig() {
  const { config, isLoaded, applyTheme } = useThemeStore()

  useEffect(() => {
    if (!isLoaded) {
      companyApi
        .getConfig()
        .then((cfg) => {
          applyTheme(cfg)
        })
        .catch(() => {
          // Defaults locales en caso de desconexión momentánea
          useThemeStore.getState().setConfig({
            id: 'default',
            name: 'InventoryOS Tech',
            logo_url: null,
            primary_color: '#2563EB',
            secondary_color: '#1E40AF',
            accent_color: '#F59E0B',
            updated_at: new Date().toISOString(),
          })
        })
    }
  }, [isLoaded, applyTheme])

  return { config, isLoaded }
}

